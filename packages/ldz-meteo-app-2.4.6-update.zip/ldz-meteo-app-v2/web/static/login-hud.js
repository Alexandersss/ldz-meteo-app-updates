(() => {
  'use strict';

  const q = (selector) => document.querySelector(selector);
  const qa = (selector) => Array.from(document.querySelectorAll(selector));
  const reducedMotion = Boolean(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  const passwordInput = q('#loginPassword');
  const passwordToggle = q('#passwordVisibility');
  if (passwordInput && passwordToggle) {
    passwordToggle.addEventListener('click', () => {
      const show = passwordInput.type === 'password';
      passwordInput.type = show ? 'text' : 'password';
      passwordToggle.setAttribute('aria-pressed', show ? 'true' : 'false');
      passwordToggle.setAttribute('aria-label', show ? 'Nascondi password' : 'Mostra password');
    });
  }

  const connectionText = q('[data-status="connection"]');
  const streamText = q('[data-status="stream"]');
  const engineText = q('[data-status="engine"]');
  const radarAgeText = q('[data-status="radar-age"]');
  const radarTimestamp = q('[data-radar-timestamp]');
  const radarImage = q('#loginRadarImage');
  const connectionModule = q('[data-module="connection"]');
  const streamModule = q('[data-module="stream"]');
  const engineModule = q('[data-module="engine"]');
  const radarFeed = q('[data-feed="radar"]');
  const webguiFeed = q('[data-feed="webgui"]');
  const streamFeed = q('[data-feed="stream"]');

  let radarSource = radarImage?.dataset.primarySrc || '/meteo-map.jpg';
  let radarFallbackUsed = false;

  const setModuleState = (node, state) => {
    if (!node) return;
    node.dataset.state = state;
  };

  const setStatus = (node, text, state = 'ok') => {
    if (!node) return;
    node.textContent = text;
    node.classList.toggle('warn', state === 'warn');
    node.classList.toggle('bad', state === 'bad');
  };

  const setFeed = (node, text, state = 'ok') => {
    if (!node) return;
    node.textContent = text;
    node.style.color = state === 'bad' ? '#ff594e' : state === 'warn' ? '#ffd26b' : '#32f49b';
  };

  const formatAge = (minutes) => {
    if (!Number.isFinite(minutes)) return 'ETÀ N/D';
    if (minutes < 1) return 'AGGIORNATO ORA';
    if (minutes < 60) return `${Math.round(minutes)} MIN FA`;
    const hours = Math.floor(minutes / 60);
    const mins = Math.round(minutes % 60);
    return `${hours}H ${mins}M FA`;
  };

  const formatTimestamp = (date) => date.toLocaleTimeString('it-IT', {
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });

  const probe = async (url) => {
    const response = await fetch(url, {
      method: 'HEAD',
      credentials: 'same-origin',
      cache: 'no-store',
      redirect: 'follow'
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response;
  };

  const refreshConnection = async () => {
    try {
      await probe(window.location.pathname + window.location.search);
      setStatus(connectionText, 'STABILE', 'ok');
      setFeed(webguiFeed, 'ONLINE', 'ok');
      setModuleState(connectionModule, 'ok');
      return true;
    } catch (_error) {
      setStatus(connectionText, 'NON DISPONIBILE', 'bad');
      setFeed(webguiFeed, 'OFFLINE', 'bad');
      setModuleState(connectionModule, 'bad');
      return false;
    }
  };

  const resolveRadarSource = async () => {
    const primary = radarImage?.dataset.primarySrc || '/meteo-map.jpg';
    const fallback = radarImage?.dataset.fallbackSrc || '/meteo.jpg';
    try {
      const response = await probe(primary);
      radarSource = primary;
      radarFallbackUsed = false;
      return response;
    } catch (_error) {
      const response = await probe(fallback);
      radarSource = fallback;
      radarFallbackUsed = true;
      return response;
    }
  };

  const refreshRadar = async () => {
    try {
      const response = await resolveRadarSource();
      const modified = response.headers.get('Last-Modified');
      const modifiedDate = modified ? new Date(modified) : null;
      const ageMinutes = modifiedDate && !Number.isNaN(modifiedDate.getTime())
        ? Math.max(0, (Date.now() - modifiedDate.getTime()) / 60000)
        : NaN;

      let state = 'ok';
      let stream = 'ATTIVO';
      let engine = 'OPERATIVO';
      let feed = 'ONLINE';

      if (!Number.isFinite(ageMinutes)) {
        state = 'warn';
        stream = 'ATTIVO · ETÀ N/D';
        feed = 'ETÀ N/D';
      } else if (ageMinutes > 90) {
        state = 'bad';
        stream = 'NON DISPONIBILE';
        engine = 'DEGRADATO';
        feed = 'DATATO';
      } else if (ageMinutes > 30) {
        state = 'warn';
        stream = 'DATO IN RITARDO';
        engine = 'DEGRADATO';
        feed = 'RITARDO';
      }

      setStatus(streamText, stream, state);
      setStatus(engineText, engine, state);
      setStatus(radarAgeText, formatAge(ageMinutes), state);
      setFeed(radarFeed, feed, state);
      setFeed(streamFeed, state === 'ok' ? 'ATTIVO' : feed, state);
      setModuleState(streamModule, state);
      setModuleState(engineModule, state);

      if (radarTimestamp) {
        radarTimestamp.textContent = modifiedDate && !Number.isNaN(modifiedDate.getTime())
          ? formatTimestamp(modifiedDate)
          : 'ETÀ N/D';
      }

      if (radarImage) {
        radarImage.hidden = false;
        radarImage.src = `${radarSource}?v=${Date.now()}`;
        radarImage.alt = radarFallbackUsed
          ? 'Anteprima del prodotto radar completo'
          : 'Anteprima radar meteorologica';
      }

      if (!reducedMotion) {
        const panel = q('.login-radar-panel');
        panel?.classList.add('radar-refresh-pulse');
        window.setTimeout(() => panel?.classList.remove('radar-refresh-pulse'), 900);
      }
    } catch (_error) {
      setStatus(streamText, 'NON DISPONIBILE', 'bad');
      setStatus(engineText, 'IN ATTESA', 'warn');
      setStatus(radarAgeText, 'RADAR NON DISPONIBILE', 'bad');
      setFeed(radarFeed, 'OFFLINE', 'bad');
      setFeed(streamFeed, 'OFFLINE', 'bad');
      setModuleState(streamModule, 'bad');
      setModuleState(engineModule, 'warn');
      if (radarTimestamp) radarTimestamp.textContent = 'NON DISPONIBILE';
      if (radarImage) radarImage.hidden = true;
    }
  };

  if (radarImage) {
    radarImage.addEventListener('error', () => {
      const fallback = radarImage.dataset.fallbackSrc || '/meteo.jpg';
      if (!radarFallbackUsed && !radarImage.src.includes(fallback)) {
        radarFallbackUsed = true;
        radarSource = fallback;
        radarImage.src = `${fallback}?v=${Date.now()}`;
        return;
      }
      radarImage.hidden = true;
      setStatus(radarAgeText, 'ANTEPRIMA NON DISPONIBILE', 'warn');
    });
    radarImage.addEventListener('load', () => { radarImage.hidden = false; });
  }

  const tickClock = () => {
    qa('[data-live-clock]').forEach((node) => {
      node.textContent = new Date().toLocaleTimeString('it-IT', {
        hour: '2-digit', minute: '2-digit', second: '2-digit'
      });
    });
  };

  tickClock();
  window.setInterval(tickClock, 1000);
  refreshConnection();
  refreshRadar();
  window.setInterval(refreshConnection, 15000);
  window.setInterval(refreshRadar, 60000);
})();
