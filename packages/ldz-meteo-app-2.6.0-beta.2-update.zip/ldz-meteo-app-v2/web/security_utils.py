#!/usr/bin/env python3
"""Security primitives shared by the LDZ WebGUI and privileged helpers.

The privileged shell helpers execute this root-owned module from the installed
WebGUI.  Update packages are authenticated separately with an Ed25519 detached
signature; this module then enforces archive structure, size and hash policy.
"""

from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any


UPDATE_MAX_COMPRESSED = 80 * 1024 * 1024
UPDATE_MAX_UNCOMPRESSED = 250 * 1024 * 1024
UPDATE_MAX_MEMBER = 64 * 1024 * 1024
UPDATE_MAX_ENTRIES = 600
BACKUP_MAX_COMPRESSED = 8 * 1024 * 1024
BACKUP_MAX_UNCOMPRESSED = 16 * 1024 * 1024
BACKUP_MAX_MEMBER = 8 * 1024 * 1024
BACKUP_MAX_ENTRIES = 10
MAX_COMPRESSION_RATIO = 200

UPDATE_TOP_LEVEL = {
    ".gitignore",
    "CHANGELOG.md",
    "FEATURES_LOCK.md",
    "README.md",
    "SCIENTIFIC_METHODS_2.6.0-beta.1.md",
    "SECURITY.md",
    "SECURITY_REPORT.md",
    "SOURCE_PACKAGE.md",
    "TESTED.md",
    "apache",
    "apply_hotfix.sh",
    "dist",
    "engine",
    "install.sh",
    "manifest.json",
    "scripts",
    "security",
    "tests",
    "web",
}
BACKUP_ALLOWED_FILES = {
    "manifest.json",
    "etc/meteo-alert/config.yml",
    "etc/meteo-alert/secrets.env",
}
UPDATE_REQUIRED_ANY = {
    "web/app.py",
    "engine/meteo_alert.py",
}
UPDATE_REQUIRED_EXACT = {
    "manifest.json",
    "web/security_utils.py",
    "engine/precision_engine.py",
    "engine/verification_engine.py",
    "engine/terrain_lifecycle.py",
    "engine/adaptive_ai.py",
    "engine/adaptive_ai_trainer.py",
    "engine/event_feedback.py",
    "engine/telegram_feedback_listener.py",
    "engine/hail_feedback.py",
    "engine/radar_wss_listener.py",
    "scripts/ldz-meteo-apply-hotfix",
    "scripts/ldz-meteo-update-check",
    "scripts/ldz-meteo-approve-update",
    "scripts/ldz-meteo-watchdog",
}
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
VERSION_RE = re.compile(r"^\d+\.\d+\.\d+(?:[-+][A-Za-z0-9._-]+)?$")


class ArchivePolicyError(ValueError):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_member_name(name: str) -> str:
    if not name or "\\" in name or "\x00" in name:
        raise ArchivePolicyError(f"nome ZIP non sicuro: {name!r}")
    if any(ord(char) < 32 or ord(char) == 127 for char in name):
        raise ArchivePolicyError(f"caratteri di controllo nel nome ZIP: {name!r}")
    path = PurePosixPath(name)
    if path.is_absolute() or not path.parts or any(part in {"", ".", ".."} for part in path.parts):
        raise ArchivePolicyError(f"percorso ZIP non sicuro: {name!r}")
    if ":" in path.parts[0]:
        raise ArchivePolicyError(f"percorso ZIP con drive non consentito: {name!r}")
    return path.as_posix()


def _reject_special_member(info: zipfile.ZipInfo) -> None:
    if info.flag_bits & 0x1:
        raise ArchivePolicyError(f"file ZIP cifrato non consentito: {info.filename}")
    unix_type = (info.external_attr >> 16) & 0o170000
    if unix_type and unix_type not in {stat.S_IFREG, stat.S_IFDIR}:
        raise ArchivePolicyError(f"tipo file ZIP speciale non consentito: {info.filename}")


def _detect_root_prefix(file_names: list[str]) -> str:
    if not file_names:
        return ""
    first = [PurePosixPath(name).parts[0] for name in file_names]
    if len(set(first)) != 1 or not all(len(PurePosixPath(name).parts) > 1 for name in file_names):
        return ""
    prefix = first[0] + "/"
    stripped = [name[len(prefix) :] for name in file_names]
    return prefix if "manifest.json" in stripped else ""


def _read_manifest(archive: zipfile.ZipFile, real_name: str) -> dict[str, Any]:
    try:
        raw = archive.read(real_name)
        if len(raw) > 1024 * 1024:
            raise ArchivePolicyError("manifest.json supera 1 MiB")
        manifest = json.loads(raw.decode("utf-8"))
    except ArchivePolicyError:
        raise
    except Exception as exc:
        raise ArchivePolicyError(f"manifest.json non valido: {exc}") from exc
    if not isinstance(manifest, dict):
        raise ArchivePolicyError("manifest.json deve contenere un oggetto JSON")
    return manifest


def validate_archive(path: Path, kind: str) -> dict[str, Any]:
    path = Path(path)
    if kind not in {"update", "backup"}:
        raise ArchivePolicyError(f"policy archivio sconosciuta: {kind}")
    if not path.is_file() or path.is_symlink():
        raise ArchivePolicyError("archivio assente, non regolare o symlink")

    max_compressed = UPDATE_MAX_COMPRESSED if kind == "update" else BACKUP_MAX_COMPRESSED
    max_uncompressed = UPDATE_MAX_UNCOMPRESSED if kind == "update" else BACKUP_MAX_UNCOMPRESSED
    max_member = UPDATE_MAX_MEMBER if kind == "update" else BACKUP_MAX_MEMBER
    max_entries = UPDATE_MAX_ENTRIES if kind == "update" else BACKUP_MAX_ENTRIES
    size = path.stat().st_size
    if size < 64 or size > max_compressed:
        raise ArchivePolicyError(f"dimensione archivio non consentita: {size} byte")

    try:
        archive = zipfile.ZipFile(path)
    except zipfile.BadZipFile as exc:
        raise ArchivePolicyError("file ZIP non valido") from exc

    with archive:
        infos = archive.infolist()
        if not infos or len(infos) > max_entries:
            raise ArchivePolicyError(f"numero entry ZIP non consentito: {len(infos)}")

        seen: set[str] = set()
        file_infos: list[tuple[str, zipfile.ZipInfo]] = []
        total_uncompressed = 0
        for info in infos:
            _reject_special_member(info)
            name = _safe_member_name(info.filename.rstrip("/") if info.is_dir() else info.filename)
            canonical = name.casefold()
            if canonical in seen:
                raise ArchivePolicyError(f"entry ZIP duplicata/case-collision: {info.filename}")
            seen.add(canonical)
            if info.is_dir():
                continue
            if info.file_size > max_member:
                raise ArchivePolicyError(f"file ZIP troppo grande: {info.filename}")
            if info.file_size and info.file_size / max(1, info.compress_size) > MAX_COMPRESSION_RATIO:
                raise ArchivePolicyError(f"rapporto di compressione sospetto: {info.filename}")
            total_uncompressed += info.file_size
            if total_uncompressed > max_uncompressed:
                raise ArchivePolicyError("contenuto ZIP espanso oltre il limite")
            file_infos.append((name, info))

        file_names = [name for name, _ in file_infos]
        prefix = _detect_root_prefix(file_names)
        logical: dict[str, zipfile.ZipInfo] = {}
        for real_name, info in file_infos:
            name = real_name[len(prefix) :] if prefix else real_name
            if not name:
                continue
            if name.casefold() in {item.casefold() for item in logical}:
                raise ArchivePolicyError(f"nome logico ZIP duplicato: {name}")
            logical[name] = info

        if "manifest.json" not in logical:
            raise ArchivePolicyError("manifest.json obbligatorio")
        manifest = _read_manifest(archive, logical["manifest.json"].filename)
        if manifest.get("app") != "LDZ Meteo App":
            raise ArchivePolicyError("manifest non appartenente a LDZ Meteo App")
        if int(manifest.get("schema_version", 0) or 0) != 2:
            raise ArchivePolicyError("schema manifest non supportato: richiesto schema_version=2")

        version = str(manifest.get("version", "")).strip()
        if not VERSION_RE.fullmatch(version):
            raise ArchivePolicyError("versione manifest assente o non valida")
        if kind == "update":
            if manifest.get("type") not in {"full-source-and-installable-hotfix", "signed-update"}:
                raise ArchivePolicyError("tipo manifest update non consentito")
            top_levels = {PurePosixPath(name).parts[0] for name in logical}
            unexpected = sorted(top_levels - UPDATE_TOP_LEVEL)
            if unexpected:
                raise ArchivePolicyError(f"top-level update non consentiti: {', '.join(unexpected)}")
            missing = sorted(UPDATE_REQUIRED_EXACT - set(logical))
            if missing:
                raise ArchivePolicyError(f"file update obbligatori mancanti: {', '.join(missing)}")
            if not (UPDATE_REQUIRED_ANY & set(logical)):
                raise ArchivePolicyError("update privo di WebGUI ed engine")
        else:
            unexpected = sorted(set(logical) - BACKUP_ALLOWED_FILES)
            if unexpected:
                raise ArchivePolicyError(f"file backup non consentiti: {', '.join(unexpected)}")
            if "etc/meteo-alert/config.yml" not in logical:
                raise ArchivePolicyError("config.yml obbligatorio nel backup")
            if manifest.get("type") != "configuration-backup":
                raise ArchivePolicyError("tipo manifest backup non consentito")

        hashes = manifest.get("files")
        if not isinstance(hashes, dict):
            raise ArchivePolicyError("manifest.files deve essere una mappa SHA-256")
        payload_names = set(logical) - {"manifest.json"}
        if set(hashes) != payload_names:
            missing = sorted(payload_names - set(hashes))
            extra = sorted(set(hashes) - payload_names)
            raise ArchivePolicyError(f"mappa hash incompleta (mancanti={missing}, extra={extra})")
        for logical_name in sorted(payload_names):
            expected = str(hashes[logical_name]).lower()
            if not SHA256_RE.fullmatch(expected):
                raise ArchivePolicyError(f"SHA-256 non valido per {logical_name}")
            digest = hashlib.sha256()
            with archive.open(logical[logical_name], "r") as source:
                for chunk in iter(lambda: source.read(1024 * 1024), b""):
                    digest.update(chunk)
            if not hmac.compare_digest(digest.hexdigest(), expected):
                raise ArchivePolicyError(f"SHA-256 non corrispondente per {logical_name}")

        corrupt = archive.testzip()
        if corrupt:
            raise ArchivePolicyError(f"CRC ZIP non valido: {corrupt}")
        return {
            "ok": True,
            "kind": kind,
            "version": version,
            "manifest": manifest,
            "root_dir": prefix.rstrip("/"),
            "files": sorted(logical),
            "file_count": len(logical),
            "compressed_bytes": size,
            "uncompressed_bytes": total_uncompressed,
            "sha256": sha256_file(path),
        }


def verify_update_signature(zip_path: Path, signature_path: Path, public_key_path: Path) -> tuple[bool, str]:
    zip_path = Path(zip_path)
    signature_path = Path(signature_path)
    public_key_path = Path(public_key_path)
    if not public_key_path.is_file() or public_key_path.is_symlink():
        return False, "chiave pubblica update assente o non valida"
    if not signature_path.is_file() or signature_path.is_symlink():
        return False, "firma detached .sig assente o non valida"
    if signature_path.stat().st_size != 64:
        return False, "firma Ed25519 con dimensione non valida"
    command = [
        "/usr/bin/openssl",
        "pkeyutl",
        "-verify",
        "-pubin",
        "-inkey",
        str(public_key_path),
        "-rawin",
        "-in",
        str(zip_path),
        "-sigfile",
        str(signature_path),
    ]
    try:
        completed = subprocess.run(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=30,
            check=False,
            env={"PATH": "/usr/bin:/bin", "LANG": "C"},
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, f"verifica firma non eseguibile: {exc}"
    if completed.returncode != 0:
        return False, "firma Ed25519 non valida"
    return True, "firma Ed25519 valida"


def safe_extract(path: Path, destination: Path, kind: str) -> dict[str, Any]:
    result = validate_archive(path, kind)
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    destination_real = destination.resolve()
    prefix = result["root_dir"] + "/" if result["root_dir"] else ""
    wanted = set(result["files"])
    with zipfile.ZipFile(path) as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            real_name = _safe_member_name(info.filename)
            logical_name = real_name[len(prefix) :] if prefix and real_name.startswith(prefix) else real_name
            if logical_name not in wanted:
                continue
            target = destination / logical_name
            target_real = target.resolve(strict=False)
            if os.path.commonpath([str(destination_real), str(target_real)]) != str(destination_real):
                raise ArchivePolicyError(f"estrazione fuori staging bloccata: {logical_name}")
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info, "r") as source, target.open("wb") as output:
                shutil.copyfileobj(source, output, length=1024 * 1024)
            source_mode = (info.external_attr >> 16) & 0o777
            target.chmod(0o755 if source_mode & 0o111 else 0o644)
    return result


def _cli() -> int:
    parser = argparse.ArgumentParser(description="LDZ Meteo archive security policy")
    sub = parser.add_subparsers(dest="command", required=True)
    for command in ("verify-update", "verify-backup"):
        item = sub.add_parser(command)
        item.add_argument("archive")
    verify_signature = sub.add_parser("verify-signature")
    verify_signature.add_argument("archive")
    verify_signature.add_argument("signature")
    verify_signature.add_argument("public_key")
    for command in ("extract-update", "extract-backup"):
        item = sub.add_parser(command)
        item.add_argument("archive")
        item.add_argument("destination")
    args = parser.parse_args()
    try:
        if args.command == "verify-signature":
            valid, message = verify_update_signature(Path(args.archive), Path(args.signature), Path(args.public_key))
            print(json.dumps({"ok": valid, "message": message}, ensure_ascii=False))
            return 0 if valid else 1
        kind = "update" if args.command.endswith("update") else "backup"
        if args.command.startswith("extract"):
            result = safe_extract(Path(args.archive), Path(args.destination), kind)
        else:
            result = validate_archive(Path(args.archive), kind)
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        return 0
    except (ArchivePolicyError, OSError, zipfile.BadZipFile) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(_cli())
