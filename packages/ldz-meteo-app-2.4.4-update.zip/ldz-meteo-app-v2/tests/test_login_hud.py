from __future__ import annotations

import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEMPLATE = ROOT / "web/templates/login.html"
CSS = ROOT / "web/static/login-hud.css"
JS = ROOT / "web/static/login-hud.js"
APP = ROOT / "web/app.py"


class FuturisticLoginStaticTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.template = TEMPLATE.read_text(encoding="utf-8")
        cls.css = CSS.read_text(encoding="utf-8")
        cls.js = JS.read_text(encoding="utf-8")
        cls.app = APP.read_text(encoding="utf-8")

    def test_login_keeps_security_and_auth_contract(self) -> None:
        for token in (
            "{{ csrf_field()|safe }}",
            'name="username"',
            'name="password"',
            'name="remember_me"',
            'autocomplete="username"',
            'autocomplete="current-password"',
        ):
            self.assertIn(token, self.template)
        for token in (
            "login_is_limited(rate_key)",
            "check_password_hash(password_hash, password)",
            "make_remember_token(username)",
            "validate_csrf_token()",
            "origin_is_allowed()",
        ):
            self.assertIn(token, self.app)

    def test_login_has_no_roleplay_copy(self) -> None:
        lowered = self.template.lower()
        for phrase in (
            "bentornato comandante",
            "missione iniziata",
            "capitano",
            "comandante",
        ):
            self.assertNotIn(phrase, lowered)

    def test_login_copy_and_feature_cards_are_application_specific(self) -> None:
        for token in (
            "Il tuo centro<br>meteo <span>privato.</span>",
            "RADAR LIVE",
            "TARGET SMART",
            "ALERT TELEGRAM",
            "FULMINI &amp; GRANDINE",
            "Traiettoria, distanza, velocità ed ETA delle celle",
            "feedback reale e notifiche mirate",
        ):
            self.assertIn(token, self.template)

    def test_login_is_real_dom_not_approved_concept_as_background(self) -> None:
        for token in (
            'class="login-radar-panel"',
            'class="login-auth-panel"',
            'class="login-status-strip"',
            'class="login-feature-grid"',
        ):
            self.assertIn(token, self.template)
        self.assertNotRegex(self.css.lower(), r"url\([^)]*(?:concept|approved|mockup|screenshot)[^)]*\)")

    def test_public_status_does_not_fake_target_or_cell_counts(self) -> None:
        self.assertIn("MONITORAGGIO TARGET", self.template.upper())
        self.assertIn("TRACKING CELLE", self.template.upper())
        protected = re.findall(r"STATO PROTETTO", self.template.upper())
        self.assertGreaterEqual(len(protected), 2)
        self.assertNotRegex(self.template, r">\s*[1-9][0-9]*\s+(?:TARGET|CELLE)\s+ATTIV")

    def test_public_dynamic_checks_are_limited_to_safe_resources(self) -> None:
        self.assertIn("method: 'HEAD'", self.js)
        self.assertIn("/meteo.jpg", self.js)
        self.assertIn("Last-Modified", self.js)
        self.assertNotIn("/diagnostics", self.js)
        self.assertNotIn("/system", self.js)
        self.assertNotIn("/events-feedback", self.js)
        for forbidden in ("systemctl", "hostname", "filesystem", "TELEGRAM_BOT_TOKEN", "LDZ_METEO_WEB_SECRET_KEY"):
            self.assertNotIn(forbidden, self.js)

    def test_dynamic_stream_has_fresh_degraded_and_unavailable_states(self) -> None:
        for token in (
            "ATTIVO",
            "DATO IN RITARDO",
            "STREAM NON DISPONIBILE",
            "OPERATIVO",
            "DEGRADATO",
            "IN ATTESA",
        ):
            self.assertIn(token, self.js)

    def test_visual_motion_and_reduced_motion_are_both_supported(self) -> None:
        for token in (
            "login-radar-spin",
            "login-blip",
            "login-wave",
            "login-eq",
            "prefers-reduced-motion: reduce",
        ):
            self.assertIn(token, self.css)

    def test_login_assets_are_local_and_csp_friendly(self) -> None:
        self.assertIn("login-hud.css", self.template)
        self.assertIn("login-hud.js", self.template)
        self.assertNotIn("fonts.googleapis.com", self.template)
        self.assertNotIn("cdnjs", self.template)
        self.assertNotIn("unpkg.com", self.template)
        self.assertNotIn("https://", self.css)
        self.assertNotIn("@import", self.css)
        # No inline executable script is needed by the redesigned login.
        self.assertNotRegex(self.template, r"<script(?![^>]*\bsrc=)[^>]*>")

    def test_responsive_and_accessibility_hooks_exist(self) -> None:
        for breakpoint in ("1420px", "1120px", "860px", "560px"):
            self.assertIn(breakpoint, self.css)
        for token in (
            'aria-label="Accesso LDZ Meteo App"',
            'aria-live="polite"',
            'for="loginUsername"',
            'for="loginPassword"',
            'aria-pressed="false"',
        ):
            self.assertIn(token, self.template)


if __name__ == "__main__":
    unittest.main()
