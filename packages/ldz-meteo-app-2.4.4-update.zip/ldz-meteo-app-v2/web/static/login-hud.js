(() => {
  'use strict';

  const q = (selector) => document.querySelector(selector);
  const qa = (selector) => Array.from(document.querySelectorAll(selector));
  const reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const passwordInput = q('#loginPassword');
  const passwordToggle = q('#passwordVisibility');
  if (passwordInput && passwordToggle) {
    passwordToggle.addEventListener('click', () => {
      const show = passwordInput.type === 'password';
      passwordInput.type = show ? 'text' : 'password';
      passwordToggle.setAttribute('aria-pressed', show ? 'true' : 'false');
      passwordToggle.setAttribute('aria-label', show ? 'Nascondi password' : 'Mostra password');
    });
  }

  const connectionText = q('[data-status="connection"]');
  const streamText = q('[data-status="stream"]');
  const engineText = q('[data-status="engine"]');
  const radarAgeText = q('[data-status="radar-age"]');
  const radarTimestamp = q('[data-radar-timestamp]');
  const radarImage = q('#loginRadarImage');
  const connectionModule = q('[data-module="connection"]');
  const streamModule = q('[data-module="stream"]');
  const engineModule = q('[data-module="engine"]');

  const setModuleState = (node, state) => {
    if (!node) return;
    node.dataset.state = state;
  };

  const setStatus = (node, text, state = 'ok') => {
    if (!node) return;
    node.textContent = text;
    node.classList.toggle('warn', state === 'warn');
    node.classList.toggle('bad', state === 'bad');
  };

  const formatAge = (minutes) => {
    if (!Number.isFinite(minutes)) return 'NON DISPONIBILE';
    if (minutes < 1) return 'AGGIORNATO ORA';
    if (minutes < 60) return `AGGIORNATO ${Math.round(minutes)} MIN FA`;
    const hours = Math.floor(minutes / 60);
    const mins = Math.round(minutes % 60);
    return `AGGIORNATO ${hours}H ${mins}M FA`;
  };

  const refreshConnection = async () => {
    try {
      const response = await fetch(window.location.pathname + window.location.search, {
        method: 'HEAD',
        credentials: 'same-origin',
        cache: 'no-store',
        redirect: 'follow'
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      setStatus(connectionText, 'STABILE', 'ok');
      setModuleState(connectionModule, 'ok');
      return true;
    } catch (_error) {
      setStatus(connectionText, 'NON DISPONIBILE', 'bad');
      setModuleState(connectionModule, 'bad');
      return false;
    }
  };

  const refreshRadar = async () => {
    try {
      const response = await fetch('/meteo.jpg', {
        method: 'HEAD',
        cache: 'no-store',
        credentials: 'same-origin'
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const modified = response.headers.get('Last-Modified');
      const modifiedDate = modified ? new Date(modified) : null;
      const ageMinutes = modifiedDate && !Number.isNaN(modifiedDate.getTime())
        ? Math.max(0, (Date.now() - modifiedDate.getTime()) / 60000)
        : NaN;

      let state = 'ok';
      let stream = 'ATTIVO';
      let engine = 'OPERATIVO';
      if (!Number.isFinite(ageMinutes)) {
        state = 'warn';
        stream = 'ATTIVO · ETÀ N/D';
      } else if (ageMinutes > 90) {
        state = 'bad';
        stream = 'STREAM NON DISPONIBILE';
        engine = 'DEGRADATO';
      } else if (ageMinutes > 30) {
        state = 'warn';
        stream = 'DATO IN RITARDO';
        engine = 'DEGRADATO';
      }

      setStatus(streamText, stream, state);
      setStatus(engineText, engine, state === 'bad' ? 'bad' : state);
      setStatus(radarAgeText, formatAge(ageMinutes), state);
      setModuleState(streamModule, state);
      setModuleState(engineModule, state);

      if (radarTimestamp && modifiedDate && !Number.isNaN(modifiedDate.getTime())) {
        radarTimestamp.textContent = modifiedDate.toLocaleTimeString('it-IT', {
          hour: '2-digit', minute: '2-digit', second: '2-digit'
        });
      }

      if (radarImage) {
        const currentBase = radarImage.dataset.src || '/meteo.jpg';
        radarImage.src = `${currentBase}?v=${Date.now()}`;
      }

      if (!reducedMotion) {
        q('.login-radar-panel')?.classList.add('radar-refresh-pulse');
        window.setTimeout(() => q('.login-radar-panel')?.classList.remove('radar-refresh-pulse'), 900);
      }
    } catch (_error) {
      setStatus(streamText, 'STREAM NON DISPONIBILE', 'bad');
      setStatus(engineText, 'IN ATTESA', 'warn');
      setStatus(radarAgeText, 'RADAR NON DISPONIBILE', 'bad');
      setModuleState(streamModule, 'bad');
      setModuleState(engineModule, 'warn');
      if (radarImage) radarImage.hidden = true;
    }
  };

  if (radarImage) {
    radarImage.addEventListener('error', () => {
      radarImage.hidden = true;
      setStatus(radarAgeText, 'ANTEPRIMA NON DISPONIBILE', 'warn');
    });
    radarImage.addEventListener('load', () => {
      radarImage.hidden = false;
    });
  }

  const tickClock = () => {
    qa('[data-live-clock]').forEach((node) => {
      node.textContent = new Date().toLocaleTimeString('it-IT', {
        hour: '2-digit', minute: '2-digit', second: '2-digit'
      });
    });
  };

  tickClock();
  window.setInterval(tickClock, 1000);
  refreshConnection();
  refreshRadar();
  window.setInterval(refreshConnection, 15000);
  window.setInterval(refreshRadar, 60000);
})();
