from __future__ import annotations

import unittest
from unittest.mock import patch

from tests.test_alert_messages import load_message_module


class StableImpactAndHailTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.ma = load_message_module()

    def cfg(self) -> dict:
        return {
            "thresholds": {
                "vmi_strong_dbz": 45,
                "vmi_core_dbz": 55,
                "vmi_hail_dbz": 55,
                "poh_medium_percent": 40,
                "poh_high_percent": 60,
                "vil_hail_threshold": 35,
                "etm_hail_threshold_m": 9000,
            },
            "tracking": {
                "prealert_minutes": 20,
                "strong_alert_vmi_dbz": 45,
                "min_alert_probability_percent": 60,
                "clear_probability_percent": 35,
                "require_consecutive_hits": 2,
                "clear_consecutive_misses": 2,
                "max_gap_minutes": 18,
                "alert_cooldown_minutes": 35,
                "clear_cooldown_minutes": 30,
                "update_cooldown_minutes": 12,
                "threat_memory_minutes": 120,
            },
            "multisignal": {
                "enabled": True,
                "hail_min_score_medium": 35,
                "hail_min_score_high": 65,
                "hail_min_poh_for_high": 35,
                "hail_min_persistence_frames": 2,
                "hail_high_min_data_quality": 65,
            },
            "lightning": {"enabled": False},
            "vertical_profile": {
                "enabled": True,
                "minimum_coverage": 0.5,
                "max_hail_adjustment_points": 12,
                "max_negative_adjustment_points": 6,
                "neutral_score": 0.35,
                "minimum_high_support_percent": 22,
            },
            "quiet_hours": {"enabled": False},
            "telegram": {},
            "notifications": {},
        }

    def cell(self, cell_id: str, timestamp_ms: int, **overrides):
        values = {
            "cell_id": cell_id,
            "timestamp_ms": timestamp_ms,
            "lat": 42.46,
            "lon": 14.10,
            "area_km2": 70.0,
            "radius_km": 5.0,
            "pixels": 120,
            "max_vmi": 59.0,
            "mean_vmi": 48.0,
            "max_sri": 40.0,
            "max_poh": 70.0,
            "max_vil": 55.0,
            "max_etm": 13000.0,
            "risk": "HIGH",
            "risk_reasons": [],
            "nearest_target": "Pescara",
            "nearest_distance_km": 9.0,
            "footprint_xy_km": [],
            "pixel_bbox": [0, 10, 0, 10],
            "centroid_row": 5.0,
            "centroid_col": 5.0,
            "shape_eccentricity": 0.5,
            "shape_orientation_deg": 90.0,
            "min_ir108": -65.0,
            "track_id": "trk-hail",
            "track_frames": 3,
            "lifecycle": "continuing",
        }
        values.update(overrides)
        return self.ma.Cell(**values)

    def test_hail_fusion_requires_quality_and_multiframe_persistence_for_high(self) -> None:
        cell = self.cell("hail-3", 2_000_600_000)
        observations = [
            {
                "timestamp_ms": 2_000_000_000 + index * 300_000,
                "max_vmi": 56.0 + index,
                "max_poh": 62.0 + index * 4,
                "max_vil": 48.0 + index * 3,
                "max_etm": 11800.0 + index * 600,
            }
            for index in range(3)
        ]
        state = {"precision": {"tracks": {"trk-hail": {"observations": observations}}}}
        eta = {
            "impact_probability_percent": 82.0,
            "trajectory_probability_percent": 82.0,
            "impact_confidence_percent": 80.0,
            "freezing_level_m": 3900.0,
            "closing_kmh": 45.0,
            "eta_minutes": 8.0,
            "exact_intersection": 1.0,
            "lifecycle": {"vmi_trend_dbz_min": 0.8, "vil_trend_min": 1.2},
            "lightning_jump": {"jump_score": 55.0},
        }
        result = self.ma.build_multisignal_context(
            self.ma.Target("Pescara", 42.46, 14.21, 3.0),
            cell,
            eta,
            self.cfg(),
            state=state,
        )
        self.assertEqual(result["hail_level"], "ALTO")
        self.assertGreaterEqual(result["hail_probability_percent"], 65.0)
        self.assertGreaterEqual(result["hail_data_quality_percent"], 65.0)
        self.assertEqual(result["hail_persistence_frames"], 3)
        self.assertGreater(result["scores"]["vil_density"], 80.0)

    def test_cappi_vertical_profile_actively_changes_hail_fusion(self) -> None:
        eta = {
            "impact_probability_percent": 78.0,
            "trajectory_probability_percent": 78.0,
            "impact_confidence_percent": 80.0,
            "freezing_level_m": 3500.0,
            "closing_kmh": 42.0,
            "eta_minutes": 7.0,
            "exact_intersection": 1.0,
        }
        base = self.cell(
            "hail-base",
            2_000_600_000,
            max_poh=48.0,
            max_vmi=57.0,
            max_vil=42.0,
            max_etm=11000.0,
        )
        strong = self.cell(
            "hail-cappi",
            2_000_600_000,
            max_poh=48.0,
            max_vmi=57.0,
            max_vil=42.0,
            max_etm=11000.0,
            cappi_profile_dbz={str(level): 58.0 if level <= 8 else 46.0 for level in range(1, 11)},
            cappi_available_levels=10,
            cappi_highest_45_km=10.0,
            cappi_highest_50_km=8.0,
            cappi_highest_55_km=8.0,
            cappi_quality_percent=100.0,
        )
        weak = self.cell(
            "hail-cappi-weak",
            2_000_600_000,
            max_poh=48.0,
            max_vmi=57.0,
            max_vil=42.0,
            max_etm=11000.0,
            cappi_profile_dbz={str(level): 46.0 if level <= 3 else 30.0 for level in range(1, 11)},
            cappi_available_levels=10,
            cappi_highest_45_km=3.0,
            cappi_highest_50_km=None,
            cappi_highest_55_km=None,
            cappi_quality_percent=100.0,
        )
        target = self.ma.Target("Pescara", 42.46, 14.21, 3.0)
        base_result = self.ma.build_multisignal_context(target, base, eta, self.cfg())
        strong_result = self.ma.build_multisignal_context(target, strong, eta, self.cfg())
        weak_result = self.ma.build_multisignal_context(target, weak, eta, self.cfg())
        self.assertGreater(strong_result["hail_probability_percent"], base_result["hail_probability_percent"])
        self.assertLess(weak_result["hail_probability_percent"], base_result["hail_probability_percent"])
        self.assertEqual(strong_result["cappi_vertical"]["label"], "forte supporto verticale alla grandine")
        self.assertTrue(strong_result["cappi_vertical"]["available"])

    def test_telegram_exposes_active_cappi_evidence(self) -> None:
        cell = self.cell("hail-cappi-message", 2_000_600_000)
        eta = {
            "eta_minutes": 7.0,
            "eta_low_minutes": 5.0,
            "eta_high_minutes": 9.0,
            "impact_probability_percent": 76.0,
            "impact_confidence_percent": 82.0,
            "motion_confidence_percent": 84.0,
            "direction_cardinal": "E",
            "speed_kmh": 42.0,
            "cappi_vertical": {
                "available": True,
                "label": "profilo compatibile con grandine",
                "detail": "eco 45 dBZ fino a 7 km, 3.2 km sopra lo zero termico",
            },
        }
        message = self.ma.build_alert_message(
            self.ma.Target("Pescara", 42.46, 14.21, 3.0),
            cell,
            eta,
            self.cfg(),
        )
        self.assertIn("Profilo verticale radar", message)
        self.assertIn("profilo compatibile con grandine", message)
        self.assertLessEqual(len(message), 1000)

    def test_urgent_forecast_still_needs_two_frames_without_observed_core(self) -> None:
        cfg = self.cfg()
        state: dict = {}
        target = self.ma.Target("Pescara", 42.46, 14.21, 3.0)
        first = self.cell("urgent-1", 3_000_000_000, max_poh=10.0, max_vil=20.0, max_sri=5.0)
        forecast = {
            "eta_minutes": 3.0,
            "eta_low_minutes": 2.0,
            "eta_high_minutes": 5.0,
            "impact_probability_percent": 90.0,
            "trajectory_probability_percent": 90.0,
            "impact_confidence_percent": 80.0,
            "motion_confidence_percent": 80.0,
            "speed_kmh": 50.0,
            "closing_kmh": 45.0,
            "mode": "approaching",
            "model": "stable-impact-ensemble",
        }
        with (
            patch.object(self.ma, "send_telegram", return_value=True) as send,
            patch.object(self.ma, "write_alert_log", return_value=None),
        ):
            sent = self.ma.evaluate_alerts(
                [first],
                state,
                [target],
                cfg,
                dry_run=False,
                precision_forecasts={f"{first.cell_id}|Pescara": forecast},
                frame_timestamp_ms=first.timestamp_ms,
            )
            self.assertEqual(sent, [])
            send.assert_not_called()

            second = self.cell("urgent-2", first.timestamp_ms + 300_000, max_poh=10.0, max_vil=20.0, max_sri=5.0)
            sent = self.ma.evaluate_alerts(
                [second],
                state,
                [target],
                cfg,
                dry_run=False,
                precision_forecasts={f"{second.cell_id}|Pescara": forecast},
                frame_timestamp_ms=second.timestamp_ms,
            )
            self.assertEqual(len(sent), 1)
            send.assert_called_once()

    def test_near_target_observed_rain_bypasses_uncertain_trajectory_delay(self) -> None:
        cfg = self.cfg()
        state: dict = {}
        target = self.ma.Target("Pescara", 42.46, 14.21, 3.0)
        cell = self.cell("near-rain", 3_100_000_000, max_sri=40.0, max_poh=8.0, max_vil=16.0)
        forecast = {
            "eta_minutes": 18.0, "eta_low_minutes": 12.0, "eta_high_minutes": 25.0,
            "impact_probability_percent": 10.0, "trajectory_probability_percent": 10.0,
            "impact_confidence_percent": 30.0, "motion_confidence_percent": 25.0,
            "speed_kmh": 15.0, "closing_kmh": -5.0, "mode": "moving_away",
            "model": "stable-impact-ensemble",
        }
        with (
            patch.object(self.ma, "send_telegram", return_value=True) as send,
            patch.object(self.ma, "write_alert_log", return_value=None),
        ):
            sent = self.ma.evaluate_alerts(
                [cell], state, [target], cfg, dry_run=False,
                precision_forecasts={f"{cell.cell_id}|Pescara": forecast},
                frame_timestamp_ms=cell.timestamp_ms,
            )
        self.assertEqual(len(sent), 1)
        self.assertTrue(sent[0]["eta"]["near_target_override"]["active"])
        self.assertGreaterEqual(sent[0]["probability"], 68.0)
        send.assert_called_once()

    def test_clear_notification_requires_two_negative_frames(self) -> None:
        cfg = self.cfg()
        target = self.ma.Target("Pescara", 42.46, 14.21, 3.0)
        state = {
            "target_threats": {
                "Pescara": {
                    "active": True,
                    "last_seen_ms": int(self.ma.utc_now().timestamp() * 1000),
                    "last_probability_percent": 88.0,
                    "last_eta_minutes": 5.0,
                    "last_cell_id": "old",
                    "last_vmi": 55.0,
                    "last_risk": "HIGH",
                }
            }
        }
        with (
            patch.object(self.ma, "send_telegram", return_value=True) as send,
            patch.object(self.ma, "write_alert_log", return_value=None),
        ):
            first = self.ma.evaluate_alerts(
                [],
                state,
                [target],
                cfg,
                dry_run=False,
                frame_timestamp_ms=4_000_000_000,
            )
            self.assertEqual(first, [])
            send.assert_not_called()
            second = self.ma.evaluate_alerts(
                [],
                state,
                [target],
                cfg,
                dry_run=False,
                frame_timestamp_ms=4_000_300_000,
            )
            self.assertEqual(len(second), 1)
            send.assert_called_once()


if __name__ == "__main__":
    unittest.main(verbosity=2)
