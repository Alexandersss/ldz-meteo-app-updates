# LDZ Meteo App - Changelog 1.0 → 2.5.1

## 2.5.1 · Management Completion

- Completati filtri per data e tipo evento, paginazione e aggiornamento live di Storico, Log ed Eventi & feedback.
- Backup e restore mostrano avanzamento reale, creano una copia pre-ripristino verificata e registrano esito e rollback.
- Eliminazione backup con conferma esplicita; azioni Sistema, dry-run e test restituiscono stato asincrono comprensibile.
- Anteprime Template realmente distinte per Telegram, e-mail e webhook; test canali con esito persistente e sanitizzato.
- Diagnostica feedback arricchita con stato listener, coda, API Telegram e ultimo callback ricevuto.
- Kiosk collegato ai dati operativi di target, rischio, traiettoria, ETA, qualità e avvisi, con fullscreen e fallback reduced-motion.
- Rimossa l'identità modello legata alla vecchia release `2.4.0`; aggiunti test funzionali di restore/rollback e scheduler CET/CEST.
- Validazione locale completa: 148 test superati; i controlli su provider e systemd reali vengono completati sull'installazione autorizzata dall'amministratore.

## 2.5.0 · Management & Operations Overhaul

- Rifatte le sezioni Backup, Manutenzione, Sistema, Template, Canali, Storico, Log, Eventi & feedback, Diagnostica e Kiosk con dati, stati e azioni reali.
- Backup schedulati in `Europe/Rome`, retention per copie/giorni/spazio, inventario con checksum, download/eliminazione confinati, anteprima restore, snapshot pre-ripristino e rollback automatico.
- Modalità manutenzione applicata dal server: landing e API `503` per i visitatori, login sempre disponibile e bypass amministratore visibile.
- Updater corretto con scansione iniziale, lock single-flight, stato tentativo/successo separato, test/stato Telegram, popup installabile, snooze 1/6/24 ore, progress staleness e unità systemd transitoria univoca.
- Preferenze updater salvate con un'azione esplicita; un cambio significativo avvia un solo controllo iniziale e non usa più `schedule_activated_epoch` come falso controllo.
- SMTP con profili Gmail/Outlook/Microsoft 365/generico, TLS implicito o STARTTLS, timeout e test; webhook HTTPS spiegato, testabile, senza redirect e protetto da SSRF.
- Template con creazione, modifica, duplicazione, eliminazione, attivazione, reset, variabili validate, anteprima live e test.
- Storico/log/eventi bounded, filtrati e paginati lato server; export CSV e redazione di password, token, cookie e API key.
- Diagnostica Telegram separa funzione configurata, unit installata/enabled/active, credenziali e coda; aggiunti repair controllati per listener e scheduler.
- Login rifinita con nuova immagine radar locale dell'Italia e animazioni continue dedicate a Connessione e Data stream.
- Versione finale `2.5.0`; nessuna release, merge o deploy automatico viene eseguito dal pacchetto.

## 2.4.7 · Master Design Login

- Ricostruita la schermata di accesso sulla specifica grafica ufficiale: composizione desktop 16:9, proporzioni, headline, quattro card, radar, pannelli laterali, form e barra inferiore.
- Nuovo asset orbitale locale dedicato con spazio, Terra notturna, atmosfera blu e sole all'orizzonte; il master completo non viene mai usato come background.
- Eliminata dalla login ogni dipendenza da `meteo-map.jpg` e `meteo.jpg`: il radar è ora uno SVG scenografico autonomo con Italia, Mediterraneo, riflettività multicolore, reticolo, sweep e gradi.
- Nessun target, cella, contatore o dato meteorologico reale viene esposto o sostituito nel pannello scenografico prima dell'autenticazione.
- Pannello Accesso amministratore, errori, password visibility, remember-me e autofill scuro ricostruiti mantenendo CSRF, rate limiting, hash password, sessioni e cookie invariati.
- Mobile riprogettato: branding e form completo sono nel primo viewport; hero, card e radar diventano contenuti secondari.
- Animazioni HUD leggere con fallback `prefers-reduced-motion`; asset locali e nessuna dipendenza CDN.

## 2.4.6 · Update Cockpit globale

- Popup aggiornamenti interattivo disponibile in Dashboard e in ogni pagina autenticata, inclusa la pagina Aggiornamenti.
- Ricerca manuale senza ricaricamento pagina, con comparsa immediata dell'avviso quando viene trovata una release.
- Pannello futuristico con avanzamento reale di download, verifica, dipendenze, backup, installazione, servizi e riavvio WebGUI.
- Installazione protetta asincrona tramite unità systemd transitoria: la procedura continua anche mentre la WebGUI viene riavviata.
- Frequenze complete: Manuale, Oraria con minuto, Giornaliera con orario, Settimanale con giorno e orario.
- Visualizzazione dell'ultimo e del prossimo controllo; preferenze salvate automaticamente con conferma visiva.
- Preservate integralmente Login HUD V2 2.4.5, conferme Telegram immediate, firma, staging, rollback e feed Stabile/Beta.

## 2.4.5 · Login HUD V2 · Concept Fidelity

- Riscrittura completa della login 2.4.4 seguendo il concept approvato come specifica grafica, non come semplice ispirazione.
- Layout desktop calibrato su tre colonne 31.4% / 37.7% / 30.9%, con hero, radar e accesso amministratore nelle proporzioni del mockup.
- Radar centrale nuovamente rettangolare: `meteo-map.jpg` è la sorgente preferita, con fallback sicuro a `meteo.jpg`, reticolo HUD, gradi, sweep, blip e legenda sovrapposti.
- Pannello amministratore ricostruito con cornice arancio, geometria HUD, input scuri e override esplicito dell'autofill Chromium/WebKit per eliminare i campi giallo/oliva.
- Barra inferiore compatta a cinque moduli, waveform, data-stream equalizer, tracking visuale e stati reali/sanitizzati.
- Background, Terra/orizzonte, stelle, glow e gerarchia cyan/arancio ricalibrati sul concept 16:9.
- Nuovi test bloccano regressioni su geometria, radar rettangolare, autofill, telemetria sicura, responsive e reduced-motion.

## 2.4.4 · Futuristic Live HUD Login

- Ricostruita da zero la login seguendo il concept futuristico approvato, con componenti DOM/SVG reali e senza usare il mockup come sfondo.
- Nuovo radar centrale animato con `meteo.jpg` reale, sweep, blip, legenda, timestamp e stato di freschezza del feed.
- Connessione e data stream diventano indicatori dinamici; dati vecchi o assenti producono stati espliciti invece di telemetria fittizia.
- Target e tracking celle non espongono dati interni prima dell'autenticazione e mostrano `STATO PROTETTO`.
- Nuovo pannello amministratore con show/hide password e grafica HUD, preservando il contratto di autenticazione 2.4.3.
- Responsive completo e riduzione automatica delle animazioni con `prefers-reduced-motion`.
- Aggiunta suite anti-regressione specifica per login, sicurezza, copy, asset locali, telemetria sicura, responsive e motion fallback.

## 2.4.3 · Feedback Telegram immediato

- Il feedback non attende più il ciclo radar: un servizio systemd dedicato usa il long polling Telegram e prende in carico il callback appena viene premuto.
- Dopo la scelta Telegram mostra una ricevuta immediata e invia il messaggio persistente **“✅ Feedback registrato: …”**.
- I pulsanti vengono rimossi dal messaggio originale dopo la prima scelta.
- Il callback viene scritto prima in una coda locale atomica e poi consolidato nello stato degli eventi sotto lo stesso lock del motore radar.
- La prima risposta diventa definitiva: ulteriori tocchi non possono sostituire il feedback né inserire dati duplicati nel dataset.
- Errori di firma, chat o salvataggio sono comunicati esplicitamente; diagnostica e pagina Sistema mostrano lo stato del listener.
- Preservati integralmente LDZ Update Network, popup, canali Stabile/Beta, backup e rollback della 2.4.2.

## 2.4.2 · LDZ Update Network

### Aggiornamenti senza account o token
- Sostituito l'accesso diretto al repository privato con due feed pubblici LDZ: **Stabile** e **Beta**.
- Il sorgente resta privato; la pipeline pubblica soltanto indici e pacchetti operativi tramite hosting statico HTTPS.
- Il canale Stabile ignora le prerelease; Beta riceve prerelease e stabili successive. Il passaggio Beta → Stabile non esegue downgrade.
- Rimossi dalla WebGUI token, repository, API e controlli destinati allo sviluppatore.
- Dimensione e SHA-256 del pacchetto sono vincolati dal feed; restano verifica integrale dell'archivio, approvazione locale, backup e rollback.

### WebGUI compatta e diagnostica
- Ridotte altezza e densità del riepilogo versioni senza perdere stato e azioni.
- Nuovi switch accessibili per controllo automatico, download anticipato e Telegram; corrette le checkbox native disallineate.
- Selezione Stabile/Beta tramite due card esplicative e pulsante **Salva preferenze** non più esteso per tutta la pagina.
- “Procedura manuale di emergenza” rinominata **Recupero avanzato** e mantenuta chiusa per impostazione predefinita.
- Il pulsante di controllo riporta ora la causa reale del checker; rimosso il messaggio generico “consulta lo stato updater”.
- La pipeline distingue automaticamente release definitive e prerelease e aggiorna i due feed senza richiedere credenziali agli utilizzatori.

## 2.4.1 · Automatic Release Updater

### Aggiornamenti senza SSH
- Ricreata da zero la pagina **Aggiornamenti** come control center: versione installata, ultima release, data, dimensione, note, stato download e catena di verifica.
- Controllo manuale, orario, giornaliero o settimanale tramite timer systemd persistente; canali stabile e beta.
- Supporto al repository GitHub privato tramite fine-grained token in sola lettura, salvato con mode `0600`, sempre mascherato e mai scritto nei log o nella riga di comando.
- Download dalla GitHub Releases API usando repository e host fissati; nessun URL remoto viene passato agli helper privilegiati.
- Il pacchetto viene validato con manifest, SHA-256 per file, CRC, limiti anti-ZIP-bomb e policy dei percorsi prima di poter essere installato.
- L'installazione resta manuale: il clic genera l'approvazione Ed25519 locale, poi l'updater root ripete i controlli su una snapshot, crea il backup ed esegue rollback in caso di errore.
- GitHub Actions testa e pubblica automaticamente una release immutabile quando `main` contiene una nuova versione.

### WebGUI e diagnostica
- Nuovo popup futuristico in alto a destra: “Nuovo aggiornamento disponibile!”, versione, accesso diretto e rinvio di 24 ore.
- Il popup interroga lo stato ogni 60 secondi anche se la pagina resta aperta.
- Fix del falso rischio rosso: una riga `WARNING ... (HTTPError)` non viene più interpretata come livello `ERROR`.
- In caso di LTG vecchio o SITES temporaneamente non disponibile, il rischio meteo resta **Basso** e la dashboard dichiara la sorgente degradata.

## 2.4.0 · Ground Truth & Event-Driven Nowcast

- Elaborazione guidata dal WebSocket STOMP ufficiale Radar-DPC alla pubblicazione del VMI, con timer fallback e lock anti-concorrenza.
- Corretto LTG: cadenza ufficiale 10 minuti, finestre dai timestamp reali, età rispetto all'ora corrente e blocco dei nuovi alert oltre 15 minuti.
- Nuovi fulmini vettoriali più grandi e leggibili, con quadro recente giallo e precedente arancione.
- Near-target override su bordo dell'eco, pioggia osservata e fulmini molto vicini; il caso “in allontanamento” non può più annullare un fenomeno già sul target.
- Pacchetto temporale coerente per VMI/SRI/POH/VIL/ETM/CAPPI/LTG e controllo ufficiale SITES dei radar operativi.
- Incidenti unificati e deduplicazione dei target vicini interessati dalla stessa cella.
- Replay compatti con variabili, ritagli radar e spiegazione dei motivi/blocchi nella nuova pagina WebGUI Eventi & feedback.
- Domanda Telegram post-evento con callback firmati e categorie strutturate; “non ero sul posto” non entra nel dataset.
- Calibrazione verticale grandine da ground truth: holdout cronologico, Brier e guardia falsi negativi, attivazione automatica solo se idonea e influenza limitata.
- Watchdog systemd esterno con avviso di stallo e recupero.
- Migrazione cumulativa e rollback integrale dalla 2.3.7; 2.3.8 e 2.3.9 sono incorporate senza release intermedie.

## 2.3.7 · Vertical Hail Fusion & Auto Login

- Integrati i dieci prodotti ufficiali Radar-DPC `CAPPI_1`–`CAPPI_10`, corrispondenti alle quote da 1 a 10 km.
- Ogni cella usa un profilo verticale robusto al 95° percentile e misura fin dove persistono eco di 45, 50 e 55 dBZ.
- Il profilo viene confrontato con lo zero termico: può correggere la stima grandine di massimo +12/-6 punti, mentre POH resta il segnale principale e il livello alto continua a richiedere qualità, persistenza e POH.
- CAPPI non resta interno: alert Telegram iniziali e aggiornamenti riportano supporto verticale e quota dell'eco; mappa e dashboard mostrano stato e livelli realmente disponibili.
- Se CAPPI è assente, incompleto o temporalmente disallineato, Hail Fusion continua con POH/VMI/VIL/ETM senza inventare valori.
- Corretto “Ricordami”: una scheda ripristinata direttamente su `/login` entra nella dashboard se il token persistente è valido.
- Il cookie persistente viene esteso all'intero host e i vecchi cookie limitati a `/ldzmeteoapp/` vengono migrati e rimossi senza salvare password nel browser.
- Il pannello si chiama semplicemente “Stable Impact & Hail Fusion”, senza il vecchio suffisso `2.3.4`.
- Aggiunti test per influenza CAPPI forte/debole, presenza CAPPI in Telegram, migrazione della configurazione e regressione auto-login.

## 2.3.6 · Lightning Clarity & Live ETA

- Aggiunti alert Telegram autonomi per i fulmini Radar-DPC LGT: soglia minima, raggio urgente, cooldown, escalation e messaggio di cessazione sono configurabili dalla WebGUI.
- Corretta la migrazione degli impianti esistenti: la vecchia sorgente predefinita `open_meteo` passa a `radar_dpc_lgt`, mentre eventuali scelte esplicite diverse vengono preservate.
- Mappa e dashboard mostrano stato LGT, conteggio scariche recenti e distanza dal target; il pannello “In parole povere” diventa “Situazione stimata”.
- L'ETA viene proiettato dal timestamp del frame radar all'ora reale di elaborazione; finestre già scadute vengono soppresse salvo nucleo osservato sul target.
- Probabilità più conservativa con tracking debole: la stima viene regolarizzata verso il 50% e limitata nei primi frame incoerenti.
- La fascia 45–55 dBZ è descritta come temporale con pioggia intensa, separandola dal temporale forte e dal nucleo molto intenso.
- Ridisegnati tutti gli alert con righe e icone uniformi, consigli pratici, “Cosa sta rilevando il sistema” e una spiegazione concreta della stabilità.
- Rimossi “da confermare”, “Affidabilità della stima” e il vecchio titolo “Perché ricevi questo avviso”.
- I rientri fanno riferimento all'avviso effettivamente inviato e classificano il risultato: transito confermato, passaggio marginale, traiettoria deviata o previsione non confermata.
- Aggiunti test end-to-end per alert fulmini autonomi, deduplicazione, ETA live, testo Telegram e classificazione del rientro.

## 2.3.5 · Clear Radar Messages

- Sostituiti gli stati generici “cella forte” e “traiettoria incerta” con messaggi riferiti al target e alla probabilità reale: nucleo osservato, temporale probabile, possibile avvicinamento, impatto poco/molto improbabile, fuori traiettoria e nessun temporale intenso.
- Il riquadro informativo riporta target, distanza, direzione, probabilità ed ETA soltanto quando quest'ultima è significativa.
- Le fasce ETA con estremi uguali vengono compattate: `20–20 min` diventa `20 min`.
- Le etichette delle celle restano dentro la mappa e non possono più invadere il pannello informativo quando il centroide è fuori inquadratura.
- `HIGH`, `MEDIUM`, `LOW`, `f` e `POH` non compaiono più isolati sulla mappa: diventano `Forte`, `Moderata`, `Debole`, `scansioni` e `grandine radar`.
- Aggiunti test per tutte le fasce di probabilità, nucleo osservato, fuori traiettoria e stato libero.

## 2.3.4 · Stable Impact & Hail Fusion

- Separati alone temporalesco e nucleo forte ≥55 dBZ: il contatto del solo inviluppo non genera più automaticamente `100%` ed ETA zero.
- Gli eventi urgenti richiedono due frame coerenti; l'unica eccezione è un nucleo forte già osservato sul target.
- Il rientro viene inviato soltanto dopo due frame negativi consecutivi, riducendo le sequenze alert/rientro causate da un singolo volume instabile.
- Hail Fusion combina POH Radar-DPC, nucleo VMI, densità VIL, sviluppo sopra lo zero termico, persistenza, crescita, Lightning Jump e temperatura della nube.
- POH resta dominante; satellite e fulmini sono correttori deboli e non viene inventata una dimensione dei chicchi.
- Telegram mostra probabilità grandine, qualità dei dati e conferma multi-frame in linguaggio semplice.
- Aggiunti test sintetici per nucleo osservato, assenza del 100% artificiale, doppia conferma urgente, isteresi del rientro e supercella grandinigena persistente.

## 2.3.3 · Human Alerts

- Ridisegnati gli alert Telegram: fenomeno, target, ETA, probabilità, intensità, grandine e consiglio pratico sono ora leggibili a colpo d'occhio.
- Aggiunta la sezione “Perché ricevi questo avviso”, che traduce VMI, SRI, POH, VIL ed ETM in linguaggio comune mantenendo il dato radar originale.
- Separate esplicitamente probabilità d'impatto, affidabilità complessiva e coerenza della traiettoria.
- Consigli contestuali per grandine, fulmini e pioggia molto intensa; rimossa la formulazione “senza panico”.
- Gli update successivi mostrano solo `RISCHIO AUMENTATO`, `TRAIETTORIA MENO PROBABILE` o `MINACCIA RIENTRATA`, senza ripetere il log del motore.
- Installer, updater e repair creano e assegnano automaticamente a `meteoalert` tutte le immagini `meteo.jpg`, `meteo-map.jpg` e `meteo-details.jpg`.
- L'updater verifica realmente la scrivibilità delle tre immagini come utente del servizio prima di concludere il deploy.

## 2.3.2 · Firma Download ZIP GitHub

- Il signer incluso nella sorgente può validare una struttura più recente
  anche quando sul server è ancora installata la policy 2.3.1.
- La policy della sorgente non viene considerata attendibile implicitamente:
  `web/security_utils.py` e lo stesso signer devono coincidere con gli SHA-256
  dichiarati nel manifest dell'archivio da firmare.
- Rimangono attivi i controlli anti path traversal, ZIP bomb, file speciali,
  top-level consentiti e integrità completa del payload.

## 2.3.2 · National Fusion & Mobile Radar

- Consenso NWP nazionale zero-config: i target sono raggruppati geograficamente e usano un contesto locale ICON-2I/ICON/ECMWF/GFS invece di un unico punto medio.
- Aggiunti SRT1 e IR_108 Radar-DPC come conferme limitate di persistenza delle precipitazioni e sommità nuvolosa; restano opzionali e non sostituiscono VMI/traiettoria.
- Nuovo verificatore event-based e a slot che conta anche falsi negativi senza previsione, con TP/FP/FN/TN, precision, recall, F1, CSI, FAR, Brier Score ed errore ETA.
- Cookie “Ricordami” indipendente, firmato e con scadenza: ripristina una nuova sessione dopo la chiusura del browser ed è invalidato da logout o cambio password.
- Tre render radar automatici: tavola completa desktop, sola mappa e soli dettagli per smartphone; nessun ingrandimento iniziale o ritaglio laterale.
- Updater corretto contro il 503 post-update: permessi di directory e virtualenv normalizzati e verificati impersonando `meteoalert` prima del riavvio.
- Il sorgente scaricato direttamente da GitHub resta accettabile dall'updater incluso; gli artefatti storici in `dist/` sono ammessi ma mai eseguiti.

## 2.3.1 · Radar Map & Learning Console

- Mappa pubblica ricomposta con pannello informativo a fasce, testi realmente mandati a capo e righe tecniche alternate.
- Label target posizionate automaticamente dentro i bordi della mappa, con scelta anti-collisione: i nomi lunghi non vengono più tagliati.
- Adaptive Forecast AI mostrata con avanzamento reale, pipeline operativa e gate per verifiche, temporali distinti, eventi positivi/negativi e vantaggio Brier.
- Timeline dei log spostata direttamente sotto la mappa, indipendente dall'altezza dei pannelli laterali.
- Layout dashboard adattivo per desktop, tablet e smartphone.
- Updater più diagnostico e robusto nella creazione del backup; `tar` è ora un prerequisito installato e verificato automaticamente.

## 2.3.0 · Terrain, Lifecycle & Adaptive AI

- Terrain Engine con profili altimetrici cella-target, cache limitata e influenza orografica massima configurabile.
- Lifecycle Engine con crescita/decadimento multi-segnale e probabilità di sopravvivenza fino al target.
- Optical flow multi-scala con spread e indicatore di deformazione.
- Consenso atmosferico ICON-2I/ICON/ECMWF: spread tra modelli e peso sempre subordinato al radar.
- Lightning Jump per track e pannello separato Storm Initiation Watch.
- Calibrazione per target, stagione, direzione e fascia ETA.
- Ingressi sensori locali opzionali tramite snapshot JSON, HTTPS e MQTT/TLS.
- Adaptive Forecast AI con modello online numerico sicuro, shadow mode, valutazione prequential, criteri minimi, attivazione limitata e circuit breaker.
- Trainer batch giornaliero isolato in un servizio systemd hardenizzato; ogni nuovo candidato deve completare una nuova finestra shadow.
- Nessun modello `pickle`; dataset JSONL ruotato, input limitati e fallback automatico al motore deterministico.
- Due distribuzioni: pacchetto update firmabile e full installer.
- Bootstrap compatibile con l'updater 2.2.9: nessun fermo engine al primo passaggio WebGUI; il secondo passaggio completa trainer e moduli nativi.
- Changelog WebGUI ridisegnato con card e righe uniformi su desktop e mobile, senza salti grafici tra release recenti e storico legacy.
- Login con opzione `Ricordami`: sessione browser con timeout breve quando disattivata, cookie persistente sicuro e limite assoluto configurabile quando attivata.

## 2.2.9 · Target WebGUI hotfix

- Corretto il salvataggio dei target dalla WebGUI su installazioni reali: il servizio mantiene ora inode, proprietario e permessi del `config.yml` root-owned senza tentare di creare file temporanei dentro `/etc/meteo-alert`.
- Corretto il validatore pre-deploy: l'helper Python `ldz-meteo-get-chat-id` viene verificato con Python e non più erroneamente con `bash -n`.
- Aggiunti lock tra scritture concorrenti, `fsync`, rifiuto dei symlink e verifica del file regolare.
- Le configurazioni legacy con `targets: null` vengono riparate automaticamente al primo salvataggio.
- Aggiunti test di regressione per aggiunta target e conservazione dei permessi.

## 2.2.9 · Precision Engine

- Sostituito il tracking a due baricentri con track persistenti multi-frame e filtro di Kalman.
- Aggiunta associazione globale delle celle con gestione dei frame duplicati e indicatori split/merge/crescita/decadimento.
- Aggiunta geometria compatta della cella: gli impatti considerano il fronte radar e non soltanto centro/raggio equivalente.
- Aggiunto optical flow locale VMI e ensemble riproducibile di 72 traiettorie con intervallo ETA e incertezza spaziale.
- Aggiunto prodotto SRI (pioggia stimata al suolo) e controllo dello skew temporale tra prodotti.
- Aggiunto prior debole ItaliaMeteo-ARPAE ICON-2I per vento 700/500 hPa, CAPE e quota zero termico; il radar resta dominante.
- Aggiunta verifica automatica hit/miss, Brier Score e calibrazione empirica per target dopo un campione minimo.
- Corretto il conteggio delle conferme: lo stesso frame DPC non può più valere come due conferme consecutive.
- Gli alert vengono sospesi se il VMI è stale; LGT rimane una conferma positiva e non è hard gate nei nuovi install.
- Nuovi messaggi Telegram per rischio in aumento e traiettoria meno probabile, con cooldown separato.
- Dashboard e pagina Regole ampliate con telemetria Precision Engine, track, optical flow, ICON-2I e calibrazione.
- Mappa pubblica aggiornata con forma delle celle, percorso previsto e cono d'incertezza.
- Installer shell ridisegnato come console futuristica a fasi, senza rimuovere compatibilità SSH/non-TTY.
- Migrazione automatica e conservativa dalla 2.2.8 con backup/rollback firmato.

## 2.2.8 · Security Hardening

- Eliminata la catena update unsigned → helper root: gli update richiedono firma Ed25519 detached approvata localmente da root.
- Eliminata la catena backup restore → sostituzione codice/systemd: i backup WebGUI sono ora data-only.
- Sudoers senza wildcard, updater in transient service separato, snapshot anti-TOCTOU e rollback.
- Policy ZIP schema 2 con SHA-256 per file, limiti anti-bomb, allowlist, blocco symlink/traversal/duplicati.
- Fix DOM-XSS geocoding/Leaflet; CSP nonce e Leaflet locale.
- Rate limiting login, session hardening, logout POST, cache `no-store`.
- Runtime Python 3.12 e versioni sicure di Flask, Waitress e Pillow.
- Limiti raster/tile/LGT e policy endpoint outbound contro SSRF e resource exhaustion.

## 2.2.7 · Nowcasting multi-segnale / grandine combinata

- Aggiunto incrocio multi-segnale per la probabilità d’impatto: traiettoria, VMI, VIL, ETM, LGT e trend/chiusura cella.
- Aggiunto `hail confidence score`: POH resta il segnale principale, ma viene pesato con VMI, VIL, ETM e fulmini LGT quando freschi.
- Gli alert Telegram mostrano probabilità corretta, traiettoria pura e confidenza multi-segnale.
- Il messaggio grandine ora distingue meglio tra “non indicata”, “poco probabile ma da monitorare”, “possibile” e “rischio alto”.
- Aggiunto blocco config `multisignal:` con default conservativi.
- Nessun radar esterno duplicato: Radar-DPC resta fonte principale, sfruttata meglio.


## 2.2.7 · Packaging fix WebGUI updater

- Stesse modifiche funzionali della 2.2.7 sulle sigle radar più leggibili.
- Hotfix ripacchettata con file a root ZIP, senza cartella contenitore, per massima compatibilità con le versioni precedenti del validator WebGUI.
- Preservati probabilità d’impatto, messaggi di allontanamento, Radar-DPC LGT, freshness guard, render fix e UI checkbox alignment.


## 2.2.7 · Sigle radar più leggibili

- Le sigle tecniche restano visibili, ma vengono espanse nei testi utente.
- Alert Telegram aggiornati con etichette più parlanti: VMI intensità verticale, POH probabilità grandine, VIL acqua/ghiaccio in nube, ETM quota eco radar.
- Aggiunta legenda compatta delle sigle negli alert.
- Aggiunta legenda completa nella guida WebGUI.
- Etichette WebGUI aggiornate per rendere più chiari VMI e sorgente LGT.
- Nessuna modifica peggiorativa alla logica meteo: preservati Radar-DPC LGT, freshness guard, render fix, checkbox alignment, probabilità impatto e allontanamento.


## 2.2.5b · Radar-DPC LGT freshness guard

- Aggiunta soglia `dpc_lgt_max_age_minutes` (default 45) per distinguere dati live da dati Lightning solo diagnostici.
- Se il layer LGT è troppo vecchio rispetto al frame radar, viene mostrato nel test ma non usato per alert live, gating o overlay mappa.
- Nuovi campi WebGUI per età massima LGT e finestra fallback.

## 2.2.7 · Checkbox alignment sweep / option rows

- Rivista tutta la WebGUI per le opzioni booleane: le spunte non sono più lontane a destra ma vicine al testo.
- Corretto l'allineamento nelle sezioni Quiet hours, Canali Notifica, Fulmini, Backup, Template e in tutte le altre righe opzione basate sui componenti toggle condivisi.
- Uniformato il layout delle righe opzione: checkbox vicina all'etichetta, testo e descrizione allineati meglio, resa più naturale anche su mobile.
- Nessuna modifica alla logica meteo; preservati tutti i fix 2.2.5c/2.2.5b/2.2.5a/2.2.5.

## 2.2.5c · Render fix Radar-DPC LGT overlay

- Corretto errore `TypeError: generate_public_image() got an unexpected keyword argument 'lightning_strikes'`.
- La generazione immagine pubblica ora accetta il parametro `lightning_strikes` e lo inizializza in modo sicuro se assente.
- Ripristinato aggiornamento `meteo.jpg` quando la sorgente Radar-DPC LGT è attiva.
- Evita che la dashboard vada in `Attenzione` solo per errore di render immagine.
- Preservati tutti i fix 2.2.5b/2.2.5a/2.2.5: freschezza LGT, fallback S3, decoder LGT e overlay fulmini.

## 2.2.5a · Radar-DPC LGT S3 fallback

- Fix Radar-DPC LGT: il bucket S3 può restituire HTTP 403 anche quando il file non esiste; ora 401/403/404 sono trattati come slot mancanti.
- Aggiunta ricerca a ritroso configurabile (`dpc_lgt_max_lookback_minutes`, default 180) per trovare l'ultimo layer LGT disponibile se è in ritardo rispetto al frame radar.
- Aggiunti header browser-like per l'endpoint S3 LGT: `Origin`, `Referer`, `User-Agent`, `Sec-Fetch-*`.
- Il test WebGUI mostra ultimo slot LGT trovato e ritardo rispetto al frame radar.
- Gli alert indicano se il layer LGT usato è più vecchio del radar.

## 2.2.5 · Radar-DPC LGT / fulmini reali

- Aggiunta sorgente `Radar-DPC LGT` per leggere i fulmini reali dal layer pubblico usato dalla WebApp ufficiale.
- Implementato decoder per `LGT/lgt_5min_<timestamp>.bin` versione 2.
- Il motore scarica più slot da 5 minuti in base a `lightning.window_minutes`.
- Calcolo per target: numero fulmini entro `lightning.radius_km` e distanza del fulmine più vicino.
- Gli alert Telegram mostrano il contesto fulmini Radar-DPC quando disponibile.
- Se abilitato `notify_on_lightning_plus_radar`, il motore può inviare solo con radar forte + fulmini DPC vicini.
- La mappa pubblica `meteo.jpg` disegna i marker fulmine sopra al radar VMI.
- Test WebGUI del modulo Fulmini aggiornato per la sorgente Radar-DPC LGT.
- Preservati tutti i fix 2.2.4/2.2.3: UI polish, Radar-DPC 403, updater read-only, probabilità impatto e allontanamento.

## 2.2.4 · WebGUI polish / spacing / mobile refinements

- Rifinitura generale della WebGUI senza modificare la logica meteo.
- Bottoni uniformati con altezza minima, centratura verticale e wrapping corretto su schermi piccoli.
- Label e campi form più coerenti nelle griglie a 2/4 colonne.
- Migliorati focus ring e leggibilità di input, select e textarea.
- Migliorato il comportamento mobile/tablet di top actions, status card e form actions.
- Rafforzata la coerenza visuale dei pannelli e delle card senza perdere i temi esistenti.
- Preservati tutti i fix 2.2.3c: checkbox/toggle ordinati e card rischio verde/ambra/rosso.
- Preservati tutti i fix 2.2.3b/2.2.3a/2.2.3: Radar-DPC 403, updater read-only, probabilità impatto e allontanamento.

## 2.2.3c · UI polish / checkbox alignment / risk palette

- Fix grafico WebGUI: le checkbox non ereditano più lo stile dei campi input full-width.
- Pagine interessate: Quiet hours, Canali notifica, modulo Fulmini, Backup e Template Telegram.
- Nuovo layout coerente per le opzioni booleane: testo allineato a sinistra, checkbox a destra, card/toggle ordinata e leggibile.
- Dashboard: card `Rischio` colorata in modo più intuitivo: verde = Basso, ambra = Moderato, rosso = Alto/Attenzione.
- Preservati tutti i fix della 2.2.3b (Radar-DPC 403), 2.2.3a (updater read-only) e 2.2.3 (precisione target).

## 2.2.3b · Fix Radar-DPC 403 / Origin headers

- Diagnostica Radar-DPC corretta: sostituito check `curl -I`/HEAD con GET reale.
- Aggiunti header `Origin` e `Referer` verso `https://radar.protezionecivile.it` per allinearsi alla REST API Radar-DPC v2.
- Aggiunti header `Accept`, `Accept-Language`, `Cache-Control`, `Pragma` e `User-Agent` dedicato.
- Le risposte Radar-DPC 401/403 vengono registrate come indisponibilità remota non fatale, evitando falsi fatal del timer.
- Preservate le ottimizzazioni 2.2.3/2.2.3a su probabilità d'impatto, allontanamento e updater read-only.

## 2.2.3a — Updater hardening fix

Correzione mirata al problema emerso durante l’applicazione della hotfix 2.2.3 dalla WebGUI.

- Fix del servizio `ldz-meteo-web.service`: `ReadWritePaths` ora include anche `/opt/ldz-meteo-web`, `/opt/meteo-alert` e `/usr/local/sbin`.
- Fix dello script `ldz-meteo-apply-hotfix`: rileva filesystem/namespace read-only e può rilanciarsi tramite `systemd-run` fuori dal namespace protetto della WebGUI.
- Fix dello script `ldz-meteo-repair`: mantiene abilitato anche `ldz-meteo-apply-hotfix` nel sudoers, evitando regressioni della pagina Aggiorna.
- Nessuna regressione funzionale sulla precisione meteo introdotta in 2.2.3: probabilità impatto, doppia conferma e messaggi di allontanamento restano invariati.


Questo changelog accompagna il sorgente completo `2.3.0`.  
Nota di accuratezza: per la catena `2.2.2 → 2.2.3` il confronto è stato fatto sul codice reale dei pacchetti disponibili. Per le prime release `1.x` e parte della `2.x`, lo storico è ricostruito dalla baseline funzionale, dai commenti presenti nel sorgente e dalla checklist anti-regressione mantenuta nelle build successive.

---

## 2.2.3 - Precision Hotfix

### Motore meteo / precisione target
- Aggiunta stima `impact_probability_percent` per calcolare quanto è probabile che una cella impatti davvero un target.
- La traiettoria non è più un controllo binario: ora valuta distanza minima dal target, raggio della cella, raggio del target, velocità, chiusura verso il target e incertezza crescente col lead-time.
- Aggiunti filtri anti-falso-positivo:
  - `min_alert_probability_percent`
  - `min_closing_kmh`
  - `min_approach_km`
  - `trajectory_uncertainty_km`
  - `lead_uncertainty_km_per_min`
  - `max_lead_uncertainty_km`
- Gli avvicinamenti non urgenti richiedono conferme radar consecutive tramite `require_consecutive_hits`.
- Gli alert urgenti restano immediati se la cella è già dentro il target o se ETA/probabilità superano le soglie `urgent_eta_minutes` e `urgent_probability_percent`.
- Aggiunta memoria delle minacce attive per target con `target_threats` e `target_candidates` nello stato runtime.
- Aggiunto alert di rientro/allontanamento quando una minaccia già notificata non è più confermata.
- Aggiunto cooldown separato per i messaggi di rientro tramite `clear_cooldown_minutes`.
- Aggiunta scadenza memoria minaccia tramite `threat_memory_minutes`.

### Alert Telegram / storico
- Il messaggio Telegram ora mostra la probabilità stimata d'impatto in percentuale.
- Aggiunta label probabilistica: bassa, incerta, medio-alta, alta.
- Aggiunto scarto traiettoria / closest approach nei dettagli tecnici.
- La fonte viene descritta come stima probabilistica personale e non come allerta ufficiale.
- `alerts.log` ora può distinguere `event_type: alert` e `event_type: clear`.

### WebGUI / sorgente
- Versione WebGUI aggiornata a `2.2.3`.
- Aggiunta pagina Changelog nella sidebar.
- Aggiunto `CHANGELOG.md` nel sorgente completo.
- Preservate le funzioni 2.2.2: updater UX, hardening, dashboard mobile, temi, storico, canali, manutenzione, backup e diagnostica.

---

## 2.2.2 - Fullstack Installer Update UX

### Aggiornamenti / hotfix
- Aggiunta pagina WebGUI `Aggiorna` per caricare pacchetti ZIP da interfaccia.
- Verifica automatica del pacchetto prima dell'applicazione:
  - controllo CRC interno ZIP;
  - calcolo SHA256;
  - blocco path assoluti e path traversal;
  - riconoscimento struttura con o senza cartella radice;
  - verifica manifest e script applicativo.
- Aggiunto staging dei pacchetti update in `/var/lib/ldz-meteo-web/updates`.
- Aggiunto helper root limitato `/usr/local/sbin/ldz-meteo-apply-hotfix`.
- Aggiunto flusso: upload → verifica → backup → applicazione → restart WebGUI → refresh automatico.

### UX / manutenzione
- Migliorata pagina Manutenzione con checkbox descrittiva e testi più chiari per l'utente.
- Rimossi testi troppo tecnici o note da changelog/dev dalle schermate operative.
- Consolidata compatibilità con layout mobile 2.2.1.

---

## 2.2.1 - Mobile Command Center

### Mobile UX
- Introdotta topbar mobile dedicata.
- Introdotto menu laterale a comparsa/drawer su smartphone.
- Aggiunte descrizioni brevi per ogni voce del menu.
- Ridisegnata dashboard smartphone con card più compatte.
- Mappa radar inserita in contenitore navigabile da mobile.
- Aggiunti controlli zoom/pan più comodi per consultazione da telefono.

### Anti-regressione UI
- Preservati temi, wallpaper, dashboard, kiosk e pagine operative già esistenti.
- Fix grafici e layout per evitare sovrapposizioni su viewport piccoli.

---

## 2.2.0 - Hardening WebGUI / Installer evoluto

### Sicurezza WebGUI
- Aggiunti controlli Host allowlist.
- Aggiunti controlli Origin/Referer sulle POST.
- Introdotti token CSRF nelle form.
- Cookie configurati con `HttpOnly`, `SameSite` e `Secure` se HTTPS.
- Aggiunti security headers:
  - Content-Security-Policy;
  - X-Frame-Options;
  - X-Content-Type-Options;
  - Referrer-Policy;
  - Permissions-Policy;
  - HSTS se HTTPS.
- Referrer-Policy mantenuta su `strict-origin-when-cross-origin` per compatibilità con tile OpenStreetMap.

### Installer / sistema
- Wizard di installazione con modalità HTTP, HTTPS self-signed e HTTPS con certificato esistente.
- Configurazione Apache reverse proxy.
- Gestione hardening WebGUI durante il wizard.
- Azioni root controllate e sudoers limitato.
- Aggiunto repair web-safe eseguibile dalla WebGUI.
- Fix per `mod_ssl` e certificati localhost.

---

## 2.1.1 - Visual Pack / Anti-regression UI

### UI / temi
- Aggiunto visual pack per dashboard e componenti principali.
- Ridisegno tema chiaro `Light Clean`.
- Aggiunte correzioni per mantenere leggibilità e coerenza tra dark/light/cyber/tactical.
- Aggiunti wallpaper JPG per i temi e uso più uniforme degli sfondi.

### Target / mappa
- Migliorata la gestione target con ricerca località/città.
- Supporto click su mappa Leaflet/OpenStreetMap quando gli asset esterni sono abilitati.
- Fix marker Leaflet locali tramite `L.divIcon`, evitando fallback testuale tipo `Mark/Marker`.

### Pagine operative
- Migliorate quick actions, card, griglie, riepiloghi e statistiche.
- Migliorati grafici e timeline nello storico alert.

---

## 2.1.0 - Theme Engine + UI polish

### WebGUI
- Introdotto motore temi.
- Aggiunti temi:
  - Dark Classic;
  - Light Clean;
  - Cyber Neon;
  - Storm HUD.
- Migliorata pagina login, dashboard e navigazione laterale.
- Migliorata coerenza visuale di pulsanti, card, eventi, badge e pannelli.

### Operatività
- Aggiunte o consolidate pagine: Aspetto, Template, Canali, Storico, Diagnostica, Backup, Manutenzione, Kiosk e Readiness.
- Migliorata consultazione dello stato sistema e dei log dalla WebGUI.

---

## 2.0.0 - WebGUI completa / gestione operativa

### Web application
- Introdotta WebGUI Flask/Waitress per gestione dell'app.
- Login con password hashata.
- Dashboard con stato radar, immagine pubblica, target, rischio e timeline.
- Gestione target da interfaccia.
- Gestione regole alert da interfaccia.
- Gestione Telegram, test messaggi e test immagine.
- Pagine log, sistema e diagnostica.

### Notifiche / storico
- Aggiunti template alert personalizzabili.
- Aggiunti canali notifiche aggiuntivi: webhook generico ed email SMTP.
- Aggiunto storico alert con KPI, timeline e statistiche.

---

## 1.2.x - Motore alert più robusto

### Radar / rischio
- Migliorata classificazione celle temporalesche.
- Gestione VMI, POH, VIL ed ETM quando disponibili.
- Rischio grandine separato dal requisito principale di alert.
- Fix logico: quando non ci sono alert inviati e `detected cells=0`, il rischio deve restare `Basso`, non `Moderato`.

### Alert
- Aggiunto controllo ETA/preavviso.
- Aggiunto cooldown per target.
- Aggiunte quiet hours.
- Migliorata descrizione rischio e consigli operativi nel messaggio Telegram.

---

## 1.1.x - Full Stack Installer iniziale

### Installer
- Creato installer full stack per ambiente Linux/AlmaLinux.
- Installazione dipendenze engine e WebGUI.
- Creazione directory runtime, log, config e asset pubblici.
- Configurazione systemd timer/service per il motore meteo.
- Configurazione Apache reverse proxy.
- Configurazione Telegram bot e chat ID.
- Generazione file `/etc/meteo-alert/config.yml` e `/etc/meteo-alert/secrets.env`.

### Output pubblico
- Pubblicazione immagine radar `meteo.jpg` sotto document root web.
- Aggiunto test Telegram post-installazione.

---

## 1.0.0 - Prima baseline radar/Telegram

### Core
- Primo motore Python per scaricare/elaborare il radar DPC.
- Definizione target geografici con nome, latitudine, longitudine e raggio.
- Analisi celle temporalesche con soglie radar.
- Generazione immagine radar pubblica.
- Invio alert Telegram quando una cella forte risulta rilevante per un target.
- Logging applicativo base.
- Configurazione tramite YAML e secrets separati.

---

## Note anti-regressione permanenti

Ogni build successiva alla 2.2.3 deve preservare almeno:

- dashboard, target, aspetto, regole, Telegram, template, canali, fulmini, storico, diagnostica, log, backup, manutenzione, aggiorna, sistema, kiosk, readiness e changelog;
- HTTPS/hardening, CSRF, Host/Origin checks e root actions limitate;
- layout mobile con drawer e radar zoomabile;
- temi e wallpaper;
- updater sicuro con verifica ZIP;
- alert probabilistici con messaggi di allontanamento/rientro;
- rischio `Basso` quando non ci sono celle/alert reali.
