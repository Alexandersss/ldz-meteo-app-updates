# LDZ Meteo 2.6.0-beta.1 — nota scientifica e matrice di applicabilità

Questa release è un miglioramento metodologico da validare su eventi italiani, non una dichiarazione di accuratezza già aumentata. Il motore usa soltanto i prodotti realmente acquisiti: VMI, SRI, POH, VIL, ETM, SRT1, IR_108, CAPPI, LTG, SITES, zero termico, contesto NWP, profili altimetrici e feedback. Non sono disponibili velocità radiale, spectrum width, ZDR, KDP, ΦDP, ρHV o classificazione polarimetrica.

## Matrice decisionale

| Metodo / problema | Riferimento PDF | Dati necessari e compatibilità LDZ | Classificazione | Rischi e decisione |
|---|---|---|---|---|
| Confidenza distinta per prodotto: disponibilità, età e skew | `opera_wp12_v6.pdf`, pp. 14–17; `WMO-1257-2024-vVI.pdf`, pp. 11, 44–54; `2602.15088v1.pdf`, pp. 3, 13–14 | Timestamp VMI/SRI/POH/VIL/ETM e stato d'uso: disponibili | **Applicabile direttamente** come controllo operativo | Evita di presentare prodotti non simultanei; non misura la qualità fisica del pixel. Implementato con decadimento continuo e limiti dichiarati. |
| Qualità per zona da beam height/blocking, clutter, bright band e attenuazione | `3_2_Basics of Weather Radar.pdf`, pp. 24–28; `WMO-1257-2024-vVI.pdf`, pp. 44–54; `opera_wp12_v6.pdf`, pp. 14–17 | Servirebbero geometria/scansioni del radar sorgente e mappe QC per pixel; il mosaico non espone l'attribuzione | **Utile solo come controllo di qualità**; correzione fisica **non applicabile con i dati attuali** | Implementato solo un proxy SITES per target, esplicitamente non equivalente a beam blocking o qualità del pixel. |
| Multi-soglia e morfologia per falsi merge | `2009-Han-3DConvectiveStormIdentificationTrackingandForecastingAnEnhancedTITANAlgorithm.pdf`, pp. 4–6 | Volumi 3-D e taratura delle soglie; LDZ ha VMI 2-D e CAPPI separati | **Applicabile dopo adattamento**, rinviato | Copiare 30–60 dBZ o kernel 3×3 rischierebbe split falsi sulla griglia nazionale; richiede replay italiani e verifica POD/FAR/CSI. |
| Associazione per sovrapposizione, velocità massima, split/merge | stesso documento, pp. 5–6 e 10 | Forme 2-D, centroidi e sequenza temporale: disponibili | **Applicabile dopo adattamento** | Il matcher LDZ resta distanza/forma/intensità; split/merge ora diventano eventi di incertezza che riducono stabilità e allargano ETA. |
| Fusione object tracking + optical flow e incertezza crescente col lead time | `2005.04988v1.pdf`, pp. 4–8; `gmd-12-4185-2019.pdf`, pp. 6 e 12 | VMI sequenziale, oggetti e optical flow: disponibili | **Applicabile direttamente** nella struttura esistente; calibrazione ancora necessaria | Implementata penalità per svolte/topologia, covarianza maggiore e finestra ETA esplicita. Le probabilità restano non calibrate finché mancano abbastanza esiti. |
| Reliability diagram, Brier, POD/FAR/CSI per lead time | `gmd-12-4185-2019.pdf`, p. 12; Han 2009, p. 10 | Ledger di previsioni/esiti: disponibile ma campione locale ancora limitato | **Applicabile soltanto dopo calibrazione** | La release conserva verifica e calibrazione shadow-first; WebGUI/Telegram mostrano un indice 0–100 finché la calibrazione non è attiva. |
| VIL Density, sviluppo sopra zero termico, 45/50/55 dBZ e persistenza | `2014_skrip_darez_hail.pdf`, pp. 3–5 | VIL, ETM, CAPPI, freezing level: disponibili; ETM non è l'altezza di una soglia di riflettività | **Applicabile dopo adattamento** | Le soglie pubblicate sono specifiche di radar/eventi esteri. LDZ le usa solo come evidenze limitate, con POH dominante e più frame; nessuna dimensione dei chicchi. |
| Hail detection single-pol e confronto con pioggia intensa | `remotesensing-11-01436-v2.pdf`, pp. 5, 9–11 | POH e prodotti single-pol disponibili; ground truth italiano parziale | **Applicabile soltanto dopo calibrazione** | Pioggia intensa e distanza radar producono falsi allarmi; la fusion non viene più chiamata “probabilità” se il candidato feedback non è validato. |
| HydroClass, ZDR column, KDP, ρHV e hail-size polarimetrico | `3_10_1_Radar-Related Topics 1_A Case Study of Hail Detection in Thunderstorms.pdf`, pp. 20–28; `remotesensing-11-01436-v2.pdf`, pp. 4–11 | Variabili Doppler/polarimetriche assenti | **Non applicabile con i dati attuali** | Nessuna implementazione e nessuna stima della dimensione dei chicchi. |
| Lightning Jump 2σ/3σ | `20090033131.pdf`, pp. 4 e 7 | Serie di flash-rate per cella e finestre confrontabili: LTG disponibile a cadenza 10 min, ma più rada dello studio | **Sperimentale / applicabile dopo adattamento** | Bassi conteggi e associazioni instabili aumentano i falsi allarmi. Implementati rate normalizzato, tre finestre baseline, completezza ≥75% e sospensione dopo split/merge; non è un avviso severo autonomo. |
| Deep learning / ConvLSTM | `2005.04988v1.pdf`, pp. 9–15 | Ampio dataset coerente, label e validazione fuori campione: non disponibili | **Non applicabile con i dati attuali** | Non implementato: rischio di overfit e falsa precisione superiore ai benefici dimostrabili. |

## Separazione delle grandezze

- Posizione e traiettoria derivano da oggetti radar, Kalman e optical flow.
- L'indice geometrico d'impatto è la quota ensemble/decision score; diventa percentuale dichiarata soltanto dopo calibrazione validata.
- La stabilità della previsione deriva da storia del track, residui, spread, svolte, split/merge e lead time.
- La confidenza dati deriva da disponibilità, freschezza, allineamento e proxy SITES; non corregge fisicamente il mosaico.
- L'indice grandine non è una probabilità; la probabilità viene esposta solo con calibrazione feedback attiva.
- Il potenziale severo resta distinto dalla grandine e dalla conferma al suolo.
- L'assenza di LTG non dimostra l'assenza di temporale.

## Validazione richiesta prima della release stabile

Replay italiani stratificati per stagione, area, distanza dalla rete radar e lead time; reliability diagram e Brier per target/lead; POD, FAR e CSI per impatto e grandine; analisi separata di pioggia intensa senza grandine; audit di split/merge e finestre LTG incomplete. Finché questi campioni non superano le soglie configurate, i valori pubblici restano indici metodologici e non percentuali calibrate.
