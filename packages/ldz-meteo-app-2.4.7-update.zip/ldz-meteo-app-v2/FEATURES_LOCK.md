# LDZ Meteo App 2.4.7 - Feature Lock / Anti-regression Checklist

## 2.4.7 Master Design Login lock

- Il master è una specifica geometrica; vietato sostituire la UI con l'immagine completa o reinterpretarne la composizione desktop.
- Il radar di login è solo scenografico e non può caricare `meteo-map.jpg`, `meteo.jpg`, target o celle reali.
- Spazio, Terra, atmosfera e sole restano presenti tramite l'asset locale separato `login-orbit.svg`.
- Nel primo viewport mobile devono comparire branding, titolo accesso, username, password, remember-me e pulsante.
- Autofill Chromium/WebKit/Firefox deve mantenere campo e testo nella palette scura cyan.
- CSRF, rate limiting, password hashing, remember-me, sessioni, logout e gestione errori restano invariati o più restrittivi.
- Radar sweep, glow, waveform, equalizzatore e indicatori rispettano `prefers-reduced-motion`.

## 2.4.6 Update Cockpit lock

- Il popup aggiornamenti è globale, interattivo e compare anche nella pagina Aggiornamenti.
- Check e download manuali non ricaricano la pagina; il popup mostra subito la release trovata.
- L'avanzamento usa fasi e percentuali reali; non simula percentuali quando una fase non è misurabile.
- L'installazione WebGUI parte in una unità systemd transitoria e continua durante il riavvio della WebGUI.
- Manuale non pianifica controlli; Oraria sceglie il minuto; Giornaliera l'orario; Settimanale giorno e orario.
- Ultimo e prossimo controllo restano visibili e ogni modifica alle preferenze viene salvata automaticamente.
- Login HUD V2 2.4.5 e relative protezioni restano invariati.

## 2.4.5 Login HUD V2 visual lock

- Desktop 16:9 mantiene le tre aree hero/radar/login e la barra inferiore a cinque moduli.
- Il radar resta rettangolare e non può essere mascherato in un oblò circolare.
- `meteo-map.jpg` è preferito per il pannello radar; `meteo.jpg` è solo fallback.
- Gli input devono restare scuri anche sotto autofill del browser.
- Nessun contatore target/celle può essere inventato prima dell'autenticazione.
- Animazioni HUD rispettano `prefers-reduced-motion`.
- CSRF, rate limiting, hash password, remember-me e sessioni restano invariati o più restrittivi.

## 2.4.4 futuristic login HUD lock

- La login resta una UI reale HTML/CSS/SVG/JS: vietato sostituirla con il concept raster completo come background.
- CSRF, rate limiting, password hashing, remember-me, cookie e redirect sicuri devono restare invariati o più restrittivi.
- Prima del login non vengono esposti target, celle, host, systemd, percorsi, token o diagnostica interna.
- Connessione e freschezza radar possono usare solo risorse pubbliche/sanitizzate; nessun numero meteorologico può essere inventato per scenografia.
- Sweep radar, waveform, equalizzatore e blip devono rispettare `prefers-reduced-motion`.
- `login-hud.css` e `login-hud.js` restano asset locali e devono essere inclusi integralmente nel pacchetto update.
- Desktop mantiene l'HUD esteso; tablet/mobile riorganizzano i pannelli senza compromettere il form di accesso.

## 2.4.3 immediate Telegram feedback lock

- Un solo servizio dedicato consuma `getUpdates`; il ciclo radar importa esclusivamente la coda locale e non compete con il listener.
- Ogni callback valido deve ricevere conferma rapida, rimozione dei pulsanti e messaggio persistente con la scelta registrata.
- Il callback deve essere accodato atomicamente prima della conferma e consolidato nello stato sotto `meteo-alert.lock`.
- La prima scelta è terminale, inclusa `ignored_not_on_site`; nessuna seconda scelta può sovrascriverla o duplicare il dataset.
- Firma HMAC, chat configurata, dimensioni bounded, file non symlink e permessi `0600` restano obbligatori.
- Il servizio `meteo-alert-telegram-feedback.service` deve essere installato, abilitato, monitorato e incluso nel rollback.

## 2.4.2 LDZ Update Network lock

- Nessun token, account, repository o URL configurabile nella WebGUI; il feed pubblico LDZ è fissato nell'installazione.
- Stable accetta soltanto versioni definitive; Beta accetta prerelease e stabili successive; nessun downgrade automatico tornando a Stable.
- Frequenza manuale/oraria/giornaliera/settimanale, download anticipato opzionale e installazione sempre esplicita.
- Feed e pacchetto vincolati da versione, nome, dimensione e SHA-256; verifica archivio, approvazione locale, backup e rollback preservati.
- Switch e radio custom devono restare accessibili da tastiera e non ricadere nelle checkbox native disallineate.
- Il pulsante Salva preferenze resta a larghezza contenuto su desktop e full-width solo su mobile.
- Gli errori del checker devono mostrare una causa utile; vietato il fallback generico “consulta lo stato updater”.

## 2.4.1 automatic updater lock

- GitHub Releases con repository fissato, supporto privato tramite token read-only mascherato e nessun URL controllabile dalla WebGUI.
- Frequenza manuale/oraria/giornaliera/settimanale, stable/beta, download automatico opzionale e installazione sempre manuale.
- Popup futuristico top-right con polling live e rinvio di 24 ore.
- Verifica archivio non privilegiata, approvazione Ed25519 locale senza argomenti, seconda verifica root-owned, backup e rollback.
- `WARNING ... HTTPError` non deve mai impostare il rischio su `Attenzione`; un vero livello `ERROR` deve continuare a farlo.

## 2.4.0 ground truth + event-driven lock

- WebSocket STOMP ufficiale Radar-DPC su `/topic/product`, VMI come trigger, timer fallback e lock non bloccante contro cicli doppi.
- LTG con cadenza 10 minuti, finestra dai timestamp reali, età rispetto all'ora corrente e blocco nuovi alert oltre 15 minuti.
- Simbolo fulmine vettoriale visibile con due età cromatiche, senza coprire il radar.
- Near-target basato sul bordo eco; pioggia intensa osservata o fulmini entro pochi km possono bypassare traiettoria e doppia conferma, ma solo con VMI forte e dati freschi.
- Pacchetto temporale unico e telemetria SITES: nessun prodotto vecchio viene presentato come simultaneo.
- Un solo incidente per cella/target vicini, con alert, escalation, downgrade e rientro deduplicati.
- Replay locale compresso, retention e limite disco; motivi e blocchi mostrati nella pagina Eventi & feedback.
- Callback Telegram firmati, chat verificata, opzione non sul posto esclusa dalla ground truth e nessun apprendimento da testo libero.
- Calibrazione grandine con split cronologico 70/30, minimo casi positivi/negativi, vantaggio Brier, guardia falsi negativi, influenza ≤25% e delta candidato ≤12 punti.
- Watchdog esterno con avviso di stallo e recupero; permessi eseguibili per l'utente `meteoalert`.
- Updater con required-file policy estesa, rollback integrale e migrazione conservativa dalla 2.3.7.

## 2.3.7 vertical hail + auto-login lock

- CAPPI_1–CAPPI_10 acquisiti esclusivamente tramite API ufficiale Radar-DPC, con controllo di freschezza rispetto al VMI.
- Profilo verticale 45/50/55 dBZ usato come correttore limitato; POH resta dominante.
- Nessun livello “grandine alta” con CAPPI disponibile ma verticale incompatibile, salvo fallback esplicito quando CAPPI manca.
- Evidenza CAPPI visibile negli alert Telegram iniziali e negli aggiornamenti, nella mappa e nella dashboard.
- Fallback senza CAPPI identico alla Hail Fusion preesistente, senza valori sintetici.
- Ricordami valido anche riaprendo direttamente `/login`; cookie legacy migrato e revocabile.
- Titolo “Stable Impact & Hail Fusion” privo di numero release storico.

## 2.3.6 lightning clarity + live ETA lock

- Alert fulmini Radar-DPC LGT autonomi dal flusso degli alert temporaleschi, senza duplicati sullo stesso target e ciclo.
- Aggiornamento conservativo della sorgente legacy `open_meteo` a `radar_dpc_lgt`.
- ETA corretto con l'età reale del frame; nessun avviso futuro per una finestra già scaduta.
- Probabilità conservativa quando tracking e coerenza sono deboli.
- Fascia 45–55 dBZ descritta come pioggia temporalesca intensa, distinta da temporale forte e nucleo molto intenso.
- Telegram con layout uniforme, significato della stabilità esplicito e nessun “da confermare”.
- Rientro collegato ai valori realmente notificati e classificato per esito.
- Pannello mappa “Situazione stimata” e telemetria LGT visibile.

## 2.3.5 clear radar messages lock

- Nessuna frase generica “cella forte, traiettoria incerta” nella tavola radar.
- Stato sempre riferito al target e alla fascia di probabilità disponibile.
- ETA con estremi uguali mostrata una sola volta.
- Etichette celle confinate all'area mappa, mai sopra il pannello sinistro.
- Rischio cella e grandine espressi in italiano; sigle tecniche solo nei dettagli dedicati.
- Motore Stable Impact & Hail Fusion 2.3.4 preservato senza modifiche scientifiche.

## 2.3.4 stable impact + hail lock

- Poligono del nucleo ≥55 dBZ distinto dall'inviluppo forte.
- Nessun 100% automatico per il solo contatto dell'alone.
- Due frame per gli alert urgenti, salvo nucleo realmente osservato sul target.
- Due frame negativi prima del messaggio di rientro.
- Hail Fusion con POH dominante, densità VIL, zero termico, persistenza, crescita, Lightning Jump e IR_108 a peso limitato.
- Probabilità grandine separata dalla qualità dei dati; nessuna stima arbitraria della dimensione.
- Alert Telegram con stima grandine e conferma temporale leggibili.

## 2.3.3 human alerts lock

- Alert iniziale con target, ETA, probabilità, intensità, grandine e consiglio operativo in apertura.
- Sezione “Perché ricevi questo avviso” con sigle spiegate e valori originali.
- Aggiornamenti compatti per escalation, downgrade e rientro.
- Caption Telegram completa e con tag HTML bilanciati entro 1.000 caratteri.
- Immagini radar desktop/mobile create e assegnate a `meteoalert` da installer, updater e repair.

Questa release hotfix deve preservare sempre tutte le funzioni già approvate nelle build precedenti.

## Installer / sicurezza
- Wizard con scelta: http / https-selfsigned / https-existing
- Hardening WebGUI nel wizard
- Host allowlist
- Origin/Referer check + CSRF
- Cookie HttpOnly/SameSite/Secure se HTTPS
- Security headers CSP/X-Frame-Options/X-Content-Type-Options/Referrer-Policy/Permissions-Policy/HSTS se HTTPS
- Root actions controllabili e sudoers limitato
- Repair web-safe da WebGUI
- Fix mod_ssl localhost.crt/localhost.key
- Referrer-Policy `strict-origin-when-cross-origin` per compatibilità OpenStreetMap
- Leaflet marker locali CSS (`L.divIcon`) per evitare fallback testuale Mark/Marker
- Leaflet JS/CSS servito localmente; nessuna dipendenza runtime da unpkg
- CSP script con nonce, senza `unsafe-inline`
- Login rate limit e logout POST con CSRF
- Ricordami persistente firmato, revocabile al logout/cambio password
- Update Ed25519 firmati e manifest schema 2 con hash per-file
- Backup/restore WebGUI data-only, senza codice o unità systemd
- Sudoers senza wildcard e transient service separato per il deploy
- Python 3.12, Flask 3.1.3, Waitress 3.0.2, Pillow 12.3.0
- Verifica permessi runtime come `meteoalert` prima del commit dell'update

## 2.3.2 national fusion lock
- NWP per cluster geografico, zero-config, con fallback radar-only
- Radar-DPC SRT1 e IR_108 opzionali e a peso limitato
- Ledger a slot/eventi con TP/FP/FN/TN e metriche probabilistiche
- Render desktop invariato più viste mobile Mappa/Dettagli

## Menu WebGUI
- Dashboard
- Target
- Aspetto
- Regole
- Telegram
- Template
- Canali
- Fulmini
- Storico
- Eventi & feedback
- Diagnostica
- Log
- Backup
- Manutenzione
- Aggiorna
- Sistema
- Kiosk
- Readiness

## Funzioni UI
- Temi: Dark Classic, Light Clean, Cyber Neon, Storm HUD
- Wallpaper JPG futuristici usati da tutti i temi, non solo dal tema Light
- Menu mobile a comparsa con descrizione breve per ogni sezione
- Dashboard smartphone ridisegnata: topbar mobile, sidebar drawer, card compatte
- Mappa radar su smartphone in contenitore scrollabile, già zoomata, navigabile con il dito e con pulsanti zoom +/-
- Target: ricerca città/località e click su mappa Leaflet/OpenStreetMap se asset esterni abilitati
- Alert Rules: ETA/preavviso, cooldown, VMI forte, VMI grandine, quiet hours
- Canali Notifica: webhook generico + Email SMTP
- Storico Alert: KPI, grafici, timeline eventi da alerts.log
- Telegram: stato bot + pulsanti test ordinati
- Manutenzione: checkbox con label/descrizione, non spunta isolata
- Aggiorna: upload ZIP, verifica struttura, staging e applicazione tramite script root limitato
- Readiness: inventario completo delle funzioni implementate
- Changelog: storico release dalla 1.0 alla versione corrente, con card responsive uniformi e visibile dalla sidebar WebGUI
- Login: opzione `Ricordami` esplicita; timeout inattività per sessione normale e limite assoluto per sessione persistente

## Fix logici
- `no alerts sent` e `detected cells=0` devono dare rischio Basso, non Moderato
- meteo.jpg deve avere pannello Monitoraggio non sovrapposto al footer
- DPC 503 deve essere temporaneo/non fatale per il timer
- Non perdere HTTPS/hardening, menu completo, repair, temi, storico, template, canali e fix già approvati nelle build successive

Questa checklist va verificata prima di consegnare qualsiasi ZIP successivo.


## Note build 2.2.3
- Sezione Aggiorna ottimizzata: upload ZIP, verifica integrità CRC/SHA256, controllo path traversal, riconoscimento struttura anche con cartella radice, applicazione automatica se valida, countdown e refresh WebGUI.
- Fix testo Manutenzione: rimosse note da changelog/dev e sostituite con descrizioni utente.
- Preservati layout mobile 2.2.1, drawer menu, radar zoomabile, wallpaper temi e hardening.


## Note build 2.2.3 Precision Hotfix
- Aggiunta probabilità stimata di impatto per target.
- Aggiunta conferma radar consecutiva per alert di avvicinamento non urgenti.
- Aggiunto messaggio di temporale in allontanamento / minaccia rientrata.
- Preservate le funzioni 2.2.2.


## Note sorgente completo 2.2.3
- Aggiunto `CHANGELOG.md` con storico release 1.0 → 2.2.5a.
- Aggiunta pagina WebGUI Changelog.
- Aggiunto `SOURCE_PACKAGE.md` con mappa del sorgente completo.


## 2.2.7 lock
- Mantenere sigle tecniche radar ma accompagnarle con testo parlante.
- Non rimuovere VMI/SRI/POH/VIL/ETM/LGT dagli alert o dalla WebGUI.
- Preservare tutti i fix LGT/render/UI/precisione delle build 2.2.5.

## 2.2.8 security lock

- Non reintrodurre update unsigned, hash-only o helper sudo con wildcard.
- Non consentire al backup WebGUI di ripristinare file eseguibili.
- Non inserire dati geocoding/target in `innerHTML` o handler inline.
- Non allargare `ReadWritePaths` della WebGUI a `/opt`, `/usr/local/sbin`, `/etc/systemd/system` o `/etc/sudoers.d`.
- Conservare limiti anti-ZIP bomb, snapshot anti-TOCTOU e rollback.

## 2.3.0 precision lock

- Conservare i track multi-frame e non contare due volte lo stesso timestamp Radar-DPC.
- Conservare forma della cella, optical flow e fallback lineare compatibile.
- La probabilità d'impatto deve derivare dalla geometria/ensemble; VMI/POH/VIL/ETM/LGT influenzano pericolosità e confidenza, non spostano la traiettoria.
- SRI deve restare nella lista prodotti e i prodotti con skew temporale eccessivo devono essere esclusi dalla fusione.
- ICON-2I è solo un prior debole, con cache e fallback radar-only; non deve rendere il ciclo dipendente da Open-Meteo.
- Conservare verifica hit/miss, Brier Score, campione minimo e calibrazione target-specifica.
- Conservare alert di escalation, downgrade e rientro con cooldown separati.
- Non inviare alert su frame VMI stale.
- Conservare pannello Precision Engine nella dashboard e controlli nella pagina Regole.
- Conservare installer shell futuristico anche in modalità non-TTY senza ANSI obbligatori.
- Conservare consenso NWP multi-modello come prior debole e fallback radar-only.
- Conservare correzione terreno limitata al 15% e separata dalla geometria della traiettoria.
- Non presentare Storm Initiation Watch come cella radar osservata o previsione certa.
- L'Adaptive AI deve partire in collection/shadow, richiedere verifiche cronologiche, casi positivi/negativi, almeno 12 eventi distinti e vantaggio Brier.
- Ogni candidato batch nuovo deve tornare shadow; vietati pickle/deserializzazione eseguibile e attivazione diretta.
- Conservare limiti su influenza, delta probabilistico, falsi negativi e circuit breaker verso shadow/suspended.
- Il trainer batch deve restare separato, non inviare alert e operare nel sandbox systemd dedicato.
