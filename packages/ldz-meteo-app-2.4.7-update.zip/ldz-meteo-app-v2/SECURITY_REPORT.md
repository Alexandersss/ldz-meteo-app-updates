# LDZ Meteo App 2.3.2 - Security Assessment and Remediation Report

Data verifica iniziale: 10 luglio 2026. Estensione National Fusion e persistenza login verificata: 20 luglio 2026. Baseline originale analizzata: `ldz-meteo-app-2.2.7-full-source`.

## Analisi della minaccia

### Esito sul presunto 0-day

Non è stata trovata evidenza pubblica di un 0-day specifico sfruttato contro LDZ Meteo App. “0-day” significa una vulnerabilità sconosciuta al produttore o priva di correzione: non è corretto usare questa etichetta per qualunque bug grave.

L’audit ha però confermato vulnerabilità applicative originali nella 2.2.7. Due consentivano a un attaccante già autenticato nella WebGUI di attraversare il confine `meteoalert → root`; non risultano CVE assegnate perché riguardano questo codice proprietario.

### F-01 — Update non autenticati con installazione root — Critica

**Vettore.** La WebGUI accettava qualunque ZIP con struttura riconoscibile. CRC e SHA-256 dimostravano solo che il file non era corrotto, non chi lo avesse prodotto. L’helper root copiava dal pacchetto `web/`, l’engine e tutti gli script `ldz-meteo-*` in `/usr/local/sbin`.

**Catena.** Credenziali WebGUI compromesse → upload di un archivio costruito dall’attaccante → `sudo ldz-meteo-apply-hotfix *` → installazione di helper controllati dall’attaccante → successiva esecuzione privilegiata.

**Amplificatori.** Sudoers con wildcard, assenza di firma, verifica ed estrazione sul file ancora modificabile da `meteoalert`, limiti solo sulla dimensione compressa, nessun rollback atomico e `ReadWritePaths` eccessivamente ampio.

**Impatto.** Esecuzione di codice root, modifica di servizi e regole sudo, furto dei token, persistenza, alterazione dei dati radar e indisponibilità completa.

### F-02 — Restore di backup capace di sostituire codice/systemd — Critica

**Vettore.** Un backup era ritenuto valido se conteneva `manifest.json` con `app: LDZ Meteo App`. Il restore root accettava anche `opt/meteo-alert/meteo_alert.py` e unità systemd.

**Catena.** Account WebGUI → upload di un falso backup → sostituzione dell’engine o del servizio → esecuzione al ciclo successivo del timer.

**Impatto.** Stesso impatto di F-01. Il manifest non era una firma e poteva essere creato dall’attaccante.

### F-03 — DOM-XSS geocoding/Leaflet — Alta

**Vettore.** `display_name` e altri campi restituiti da Nominatim erano concatenati in `innerHTML`; l’oggetto completo veniva inserito in un attributo `onclick` delimitato da apici. Un apice o markup appositamente costruito poteva interrompere il contesto previsto. Anche `bindPopup(String(t.name))` trattava il nome target come HTML.

**Impatto.** Script nella sessione amministrativa, lettura del DOM e del token CSRF, modifica configurazione e invocazione delle azioni dell’utente. Il cookie `HttpOnly` limita il furto diretto del cookie, ma non impedisce azioni same-origin.

### F-04 — Brute force e session hardening incompleto — Media

Non esisteva rate limiting. Il token CSRF anonimo veniva conservato dopo il login invece di ruotare con la sessione; logout era una GET. Le risposte autenticate non impostavano globalmente `Cache-Control: private, no-store`.

### F-05 — Archive bomb, collisioni e race TOCTOU — Alta

Il limite di 80 MB riguardava il solo ZIP. Mancavano limiti sul totale espanso, singola entry, rapporto di compressione e numero file; mancavano blocchi per symlink/file speciali, duplicati e collisioni case-insensitive. Il file caricato restava posseduto da `meteoalert` durante la verifica privilegiata.

### F-06 — SSRF/resource exhaustion nel motore — Media

URL webhook, SMTP, `radar.api_base` e URL raster restituiti dall’API potevano puntare a endpoint privati. Raster, layer LGT e tile non avevano tutti un limite esplicito prima del parsing. Un endpoint compromesso o una configurazione ostile potevano causare scansione interna, accesso a metadata service o consumo di memoria/disco.

### F-07 — Dipendenze troppo permissive — Alta

I requirement originali consentivano versioni oggi vulnerabili:

- Flask `<3.1.3` è interessato da CVE-2026-27205 in particolari scenari con cache e sessioni; fix 3.1.3: <https://github.com/pallets/flask/security/advisories/GHSA-68rp-wp8r-4726>.
- Waitress `<3.0.1` è vulnerabile a resource exhaustion, CVE-2024-49769; fix 3.0.1: <https://github.com/Pylons/waitress/security/advisories/GHSA-3f84-rpwh-47g6>.
- Pillow `>=10.3.0,<12.2.0` comprende CVE-2026-25990, CVE-2026-42311 e CVE-2026-40192. Pillow 12.3.0 include ulteriori correzioni del 1° luglio 2026: <https://pillow.readthedocs.io/en/stable/releasenotes/12.3.0.html>.

Il codice usa `yaml.safe_load`, quindi non è presente la classica RCE da deserializzazione PyYAML. Non esiste un database SQL nello stack: prepared statements non sono applicabili a questa release.

### F-08 — Integrità del nowcast e disponibilità del nuovo motore — Media

La 2.3.0 introduce stato persistente, cache raster, geometrie e un endpoint ICON-2I opzionale. Senza limiti, input numerici o cache ostili potrebbero causare consumo CPU/RAM, uso di dati stale o percentuali ingannevoli.

**Difese implementate.** History massimo 12 frame, ensemble massimo 256 membri, poligono massimo 96 vertici, passo temporale limitato, cache NPZ caricata con `allow_pickle=False`, size/shape/CRS/transform verificati, stato WebGUI limitato a 12 MiB, endpoint NWP HTTPS validato contro SSRF, redirect vietati, risposta JSON massima 2 MiB, cache atmosferica massima 1 MiB e fallback radar-only. I prodotti con skew superiore alla soglia non entrano nella fusione e un VMI stale sospende alert e calibrazione.

**Integrità statistica.** Lo stesso timestamp Radar-DPC non incrementa track o conferme consecutive. Le verifiche sono deduplicate per coppia target/track; la calibrazione parte solo dopo il campione minimo e ogni correzione empirica è limitata a ±15 punti percentuali.

### F-09 — Data poisoning o attivazione prematura dell’AI adattiva — Alta

**Vettore.** Dati radar anomali, sensori locali compromessi, un dataset manomesso o un candidato batch non validato potrebbero addestrare un modello distorto. Un’attivazione immediata potrebbe ridurre una probabilità corretta o aumentare falsi allarmi.

**Difese implementate.** Nessun `pickle` o modello eseguibile: feature, dataset, stato e candidati sono esclusivamente numeri/JSON limitati. Il modello viene valutato cronologicamente prima di aggiornare i pesi. Parte in `collection`, passa a `shadow` e richiede almeno 80 verifiche, 12 eventi distinti, 20 positivi, 20 negativi, miglioramento Brier minimo e limite sui falsi negativi. L’attivazione richiede una streak, parte con influenza 20%, ha limite assoluto 30% e delta massimo 18 punti. Ogni candidato batch torna obbligatoriamente shadow per almeno 25 verifiche successive; il circuit breaker sospende l’influenza se il Brier degrada.

Il trainer batch è un servizio oneshot separato: utente non privilegiato, `ProtectSystem=strict`, filesystem in sola lettura salvo directory dati/log, `NoNewPrivileges`, CPUQuota e MemoryMax. Non invia notifiche e non promuove autonomamente un modello operativo.

### F-10 — Input esterni terrain/NWP/sensori — Media

**Vettore.** Endpoint atmosferici o altimetrici compromessi, JSON sensore malformato, broker MQTT ostile o dati fisicamente impossibili possono causare SSRF, blocchi, consumo risorse o conferme meteorologiche false.

**Difese implementate.** Endpoint HTTPS validati, redirect disabilitati, limiti risposta/timeout/cache e fallback radar-only. Profili altimetrici limitati per distanza, coppie, campioni e cache; l’orografia modifica soltanto la sopravvivenza e al massimo del 15%. Sensori disabilitati per default, campi numerici finiti e limitati, età massima, target allowlist e peso massimo 15%; confermano ma non modificano il vettore di moto. MQTT usa TLS per default e credenziali solo da variabili d’ambiente. Lightning Jump considera una finestra recente limitata.

### F-11 — Persistenza login e indisponibilità post-update — Alta

**Vettori.** Un cookie “Ricordami” non firmato o non revocabile diventerebbe una credenziale permanente. Separatamente, l'`umask 077` dell'updater poteva propagare directory root-only in `/opt`: systemd falliva il `WorkingDirectory` e Apache mostrava 503.

**Difese implementate.** Il token persistente usa `URLSafeTimedSerializer` con salt dedicato, scadenza server-side, `Secure`, `HttpOnly`, `SameSite=Lax` e fingerprint dell'hash password; logout e password cambiata lo invalidano. Non contiene password. L'updater normalizza codice e virtualenv a `u=rwX,go=rX`, mantiene root come proprietario e verifica eseguibilità/lettura tramite `runuser -u meteoalert` prima del riavvio; un errore attiva il rollback.

## Codice fixato

### Confine update — spiegazione del flusso, istruzione per istruzione

File: `scripts/ldz-meteo-apply-hotfix`, `scripts/ldz-meteo-sign-update`, `web/security_utils.py`.

1. `umask 077` impedisce che snapshot, firme e file temporanei diventino leggibili da altri utenti.
2. La WebGUI scrive solo il basename selezionato in `pending-update`; sudo invoca l’helper senza argomenti, eliminando la wildcard.
3. L’helper verifica basename, file regolare, assenza di symlink e appartenenza alla directory staging tramite `realpath`.
4. `systemd-run` sposta il deploy fuori dal mount namespace read-only della WebGUI e crea un sandbox root separato con `ProtectSystem=strict` e una allowlist di percorsi scrivibili.
5. `install -o root -g root -m 600` crea uno snapshot immutabile dal punto di vista di `meteoalert`; tutte le verifiche successive lavorano su quello snapshot.
6. `openssl pkeyutl -verify ... -rawin` valida la firma Ed25519 detached con la chiave pubblica installata.
7. `security_utils.py verify-update` applica limiti di dimensione/entry/ratio, rifiuta traversal, backslash, symlink, file speciali, encryption, duplicati e collisioni case-insensitive.
8. Il manifest schema 2 deve elencare esattamente tutti i payload e il relativo SHA-256; hash mancanti, extra o non corrispondenti bloccano il pacchetto.
9. L’estrazione ricostruisce manualmente i file sotto lo staging e verifica con `commonpath` che nessun target esca dalla directory.
10. Il downgrade è bloccato per le richieste WebGUI. Un override è possibile solo da una shell root esplicita.
11. Prima del deploy vengono eseguiti `py_compile`, `bash -n`, creazione di virtualenv Python 3.12, installazione binary-only e `pip check`.
12. Il backup pre-update è obbligatorio. Una trap ripristina file e virtualenv se una fase di deploy fallisce.
13. Solo sei helper con nome esatto possono essere installati; non viene più usato il glob generico del pacchetto.
14. La sudoers finale non contiene `*`; il signer è mode `0700` e non compare nella sudoers WebGUI.

### Restore data-only

File: `web/app.py::write_backup_zip`, `scripts/ldz-meteo-restore-backup`.

1. L’export inserisce solo `config.yml` e, se richiesto, `secrets.env`.
2. Il manifest dichiara `type: configuration-backup`, `schema_version: 2` e lo SHA-256 esatto dei file.
3. La policy backup ammette tre soli path: manifest, config e secrets.
4. Dopo l’estrazione, `yaml.safe_load` richiede che config sia una mappa.
5. `secrets.env` accetta esclusivamente le tre chiavi previste e una grammatica senza newline.
6. L’installazione è atomica (`file.new` + `mv`) con owner/mode espliciti.
7. Nessuna riga del restore scrive più in `/opt` o `/etc/systemd/system`.

### DOM-XSS e CSP

File: `web/templates/targets.html`, `web/app.py::security_headers`.

1. I risultati geocoding vengono costruiti con `createElement`.
2. Tutti i valori remoti entrano in `textContent`, che non interpreta markup.
3. I pulsanti usano `data-result-index` e un listener registrato dal codice; nessun dato viene serializzato dentro `onclick`.
4. I popup Leaflet ricevono un nodo `<span>` con `textContent`, non una stringa HTML.
5. Leaflet 1.9.4 è servito da `/static/vendor/leaflet`.
6. Ogni script inline riceve un nonce casuale per risposta.
7. `script-src 'self' 'nonce-…'` rimuove `unsafe-inline` dagli script. `style-src` mantiene temporaneamente `unsafe-inline` perché la UI esistente usa stili dinamici inline non eseguibili.

### Autenticazione e input

File: `web/app.py::login`, `safe_text`, `save_upload_limited`.

- L’identità usa `hmac.compare_digest`; l’hash password viene comunque verificato per uniformare il percorso.
- Dopo 5 errori/15 minuti l’indirizzo è bloccato con HTTP 429.
- `session.clear()` ruota interamente sessione e CSRF; senza `Ricordami` vale il timeout inattività predefinito di 30 minuti. La modalità persistente è esplicita, usa lo stesso cookie firmato/HttpOnly/SameSite/Secure e impone un limite assoluto predefinito di 30 giorni.
- Logout è POST protetta da CSRF.
- Testi, filename e upload hanno limiti espliciti; la scrittura config usa fsync + replace atomico.

### Motore e rete

File: `engine/meteo_alert.py`.

- `validate_outbound_url/host` richiede HTTPS per default, risolve tutte le destinazioni e blocca indirizzi non globali salvo opt-in amministrativo.
- I webhook non seguono redirect; gli SMTP host passano la stessa policy IP.
- Raster: massimo 128 MiB di default, streaming contato, massimo 30 milioni di pixel e 16 bande.
- Precision Engine: history/ensemble/geometrie sono limitati; le cache NumPy non usano pickle e vengono validate prima del caricamento.
- ICON-2I usa un endpoint HTTPS validato, nessun redirect e cache locale; un errore esterno non interrompe il ciclo Radar-DPC.
- La probabilità geometrica resta separata dagli score di pericolosità, riducendo il rischio di presentare POH/VMI elevati come certezza d'impatto.
- Terrain e Lifecycle producono una probabilità di impatto significativo distinta dalla sola intersezione geometrica; la WebGUI mostra entrambe le componenti di confidenza senza chiamarle previsione ufficiale.
- Adaptive AI non può influire in collection/shadow/eligible/suspended; nuovi candidati vengono caricati solo da JSON numerico con schema e feature esatte.
- LGT: massimo 8 MiB. Tile OSM: massimo 2 MiB, solo PNG e dimensione esatta 256×256.
- Le risposte JSON Radar-DPC sono limitate a 2 MiB.

## Misure di mitigazione aggiuntive

- Pubblicare la WebGUI solo in HTTPS dietro VPN o access proxy con MFA; non esporre Waitress 8090.
- Applicare allowlist IP su Apache/firewall per le reti amministrative.
- Valutare ModSecurity + OWASP CRS in modalità detection, poi blocking dopo tuning; limitare in particolare `/login`, `/backup/restore` e `/update`.
- Inviare journal e audit di `sudo`, systemd transient unit e modifiche a `/etc/ldz-meteo-web` verso un SIEM.
- Proteggere la chiave privata update con backup cifrato root-only; ruotarla se il server è compromesso.
- Eseguire periodicamente `pip-audit` nei due virtualenv e patchare anche RPM/OpenSSL/Apache tramite il ciclo AlmaLinux/RHEL.
- Se servono webhook/SMTP privati, abilitare `network.allow_private_endpoints` solo dopo una allowlist di egress a livello firewall.
- Aggiungere MFA applicativa se la WebGUI deve essere raggiungibile senza access proxy.

## Test di validazione

### Suite automatica

```bash
./tests/run_tests.sh
```

Copre firma valida/tamper, traversal, ZIP bomb, hash mismatch, backup con systemd bloccato, sink DOM-XSS, sudoers wildcard, dependency floor, CSP, cache, rate limit, login, logout POST, cookie `Ricordami` e scadenza server-side delle sessioni.

### Payload innocui

- Nome target: `O'Brien <img src=x onerror=alert(1)>`. Deve comparire come testo e non creare nodi `img`.
- ZIP traversal: entry `../innocuo.txt`. La verifica deve rispondere “percorso ZIP non sicuro” e nessun file deve comparire fuori staging.
- Firma: aggiungere un byte allo ZIP dopo la firma. La UI deve mostrare “firma Ed25519 non valida”.
- Backup: aggiungere `etc/systemd/system/meteo-alert.service`. Il restore deve essere rifiutato prima di sudo.
- Brute force: dopo 5 password errate nello stesso intervallo, la richiesta successiva deve ottenere HTTP 429.

### Controlli post-installazione

```bash
sudo -u meteoalert sudo -n -l
systemctl cat ldz-meteo-web.service
stat -c '%U:%G %a %n' /etc/ldz-meteo-web/update-signing-*.pem
curl -kI https://HOST/ldzmeteoapp/login
```

Atteso: nessun comando sudo con wildcard; chiave privata `root:root 600`; WebGUI senza `ReadWritePaths` su `/opt`, `/usr/local/sbin`, systemd o sudoers; header CSP, HSTS, `nosniff` e `Cache-Control: private, no-store` presenti.
