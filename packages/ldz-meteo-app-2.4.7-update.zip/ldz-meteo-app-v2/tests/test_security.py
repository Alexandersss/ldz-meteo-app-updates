from __future__ import annotations

import hashlib
import importlib
import io
import json
import os
import re
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "web"
sys.path.insert(0, str(WEB))

from security_utils import (  # noqa: E402
    ArchivePolicyError,
    safe_extract,
    validate_archive,
    verify_update_signature,
)


def create_archive(path: Path, kind: str, payload: dict[str, bytes], root: str = "") -> None:
    manifest = {
        "app": "LDZ Meteo App",
        "type": "configuration-backup" if kind == "backup" else "signed-update",
        "schema_version": 2,
        "version": "2.3.0",
        "files": {name: hashlib.sha256(data).hexdigest() for name, data in payload.items()},
    }
    prefix = f"{root}/" if root else ""
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, data in payload.items():
            archive.writestr(prefix + name, data)
        archive.writestr(prefix + "manifest.json", json.dumps(manifest))


class ArchivePolicyTests(unittest.TestCase):
    def test_source_signer_binds_policy_and_script_to_archive_manifest(self) -> None:
        signer = (ROOT / "scripts/ldz-meteo-sign-update").read_text(encoding="utf-8")
        self.assertIn('"web/security_utils.py": source_root / "web/security_utils.py"', signer)
        self.assertIn(
            '"scripts/ldz-meteo-sign-update": source_root / "scripts/ldz-meteo-sign-update"',
            signer,
        )
        self.assertIn("actual != expected.lower()", signer)
        self.assertIn('SECURITY_TOOL="$SOURCE_SECURITY_TOOL"', signer)

    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.base = Path(self.temp.name)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def minimal_update(self) -> dict[str, bytes]:
        return {
            "web/app.py": b"APP_VERSION = '2.3.0'\n",
            "web/security_utils.py": b"# policy\n",
            "engine/meteo_alert.py": b"# engine\n",
            "engine/precision_engine.py": b"# precision engine\n",
            "engine/verification_engine.py": b"# complete verification engine\n",
            "engine/terrain_lifecycle.py": b"# terrain and lifecycle\n",
            "engine/adaptive_ai.py": b"# adaptive ai\n",
            "engine/adaptive_ai_trainer.py": b"# isolated trainer\n",
            "engine/event_feedback.py": b"# event feedback\n",
            "engine/telegram_feedback_listener.py": b"# immediate feedback listener\n",
            "engine/hail_feedback.py": b"# hail ground truth\n",
            "engine/radar_wss_listener.py": b"# official websocket\n",
            "scripts/ldz-meteo-apply-hotfix": b"#!/bin/bash\nexit 0\n",
            "scripts/ldz-meteo-update-check": b"#!/usr/bin/python3\n",
            "scripts/ldz-meteo-approve-update": b"#!/bin/bash\nexit 0\n",
            "scripts/ldz-meteo-watchdog": b"#!/usr/bin/python3\n",
        }

    def test_valid_rooted_update_and_safe_extract(self) -> None:
        package = self.base / "valid.zip"
        create_archive(package, "update", self.minimal_update(), root="ldz-meteo-app-2.3.0")
        result = validate_archive(package, "update")
        self.assertTrue(result["ok"])
        self.assertEqual(result["root_dir"], "ldz-meteo-app-2.3.0")
        destination = self.base / "out"
        safe_extract(package, destination, "update")
        self.assertTrue((destination / "web/app.py").is_file())

    def test_path_traversal_rejected(self) -> None:
        package = self.base / "traversal.zip"
        with zipfile.ZipFile(package, "w") as archive:
            archive.writestr("../outside", b"no")
            archive.writestr("manifest.json", b"{}")
        with self.assertRaises(ArchivePolicyError):
            validate_archive(package, "update")

    def test_zip_bomb_ratio_rejected(self) -> None:
        package = self.base / "bomb.zip"
        payload = self.minimal_update()
        payload["web/static/bomb.bin"] = b"0" * (4 * 1024 * 1024)
        create_archive(package, "update", payload)
        with self.assertRaisesRegex(ArchivePolicyError, "compressione"):
            validate_archive(package, "update")

    def test_hash_mismatch_rejected(self) -> None:
        package = self.base / "hash.zip"
        payload = self.minimal_update()
        manifest = {
            "app": "LDZ Meteo App",
            "type": "signed-update",
            "schema_version": 2,
            "version": "2.3.0",
            "files": {name: hashlib.sha256(data).hexdigest() for name, data in payload.items()},
        }
        manifest["files"]["web/app.py"] = "0" * 64
        with zipfile.ZipFile(package, "w", zipfile.ZIP_DEFLATED) as archive:
            for name, data in payload.items():
                archive.writestr(name, data)
            archive.writestr("manifest.json", json.dumps(manifest))
        with self.assertRaisesRegex(ArchivePolicyError, "non corrispondente"):
            validate_archive(package, "update")

    def test_backup_cannot_contain_executable_components(self) -> None:
        package = self.base / "backup.zip"
        create_archive(
            package,
            "backup",
            {
                "etc/meteo-alert/config.yml": b"app: {}\n",
                "etc/systemd/system/meteo-alert.service": b"[Service]\nExecStart=/bin/sh\n",
            },
        )
        with self.assertRaisesRegex(ArchivePolicyError, "non consentiti"):
            validate_archive(package, "backup")

    def test_ed25519_signature_accepts_original_and_rejects_tamper(self) -> None:
        package = self.base / "signed.zip"
        private = self.base / "private.pem"
        public = self.base / "public.pem"
        signature = self.base / "signed.zip.sig"
        create_archive(package, "update", self.minimal_update())
        subprocess.run(["openssl", "genpkey", "-algorithm", "ED25519", "-out", private], check=True)
        subprocess.run(["openssl", "pkey", "-in", private, "-pubout", "-out", public], check=True)
        subprocess.run(["openssl", "pkeyutl", "-sign", "-inkey", private, "-rawin", "-in", package, "-out", signature], check=True)
        self.assertTrue(verify_update_signature(package, signature, public)[0])
        package.write_bytes(package.read_bytes() + b"tamper")
        self.assertFalse(verify_update_signature(package, signature, public)[0])


class StaticRegressionTests(unittest.TestCase):
    def test_dom_xss_sinks_removed(self) -> None:
        target = (ROOT / "web/templates/targets.html").read_text(encoding="utf-8")
        self.assertNotIn("innerHTML", target)
        self.assertNotIn("onclick=", target)
        self.assertNotIn("unpkg.com", target)
        self.assertNotIn("bindPopup(String", target)

    def test_privileged_sudoers_has_no_wildcards(self) -> None:
        installer = (ROOT / "install.sh").read_text(encoding="utf-8")
        self.assertNotRegex(installer, r"ldz-meteo-(?:restore-backup|apply-hotfix|repair) \*")
        restore = (ROOT / "scripts/ldz-meteo-restore-backup").read_text(encoding="utf-8")
        self.assertNotIn("opt/meteo-alert/meteo_alert.py", restore)
        self.assertNotIn("etc/systemd/system", restore)

    def test_no_shell_true_or_unsafe_yaml_loader(self) -> None:
        source = "\n".join(
            path.read_text(encoding="utf-8")
            for path in (ROOT / "web/app.py", ROOT / "engine/meteo_alert.py")
        )
        self.assertNotIn("shell=True", source)
        self.assertNotRegex(source, r"yaml\.(?:unsafe_load|load)\(")

    def test_secure_dependency_floors(self) -> None:
        web_requirements = (ROOT / "web/requirements.txt").read_text()
        engine_requirements = (ROOT / "engine/requirements.txt").read_text()
        self.assertIn("Flask==3.1.3", web_requirements)
        self.assertIn("waitress==3.0.2", web_requirements)
        self.assertIn("Pillow==12.3.0", engine_requirements)

    def test_precision_engine_is_versioned_and_deployed_everywhere(self) -> None:
        installer = (ROOT / "install.sh").read_text(encoding="utf-8")
        updater = (ROOT / "scripts/ldz-meteo-apply-hotfix").read_text(encoding="utf-8")
        policy = (ROOT / "web/security_utils.py").read_text(encoding="utf-8")
        web = (ROOT / "web/app.py").read_text(encoding="utf-8")
        self.assertIn('APP_VERSION = "2.4.7"', web)
        self.assertIn("engine/precision_engine.py", policy)
        self.assertIn("engine/verification_engine.py", policy)
        self.assertIn("engine/terrain_lifecycle.py", policy)
        self.assertIn("engine/adaptive_ai.py", policy)
        self.assertIn("engine/adaptive_ai_trainer.py", policy)
        self.assertIn("engine/event_feedback.py", policy)
        self.assertIn("engine/telegram_feedback_listener.py", policy)
        self.assertIn("engine/hail_feedback.py", policy)
        self.assertIn("engine/radar_wss_listener.py", policy)
        self.assertIn("scripts/ldz-meteo-watchdog", policy)
        self.assertIn('engine/precision_engine.py" "$ENGINE_DIR/precision_engine.py', updater)
        self.assertIn('engine/verification_engine.py" "$ENGINE_DIR/verification_engine.py', updater)
        self.assertIn('engine/adaptive_ai_trainer.py" "$ENGINE_DIR/adaptive_ai_trainer.py', updater)
        self.assertIn("engine/meteo_alert.py engine/precision_engine.py", installer)

    def test_240_ground_truth_websocket_and_watchdog_are_operational(self) -> None:
        engine = (ROOT / "engine/meteo_alert.py").read_text(encoding="utf-8")
        feedback = (ROOT / "engine/event_feedback.py").read_text(encoding="utf-8")
        hail = (ROOT / "engine/hail_feedback.py").read_text(encoding="utf-8")
        installer = (ROOT / "install.sh").read_text(encoding="utf-8")
        updater = (ROOT / "scripts/ldz-meteo-apply-hotfix").read_text(encoding="utf-8")
        web = (ROOT / "web/app.py").read_text(encoding="utf-8")
        for token in ("near_target_observation_context", "build_temporal_bundle", "fetch_radar_sites_status", "send_due_feedback_prompts"):
            self.assertIn(token, engine)
        self.assertIn("hmac.compare_digest", feedback)
        self.assertIn("ignored_not_on_site", feedback)
        self.assertIn("validation_rows", hail)
        self.assertIn("candidate_fn <= baseline_fn", hail)
        self.assertIn("meteo-alert-radar-events.service", installer)
        self.assertIn("meteo-alert-watchdog.timer", installer)
        self.assertIn("group=meteoalert", updater)
        self.assertIn('route("/events-feedback")', web)

    def test_234_stable_impact_and_hail_defaults_are_migrated(self) -> None:
        installer = (ROOT / "install.sh").read_text(encoding="utf-8")
        updater = (ROOT / "scripts/ldz-meteo-apply-hotfix").read_text(encoding="utf-8")
        engine = (ROOT / "engine/meteo_alert.py").read_text(encoding="utf-8")
        for token in (
            "vmi_core_dbz: 55",
            "hail_min_persistence_frames: 2",
            "hail_high_min_data_quality: 65",
            "clear_consecutive_misses: 2",
            "observed_core_probability_percent: 97",
        ):
            self.assertIn(token, installer)
        for token in (
            'thresholds.setdefault("vmi_core_dbz", 55)',
            'multisignal.setdefault("hail_min_persistence_frames", 2)',
            'tracking.setdefault("clear_consecutive_misses", 2)',
        ):
            self.assertIn(token, updater)
        self.assertIn("target_clear_candidates", engine)
        self.assertIn("hail_data_quality_percent", engine)

    def test_mobile_radar_images_are_created_with_service_permissions(self) -> None:
        installer = (ROOT / "install.sh").read_text(encoding="utf-8")
        repair = (ROOT / "scripts/ldz-meteo-repair").read_text(encoding="utf-8")
        updater = (ROOT / "scripts/ldz-meteo-apply-hotfix").read_text(encoding="utf-8")
        self.assertIn("meteo-map.jpg", installer)
        self.assertIn("meteo-details.jpg", installer)
        for source in (repair, updater):
            self.assertIn("PUBLIC_MAP_IMAGE", source)
            self.assertIn("PUBLIC_DETAILS_IMAGE", source)
        for source in (installer, repair, updater):
            self.assertIn("meteoalert:meteoalert", source)
        self.assertIn("runuser -u meteoalert -- test -w", updater)

    def test_235_public_radar_copy_and_cell_labels_are_human_and_contained(self) -> None:
        engine = (ROOT / "engine/meteo_alert.py").read_text(encoding="utf-8")
        for wording in (
            "nucleo intenso rilevato",
            "temporale probabile",
            "avvicinamento possibile",
            "impatto poco probabile",
            "impatto molto improbabile",
            "temporale fuori traiettoria",
            "Nessun temporale intenso vicino ai target",
        ):
            self.assertIn(wording, engine)
        self.assertNotIn('radar_status = "Cella forte vista, traiettoria incerta"', engine)
        self.assertIn("annotation_clip=True", engine)
        self.assertIn("clip_on=True", engine)
        self.assertIn('"MEDIUM": "Moderata"', engine)
        self.assertIn("grandine radar", engine)

    def test_236_lightning_alerts_live_eta_and_legacy_source_are_deployed(self) -> None:
        installer = (ROOT / "install.sh").read_text(encoding="utf-8")
        updater = (ROOT / "scripts/ldz-meteo-apply-hotfix").read_text(encoding="utf-8")
        engine = (ROOT / "engine/meteo_alert.py").read_text(encoding="utf-8")
        web = (ROOT / "web/templates/lightning.html").read_text(encoding="utf-8")
        for token in (
            "notify_on_lightning: true",
            "alert_min_strikes: 2",
            "alert_urgent_radius_km: 8",
            "expired_eta_grace_minutes: 2",
            "confidence_shrinkage_enabled: true",
        ):
            self.assertIn(token, installer)
        self.assertIn('in {"", "open_meteo"}', updater)
        self.assertIn('lightning["source"] = "radar_dpc_lgt"', updater)
        self.assertIn("def evaluate_lightning_alerts(", engine)
        self.assertIn("def adjust_eta_for_data_age(", engine)
        self.assertIn("Situazione stimata", engine)
        self.assertIn('name="notify_on_lightning"', web)

    def test_237_cappi_vertical_hail_is_active_and_visible_in_telegram(self) -> None:
        installer = (ROOT / "install.sh").read_text(encoding="utf-8")
        updater = (ROOT / "scripts/ldz-meteo-apply-hotfix").read_text(encoding="utf-8")
        engine = (ROOT / "engine/meteo_alert.py").read_text(encoding="utf-8")
        dashboard = (ROOT / "web/templates/dashboard.html").read_text(encoding="utf-8")
        settings = (ROOT / "web/templates/settings.html").read_text(encoding="utf-8")
        self.assertIn("vertical_profile:", installer)
        self.assertIn("CAPPI_10", installer)
        self.assertIn('cfg.setdefault("vertical_profile", {})', updater)
        self.assertIn("cappi_vertical_hail_context", engine)
        self.assertIn("Profilo verticale radar:", engine)
        self.assertIn("active_in_hail_fusion", engine)
        self.assertIn("attivo nella stima grandine", dashboard)
        self.assertIn("vertical_profile_enabled", settings)

    def test_adaptive_ai_is_shadow_first_and_trainer_is_sandboxed(self) -> None:
        ai = (ROOT / "engine/adaptive_ai.py").read_text(encoding="utf-8")
        trainer = (ROOT / "engine/adaptive_ai_trainer.py").read_text(encoding="utf-8")
        installer = (ROOT / "install.sh").read_text(encoding="utf-8")
        self.assertNotIn("pickle", trainer)
        self.assertIn('ai["status"] = "shadow"', ai)
        self.assertIn("candidate_guard_events", ai)
        self.assertIn("ProtectSystem=strict", installer)
        self.assertIn("CPUQuota=35%", installer)
        self.assertIn("meteo-alert-ai-trainer.timer", installer)

    def test_229_bootstrap_modules_match_native_engine_modules(self) -> None:
        for name in ("adaptive_ai.py", "terrain_lifecycle.py", "verification_engine.py"):
            native = (ROOT / "engine" / name).read_bytes()
            bootstrap = (ROOT / "web" / "engine_compat" / name).read_bytes()
            self.assertEqual(native, bootstrap, f"bootstrap non sincronizzato: {name}")
        precision = (ROOT / "engine/precision_engine.py").read_text(encoding="utf-8")
        self.assertIn("signed-web-bootstrap", precision)

    def test_229_bootstrap_can_import_without_native_new_modules(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            isolated = Path(temp) / "engine"
            isolated.mkdir()
            (isolated / "precision_engine.py").write_bytes((ROOT / "engine/precision_engine.py").read_bytes())
            env = dict(os.environ)
            env["PYTHONPATH"] = os.pathsep.join(filter(None, [str(isolated), os.environ.get("PYTHONPATH", "")]))
            env["LDZ_METEO_COMPAT_MODULE_DIR"] = str(ROOT / "web/engine_compat")
            result = subprocess.run(
                [sys.executable, "-c", "import precision_engine as p; print(p.COMPAT_MODULE_SOURCE)"],
                env=env,
                capture_output=True,
                text=True,
            )
            if "No module named" in result.stderr and any(name in result.stderr for name in ("numpy", "scipy", "pyproj")):
                self.skipTest("dipendenze scientifiche non installate nel runner WebGUI")
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout.strip(), "signed-web-bootstrap")

    def test_precision_defaults_preserve_radar_as_primary_motion_source(self) -> None:
        installer = (ROOT / "install.sh").read_text(encoding="utf-8")
        self.assertIn("nwp_steering_weight: 0.10", installer)
        self.assertIn("optical_flow_weight: 0.30", installer)
        self.assertIn("require_consecutive_hits: 2", installer)
        self.assertIn("notify_on_lightning_plus_radar: false", installer)

    def test_hotfix_validates_helpers_with_the_correct_interpreter(self) -> None:
        updater = (ROOT / "scripts/ldz-meteo-apply-hotfix").read_text(encoding="utf-8")
        self.assertNotIn('for script in "$SRC"/scripts/ldz-meteo-*', updater)
        self.assertIn('"$SRC/scripts/ldz-meteo-get-chat-id"', updater)
        self.assertIn('"$PYTHON_BASE" -m py_compile', updater)

    def test_231_dashboard_uses_real_ai_gates_and_map_first_timeline(self) -> None:
        template = (ROOT / "web/templates/dashboard.html").read_text(encoding="utf-8")
        css = (ROOT / "web/static/app.css").read_text(encoding="utf-8")
        app = (ROOT / "web/app.py").read_text(encoding="utf-8")
        self.assertIn('class="ai-gauge-v231"', template)
        self.assertIn("ai_view.gates", template)
        self.assertNotIn("precision-orbit-v229", template)
        self.assertLess(template.index("dashboard-events-v222"), template.index("dashboard-side-v222"))
        self.assertIn(".dashboard-main-stack-v231", css)
        self.assertIn('"readiness_percent"', app)

    def test_fusion_panel_name_is_not_tied_to_an_old_release(self) -> None:
        for relative_path in ("web/templates/dashboard.html", "web/templates/settings.html"):
            template = (ROOT / relative_path).read_text(encoding="utf-8")
            self.assertIn("Stable Impact & Hail Fusion", template)
            self.assertNotIn("Stable Impact & Hail Fusion 2.3.4", template)

    def test_231_installs_and_checks_tar_before_backup(self) -> None:
        installer = (ROOT / "install.sh").read_text(encoding="utf-8")
        updater = (ROOT / "scripts/ldz-meteo-apply-hotfix").read_text(encoding="utf-8")
        self.assertIn("curl unzip tar sudo", installer)
        self.assertIn("command -v tar", updater)
        self.assertIn("dnf install -y tar", updater)
        self.assertNotIn("2>/dev/null\n[[ -s \"$BACKUP_TGZ\" ]]", updater)

    def test_232_updater_prevents_service_permission_regression(self) -> None:
        updater = (ROOT / "scripts/ldz-meteo-apply-hotfix").read_text(encoding="utf-8")
        self.assertIn('chmod -R u=rwX,go=rX "$WEB_DIR" "$ENGINE_DIR"', updater)
        self.assertIn('/usr/sbin/runuser -u meteoalert -- test -x "$WEB_DIR/venv/bin/python"', updater)
        self.assertIn('/usr/sbin/runuser -u meteoalert -- test -r "$WEB_DIR/app.py"', updater)

    def test_232_mobile_radar_uses_native_map_and_detail_views(self) -> None:
        template = (ROOT / "web/templates/dashboard.html").read_text(encoding="utf-8")
        engine = (ROOT / "engine/meteo_alert.py").read_text(encoding="utf-8")
        self.assertIn('data-radar-view="map"', template)
        self.assertIn('data-radar-view="details"', template)
        self.assertIn("generate_public_image_variants", engine)
        self.assertNotIn("let zoom = window.matchMedia", template)

    def test_changelog_uses_one_responsive_visual_system(self) -> None:
        template = (ROOT / "web/templates/changelog.html").read_text(encoding="utf-8")
        css = (ROOT / "web/static/app.css").read_text(encoding="utf-8")
        self.assertIn('class="changelog-page-v230"', template)
        self.assertIn(".changelog-page-v230 .timeline-v2 > div", css)
        self.assertIn(".changelog-page-v230 .help-grid-v222 > div", css)
        self.assertIn("@media (max-width: 680px)", css)


@unittest.skipUnless(importlib.util.find_spec("flask") and importlib.util.find_spec("werkzeug"), "Flask test dependencies not installed")
class FlaskSecurityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        from werkzeug.security import generate_password_hash

        cls.temp = tempfile.TemporaryDirectory()
        cls.base = Path(cls.temp.name)
        (cls.base / "config.yml").write_text("app: {}\ntargets: []\n", encoding="utf-8")
        (cls.base / "secrets.env").write_text("", encoding="utf-8")
        env_file = cls.base / "web.env"
        env_file.write_text(
            "\n".join(
                [
                    'LDZ_METEO_WEB_USERNAME="admin"',
                    f'LDZ_METEO_WEB_PASSWORD_HASH="{generate_password_hash("Correct-Horse-42")}"',
                    f'LDZ_METEO_WEB_SECRET_KEY="{"a" * 64}"',
                    f'LDZ_METEO_CONFIG="{cls.base / "config.yml"}"',
                    f'LDZ_METEO_SECRETS="{cls.base / "secrets.env"}"',
                    f'LDZ_METEO_BACKUP_DIR="{cls.base / "backups"}"',
                    f'LDZ_METEO_BACKUP_EXPORT_DIR="{cls.base / "exports"}"',
                    f'LDZ_METEO_RESTORE_UPLOAD_DIR="{cls.base / "uploads"}"',
                    f'LDZ_METEO_UPDATE_UPLOAD_DIR="{cls.base / "updates"}"',
                    f'LDZ_METEO_GEOCODE_CACHE="{cls.base / "geocode.json"}"',
                    f'LDZ_METEO_PENDING_UPDATE_FILE="{cls.base / "pending-update"}"',
                    f'LDZ_METEO_PENDING_RESTORE_FILE="{cls.base / "pending-restore"}"',
                    'LDZ_METEO_LOGIN_MAX_FAILURES="3"',
                    'LDZ_METEO_SESSION_MINUTES="30"',
                    'LDZ_METEO_REMEMBER_DAYS="30"',
                    'LDZ_METEO_ROOT_ACTIONS_ENABLED="false"',
                    'LDZ_METEO_PUBLIC_BASE_URL="https://meteo.example.test/ldzmeteoapp"',
                ]
            )
            + "\n",
            encoding="utf-8",
        )
        os.environ["LDZ_METEO_WEB_ENV"] = str(env_file)
        sys.modules.pop("app", None)
        cls.module = importlib.import_module("app")
        cls.module.app.config.update(TESTING=True)

    @classmethod
    def tearDownClass(cls) -> None:
        cls.temp.cleanup()

    @staticmethod
    def csrf(body: bytes) -> str:
        match = re.search(rb'name="_csrf_token" value="([^"]+)"', body)
        if not match:
            raise AssertionError("CSRF token non trovato")
        return match.group(1).decode()

    def test_csp_nonce_and_no_store(self) -> None:
        client = self.module.app.test_client()
        response = client.get("/login")
        csp = response.headers["Content-Security-Policy"]
        self.assertIn("script-src 'self' 'nonce-", csp)
        self.assertNotIn("script-src 'self' 'unsafe-inline'", csp)
        self.assertEqual(response.headers["Cache-Control"], "private, no-store, max-age=0")
        self.assertIn("Strict-Transport-Security", response.headers)

    def test_login_rotation_and_rate_limit(self) -> None:
        client = self.module.app.test_client()
        token = self.csrf(client.get("/login").data)
        for _ in range(3):
            response = client.post("/login", data={"_csrf_token": token, "username": "admin", "password": "wrong"})
            self.assertEqual(response.status_code, 200)
        limited = client.post("/login", data={"_csrf_token": token, "username": "admin", "password": "wrong"})
        self.assertEqual(limited.status_code, 429)

    def test_valid_login_and_logout_requires_post(self) -> None:
        self.module.LOGIN_FAILURES.clear()
        client = self.module.app.test_client()
        token = self.csrf(client.get("/login").data)
        response = client.post(
            "/login",
            data={"_csrf_token": token, "username": "admin", "password": "Correct-Horse-42"},
            follow_redirects=False,
        )
        self.assertEqual(response.status_code, 302)
        self.assertEqual(client.get("/logout").status_code, 405)
        new_token = self.csrf(client.get("/").data)
        self.assertEqual(client.post("/logout", data={"_csrf_token": new_token}).status_code, 302)

    def test_remember_me_controls_cookie_persistence(self) -> None:
        self.module.LOGIN_FAILURES.clear()
        short_client = self.module.app.test_client()
        token = self.csrf(short_client.get("/login").data)
        short_login = short_client.post(
            "/login",
            data={"_csrf_token": token, "username": "admin", "password": "Correct-Horse-42"},
            follow_redirects=False,
        )
        short_cookie = next(value for value in short_login.headers.getlist("Set-Cookie") if value.startswith("ldz_meteo_session="))
        self.assertNotIn("Expires=", short_cookie)
        with short_client.session_transaction() as auth_session:
            self.assertFalse(auth_session["remember_me"])
            self.assertFalse(auth_session.permanent)

        remembered_client = self.module.app.test_client()
        token = self.csrf(remembered_client.get("/login").data)
        remembered_login = remembered_client.post(
            "/login",
            data={
                "_csrf_token": token, "username": "admin", "password": "Correct-Horse-42",
                "remember_me": "1",
            },
            follow_redirects=False,
        )
        remembered_cookie = "\n".join(remembered_login.headers.getlist("Set-Cookie"))
        self.assertIn("Expires=", remembered_cookie)
        self.assertIn("Secure", remembered_cookie)
        self.assertIn("HttpOnly", remembered_cookie)
        self.assertIn("SameSite=Lax", remembered_cookie)
        self.assertIn("Path=/", remembered_cookie)
        with remembered_client.session_transaction() as auth_session:
            self.assertTrue(auth_session["remember_me"])
            self.assertTrue(auth_session.permanent)

    def test_signed_remember_cookie_restores_session_after_browser_restart(self) -> None:
        self.module.LOGIN_FAILURES.clear()
        first = self.module.app.test_client()
        token = self.csrf(first.get("/login").data)
        login = first.post(
            "/login",
            data={"_csrf_token": token, "username": "admin", "password": "Correct-Horse-42", "remember_me": "1"},
            follow_redirects=False,
        )
        cookies = "\n".join(login.headers.getlist("Set-Cookie"))
        match = re.search(r"ldz_meteo_remember=([^;]+)", cookies)
        self.assertIsNotNone(match)
        restarted = self.module.app.test_client()
        restarted.set_cookie("ldz_meteo_remember", match.group(1), path="/")
        response = restarted.get("/login", follow_redirects=False)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.headers["Location"], "/")
        dashboard = restarted.get("/", follow_redirects=False)
        self.assertEqual(dashboard.status_code, 200)
        with restarted.session_transaction() as auth_session:
            self.assertTrue(auth_session["logged_in"])
            self.assertTrue(auth_session["remember_me"])

    def test_radar_view_parameter_is_allowlisted(self) -> None:
        client = self.module.app.test_client()
        with client.session_transaction() as auth_session:
            now = int(self.module.time.time())
            auth_session.update(logged_in=True, username="admin", remember_me=False, auth_started_at=now, last_seen_at=now)
        self.assertEqual(client.get("/radar-image?view=invalid").status_code, 400)

    def test_session_time_limits_are_enforced_server_side(self) -> None:
        self.module.LOGIN_FAILURES.clear()
        client = self.module.app.test_client()
        token = self.csrf(client.get("/login").data)
        client.post(
            "/login",
            data={"_csrf_token": token, "username": "admin", "password": "Correct-Horse-42"},
            follow_redirects=False,
        )
        now = int(self.module.time.time())
        with client.session_transaction() as auth_session:
            auth_session["last_seen_at"] = now - self.module.SESSION_MINUTES * 60 - 1
        expired = client.get("/", follow_redirects=False)
        self.assertEqual(expired.status_code, 302)
        self.assertIn("/login", expired.headers["Location"])
        with client.session_transaction() as auth_session:
            self.assertNotIn("logged_in", auth_session)

        token = self.csrf(client.get("/login").data)
        client.post(
            "/login",
            data={
                "_csrf_token": token, "username": "admin", "password": "Correct-Horse-42",
                "remember_me": "1",
            },
            follow_redirects=False,
        )
        with client.session_transaction() as auth_session:
            auth_session["auth_started_at"] = now - self.module.REMEMBER_DAYS * 86400 - 1
            auth_session["last_seen_at"] = now
        expired = client.get("/", follow_redirects=False)
        self.assertEqual(expired.status_code, 302)
        with client.session_transaction() as auth_session:
            self.assertNotIn("logged_in", auth_session)

    def test_authenticated_routes_render(self) -> None:
        self.module.LOGIN_FAILURES.clear()
        client = self.module.app.test_client()
        token = self.csrf(client.get("/login").data)
        login = client.post(
            "/login",
            data={"_csrf_token": token, "username": "admin", "password": "Correct-Horse-42"},
            follow_redirects=False,
        )
        self.assertEqual(login.status_code, 302)
        original_run_cmd = self.module.run_cmd
        original_root_actions = self.module.ROOT_ACTIONS_ENABLED
        self.module.run_cmd = lambda command, timeout=45: (0, "inactive")
        self.module.ROOT_ACTIONS_ENABLED = True
        try:
            routes = [
                "/", "/targets", "/appearance", "/settings", "/telegram", "/templates",
                "/channels", "/lightning", "/history", "/events-feedback", "/logs", "/backup", "/maintenance",
                "/update", "/system", "/diagnostics", "/kiosk", "/guide", "/changelog",
            ]
            for route in routes:
                with self.subTest(route=route):
                    self.assertEqual(client.get(route).status_code, 200)
        finally:
            self.module.run_cmd = original_run_cmd
            self.module.ROOT_ACTIONS_ENABLED = original_root_actions

    def test_target_xss_payload_is_encoded(self) -> None:
        self.module.LOGIN_FAILURES.clear()
        client = self.module.app.test_client()
        token = self.csrf(client.get("/login").data)
        client.post(
            "/login",
            data={"_csrf_token": token, "username": "admin", "password": "Correct-Horse-42"},
            follow_redirects=False,
        )
        target_page = client.get("/targets")
        token = self.csrf(target_page.data)
        payload = "O'Brien <img src=x onerror=alert(1)>"
        response = client.post(
            "/targets/add-geocoded",
            data={"_csrf_token": token, "name": payload, "lat": "42.1", "lon": "14.1", "radius_km": "7"},
            follow_redirects=False,
        )
        self.assertEqual(response.status_code, 302)
        rendered = client.get("/targets").data.decode("utf-8")
        self.assertNotIn("<img src=x onerror=alert(1)>", rendered)
        self.assertTrue("&lt;img" in rendered or "\\u003cimg" in rendered)

    def test_config_save_preserves_existing_inode_and_permissions(self) -> None:
        config_path = self.module.CONFIG_PATH
        before = config_path.stat()
        cfg = self.module.load_config()
        cfg["save_regression_test"] = "ok"
        self.module.save_config(cfg)
        after = config_path.stat()
        self.assertEqual(after.st_ino, before.st_ino)
        self.assertEqual(after.st_mode, before.st_mode)
        self.assertEqual(self.module.load_config()["save_regression_test"], "ok")

    def test_add_target_repairs_null_targets_configuration(self) -> None:
        cfg = self.module.load_config()
        cfg["targets"] = None
        self.module.save_config(cfg)
        client = self.module.app.test_client()
        token = self.csrf(client.get("/login").data)
        client.post(
            "/login",
            data={"_csrf_token": token, "username": "admin", "password": "Correct-Horse-42"},
            follow_redirects=False,
        )
        token = self.csrf(client.get("/targets").data)
        response = client.post(
            "/targets/add-geocoded",
            data={"_csrf_token": token, "name": "Target test", "lat": "42.1", "lon": "14.1", "radius_km": "7"},
            follow_redirects=False,
        )
        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.module.load_config()["targets"][0]["name"], "Target test")

    def test_precision_settings_are_server_side_bounded(self) -> None:
        self.module.LOGIN_FAILURES.clear()
        client = self.module.app.test_client()
        token = self.csrf(client.get("/login").data)
        client.post(
            "/login",
            data={"_csrf_token": token, "username": "admin", "password": "Correct-Horse-42"},
            follow_redirects=False,
        )
        token = self.csrf(client.get("/settings").data)
        response = client.post(
            "/settings",
            data={
                "_csrf_token": token,
                "precision_enabled": "on",
                "verification_enabled": "on",
                "history_frames": "999",
                "ensemble_members": "99999",
                "optical_flow_weight": "4.5",
                "max_product_skew_minutes": "999",
                "min_alert_probability_percent": "101",
                "require_consecutive_hits": "99",
                "update_cooldown_minutes": "9999",
                "near_target_enabled": "on",
                "near_target_edge_margin_km": "999",
                "near_target_lightning_radius_km": "999",
                "event_feedback_enabled": "on",
                "feedback_prompt_delay_minutes": "9999",
                "event_replay_enabled": "on",
                "event_replay_retention_days": "9999",
                "hail_feedback_enabled": "on",
                "hail_feedback_auto_activate": "on",
                "hail_feedback_minimum_events": "99999",
                "hail_feedback_minimum_improvement": "999",
                "hail_feedback_guarded_influence": "5",
            },
            follow_redirects=False,
        )
        self.assertEqual(response.status_code, 302)
        cfg = self.module.load_config()
        precision = cfg["precision_engine"]
        tracking = cfg["tracking"]
        self.assertEqual(precision["history_frames"], 12)
        self.assertEqual(precision["ensemble_members"], 256)
        self.assertEqual(precision["optical_flow_weight"], 0.45)
        self.assertEqual(precision["max_product_skew_minutes"], 30)
        self.assertEqual(tracking["min_alert_probability_percent"], 99.0)
        self.assertEqual(tracking["require_consecutive_hits"], 5)
        self.assertEqual(tracking["update_cooldown_minutes"], 120)
        self.assertEqual(cfg["near_target_override"]["edge_margin_km"], 10.0)
        self.assertEqual(cfg["near_target_override"]["lightning_radius_km"], 10.0)
        self.assertEqual(cfg["event_feedback"]["prompt_delay_minutes"], 180)
        self.assertEqual(cfg["event_replay"]["retention_days"], 180)
        self.assertEqual(cfg["hail_feedback_calibration"]["minimum_events"], 1000)
        self.assertEqual(cfg["hail_feedback_calibration"]["minimum_brier_improvement_percent"], 50.0)
        self.assertEqual(cfg["hail_feedback_calibration"]["guarded_influence"], 0.25)


if __name__ == "__main__":
    unittest.main(verbosity=2)
