# LDZ Meteo App 2.6.0f - Feature Lock / Anti-regression Checklist

## 2.6.0f Human Alerts lock

- Gli avvisi Telegram devono usare “Cosa vede il radar” con pioggia, distanza, movimento ed evoluzione in linguaggio comune.
- dBZ e mm/h possono apparire come nota secondaria; VMI/SRI/POH non devono dominare un avviso operativo normale.
- Aggiornamenti e chiusure non devono mostrare “indice geometrico”, profilo verticale o stabilità tecnica salvo anomalia realmente rilevante.
- La richiesta feedback deve usare “Com'è andata?” e preservare integralmente firma HMAC, callback e opzioni di risposta.

## 2.6.0e Adaptive AI Quality lock

- Il candidato Adaptive AI deve partire dalla probabilità stabile e può apprendere soltanto una correzione residua limitata.
- Un candidato che non supera baseline, soglia Brier o limite falsi negativi nel holdout cronologico non può essere caricato dal runtime.
- Warm-up senza baseline e osservazioni dello stesso `track_id` su target diversi non possono gonfiare training o conteggio dei temporali distinti.
- La dashboard deve distinguere copertura dati e qualità senza rappresentare la mancata idoneità come avanzamento artificiale al 90%.

## 2.6.0d Strict Update Channels lock

- Una release stabile può aggiornare soltanto i feed Stabile; una prerelease può aggiornare soltanto i feed Beta.
- Il feed Beta deve avere `prerelease=true`; il feed Stabile deve avere `prerelease=false`.
- Il generatore e il client devono rifiutare qualsiasi feed con canale e tipo di release incoerenti.
- Il passaggio tra canali non può avviare un downgrade automatico.

## 2.6.0c Update Job Completion lock

- Il completamento di check, download e installazione deve essere deduplicato per `job_id`; la sola versione non identifica un'operazione.
- Due check consecutivi della stessa release devono mostrare entrambi lo stato terminale e chiudere la progressione intermedia.
- Ogni processo asincrono deve avere un limite assoluto e produrre un errore terminale leggibile se lo supera.

## 2.6.0b Resilient Update Core lock

- Check manuale, scansione iniziale e download devono restare asincroni: nessuna route WebGUI può occupare il worker per l'intera operazione.
- Ogni job interattivo conserva lo stesso `job_id`; uno stato appartenente a un'altra operazione non può cambiare il popup attivo.
- L'assenza temporanea della WebGUI durante il riavvio è `reconnecting`, non `error`; il completamento richiede la corrispondenza della versione runtime.
- Il polling live non può lanciare `systemctl` a ogni richiesta e deve avere timeout/retry senza richieste sovrapposte.
- La console update resta responsive, leggibile, utilizzabile con `prefers-reduced-motion` e priva di progressi inventati.

## 2.6.0a Stable Quality revision lock

- La release resta nella linea stabile 2.6; nessuna funzione può essere presentata come 2.7 o come aumento di accuratezza non dimostrato.
- Le analisi SHI/POSH e raster restano shadow/non calibrate finché il replay italiano non supera una validazione dichiarata.
- Redirect e URL locali devono conservare `/ldzmeteoapp` anche senza header proxy; nessun form può reintrodurre un path root assoluto.
- Tutte le pagine operative devono restare prive di testo sotto 12 px, overflow orizzontale e controlli sovrapposti nelle viewport 360–2560 px.

## 2.6.0 Stable and revision compatibility lock

- L'ordine deve restare `2.6.0-beta.2 < 2.6.0 < 2.6.0a < 2.6.0b < 2.6.0c < 2.6.0d < 2.6.0e < 2.6.0f`; le lettere post-stabile non sono prerelease alpha.
- I client 2.5.x devono continuare a ricevere una 2.6.0 validabile dal feed legacy prima di passare ai feed v2 revision-aware.
- Le revisioni letterali aggiornano soltanto `stable-v2`; non possono sostituire né i feed Beta né il feed legacy con un formato incoerente.
- Il controllo downgrade deve impedire il ritorno da una revisione letterale alla 2.6.0 base.

## 2.6.0-beta.2 Update Compatibility lock

- Il pacchetto operativo deve essere validabile dalla policy top-level già distribuita con la 2.5.3.
- Le note scientifiche versionate appartengono al sorgente completo e non devono entrare nello ZIP update.
- La compatibilità non può essere ottenuta ampliando dinamicamente l'allowlist del client già installato.

## 2.6.0-beta.1 Scientific Quality lock

- Disponibilità, freschezza, allineamento, copertura SITES e limiti fisici non valutati restano grandezze distinte; il proxy non può essere rinominato qualità radar per pixel.
- Split, merge, svolte e pochi frame devono degradare stabilità e/o ampliare ETA senza spostare artificialmente la cella.
- Un valore grandine combinato non può essere mostrato come percentuale finché la calibrazione feedback non è attiva e validata.
- POH, indice di evidenza, confidenza dati, potenziale severo e conferma al suolo non possono essere fusi in un'unica certezza.
- Lightning Jump richiede finestre confrontabili e associazione stabile; slot mancanti o split/merge non possono attivare il jump.
- L'assenza di LTG non equivale all'assenza certa di temporale e la sola riflettività elevata non equivale a grandine.

## 2.5.1 Management Completion lock

- Filtri temporali/tipo, paginazione e refresh live non possono tornare a controlli soltanto grafici.
- Restore deve conservare backup pre-ripristino, progress, verifica servizi e rollback registrato.
- Template, canali, Diagnostica e Kiosk devono mostrare stato proveniente dal backend, mai valori inventati.

## 2.5.0 Management & Operations lock

- Backup pianificati con timezone `Europe/Rome`, lock single-flight, ZIP atomico, manifest/checksum e retention automatica; restore limitato a config/secrets con anteprima, pre-backup e rollback.
- Manutenzione deve rispondere `503` a pagine/API visitatore, lasciare il login raggiungibile e mostrare il bypass all'amministratore autenticato.
- Stato sistema e diagnostica devono leggere runtime reale; un toggle di configurazione non equivale mai a unità installata, enabled o active.
- Template conservano CRUD/duplica/elimina/attiva/reset, validazione variabili, anteprima live e test.
- SMTP e webhook restano testabili con TLS/STARTTLS, timeout, errori sanitizzati, HTTPS, blocco SSRF e redirect disabilitati.
- Storico, log e feedback sono bounded, filtrati e paginati lato server; export e UI non espongono segreti.
- Updater usa timezone esplicita, controllo iniziale dopo modifiche significative, lock single-flight e stati distinti per tentativo, successo e notifica.
- `schedule_activated_epoch` non può simulare un controllo né rinviare la prima scansione; l'installazione resta sempre manuale.
- Popup globale supporta installazione POST, snooze version-bound 1/6/24 ore, retry/dettagli e progress stale; le unità transitorie devono avere nomi univoci.
- Login usa un asset locale con Italia riconoscibile; i vecchi tracciati informi sono esclusi dal rendering e Connessione/Data stream mantengono animazioni pulite con reduced-motion.

## 2.4.7 Master Design Login lock

- Il master è una specifica geometrica; vietato sostituire la UI con l'immagine completa o reinterpretarne la composizione desktop.
- Il radar di login è solo scenografico e non può caricare `meteo-map.jpg`, `meteo.jpg`, target o celle reali.
- Spazio, Terra, atmosfera e sole restano presenti tramite l'asset locale separato `login-orbit.svg`.
- Nel primo viewport mobile devono comparire branding, titolo accesso, username, password, remember-me e pulsante.
- Autofill Chromium/WebKit/Firefox deve mantenere campo e testo nella palette scura cyan.
- CSRF, rate limiting, password hashing, remember-me, sessioni, logout e gestione errori restano invariati o più restrittivi.
- Radar sweep, glow, waveform, equalizzatore e indicatori rispettano `prefers-reduced-motion`.

## 2.4.6 Update Cockpit lock

- Il popup aggiornamenti è globale, interattivo e compare anche nella pagina Aggiornamenti.
- Check e download manuali non ricaricano la pagina; il popup mostra subito la release trovata.
- L'avanzamento usa fasi e percentuali reali; non simula percentuali quando una fase non è misurabile.
- L'installazione WebGUI parte in una unità systemd transitoria e continua durante il riavvio della WebGUI.
- Manuale non pianifica controlli; Oraria sceglie il minuto; Giornaliera l'orario; Settimanale giorno e orario.
- Ultimo e prossimo controllo restano visibili; dalla 2.5.0 le modifiche vengono applicate con un unico salvataggio esplicito.
- Login HUD V2 2.4.5 e relative protezioni restano invariati.

## 2.4.5 Login HUD V2 visual lock

- Desktop 16:9 mantiene le tre aree hero/radar/login e la barra inferiore a cinque moduli.
- Il radar resta rettangolare e non può essere mascherato in un oblò circolare.
- `meteo-map.jpg` è preferito per il pannello radar; `meteo.jpg` è solo fallback.
- Gli input devono restare scuri anche sotto autofill del browser.
- Nessun contatore target/celle può essere inventato prima dell'autenticazione.
- Animazioni HUD rispettano `prefers-reduced-motion`.
- CSRF, rate limiting, hash password, remember-me e sessioni restano invariati o più restrittivi.

## 2.4.4 futuristic login HUD lock

- La login resta una UI reale HTML/CSS/SVG/JS: vietato sostituirla con il concept raster completo come background.
- CSRF, rate limiting, password hashing, remember-me, cookie e redirect sicuri devono restare invariati o più restrittivi.
- Prima del login non vengono esposti target, celle, host, systemd, percorsi, token o diagnostica interna.
- Connessione e freschezza radar possono usare solo risorse pubbliche/sanitizzate; nessun numero meteorologico può essere inventato per scenografia.
- Sweep radar, waveform, equalizzatore e blip devono rispettare `prefers-reduced-motion`.
- `login-hud.css` e `login-hud.js` restano asset locali e devono essere inclusi integralmente nel pacchetto update.
- Desktop mantiene l'HUD esteso; tablet/mobile riorganizzano i pannelli senza compromettere il form di accesso.

## 2.4.3 immediate Telegram feedback lock

- Un solo servizio dedicato consuma `getUpdates`; il ciclo radar importa esclusivamente la coda locale e non compete con il listener.
- Ogni callback valido deve ricevere conferma rapida, rimozione dei pulsanti e messaggio persistente con la scelta registrata.
- Il callback deve essere accodato atomicamente prima della conferma e consolidato nello stato sotto `meteo-alert.lock`.
- La prima scelta è terminale, inclusa `ignored_not_on_site`; nessuna seconda scelta può sovrascriverla o duplicare il dataset.
- Firma HMAC, chat configurata, dimensioni bounded, file non symlink e permessi `0600` restano obbligatori.
- Il servizio `meteo-alert-telegram-feedback.service` deve essere installato, abilitato, monitorato e incluso nel rollback.

## 2.4.2 LDZ Update Network lock

- Nessun token, account, repository o URL configurabile nella WebGUI; il feed pubblico LDZ è fissato nell'installazione.
- Stable accetta soltanto versioni definitive; Beta accetta soltanto prerelease; nessun downgrade automatico cambiando canale.
- Frequenza manuale/oraria/giornaliera/settimanale, download anticipato opzionale e installazione sempre esplicita.
- Feed e pacchetto vincolati da versione, nome, dimensione e SHA-256; verifica archivio, approvazione locale, backup e rollback preservati.
- Switch e radio custom devono restare accessibili da tastiera e non ricadere nelle checkbox native disallineate.
- Il pulsante Salva preferenze resta a larghezza contenuto su desktop e full-width solo su mobile.
- Gli errori del checker devono mostrare una causa utile; vietato il fallback generico “consulta lo stato updater”.

## 2.4.1 automatic updater lock

- GitHub Releases con repository fissato, supporto privato tramite token read-only mascherato e nessun URL controllabile dalla WebGUI.
- Frequenza manuale/oraria/giornaliera/settimanale, stable/beta, download automatico opzionale e installazione sempre manuale.
- Popup futuristico top-right con polling live e rinvio di 24 ore.
- Verifica archivio non privilegiata, approvazione Ed25519 locale senza argomenti, seconda verifica root-owned, backup e rollback.
- `WARNING ... HTTPError` non deve mai impostare il rischio su `Attenzione`; un vero livello `ERROR` deve continuare a farlo.

## 2.4.0 ground truth + event-driven lock

- WebSocket STOMP ufficiale Radar-DPC su `/topic/product`, VMI come trigger, timer fallback e lock non bloccante contro cicli doppi.
- LTG con cadenza 10 minuti, finestra dai timestamp reali, età rispetto all'ora corrente e blocco nuovi alert oltre 15 minuti.
- Simbolo fulmine vettoriale visibile con due età cromatiche, senza coprire il radar.
- Near-target basato sul bordo eco; pioggia intensa osservata o fulmini entro pochi km possono bypassare traiettoria e doppia conferma, ma solo con VMI forte e dati freschi.
- Pacchetto temporale unico e telemetria SITES: nessun prodotto vecchio viene presentato come simultaneo.
- Un solo incidente per cella/target vicini, con alert, escalation, downgrade e rientro deduplicati.
- Replay locale compresso, retention e limite disco; motivi e blocchi mostrati nella pagina Eventi & feedback.
- Callback Telegram firmati, chat verificata, opzione non sul posto esclusa dalla ground truth e nessun apprendimento da testo libero.
- Calibrazione grandine con split cronologico 70/30, minimo casi positivi/negativi, vantaggio Brier, guardia falsi negativi, influenza ≤25% e delta candidato ≤12 punti.
- Watchdog esterno con avviso di stallo e recupero; permessi eseguibili per l'utente `meteoalert`.
- Updater con required-file policy estesa, rollback integrale e migrazione conservativa dalla 2.3.7.

## 2.3.7 vertical hail + auto-login lock

- CAPPI_1–CAPPI_10 acquisiti esclusivamente tramite API ufficiale Radar-DPC, con controllo di freschezza rispetto al VMI.
- Profilo verticale 45/50/55 dBZ usato come correttore limitato; POH resta dominante.
- Nessun livello “grandine alta” con CAPPI disponibile ma verticale incompatibile, salvo fallback esplicito quando CAPPI manca.
- Evidenza CAPPI visibile negli alert Telegram iniziali e negli aggiornamenti, nella mappa e nella dashboard.
- Fallback senza CAPPI identico alla Hail Fusion preesistente, senza valori sintetici.
- Ricordami valido anche riaprendo direttamente `/login`; cookie legacy migrato e revocabile.
- Titolo “Stable Impact & Hail Fusion” privo di numero release storico.

## 2.3.6 lightning clarity + live ETA lock

- Alert fulmini Radar-DPC LGT autonomi dal flusso degli alert temporaleschi, senza duplicati sullo stesso target e ciclo.
- Aggiornamento conservativo della sorgente legacy `open_meteo` a `radar_dpc_lgt`.
- ETA corretto con l'età reale del frame; nessun avviso futuro per una finestra già scaduta.
- Probabilità conservativa quando tracking e coerenza sono deboli.
- Fascia 45–55 dBZ descritta come pioggia temporalesca intensa, distinta da temporale forte e nucleo molto intenso.
- Telegram con layout uniforme, significato della stabilità esplicito e nessun “da confermare”.
- Rientro collegato ai valori realmente notificati e classificato per esito.
- Pannello mappa “Situazione stimata” e telemetria LGT visibile.

## 2.3.5 clear radar messages lock

- Nessuna frase generica “cella forte, traiettoria incerta” nella tavola radar.
- Stato sempre riferito al target e alla fascia di probabilità disponibile.
- ETA con estremi uguali mostrata una sola volta.
- Etichette celle confinate all'area mappa, mai sopra il pannello sinistro.
- Rischio cella e grandine espressi in italiano; sigle tecniche solo nei dettagli dedicati.
- Motore Stable Impact & Hail Fusion 2.3.4 preservato senza modifiche scientifiche.

## 2.3.4 stable impact + hail lock

- Poligono del nucleo ≥55 dBZ distinto dall'inviluppo forte.
- Nessun 100% automatico per il solo contatto dell'alone.
- Due frame per gli alert urgenti, salvo nucleo realmente osservato sul target.
- Due frame negativi prima del messaggio di rientro.
- Hail Fusion con POH dominante, densità VIL, zero termico, persistenza, crescita, Lightning Jump e IR_108 a peso limitato.
- Probabilità grandine separata dalla qualità dei dati; nessuna stima arbitraria della dimensione.
- Alert Telegram con stima grandine e conferma temporale leggibili.

## 2.3.3 human alerts lock

- Alert iniziale con target, ETA, probabilità, intensità, grandine e consiglio operativo in apertura.
- Sezione “Perché ricevi questo avviso” con sigle spiegate e valori originali.
- Aggiornamenti compatti per escalation, downgrade e rientro.
- Caption Telegram completa e con tag HTML bilanciati entro 1.000 caratteri.
- Immagini radar desktop/mobile create e assegnate a `meteoalert` da installer, updater e repair.

Questa release hotfix deve preservare sempre tutte le funzioni già approvate nelle build precedenti.

## Installer / sicurezza
- Wizard con scelta: http / https-selfsigned / https-existing
- Hardening WebGUI nel wizard
- Host allowlist
- Origin/Referer check + CSRF
- Cookie HttpOnly/SameSite/Secure se HTTPS
- Security headers CSP/X-Frame-Options/X-Content-Type-Options/Referrer-Policy/Permissions-Policy/HSTS se HTTPS
- Root actions controllabili e sudoers limitato
- Repair web-safe da WebGUI
- Fix mod_ssl localhost.crt/localhost.key
- Referrer-Policy `strict-origin-when-cross-origin` per compatibilità OpenStreetMap
- Leaflet marker locali CSS (`L.divIcon`) per evitare fallback testuale Mark/Marker
- Leaflet JS/CSS servito localmente; nessuna dipendenza runtime da unpkg
- CSP script con nonce, senza `unsafe-inline`
- Login rate limit e logout POST con CSRF
- Ricordami persistente firmato, revocabile al logout/cambio password
- Update Ed25519 firmati e manifest schema 2 con hash per-file
- Backup/restore WebGUI data-only, senza codice o unità systemd
- Sudoers senza wildcard e transient service separato per il deploy
- Python 3.12, Flask 3.1.3, Waitress 3.0.2, Pillow 12.3.0
- Verifica permessi runtime come `meteoalert` prima del commit dell'update

## 2.3.2 national fusion lock
- NWP per cluster geografico, zero-config, con fallback radar-only
- Radar-DPC SRT1 e IR_108 opzionali e a peso limitato
- Ledger a slot/eventi con TP/FP/FN/TN e metriche probabilistiche
- Render desktop invariato più viste mobile Mappa/Dettagli

## Menu WebGUI
- Dashboard
- Target
- Aspetto
- Regole
- Telegram
- Template
- Canali
- Fulmini
- Storico
- Eventi & feedback
- Diagnostica
- Log
- Backup
- Manutenzione
- Aggiorna
- Sistema
- Kiosk
- Readiness

## Funzioni UI
- Temi: Dark Classic, Light Clean, Cyber Neon, Storm HUD
- Wallpaper JPG futuristici usati da tutti i temi, non solo dal tema Light
- Menu mobile a comparsa con descrizione breve per ogni sezione
- Dashboard smartphone ridisegnata: topbar mobile, sidebar drawer, card compatte
- Mappa radar su smartphone in contenitore scrollabile, già zoomata, navigabile con il dito e con pulsanti zoom +/-
- Target: ricerca città/località e click su mappa Leaflet/OpenStreetMap se asset esterni abilitati
- Alert Rules: ETA/preavviso, cooldown, VMI forte, VMI grandine, quiet hours
- Canali Notifica: webhook generico + Email SMTP
- Storico Alert: KPI, grafici, timeline eventi da alerts.log
- Telegram: stato bot + pulsanti test ordinati
- Manutenzione: checkbox con label/descrizione, non spunta isolata
- Aggiorna: upload ZIP, verifica struttura, staging e applicazione tramite script root limitato
- Readiness: inventario completo delle funzioni implementate
- Changelog: storico release dalla 1.0 alla versione corrente, con card responsive uniformi e visibile dalla sidebar WebGUI
- Login: opzione `Ricordami` esplicita; timeout inattività per sessione normale e limite assoluto per sessione persistente

## Fix logici
- `no alerts sent` e `detected cells=0` devono dare rischio Basso, non Moderato
- meteo.jpg deve avere pannello Monitoraggio non sovrapposto al footer
- DPC 503 deve essere temporaneo/non fatale per il timer
- Non perdere HTTPS/hardening, menu completo, repair, temi, storico, template, canali e fix già approvati nelle build successive

Questa checklist va verificata prima di consegnare qualsiasi ZIP successivo.


## Note build 2.2.3
- Sezione Aggiorna ottimizzata: upload ZIP, verifica integrità CRC/SHA256, controllo path traversal, riconoscimento struttura anche con cartella radice, applicazione automatica se valida, countdown e refresh WebGUI.
- Fix testo Manutenzione: rimosse note da changelog/dev e sostituite con descrizioni utente.
- Preservati layout mobile 2.2.1, drawer menu, radar zoomabile, wallpaper temi e hardening.


## Note build 2.2.3 Precision Hotfix
- Aggiunta probabilità stimata di impatto per target.
- Aggiunta conferma radar consecutiva per alert di avvicinamento non urgenti.
- Aggiunto messaggio di temporale in allontanamento / minaccia rientrata.
- Preservate le funzioni 2.2.2.


## Note sorgente completo 2.2.3
- Aggiunto `CHANGELOG.md` con storico release 1.0 → 2.2.5a.
- Aggiunta pagina WebGUI Changelog.
- Aggiunto `SOURCE_PACKAGE.md` con mappa del sorgente completo.


## 2.2.7 lock
- Mantenere sigle tecniche radar ma accompagnarle con testo parlante.
- Non rimuovere VMI/SRI/POH/VIL/ETM/LGT dagli alert o dalla WebGUI.
- Preservare tutti i fix LGT/render/UI/precisione delle build 2.2.5.

## 2.2.8 security lock

- Non reintrodurre update unsigned, hash-only o helper sudo con wildcard.
- Non consentire al backup WebGUI di ripristinare file eseguibili.
- Non inserire dati geocoding/target in `innerHTML` o handler inline.
- Non allargare `ReadWritePaths` della WebGUI a `/opt`, `/usr/local/sbin`, `/etc/systemd/system` o `/etc/sudoers.d`.
- Conservare limiti anti-ZIP bomb, snapshot anti-TOCTOU e rollback.

## 2.3.0 precision lock

- Conservare i track multi-frame e non contare due volte lo stesso timestamp Radar-DPC.
- Conservare forma della cella, optical flow e fallback lineare compatibile.
- La probabilità d'impatto deve derivare dalla geometria/ensemble; VMI/POH/VIL/ETM/LGT influenzano pericolosità e confidenza, non spostano la traiettoria.
- SRI deve restare nella lista prodotti e i prodotti con skew temporale eccessivo devono essere esclusi dalla fusione.
- ICON-2I è solo un prior debole, con cache e fallback radar-only; non deve rendere il ciclo dipendente da Open-Meteo.
- Conservare verifica hit/miss, Brier Score, campione minimo e calibrazione target-specifica.
- Conservare alert di escalation, downgrade e rientro con cooldown separati.
- Non inviare alert su frame VMI stale.
- Conservare pannello Precision Engine nella dashboard e controlli nella pagina Regole.
- Conservare installer shell futuristico anche in modalità non-TTY senza ANSI obbligatori.
- Conservare consenso NWP multi-modello come prior debole e fallback radar-only.
- Conservare correzione terreno limitata al 15% e separata dalla geometria della traiettoria.
- Non presentare Storm Initiation Watch come cella radar osservata o previsione certa.
- L'Adaptive AI deve partire in collection/shadow, richiedere verifiche cronologiche, casi positivi/negativi, almeno 12 eventi distinti e vantaggio Brier.
- Ogni candidato batch nuovo deve tornare shadow; vietati pickle/deserializzazione eseguibile e attivazione diretta.
- Conservare limiti su influenza, delta probabilistico, falsi negativi e circuit breaker verso shadow/suspended.
- Il trainer batch deve restare separato, non inviare alert e operare nel sandbox systemd dedicato.
