(() => {
  'use strict';

  const passwordInput = document.querySelector('#loginPassword');
  const passwordToggle = document.querySelector('#passwordVisibility');

  if (passwordInput && passwordToggle) {
    passwordToggle.addEventListener('click', () => {
      const show = passwordInput.type === 'password';
      passwordInput.type = show ? 'text' : 'password';
      passwordToggle.setAttribute('aria-pressed', show ? 'true' : 'false');
      passwordToggle.setAttribute('aria-label', show ? 'Nascondi password' : 'Mostra password');
      passwordInput.focus({ preventScroll: true });
    });
  }

  const clock = document.querySelector('[data-scenic-clock]');
  const updateClock = () => {
    if (!clock) return;
    clock.textContent = new Intl.DateTimeFormat('it-IT', {
      timeZone: 'UTC',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    }).format(new Date()) + ' UTC';
  };

  updateClock();
  window.setInterval(updateClock, 1000);
})();

