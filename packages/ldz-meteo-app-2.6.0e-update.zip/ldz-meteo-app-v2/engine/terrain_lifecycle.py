#!/usr/bin/env python3
"""Terrain, lifecycle, lightning-jump and initiation helpers for 2.3.2."""
from __future__ import annotations

import math
from datetime import datetime, timezone
from typing import Any


def clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(value)))


def finite(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except Exception:
        return default


def trend(observations: list[dict[str, Any]], key: str) -> float:
    rows = []
    for row in observations[-8:]:
        value = row.get(key)
        if value is None:
            continue
        rows.append((int(row.get("timestamp_ms", 0) or 0), finite(value)))
    if len(rows) < 2:
        return 0.0
    t0 = rows[-1][0]
    xs = [(timestamp - t0) / 60000.0 for timestamp, _ in rows]
    ys = [value for _, value in rows]
    mean_x = sum(xs) / len(xs)
    mean_y = sum(ys) / len(ys)
    denominator = sum((x - mean_x) ** 2 for x in xs)
    if denominator <= 1e-9:
        return 0.0
    return sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys)) / denominator


def project_lifecycle(observations: list[dict[str, Any]], lead_minutes: float, cfg: dict[str, Any]) -> dict[str, Any]:
    """Proietta crescita/decadimento con limiti fisici prudenti al lead time."""
    if not observations:
        return {"lead_minutes": float(lead_minutes), "area_scale": 1.0, "survival_probability_percent": 50.0, "strong_echo_supported": False}
    lead = max(0.0, min(90.0, float(lead_minutes)))
    current = observations[-1]
    damping = clamp(finite(cfg.get("lifecycle_engine", {}).get("lead_trend_damping", 0.72), 0.72), 0.2, 1.0)
    current_vmi = max(0.0, finite(current.get("max_vmi")))
    current_area = max(0.1, finite(current.get("area_km2"), 0.1))
    current_vil = max(0.0, finite(current.get("max_vil")))
    current_etm = max(0.0, finite(current.get("max_etm")))
    current_ir = current.get("min_ir108")
    vmi_slope = clamp(trend(observations, "max_vmi"), -1.6, 1.6)
    area_slope = clamp(trend(observations, "area_km2"), -max(1.0, current_area * 0.08), max(1.0, current_area * 0.08))
    vil_slope = clamp(trend(observations, "max_vil"), -1.8, 1.8)
    etm_slope = clamp(trend(observations, "max_etm"), -450.0, 450.0)
    ir_slope = clamp(trend(observations, "min_ir108"), -0.8, 0.8) if current_ir is not None else 0.0
    effective_lead = lead * damping
    projected_vmi = clamp(current_vmi + vmi_slope * effective_lead, 0.0, 80.0)
    projected_area = clamp(current_area + area_slope * effective_lead, current_area * 0.25, current_area * 2.5)
    projected_vil = clamp(current_vil + vil_slope * effective_lead, 0.0, max(80.0, current_vil * 2.0))
    projected_etm = clamp(current_etm + etm_slope * effective_lead, 0.0, 20000.0)
    projected_ir = None if current_ir is None else clamp(finite(current_ir) + ir_slope * effective_lead, -100.0, 45.0)
    strong_threshold = finite(cfg.get("thresholds", {}).get("vmi_strong_dbz", 45.0), 45.0)
    intensity = clamp((projected_vmi - (strong_threshold - 12.0)) / 24.0)
    vertical = 0.5 * clamp(projected_vil / 55.0) + 0.5 * clamp(projected_etm / 12000.0)
    area_support = clamp(projected_area / max(1.0, current_area * 1.25))
    trend_support = clamp(0.5 + vmi_slope / 2.5 + area_slope / max(3.0, current_area * 0.18))
    lead_decay = clamp(1.0 - lead / 110.0, 0.32, 1.0)
    survival = 100.0 * clamp((0.38 * intensity + 0.24 * vertical + 0.20 * area_support + 0.18 * trend_support) * lead_decay, 0.03, 0.99)
    return {
        "lead_minutes": round(lead, 2),
        "projected_vmi_dbz": round(projected_vmi, 2),
        "projected_area_km2": round(projected_area, 2),
        "projected_vil": round(projected_vil, 2),
        "projected_etm_m": round(projected_etm, 1),
        "projected_ir108_c": None if projected_ir is None else round(projected_ir, 2),
        "area_scale": round(math.sqrt(projected_area / current_area), 4),
        "survival_probability_percent": round(survival, 1),
        "strong_echo_supported": bool(projected_vmi >= strong_threshold),
        "trends": {"vmi_dbz_min": round(vmi_slope, 3), "area_km2_min": round(area_slope, 3),
                   "vil_min": round(vil_slope, 3), "etm_m_min": round(etm_slope, 2), "ir108_c_min": round(ir_slope, 3)},
    }


def update_lightning_jump(
    track_id: str,
    current_count: int,
    timestamp_ms: int,
    state: dict[str, Any],
    cfg: dict[str, Any],
    *,
    coverage_percent: float = 100.0,
    effective_window_minutes: float = 15.0,
    association_stable: bool = True,
) -> dict[str, Any]:
    precision = state.setdefault("precision", {})
    histories = precision.setdefault("lightning_history", {})
    history = histories.setdefault(track_id, [])
    window_minutes = max(1.0, float(effective_window_minutes or 15.0))
    rate_per_10min = max(0, int(current_count)) * 10.0 / window_minutes
    row = {
        "timestamp_ms": int(timestamp_ms),
        "count": max(0, int(current_count)),
        "rate_per_10min": rate_per_10min,
        "coverage_percent": clamp(float(coverage_percent), 0.0, 100.0),
        "association_stable": bool(association_stable),
    }
    if not history or int(history[-1].get("timestamp_ms", 0) or 0) != int(timestamp_ms):
        history.append(row)
    else:
        history[-1] = row
    del history[:-12]
    maximum_age = max(30, int(cfg.get("lifecycle_engine", {}).get("lightning_history_minutes", 90) or 90))
    histories[track_id] = [
        row for row in history
        if timestamp_ms - int(row.get("timestamp_ms", 0) or 0) <= maximum_age * 60000
    ]
    history = histories[track_id]
    minimum_coverage = clamp(float(cfg.get("lifecycle_engine", {}).get("lightning_jump_min_coverage_percent", 75) or 75), 0.0, 100.0)
    baseline_points = max(2, min(8, int(cfg.get("lifecycle_engine", {}).get("lightning_jump_baseline_points", 3) or 3)))
    previous_rows = [
        item for item in history[:-1]
        if float(item.get("coverage_percent", 0.0) or 0.0) >= minimum_coverage
        and bool(item.get("association_stable", True))
    ]
    baseline = previous_rows[-baseline_points:]
    baseline_rates = [float(item.get("rate_per_10min", 0.0) or 0.0) for item in baseline]
    previous_rate = baseline_rates[-1] if baseline_rates else rate_per_10min
    mean_rate = sum(baseline_rates) / len(baseline_rates) if baseline_rates else rate_per_10min
    variance = sum((value - mean_rate) ** 2 for value in baseline_rates) / max(1, len(baseline_rates) - 1) if len(baseline_rates) >= 2 else 0.0
    sigma = math.sqrt(max(0.0, variance))
    delta = rate_per_10min - mean_rate
    ratio = (rate_per_10min + 1.0) / (mean_rate + 1.0)
    minimum_delta = max(2, int(cfg.get("lifecycle_engine", {}).get("lightning_jump_min_delta", 4) or 4))
    comparable = (
        float(coverage_percent) >= minimum_coverage
        and bool(association_stable)
        and len(baseline) >= baseline_points
    )
    sigma_threshold = mean_rate + max(float(minimum_delta), 2.0 * sigma)
    minimum_count = max(minimum_delta, int(cfg.get("lifecycle_engine", {}).get("lightning_jump_min_count", 6) or 6))
    jump_detected = comparable and rate_per_10min >= minimum_count and rate_per_10min >= sigma_threshold and ratio >= 1.5
    jump_score = 0.0 if not comparable else 100.0 * clamp(
        0.58 * max(0.0, delta) / max(1.0, minimum_delta * 2.0)
        + 0.42 * max(0.0, ratio - 1.0) / 2.0
    )
    if not association_stable:
        reason = "associazione cella instabile dopo split/merge"
    elif float(coverage_percent) < minimum_coverage:
        reason = "finestra LTG incompleta"
    elif len(baseline) < baseline_points:
        reason = "storico LTG insufficiente"
    else:
        reason = "finestra e associazione confrontabili"
    return {
        "count": int(current_count),
        "rate_per_10min": round(rate_per_10min, 2),
        "previous_rate_per_10min": round(previous_rate, 2),
        "baseline_rate_per_10min": round(mean_rate, 2),
        "baseline_sigma": round(sigma, 2),
        "previous_count": int(history[-2].get("count", current_count) or 0) if len(history) >= 2 else int(current_count),
        "delta": round(delta, 2),
        "ratio": round(ratio, 3),
        "jump_score": round(jump_score, 1),
        "jump_detected": bool(jump_detected),
        "comparable": bool(comparable),
        "quality_percent": round(clamp(float(coverage_percent), 0.0, 100.0), 1),
        "reason": reason,
        "history_points": len(history),
    }


def assess_lifecycle(
    observations: list[dict[str, Any]],
    lightning: dict[str, Any],
    atmospheric: dict[str, Any],
    terrain: dict[str, Any],
    cfg: dict[str, Any],
) -> dict[str, Any]:
    """Stima euristica e spiegabile della sopravvivenza al lead time."""
    if not bool(cfg.get("lifecycle_engine", {}).get("enabled", True)):
        return {"survival_probability_percent": 100.0, "state": "disabilitato", "components": {}}
    if not observations:
        return {"survival_probability_percent": 50.0, "state": "in acquisizione"}
    current = observations[-1]
    vmi = finite(current.get("max_vmi"))
    poh = finite(current.get("max_poh"))
    vil = finite(current.get("max_vil"))
    etm = finite(current.get("max_etm"))
    srt1 = finite(current.get("max_srt1"))
    ir108 = current.get("min_ir108")
    vmi_trend = trend(observations, "max_vmi")
    area_trend = trend(observations, "area_km2")
    vil_trend = trend(observations, "max_vil")
    etm_trend = trend(observations, "max_etm")
    intensity = clamp((vmi - 25.0) / 35.0)
    vertical = 0.50 * clamp(vil / 55.0) + 0.50 * clamp(etm / 12000.0)
    hail = clamp(poh / 100.0)
    growth = clamp(0.5 + vmi_trend / 3.0 + area_trend / 15.0 + vil_trend / 8.0 + etm_trend / 5000.0)
    electric = clamp(finite(lightning.get("jump_score")) / 100.0)
    cape = clamp(finite(atmospheric.get("cape_jkg")) / 3500.0)
    barrier = clamp(finite(terrain.get("barrier_m")) / 1800.0)
    frames = clamp((len(observations) - 1) / 5.0)
    # Accumulo radar-orario e temperatura della sommita' nuvolosa sono
    # conferme indipendenti, quindi rimangono correttori piccoli e limitati.
    persistence = clamp(srt1 / 45.0)
    cold_cloud = clamp((-finite(ir108, 5.0) - 20.0) / 45.0) if ir108 is not None else 0.0
    raw = (
        0.21 * intensity
        + 0.17 * vertical
        + 0.08 * hail
        + 0.21 * growth
        + 0.10 * electric
        + 0.08 * cape
        + 0.06 * frames
        + 0.05 * persistence
        + 0.04 * cold_cloud
    )
    # L'orografia è soltanto un correttore limitato: mai una regola fisica assoluta.
    terrain_limit = clamp(finite(cfg.get("terrain_engine", {}).get("max_survival_adjustment", 0.12), 0.12), 0.0, 0.15)
    terrain_adjustment = -terrain_limit * barrier if vmi_trend < 0.0 else terrain_limit * 0.35 * barrier
    survival = 100.0 * clamp(raw + terrain_adjustment, 0.05, 0.98)
    if vmi_trend >= 0.7 or area_trend >= 1.8 or bool(lightning.get("jump_detected")):
        state_name = "intensificazione"
    elif vmi_trend <= -0.7 or area_trend <= -1.8:
        state_name = "indebolimento"
    else:
        state_name = "stabile"
    return {
        "survival_probability_percent": round(survival, 1),
        "state": state_name,
        "vmi_trend_dbz_min": round(vmi_trend, 3),
        "area_trend_km2_min": round(area_trend, 3),
        "vil_trend_min": round(vil_trend, 3),
        "etm_trend_m_min": round(etm_trend, 2),
        "terrain_adjustment_percent": round(terrain_adjustment * 100.0, 2),
        "components": {
            "intensity": round(intensity * 100.0, 1),
            "vertical": round(vertical * 100.0, 1),
            "growth": round(growth * 100.0, 1),
            "electric": round(electric * 100.0, 1),
            "environment": round(cape * 100.0, 1),
            "radar_persistence": round(persistence * 100.0, 1),
            "cold_cloud": round(cold_cloud * 100.0, 1),
        },
    }


def terrain_summary(elevations: list[float], cfg: dict[str, Any]) -> dict[str, Any]:
    values = [finite(value, float("nan")) for value in elevations]
    if len(values) < 3 or any(not math.isfinite(value) for value in values):
        return {"available": False}
    start, end = values[0], values[-1]
    peak = max(values)
    valley = min(values)
    barrier = max(0.0, peak - max(start, end))
    ascent = sum(max(0.0, b - a) for a, b in zip(values, values[1:]))
    descent = sum(max(0.0, a - b) for a, b in zip(values, values[1:]))
    return {
        "available": True,
        "source": "Open-Meteo Elevation / Copernicus DEM",
        "samples": len(values),
        "start_m": round(start, 1),
        "target_m": round(end, 1),
        "peak_m": round(peak, 1),
        "valley_m": round(valley, 1),
        "barrier_m": round(barrier, 1),
        "cumulative_ascent_m": round(ascent, 1),
        "cumulative_descent_m": round(descent, 1),
    }


def significant_impact_probability(trajectory_percent: float, survival_percent: float, sensor_score: float, cfg: dict[str, Any]) -> float:
    lcfg = cfg.get("lifecycle_engine", {})
    survival_weight = clamp(finite(lcfg.get("survival_weight", 0.34), 0.34), 0.10, 0.50)
    sensor_weight = clamp(finite(lcfg.get("sensor_confirmation_weight", 0.06), 0.06), 0.0, 0.15)
    trajectory_weight = max(0.35, 1.0 - survival_weight - sensor_weight)
    trajectory = clamp(trajectory_percent / 100.0)
    survival = clamp(survival_percent / 100.0)
    sensor = clamp(sensor_score / 100.0)
    # Media geometrica parziale: una traiettoria alta non basta se la cella decade.
    combined = trajectory_weight * trajectory + survival_weight * (trajectory * survival) + sensor_weight * max(trajectory, sensor)
    return round(100.0 * clamp(combined), 2)


def initiation_watch(
    targets: list[Any],
    atmospheric: dict[str, Any],
    lightning_by_target: dict[str, dict[str, Any]],
    sensor_by_target: dict[str, dict[str, Any]],
    cfg: dict[str, Any],
) -> dict[str, dict[str, Any]]:
    output: dict[str, dict[str, Any]] = {}
    cape = clamp(finite(atmospheric.get("cape_jkg")) / 3500.0)
    cin_value = max(0.0, abs(finite(atmospheric.get("cin_jkg"))))
    inhibition = clamp(cin_value / 250.0)
    spread = clamp(finite(atmospheric.get("steering_spread_kmh")) / 80.0)
    for target in targets:
        name = str(getattr(target, "name", target.get("name") if isinstance(target, dict) else "target"))
        lightning = lightning_by_target.get(name, {})
        sensor = sensor_by_target.get(name, {})
        electric = clamp(finite(lightning.get("count")) / 12.0)
        local = clamp(finite(sensor.get("confirmation_score")) / 100.0)
        score = 100.0 * clamp(0.50 * cape + 0.22 * electric + 0.18 * local + 0.10 * spread - 0.28 * inhibition)
        if score >= 70:
            level = "alto"
        elif score >= 45:
            level = "moderato"
        elif score >= 25:
            level = "basso"
        else:
            level = "minimo"
        output[name] = {
            "score_percent": round(score, 1),
            "level": level,
            "observed_cell": False,
            "advisory_only": True,
            "label": "potenziale innesco, non cella osservata",
        }
    return output


def calibration_segment(direction: str, lead_minutes: float, timestamp_ms: int) -> str:
    try:
        month = datetime.fromtimestamp(timestamp_ms / 1000.0, tz=timezone.utc).month
    except Exception:
        month = 1
    season = "winter" if month in {12, 1, 2} else "spring" if month in {3, 4, 5} else "summer" if month in {6, 7, 8} else "autumn"
    lead_bin = "0-15" if lead_minutes <= 15 else "16-30" if lead_minutes <= 30 else "31-45" if lead_minutes <= 45 else "46+"
    cardinal = str(direction or "ND").upper()[:3]
    return f"{season}|{cardinal}|{lead_bin}"
