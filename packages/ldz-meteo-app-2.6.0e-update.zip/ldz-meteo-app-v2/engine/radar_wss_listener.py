#!/usr/bin/env python3
"""Listener STOMP del WebSocket ufficiale Radar-DPC con timer di fallback."""
from __future__ import annotations

import argparse
import json
import logging
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import websocket
import yaml


def parse_stomp_frame(frame: str | bytes) -> tuple[str, dict[str, str], str]:
    text = frame.decode("utf-8", errors="replace") if isinstance(frame, bytes) else str(frame)
    text = text.rstrip("\x00")
    if text in {"", "\n"}:
        return "HEARTBEAT", {}, ""
    head, _, body = text.partition("\n\n")
    lines = head.splitlines()
    command = lines[0].strip() if lines else ""
    headers: dict[str, str] = {}
    for line in lines[1:]:
        if ":" in line:
            key, value = line.split(":", 1)
            headers[key.strip()] = value.strip()
    return command, headers, body.strip()


def message_product(frame: str | bytes) -> dict[str, Any] | None:
    command, _, body = parse_stomp_frame(frame)
    if command != "MESSAGE" or not body:
        return None
    try:
        payload = json.loads(body)
        return payload if isinstance(payload, dict) else None
    except Exception:
        return None


def run_engine(config_path: Path, engine_path: Path, settle_seconds: float) -> int:
    time.sleep(max(0.0, min(90.0, settle_seconds)))
    result = subprocess.run(
        [sys.executable, str(engine_path), "--config", str(config_path)],
        check=False,
        timeout=300,
        env=os.environ.copy(),
    )
    return int(result.returncode)


def listen(config_path: Path, engine_path: Path) -> int:
    cfg = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    radar = cfg.get("radar", {})
    wss = cfg.get("radar_websocket", {})
    if not bool(wss.get("enabled", True)):
        logging.info("Radar-DPC WebSocket disattivato; resta il timer fallback")
        return 0
    url = str(wss.get("url", "wss://radar-wss.protezionecivile.it"))
    settle = float(wss.get("settle_seconds", 35) or 35)
    trigger_product = str(wss.get("trigger_product", "VMI"))
    reconnect = max(2.0, min(120.0, float(wss.get("reconnect_seconds", 10) or 10)))
    origin = str(radar.get("origin", "https://radar.protezionecivile.it"))
    user_agent = str(radar.get("user_agent", "LDZMeteoApp/2.4.0"))
    last_timestamp = 0
    while True:
        ws = None
        try:
            ws = websocket.create_connection(
                url,
                timeout=45,
                origin=origin,
                header=[f"User-Agent: {user_agent}"],
                enable_multithread=False,
            )
            ws.send("CONNECT\naccept-version:1.2\nheart-beat:10000,10000\n\n\x00")
            command, _, _ = parse_stomp_frame(ws.recv())
            if command != "CONNECTED":
                raise RuntimeError(f"handshake STOMP inatteso: {command}")
            ws.send("SUBSCRIBE\nid:ldz-meteo-2.4\ndestination:/topic/product\nack:auto\n\n\x00")
            logging.info("Radar-DPC WebSocket connesso; trigger=%s", trigger_product)
            while True:
                raw = ws.recv()
                product = message_product(raw)
                if not product or str(product.get("productType", "")) != trigger_product:
                    continue
                timestamp = int(product.get("time", 0) or 0)
                if timestamp <= last_timestamp:
                    continue
                last_timestamp = timestamp
                logging.info("nuovo prodotto %s timestamp=%s; attendo coerenza pacchetto", trigger_product, timestamp)
                code = run_engine(config_path, engine_path, settle)
                logging.info("ciclo Radar-DPC event-driven terminato code=%s", code)
        except KeyboardInterrupt:
            return 0
        except Exception as exc:
            logging.warning("Radar-DPC WebSocket non disponibile (%s); riconnessione tra %.0fs", type(exc).__name__, reconnect)
            time.sleep(reconnect)
        finally:
            if ws is not None:
                try:
                    ws.close()
                except Exception:
                    pass


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="/etc/meteo-alert/config.yml")
    parser.add_argument("--engine", default="/opt/meteo-alert/meteo_alert.py")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    return listen(Path(args.config), Path(args.engine))


if __name__ == "__main__":
    raise SystemExit(main())
