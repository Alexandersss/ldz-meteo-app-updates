#!/usr/bin/env python3
"""Calibrazione grandine da feedback al suolo, shadow-first e limitata.

Il modulo accetta esclusivamente feature numeriche bounded e file JSON/JSONL.
Un feedback non modifica mai direttamente la previsione: il candidato viene
addestrato su eventi precedenti, validato cronologicamente su eventi successivi
e può influire in modo limitato solo se migliora la baseline.
"""
from __future__ import annotations

import json
import math
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np


FEATURE_NAMES = (
    "poh",
    "vmi",
    "vil_density",
    "cappi_vertical",
    "cappi_45_above_freezing",
    "lightning",
    "surface_rain",
    "persistence",
    "data_quality",
)


def clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(value)))


def _finite(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
        return result if math.isfinite(result) else default
    except (TypeError, ValueError, OverflowError):
        return default


def build_feature_vector(values: dict[str, Any]) -> list[float]:
    """Normalizza la telemetria grandine nello schema stabile della 2.4.0."""
    vector = [
        clamp(_finite(values.get("poh")) / 100.0),
        clamp((_finite(values.get("vmi")) - 20.0) / 50.0),
        clamp(_finite(values.get("vil_density")) / 5.0),
        clamp(_finite(values.get("cappi_vertical")) / 100.0),
        clamp(_finite(values.get("cappi_45_above_freezing")) / 6.0),
        clamp(_finite(values.get("lightning")) / 100.0),
        clamp(_finite(values.get("surface_rain")) / 100.0),
        clamp(_finite(values.get("persistence")) / 100.0),
        clamp(_finite(values.get("data_quality")) / 100.0),
    ]
    return [round(value, 7) for value in vector]


def _sigmoid(value: Any) -> Any:
    return 1.0 / (1.0 + np.exp(-np.clip(value, -30.0, 30.0)))


def load_feedback_rows(path: Path, maximum: int = 5000) -> list[dict[str, Any]]:
    if not path.is_file() or path.is_symlink() or path.stat().st_size > 200 * 1024 * 1024:
        return []
    rows: list[dict[str, Any]] = []
    with path.open(encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if len(line) > 64 * 1024:
                continue
            try:
                row = json.loads(line)
                features = row.get("features")
                outcome = int(row.get("hail_outcome"))
                if not isinstance(features, list) or len(features) != len(FEATURE_NAMES) or outcome not in {0, 1}:
                    continue
                numeric = [float(value) for value in features]
                baseline = clamp(_finite(row.get("baseline_hail_probability"), 0.0) / 100.0)
                if all(math.isfinite(value) and 0.0 <= value <= 1.0 for value in numeric):
                    rows.append({
                        "features": numeric,
                        "outcome": outcome,
                        "baseline": baseline,
                        "event_id": str(row.get("event_id", ""))[:40],
                        "observed_ms": int(row.get("observed_ms", 0) or 0),
                    })
            except Exception:
                continue
    rows.sort(key=lambda row: (int(row.get("observed_ms", 0)), str(row.get("event_id", ""))))
    return rows[-max(30, int(maximum)):]


def train_candidate(rows: list[dict[str, Any]], cfg: dict[str, Any]) -> dict[str, Any]:
    hcfg = cfg.get("hail_feedback_calibration", {})
    minimum = max(30, min(2000, int(hcfg.get("minimum_events", 40) or 40)))
    min_positive = max(5, int(hcfg.get("minimum_positive_events", 8) or 8))
    min_negative = max(10, int(hcfg.get("minimum_negative_events", 20) or 20))
    positives = sum(int(row["outcome"]) for row in rows)
    negatives = len(rows) - positives
    if len(rows) < minimum or positives < min_positive or negatives < min_negative:
        return {
            "ready": False,
            "reason": "insufficient_ground_truth",
            "events": len(rows),
            "positive_events": positives,
            "negative_events": negatives,
            "required": minimum,
        }

    split = max(20, min(len(rows) - 10, int(len(rows) * 0.70)))
    train_rows, validation_rows = rows[:split], rows[split:]
    x = np.asarray([row["features"] for row in train_rows], dtype="float64")
    y = np.asarray([row["outcome"] for row in train_rows], dtype="float64")
    weights = np.zeros(x.shape[1], dtype="float64")
    bias = 0.0
    lr = max(0.005, min(0.20, _finite(hcfg.get("learning_rate"), 0.07)))
    l2 = max(0.0, min(0.05, _finite(hcfg.get("l2_regularization"), 0.003)))
    epochs = max(40, min(500, int(hcfg.get("epochs", 160) or 160)))
    for epoch in range(epochs):
        prediction = _sigmoid(x @ weights + bias)
        error = prediction - y
        step = lr / math.sqrt(1.0 + epoch / 30.0)
        weights -= step * ((x.T @ error) / len(x) + l2 * weights)
        bias -= step * float(np.mean(error))

    vx = np.asarray([row["features"] for row in validation_rows], dtype="float64")
    vy = np.asarray([row["outcome"] for row in validation_rows], dtype="float64")
    baseline = np.asarray([row["baseline"] for row in validation_rows], dtype="float64")
    candidate = _sigmoid(vx @ weights + bias)
    baseline_brier = float(np.mean((baseline - vy) ** 2))
    candidate_brier = float(np.mean((candidate - vy) ** 2))
    improvement = 0.0 if baseline_brier <= 1e-12 else 100.0 * (baseline_brier - candidate_brier) / baseline_brier
    positive_mask = vy >= 0.5
    baseline_fn = float(np.mean(baseline[positive_mask] < 0.35)) if np.any(positive_mask) else 0.0
    candidate_fn = float(np.mean(candidate[positive_mask] < 0.35)) if np.any(positive_mask) else 0.0
    required_improvement = max(1.0, _finite(hcfg.get("minimum_brier_improvement_percent"), 10.0))
    eligible = (
        len(validation_rows) >= max(10, int(hcfg.get("minimum_validation_events", 12) or 12))
        and improvement >= required_improvement
        and candidate_fn <= baseline_fn + 1e-9
    )
    return {
        "ready": True,
        "schema": 1,
        "feature_names": list(FEATURE_NAMES),
        "weights": [round(float(value), 10) for value in weights],
        "bias": round(float(bias), 10),
        "trained_events": len(train_rows),
        "validation_events": len(validation_rows),
        "positive_events": positives,
        "negative_events": negatives,
        "baseline_brier": round(baseline_brier, 6),
        "candidate_brier": round(candidate_brier, 6),
        "improvement_percent": round(improvement, 2),
        "baseline_false_negative_rate": round(baseline_fn, 4),
        "candidate_false_negative_rate": round(candidate_fn, 4),
        "eligible": eligible,
        "status": "eligible" if eligible else "shadow",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
    }


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, dir=str(path.parent)) as handle:
        json.dump(payload, handle, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
        handle.write("\n")
        temporary = Path(handle.name)
    temporary.replace(path)
    path.chmod(0o600)


def train_feedback_file(cfg: dict[str, Any]) -> dict[str, Any]:
    data_dir = Path(cfg.get("app", {}).get("data_dir", "/var/lib/meteo-alert"))
    hcfg = cfg.get("hail_feedback_calibration", {})
    dataset = Path(hcfg.get("dataset_file", str(data_dir / "feedback" / "ground-truth.jsonl")))
    candidate = Path(hcfg.get("candidate_model_file", str(data_dir / "feedback" / "hail-candidate.json")))
    report = Path(hcfg.get("training_report_file", str(data_dir / "feedback" / "hail-training-report.json")))
    rows = load_feedback_rows(dataset, max(100, min(10000, int(hcfg.get("maximum_events", 5000) or 5000))))
    result = train_candidate(rows, cfg)
    atomic_json(report, result)
    if result.get("ready"):
        atomic_json(candidate, result)
    return result


def load_candidate(cfg: dict[str, Any]) -> dict[str, Any]:
    data_dir = Path(cfg.get("app", {}).get("data_dir", "/var/lib/meteo-alert"))
    hcfg = cfg.get("hail_feedback_calibration", {})
    path = Path(hcfg.get("candidate_model_file", str(data_dir / "feedback" / "hail-candidate.json")))
    try:
        if not path.is_file() or path.is_symlink() or path.stat().st_size > 1024 * 1024:
            return {"available": False, "status": "collection"}
        payload = json.loads(path.read_text(encoding="utf-8"))
        weights = payload.get("weights")
        if payload.get("schema") != 1 or payload.get("feature_names") != list(FEATURE_NAMES):
            return {"available": False, "status": "invalid"}
        if not isinstance(weights, list) or len(weights) != len(FEATURE_NAMES):
            return {"available": False, "status": "invalid"}
        numbers = [float(value) for value in weights]
        bias = float(payload.get("bias"))
        if not all(math.isfinite(value) and abs(value) <= 100.0 for value in numbers + [bias]):
            return {"available": False, "status": "invalid"}
        payload.update({"available": True, "weights": numbers, "bias": bias})
        return payload
    except Exception:
        return {"available": False, "status": "invalid"}


def apply_candidate(base_probability: float, features: list[float], cfg: dict[str, Any]) -> dict[str, Any]:
    base = max(0.0, min(100.0, _finite(base_probability)))
    hcfg = cfg.get("hail_feedback_calibration", {})
    if not bool(hcfg.get("enabled", True)):
        return {"status": "disabled", "applied": False, "base_probability_percent": round(base, 1), "probability_percent": round(base, 1)}
    model = load_candidate(cfg)
    if not model.get("available"):
        return {"status": str(model.get("status", "collection")), "applied": False, "base_probability_percent": round(base, 1), "probability_percent": round(base, 1)}
    score = float(model["bias"]) + sum(float(weight) * float(value) for weight, value in zip(model["weights"], features))
    candidate_probability = 100.0 / (1.0 + math.exp(-max(-30.0, min(30.0, score))))
    eligible = bool(model.get("eligible"))
    auto_activate = bool(hcfg.get("auto_activate", True))
    influence = max(0.0, min(0.25, _finite(hcfg.get("guarded_influence"), 0.18))) if eligible and auto_activate else 0.0
    maximum_delta = max(2.0, min(12.0, _finite(hcfg.get("maximum_probability_delta_percent"), 10.0)))
    delta = max(-maximum_delta, min(maximum_delta, candidate_probability - base))
    calibrated = max(0.0, min(100.0, base + influence * delta))
    return {
        "status": "active_guarded" if influence > 0.0 else "eligible" if eligible else "shadow",
        "applied": influence > 0.0,
        "influence_percent": round(influence * 100.0, 1),
        "base_probability_percent": round(base, 1),
        "candidate_probability_percent": round(candidate_probability, 1),
        "probability_percent": round(calibrated, 1),
        "validation_events": int(model.get("validation_events", 0) or 0),
        "improvement_percent": model.get("improvement_percent"),
        "generated_utc": str(model.get("generated_utc", ""))[:64],
    }
