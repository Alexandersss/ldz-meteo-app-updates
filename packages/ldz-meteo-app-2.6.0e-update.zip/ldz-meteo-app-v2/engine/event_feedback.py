#!/usr/bin/env python3
"""Incidenti meteo, replay compatto e feedback Telegram verificabile."""
from __future__ import annotations

import hashlib
import hmac
import html
import json
import math
import os
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import numpy as np
import rasterio

from hail_feedback import build_feature_vector


FEEDBACK_OPTIONS = {
    "none": {"label": "☀️ Nessun fenomeno", "impact": 0, "hail": 0, "severity": 0},
    "lightning": {"label": "⚡ Solo fulmini", "impact": 1, "hail": 0, "severity": 1},
    "rain": {"label": "🌧️ Pioggia debole/moderata", "impact": 1, "hail": 0, "severity": 2},
    "heavy_rain": {"label": "🌧️ Pioggia intensa", "impact": 1, "hail": 0, "severity": 3},
    "small_hail": {"label": "🧊 Grandine piccola", "impact": 1, "hail": 1, "severity": 4},
    "damaging_hail": {"label": "🚨 Grandine con danni", "impact": 1, "hail": 1, "severity": 5},
    "not_there": {"label": "❓ Non ero sul posto", "impact": None, "hail": None, "severity": None},
}
OPTION_CODES = {
    "n": "none", "l": "lightning", "r": "rain", "i": "heavy_rain",
    "h": "small_hail", "d": "damaging_hail", "x": "not_there",
}
OPTION_CODES_REVERSE = {value: key for key, value in OPTION_CODES.items()}
TERMINAL_FEEDBACK_STATUSES = {"received", "ignored_not_on_site"}


def _finite(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError, OverflowError):
        return default


def _value(obj: Any, key: str, default: Any = None) -> Any:
    return obj.get(key, default) if isinstance(obj, dict) else getattr(obj, key, default)


def _now_ms() -> int:
    return int(datetime.now(timezone.utc).timestamp() * 1000)


def _safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "-", value).strip("-.")[:60] or "target"


def _append_jsonl(path: Path, row: dict[str, Any], maximum_mb: int = 50) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise OSError("ledger symlink non consentito")
    maximum = max(1, min(200, int(maximum_mb))) * 1024 * 1024
    if path.is_file() and path.stat().st_size > maximum:
        rotated = path.with_suffix(path.suffix + ".1")
        rotated.unlink(missing_ok=True)
        path.replace(rotated)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    path.chmod(0o600)


def _best_by_target(forecasts: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
    best: dict[str, dict[str, Any]] = {}
    for key, forecast in forecasts.items():
        _, _, target = str(key).partition("|")
        if not target or not isinstance(forecast, dict):
            continue
        if target not in best or _finite(forecast.get("impact_probability_percent")) > _finite(best[target].get("impact_probability_percent")):
            best[target] = forecast
    return best


def _cell_by_id(cells: list[Any]) -> dict[str, Any]:
    return {str(_value(cell, "cell_id", "")): cell for cell in cells}


def decision_explanation(forecast: dict[str, Any], cell: Any | None, temporal_bundle: dict[str, Any]) -> dict[str, Any]:
    probability = _finite(forecast.get("impact_probability_percent"))
    threshold = _finite(forecast.get("alert_threshold_percent"), 60.0)
    mode = str(forecast.get("mode", "unknown"))
    near = forecast.get("near_target_override") if isinstance(forecast.get("near_target_override"), dict) else {}
    reasons: list[str] = []
    blockers: list[str] = []
    if near.get("active"):
        reasons.append(str(near.get("reason", "fenomeno osservato molto vicino al target")))
    if mode == "observed_core":
        reasons.append("nucleo forte osservato dentro l'area target")
    elif mode == "fringe_inside":
        reasons.append("bordo della precipitazione già dentro l'area target")
    elif _finite(forecast.get("closing_kmh")) > 0:
        reasons.append(f"cella in avvicinamento a {_finite(forecast.get('closing_kmh')):.0f} km/h")
    else:
        blockers.append("traiettoria non convergente o ancora incerta")
    if cell is not None:
        if _finite(_value(cell, "max_vmi")) >= 45:
            reasons.append(f"VMI {_finite(_value(cell, 'max_vmi')):.1f} dBZ")
        if _value(cell, "max_sri") is not None and _finite(_value(cell, "max_sri")) >= 15:
            reasons.append(f"SRI {_finite(_value(cell, 'max_sri')):.1f} mm/h")
    if probability < threshold and not near.get("active"):
        blockers.append(f"probabilità {probability:.0f}% sotto soglia {threshold:.0f}%")
    if str(temporal_bundle.get("status", "aligned")) != "aligned":
        blockers.append("prodotti temporalmente incompleti o disallineati")
    return {
        "decision": "alert" if probability >= threshold or near.get("active") else "monitor_only",
        "probability_percent": round(probability, 1),
        "threshold_percent": round(threshold, 1),
        "mode": mode,
        "reasons": reasons[:6],
        "blockers": blockers[:5],
        "data_status": str(temporal_bundle.get("status", "unknown")),
    }


def _incident_id(target: str, timestamp_ms: int, track_id: str) -> str:
    material = f"{target}|{timestamp_ms // 60000}|{track_id}".encode("utf-8")
    return hashlib.sha256(material).hexdigest()[:14]


def update_incidents(
    state: dict[str, Any],
    targets: list[Any],
    cells: list[Any],
    forecasts: dict[str, dict[str, Any]],
    lightning: dict[str, dict[str, Any]],
    sent: list[dict[str, Any]],
    timestamp_ms: int,
    cfg: dict[str, Any],
    temporal_bundle: dict[str, Any],
) -> dict[str, Any]:
    fcfg = cfg.get("event_feedback", {})
    root = state.setdefault("event_feedback", {})
    root["schema"] = 1
    incidents = root.setdefault("incidents", {})
    active = root.setdefault("active_by_target", {})
    best = _best_by_target(forecasts)
    cells_by_id = _cell_by_id(cells)
    min_capture = max(5.0, min(80.0, _finite(fcfg.get("minimum_capture_probability_percent"), 15.0)))
    close_after_ms = max(10, min(180, int(fcfg.get("close_after_minutes", 30) or 30))) * 60000
    feedback_delay_ms = max(5, min(180, int(fcfg.get("prompt_delay_minutes", 25) or 25))) * 60000
    sent_by_target: dict[str, list[dict[str, Any]]] = {}
    for item in sent:
        if isinstance(item, dict) and item.get("target"):
            sent_by_target.setdefault(str(item["target"]), []).append(item)

    for target in targets:
        name = str(_value(target, "name", "target"))[:100]
        forecast = dict(best.get(name) or {})
        forecast["alert_threshold_percent"] = _finite(cfg.get("tracking", {}).get("min_alert_probability_percent"), 60.0)
        cell_id = str(forecast.get("cell_id", ""))
        cell = cells_by_id.get(cell_id)
        lt = lightning.get(name) if isinstance(lightning.get(name), dict) else {}
        target_sent = sent_by_target.get(name, [])
        clear_sent = any(str(item.get("mode", "")) in {"clear", "lightning_clear"} for item in target_sent)
        alert_sent = any(str(item.get("mode", "")) not in {"clear", "lightning_clear"} for item in target_sent)
        probability = _finite(forecast.get("impact_probability_percent"))
        lgt_count = int(lt.get("count", 0) or 0)
        signal = bool(alert_sent or probability >= min_capture or lgt_count > 0)
        event_id = str(active.get(name, ""))
        event = incidents.get(event_id) if event_id else None

        if signal and (not isinstance(event, dict) or event.get("status") == "closed"):
            track_id = str(forecast.get("track_id", cell_id or "untracked"))[:80]
            event_id = _incident_id(name, timestamp_ms, track_id)
            event = {
                "event_id": event_id,
                "target": name,
                "status": "open",
                "started_ms": int(timestamp_ms),
                "last_seen_ms": int(timestamp_ms),
                "alerted": False,
                "alert_modes": [],
                "track_ids": [],
                "timeline": [],
                "feedback_status": "not_due",
            }
            incidents[event_id] = event
            active[name] = event_id

        if isinstance(event, dict) and signal:
            event["last_seen_ms"] = int(timestamp_ms)
            track_id = str(forecast.get("track_id", cell_id or ""))[:80]
            if track_id and track_id not in event["track_ids"]:
                event["track_ids"].append(track_id)
                event["track_ids"] = event["track_ids"][-8:]
            event["alerted"] = bool(event.get("alerted") or alert_sent)
            for item in target_sent:
                mode = str(item.get("mode", ""))[:40]
                if mode and mode not in event["alert_modes"]:
                    event["alert_modes"].append(mode)
            peak = event.setdefault("peak", {})
            hail_probability = forecast.get("hail_probability_percent")
            hail_evidence = _finite(forecast.get("hail_evidence_score_percent", forecast.get("hail_confidence_percent")))
            metrics = {
                "impact_probability_percent": probability,
                "hail_probability_percent": None if hail_probability is None else _finite(hail_probability),
                "hail_probability_calibrated": bool(forecast.get("hail_probability_calibrated")),
                "hail_evidence_score_percent": hail_evidence,
                "hail_calibration_baseline_percent": _finite(forecast.get("hail_calibration_baseline_percent", hail_evidence)),
                "vmi": _finite(_value(cell, "max_vmi")) if cell is not None else 0.0,
                "sri": None if cell is None or _value(cell, "max_sri") is None else _finite(_value(cell, "max_sri")),
                "poh": None if cell is None or _value(cell, "max_poh") is None else _finite(_value(cell, "max_poh")),
                "vil": None if cell is None or _value(cell, "max_vil") is None else _finite(_value(cell, "max_vil")),
                "etm": None if cell is None or _value(cell, "max_etm") is None else _finite(_value(cell, "max_etm")),
                "lightning_count": lgt_count,
                "lightning_nearest_km": lt.get("nearest_km"),
                "cappi_vertical": forecast.get("cappi_vertical") if isinstance(forecast.get("cappi_vertical"), dict) else {},
                "hail_data_quality_percent": _finite(forecast.get("hail_data_quality_percent")),
                "hail_persistence_frames": int(forecast.get("hail_persistence_frames", 0) or 0),
                "scores": (forecast.get("multisignal") or {}).get("scores", {}) if isinstance(forecast.get("multisignal"), dict) else {},
            }
            if probability >= _finite(peak.get("impact_probability_percent"), -1.0):
                peak.update(metrics)
                event["decision"] = decision_explanation(forecast, cell, temporal_bundle)
                event["temporal_bundle"] = temporal_bundle
            event["timeline"].append({
                "timestamp_ms": int(timestamp_ms), "probability": round(probability, 1),
                "hail": round(hail_evidence, 1), "vmi": round(metrics["vmi"], 1),
                "lightning": lgt_count, "decision": event.get("decision", {}).get("decision", "monitor_only"),
            })
            event["timeline"] = event["timeline"][-72:]

        should_close = False
        if isinstance(event, dict) and event.get("status") == "open":
            should_close = clear_sent or (not signal and int(timestamp_ms) - int(event.get("last_seen_ms", timestamp_ms)) >= close_after_ms)
        if should_close and isinstance(event, dict):
            event["status"] = "closed"
            event["closed_ms"] = int(timestamp_ms)
            active.pop(name, None)
            if event.get("alerted") and bool(fcfg.get("enabled", True)):
                event["feedback_status"] = "pending"
                event["feedback_due_ms"] = int(timestamp_ms) + feedback_delay_ms
            else:
                event["feedback_status"] = "shadow_only"

    retention_ms = max(7, min(180, int(fcfg.get("retention_days", 60) or 60))) * 86400000
    cutoff = int(timestamp_ms) - retention_ms
    old_ids = [event_id for event_id, event in incidents.items() if int(event.get("last_seen_ms", 0) or 0) < cutoff]
    for event_id in old_ids:
        incidents.pop(event_id, None)
    if len(incidents) > 400:
        ordered = sorted(incidents, key=lambda key: int(incidents[key].get("last_seen_ms", 0) or 0))
        for event_id in ordered[:-400]:
            incidents.pop(event_id, None)
    root["updated_ms"] = int(timestamp_ms)
    root["totals"] = {
        "incidents": len(incidents),
        "open": sum(1 for event in incidents.values() if event.get("status") == "open"),
        "feedback_received": sum(1 for event in incidents.values() if event.get("feedback_status") == "received"),
        "feedback_pending": sum(1 for event in incidents.values() if event.get("feedback_status") == "pending"),
    }
    return root


def feedback_signature(token: str, event_id: str, code: str) -> str:
    return hmac.new(token.encode("utf-8"), f"{event_id}:{code}".encode("utf-8"), hashlib.sha256).hexdigest()[:10]


def validate_feedback_update(
    update: dict[str, Any],
    state: dict[str, Any],
    token: str,
    chat_id: str,
) -> dict[str, Any]:
    callback = update.get("callback_query") if isinstance(update, dict) else None
    if not isinstance(callback, dict):
        return {"ok": False, "callback_id": "", "answer": "Aggiornamento Telegram non valido."}
    callback_id = str(callback.get("id", ""))[:200]
    message = callback.get("message") if isinstance(callback.get("message"), dict) else {}
    chat = message.get("chat") if isinstance(message.get("chat"), dict) else {}
    callback_chat = str(chat.get("id", ""))
    try:
        message_id = int(message.get("message_id", 0) or 0)
    except (TypeError, ValueError, OverflowError):
        message_id = 0
    parts = str(callback.get("data", "")).split(":")
    if len(parts) != 4 or parts[0] != "fb" or callback_chat != str(chat_id):
        return {
            "ok": False, "callback_id": callback_id,
            "answer": "Feedback non valido per questa chat.",
            "chat_id": callback_chat, "message_id": message_id,
        }
    _, event_id, code, signature = parts
    option = OPTION_CODES.get(code)
    expected = feedback_signature(token, event_id, code)
    incidents = ((state.get("event_feedback") or {}).get("incidents") or {})
    event = incidents.get(event_id)
    if not option or not hmac.compare_digest(signature, expected) or not isinstance(event, dict):
        return {
            "ok": False, "callback_id": callback_id,
            "answer": "Evento non riconosciuto o firma non valida.",
            "chat_id": callback_chat, "message_id": message_id,
        }
    definition = FEEDBACK_OPTIONS[option]
    clean_label = re.sub(r"^[^A-Za-zÀ-ÿ0-9]+", "", str(definition["label"])).strip()
    duplicate = event.get("feedback_status") in TERMINAL_FEEDBACK_STATUSES or isinstance(event.get("feedback"), dict)
    return {
        "ok": True,
        "callback_id": callback_id,
        "chat_id": callback_chat,
        "message_id": message_id,
        "event_id": event_id,
        "option": option,
        "label": definition["label"],
        "clean_label": clean_label,
        "duplicate": duplicate,
        "answer": "Feedback già registrato, grazie." if duplicate else f"Feedback ricevuto: {clean_label}",
    }


def _feedback_inbox(cfg: dict[str, Any]) -> Path:
    data_dir = Path(cfg.get("app", {}).get("data_dir", "/var/lib/meteo-alert"))
    return data_dir / "feedback" / "telegram-inbox"


def queue_feedback_update(update: dict[str, Any], cfg: dict[str, Any]) -> bool:
    try:
        update_id = int(update.get("update_id", 0) or 0)
    except (TypeError, ValueError, OverflowError):
        return False
    if update_id <= 0:
        return False
    encoded = json.dumps(update, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if len(encoded) > 64 * 1024:
        raise ValueError("callback Telegram troppo grande")
    inbox = _feedback_inbox(cfg)
    inbox.parent.mkdir(parents=True, exist_ok=True)
    if inbox.exists() and inbox.is_symlink():
        raise OSError("inbox feedback symlink non consentito")
    inbox.mkdir(mode=0o700, exist_ok=True)
    destination = inbox / f"{update_id}.json"
    if destination.exists():
        return False
    with tempfile.NamedTemporaryFile("wb", delete=False, dir=str(inbox), prefix=".pending-") as handle:
        handle.write(encoded)
        handle.flush()
        os.fsync(handle.fileno())
        temp_path = Path(handle.name)
    temp_path.chmod(0o600)
    temp_path.replace(destination)
    return True


def feedback_event_is_queued(cfg: dict[str, Any], event_id: str) -> bool:
    inbox = _feedback_inbox(cfg)
    if not inbox.is_dir() or inbox.is_symlink():
        return False
    for path in sorted(inbox.glob("[0-9]*.json"))[:500]:
        try:
            if path.is_symlink() or path.stat().st_size > 64 * 1024:
                continue
            payload = json.loads(path.read_text(encoding="utf-8"))
            data = str(((payload.get("callback_query") or {}).get("data", "")))
            parts = data.split(":")
            if len(parts) == 4 and parts[0] == "fb" and parts[1] == event_id:
                return True
        except (OSError, ValueError, TypeError):
            continue
    return False


def drain_feedback_inbox(
    state: dict[str, Any],
    cfg: dict[str, Any],
    token: str,
    chat_id: str,
    now_ms: int | None = None,
) -> list[dict[str, Any]]:
    inbox = _feedback_inbox(cfg)
    if not inbox.is_dir() or inbox.is_symlink():
        return []
    paths: list[Path] = []
    updates: list[dict[str, Any]] = []
    candidates = [path for path in inbox.glob("*.json") if re.fullmatch(r"[0-9]+", path.stem)]
    for path in sorted(candidates, key=lambda item: int(item.stem))[:100]:
        try:
            if path.is_symlink() or path.stat().st_size > 64 * 1024:
                path.unlink(missing_ok=True)
                continue
            payload = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                raise ValueError("payload non oggetto")
            paths.append(path)
            updates.append(payload)
        except (OSError, ValueError, TypeError):
            path.unlink(missing_ok=True)
    results = handle_feedback_updates(updates, state, cfg, token, chat_id, now_ms=now_ms)
    handled_ids = {str(item.get("callback_id", "")) for item in results}
    for path, update in zip(paths, updates):
        callback_id = str(((update.get("callback_query") or {}).get("id", "")))
        if callback_id in handled_ids:
            path.unlink(missing_ok=True)
    return results


def build_feedback_prompt(event: dict[str, Any], token: str) -> tuple[str, dict[str, Any]]:
    event_id = str(event.get("event_id", ""))
    target = html.escape(str(event.get("target", "target"))[:100])
    peak = event.get("peak") if isinstance(event.get("peak"), dict) else {}
    probability = _finite(peak.get("impact_probability_percent"))
    hail_probability = peak.get("hail_probability_percent")
    hail_evidence = _finite(peak.get("hail_evidence_score_percent", peak.get("hail_calibration_baseline_percent")))
    hail_text = (
        f"probabilità grandine calibrata al <b>{_finite(hail_probability):.0f}%</b>"
        if peak.get("hail_probability_calibrated") and hail_probability is not None
        else f"indice di evidenza grandine <b>{hail_evidence:.0f}/100</b>"
    )
    message = (
        f"🔎 <b>VERIFICA DELL'EVENTO</b>\n\n"
        f"📍 <b>{target}</b>\n"
        f"Il sistema aveva registrato un indice d'impatto massimo di <b>{probability:.0f}/100</b> "
        f"e {hail_text}.\n\n"
        "Eri sul posto? Se sì, cosa è accaduto realmente? La risposta non modifica "
        "subito le soglie: verrà usata solo dopo una validazione su molti eventi."
    )
    rows = [
        ("none", "lightning"),
        ("rain", "heavy_rain"),
        ("small_hail", "damaging_hail"),
        ("not_there",),
    ]
    keyboard = []
    for row in rows:
        buttons = []
        for option in row:
            code = OPTION_CODES_REVERSE[option]
            signature = feedback_signature(token, event_id, code)
            buttons.append({"text": FEEDBACK_OPTIONS[option]["label"], "callback_data": f"fb:{event_id}:{code}:{signature}"})
        keyboard.append(buttons)
    return message, {"inline_keyboard": keyboard}


def pending_feedback_prompts(state: dict[str, Any], now_ms: int | None = None) -> list[dict[str, Any]]:
    current = int(now_ms if now_ms is not None else _now_ms())
    incidents = ((state.get("event_feedback") or {}).get("incidents") or {})
    return [
        event for event in incidents.values()
        if isinstance(event, dict)
        and event.get("feedback_status") == "pending"
        and int(event.get("feedback_due_ms", 0) or 0) <= current
    ][:3]


def mark_prompt_sent(event: dict[str, Any], now_ms: int | None = None) -> None:
    event["feedback_status"] = "asked"
    event["feedback_asked_ms"] = int(now_ms if now_ms is not None else _now_ms())


def _feedback_dataset_row(event: dict[str, Any], option: str, observed_ms: int) -> dict[str, Any] | None:
    definition = FEEDBACK_OPTIONS[option]
    if definition["hail"] is None:
        return None
    peak = event.get("peak") if isinstance(event.get("peak"), dict) else {}
    cappi = peak.get("cappi_vertical") if isinstance(peak.get("cappi_vertical"), dict) else {}
    scores = peak.get("scores") if isinstance(peak.get("scores"), dict) else {}
    vil = peak.get("vil")
    etm = peak.get("etm")
    vil_density = 0.0
    if vil is not None and etm is not None and _finite(etm) > 1000.0:
        vil_density = _finite(vil) * 1000.0 / _finite(etm)
    features = build_feature_vector({
        "poh": peak.get("poh"),
        "vmi": peak.get("vmi"),
        "vil_density": vil_density,
        "cappi_vertical": cappi.get("score_percent", scores.get("cappi_vertical")),
        "cappi_45_above_freezing": cappi.get("height_45_above_freezing_km"),
        "lightning": scores.get("lightning", min(100.0, _finite(peak.get("lightning_count")) * 8.0)),
        "surface_rain": min(100.0, _finite(peak.get("sri")) / 1.5),
        "persistence": min(100.0, _finite(peak.get("hail_persistence_frames")) * 33.3),
        "data_quality": peak.get("hail_data_quality_percent"),
    })
    return {
        "schema": 1,
        "event_id": str(event.get("event_id", "")),
        "target": str(event.get("target", ""))[:100],
        "started_ms": int(event.get("started_ms", 0) or 0),
        "observed_ms": int(observed_ms),
        "feedback": option,
        "impact_outcome": int(definition["impact"]),
        "hail_outcome": int(definition["hail"]),
        "severity": int(definition["severity"]),
        "baseline_hail_probability": round(_finite(peak.get("hail_calibration_baseline_percent", peak.get("hail_evidence_score_percent", peak.get("hail_probability_percent")))), 2),
        "features": features,
    }


def handle_feedback_updates(
    updates: list[dict[str, Any]],
    state: dict[str, Any],
    cfg: dict[str, Any],
    token: str,
    chat_id: str,
    now_ms: int | None = None,
) -> list[dict[str, Any]]:
    current = int(now_ms if now_ms is not None else _now_ms())
    incidents = ((state.get("event_feedback") or {}).get("incidents") or {})
    accepted: list[dict[str, Any]] = []
    data_dir = Path(cfg.get("app", {}).get("data_dir", "/var/lib/meteo-alert"))
    hcfg = cfg.get("hail_feedback_calibration", {})
    dataset = Path(hcfg.get("dataset_file", str(data_dir / "feedback" / "ground-truth.jsonl")))
    maximum_mb = int(hcfg.get("maximum_dataset_mb", 50) or 50)
    for update in updates:
        validated = validate_feedback_update(update, state, token, chat_id)
        callback_id = str(validated.get("callback_id", ""))
        if not validated.get("ok"):
            if callback_id:
                accepted.append(validated)
            continue
        event_id = str(validated["event_id"])
        option = str(validated["option"])
        event = incidents[event_id]
        if validated.get("duplicate"):
            accepted.append(validated)
            continue
        definition = FEEDBACK_OPTIONS[option]
        event["feedback_status"] = "ignored_not_on_site" if option == "not_there" else "received"
        event["feedback"] = {
            "option": option,
            "label": definition["label"],
            "received_ms": current,
            "trusted_ground_truth": option != "not_there",
        }
        row = _feedback_dataset_row(event, option, current)
        if row is not None:
            _append_jsonl(dataset, row, maximum_mb)
        accepted.append({
            "callback_id": callback_id,
            "ok": True,
            "answer": "Feedback registrato: " + str(validated["clean_label"]),
            "event_id": event_id,
            "option": option,
            "label": definition["label"],
            "clean_label": validated["clean_label"],
            "chat_id": validated["chat_id"],
            "message_id": validated["message_id"],
            "duplicate": False,
        })
    return accepted


def save_replay_snapshots(
    ref: dict[str, Any],
    arrays: dict[str, np.ndarray],
    targets: list[Any],
    forecasts: dict[str, dict[str, Any]],
    timestamp_ms: int,
    cfg: dict[str, Any],
    temporal_bundle: dict[str, Any],
    *,
    shadow_analysis: Optional[dict[str, Any]] = None,
) -> int:
    rcfg = cfg.get("event_replay", {})
    if not bool(rcfg.get("enabled", True)):
        return 0
    best = _best_by_target(forecasts)
    minimum = max(5.0, min(90.0, _finite(rcfg.get("minimum_probability_percent"), 15.0)))
    crop = max(12, min(160, int(rcfg.get("crop_radius_pixels", 48) or 48)))
    products = [str(product) for product in rcfg.get("products", ["VMI", "SRI", "POH", "VIL", "ETM"])]
    data_dir = Path(cfg.get("app", {}).get("data_dir", "/var/lib/meteo-alert"))
    root = Path(rcfg.get("directory", str(data_dir / "replay")))
    root.mkdir(parents=True, exist_ok=True)
    saved = 0
    negative_interval = max(10, min(180, int(rcfg.get("negative_sampling_interval_minutes", 30) or 30)))
    negative_slot = int(timestamp_ms // (negative_interval * 60000))
    for target in targets:
        name = str(_value(target, "name", "target"))[:100]
        forecast = best.get(name) or {}
        positive = _finite(forecast.get("impact_probability_percent")) >= minimum or bool((forecast.get("near_target_override") or {}).get("active"))
        # I casi senza allerta sono indispensabili per FAR/FN e calibrazione.
        # Ne salviamo uno per slot, evitando di moltiplicare lo spazio disco.
        target_dir = root / _safe_name(name)
        negative_marker = target_dir / f"negative-slot-{negative_slot}.marker"
        if not positive and negative_marker.exists():
            continue
        try:
            row, col = rasterio.transform.rowcol(ref["transform"], float(_value(target, "lon")), float(_value(target, "lat")))
            row, col = int(row), int(col)
            r0, r1 = max(0, row - crop), min(int(ref["height"]), row + crop + 1)
            c0, c1 = max(0, col - crop), min(int(ref["width"]), col + crop + 1)
            if r1 <= r0 or c1 <= c0:
                continue
            target_dir.mkdir(parents=True, exist_ok=True)
            destination = target_dir / f"{int(timestamp_ms)}.npz"
            if destination.exists():
                continue
            payload = {
                product: np.asarray(arrays[product][r0:r1, c0:c1], dtype="float32")
                for product in products if product in arrays
            }
            if not payload:
                continue
            with tempfile.NamedTemporaryFile(delete=False, dir=str(target_dir), suffix=".npz") as handle:
                temporary = Path(handle.name)
            np.savez_compressed(temporary, **payload)
            temporary.replace(destination)
            meta = {
                "schema": 2, "timestamp_ms": int(timestamp_ms), "target": name,
                "window": [r0, r1, c0, c1], "products": sorted(payload),
                "forecast": forecast, "temporal_bundle": temporal_bundle,
                "sample_class": "positive" if positive else "negative",
                "operational_alert_candidate": bool(positive),
                "shadow_analysis": shadow_analysis or {},
            }
            meta_path = destination.with_suffix(".json")
            with tempfile.NamedTemporaryFile("w", delete=False, dir=str(target_dir), encoding="utf-8") as handle:
                json.dump(meta, handle, ensure_ascii=False, separators=(",", ":"))
                handle.write("\n")
                meta_tmp = Path(handle.name)
            meta_tmp.replace(meta_path)
            if not positive:
                negative_marker.touch(exist_ok=True)
            saved += 1
        except Exception:
            continue
    cleanup_replay(root, cfg, timestamp_ms)
    return saved


def cleanup_replay(root: Path, cfg: dict[str, Any], now_ms: int) -> None:
    rcfg = cfg.get("event_replay", {})
    cutoff = int(now_ms) - max(7, min(180, int(rcfg.get("retention_days", 60) or 60))) * 86400000
    maximum = max(50, min(5000, int(rcfg.get("maximum_total_mb", 750) or 750))) * 1024 * 1024
    files = []
    total = 0
    for path in root.rglob("*"):
        try:
            if not path.is_file() or path.is_symlink():
                continue
            timestamp = int(path.stem) if path.stem.isdigit() else int(path.stat().st_mtime * 1000)
            if timestamp < cutoff:
                path.unlink(missing_ok=True)
                continue
            size = path.stat().st_size
            total += size
            files.append((timestamp, size, path))
        except Exception:
            continue
    if total <= maximum:
        return
    for _, size, path in sorted(files):
        path.unlink(missing_ok=True)
        total -= size
        if total <= maximum:
            break
