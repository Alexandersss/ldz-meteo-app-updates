#!/usr/bin/env python3
"""Verifica nazionale event-based per LDZ Meteo 2.3.2.

Registra anche le opportunita' senza previsione, misura TP/FP/FN/TN e non
confonde i singoli frame di uno stesso temporale con eventi indipendenti.
Il modulo non invia alert e non modifica direttamente le probabilita'.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any


def _finite(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
        return result if math.isfinite(result) else default
    except (TypeError, ValueError, OverflowError):
        return default


def _haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    radius = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2.0) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2.0) ** 2
    return radius * 2.0 * math.atan2(math.sqrt(a), math.sqrt(max(0.0, 1.0 - a)))


def _target_value(target: Any, key: str, default: Any = None) -> Any:
    return target.get(key, default) if isinstance(target, dict) else getattr(target, key, default)


def _cell_value(cell: Any, key: str, default: Any = None) -> Any:
    return cell.get(key, default) if isinstance(cell, dict) else getattr(cell, key, default)


def _append_jsonl(path: Path, row: dict[str, Any], maximum_mb: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    maximum = max(1, min(200, maximum_mb)) * 1024 * 1024
    if path.is_file() and path.stat().st_size > maximum:
        rotated = path.with_suffix(path.suffix + ".1")
        rotated.unlink(missing_ok=True)
        path.replace(rotated)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")


def _best_by_target(forecasts: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
    best: dict[str, dict[str, Any]] = {}
    for key, forecast in forecasts.items():
        _, _, target_name = str(key).partition("|")
        if not target_name or not isinstance(forecast, dict):
            continue
        current = best.get(target_name)
        if current is None or _finite(forecast.get("impact_probability_percent")) > _finite(current.get("impact_probability_percent")):
            best[target_name] = forecast
    return best


def _observed_on_target(target: Any, cells: list[Any], strong_vmi: float) -> bool:
    target_lat = _finite(_target_value(target, "lat"))
    target_lon = _finite(_target_value(target, "lon"))
    target_radius = max(0.1, _finite(_target_value(target, "radius_km"), 3.0))
    for cell in cells:
        if _finite(_cell_value(cell, "max_vmi")) < strong_vmi:
            continue
        cell_radius = max(0.5, _finite(_cell_value(cell, "radius_km"), 1.0))
        if _haversine_km(target_lat, target_lon, _finite(_cell_value(cell, "lat")), _finite(_cell_value(cell, "lon"))) <= target_radius + cell_radius:
            return True
    return False


def _safe_ratio(numerator: int, denominator: int) -> float | None:
    return round(100.0 * numerator / denominator, 2) if denominator else None


def _metrics(counters: dict[str, Any]) -> dict[str, Any]:
    tp = int(counters.get("tp", 0) or 0)
    fp = int(counters.get("fp", 0) or 0)
    fn = int(counters.get("fn", 0) or 0)
    tn = int(counters.get("tn", 0) or 0)
    brier_count = int(counters.get("brier_count", 0) or 0)
    precision = _safe_ratio(tp, tp + fp)
    recall = _safe_ratio(tp, tp + fn)
    f1 = None
    if precision is not None and recall is not None and precision + recall > 0:
        f1 = round(2.0 * precision * recall / (precision + recall), 2)
    return {
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
        "precision_percent": precision,
        "recall_percent": recall,
        "f1_percent": f1,
        "csi_percent": _safe_ratio(tp, tp + fp + fn),
        "false_alarm_ratio_percent": _safe_ratio(fp, tp + fp),
        "brier_score": round(_finite(counters.get("brier_sum")) / brier_count, 6) if brier_count else None,
        "slots": brier_count,
        "events": tp + fn,
        "eta_mae_minutes": round(_finite(counters.get("eta_error_sum")) / int(counters.get("eta_count", 0) or 1), 2) if int(counters.get("eta_count", 0) or 0) else None,
    }


def update_complete_verification(
    state: dict[str, Any],
    targets: list[Any],
    cells: list[Any],
    forecasts: dict[str, dict[str, Any]],
    timestamp_ms: int,
    cfg: dict[str, Any],
    sensor_context: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Aggiorna ledger a slot ed episodi, includendo i falsi negativi reali."""
    vcfg = cfg.get("verification_engine", {})
    if not bool(vcfg.get("enabled", True)):
        return {"enabled": False}
    precision = state.setdefault("precision", {})
    root = precision.setdefault("verification_v2", {})
    root.setdefault("schema", 2)
    target_state = root.setdefault("targets", {})
    overall = root.setdefault("overall_counters", {})
    recent = root.setdefault("recent_forecasts", [])
    pending_alerts = root.setdefault("pending_alerts", {})
    best = _best_by_target(forecasts)
    sensors = sensor_context or {}
    strong_vmi = _finite(cfg.get("tracking", {}).get("strong_alert_vmi_dbz", 45), 45.0)
    alert_threshold = _finite(cfg.get("tracking", {}).get("min_alert_probability_percent", 60), 60.0)
    ground_rain = max(0.1, _finite(vcfg.get("ground_rain_threshold_mmh", 2.0), 2.0))
    hits_to_open = max(1, min(4, int(vcfg.get("episode_open_hits", 2) or 2)))
    clears_to_close = max(1, min(12, int(vcfg.get("episode_close_misses", 3) or 3)))
    horizon_minutes = max(5, min(90, int(vcfg.get("event_match_minutes", cfg.get("tracking", {}).get("prealert_minutes", 20)) or 20)))
    data_dir = Path(cfg.get("app", {}).get("data_dir", "/var/lib/meteo-alert"))
    ledger = Path(vcfg.get("ledger_file", str(data_dir / "verification" / "national-slots.jsonl")))
    event_ledger = Path(vcfg.get("event_ledger_file", str(data_dir / "verification" / "national-events.jsonl")))
    maximum_mb = int(vcfg.get("max_ledger_mb", 50) or 50)

    # La storia serve soltanto per associare l'onset a previsioni precedenti.
    cutoff_ms = timestamp_ms - max(120, horizon_minutes * 3) * 60000
    recent[:] = [row for row in recent if int(row.get("timestamp_ms", 0) or 0) >= cutoff_ms][-4000:]

    for target in targets:
        name = str(_target_value(target, "name", "target"))[:100]
        info = best.get(name, {})
        probability = max(0.0, min(100.0, _finite(info.get("impact_probability_percent"))))
        eta = max(0.0, _finite(info.get("eta_minutes"))) if info else None
        radar_hit = _observed_on_target(target, cells, strong_vmi)
        sensor = sensors.get(name) or {}
        ground_hit = bool(sensor.get("available")) and _finite(sensor.get("rain_rate_mmh")) >= ground_rain
        observed = bool(radar_hit or ground_hit)
        truth_level = "radar_and_ground" if radar_hit and ground_hit else "ground_confirmed" if ground_hit else "radar_observed" if radar_hit else "clear"
        predicted = probability >= alert_threshold
        row = {
            "timestamp_ms": int(timestamp_ms), "target": name,
            "probability_percent": round(probability, 2), "eta_minutes": eta,
            "predicted_alert": predicted, "observed": observed,
            "truth_level": truth_level,
            "track_id": str(info.get("track_id", "")),
            "confidence_percent": round(_finite(info.get("impact_confidence_percent")), 2),
        }
        tstate = target_state.setdefault(name, {
            "active": False, "hit_streak": 0, "clear_streak": 0,
            "slot_counters": {}, "event_counters": {}, "last_slot_ms": 0,
        })
        if int(tstate.get("last_slot_ms", 0) or 0) == int(timestamp_ms):
            continue
        tstate["last_slot_ms"] = int(timestamp_ms)
        _append_jsonl(ledger, row, maximum_mb)
        recent.append(row)

        slot = tstate.setdefault("slot_counters", {})
        outcome_key = "tp" if predicted and observed else "fp" if predicted else "fn" if observed else "tn"
        slot[outcome_key] = int(slot.get(outcome_key, 0) or 0) + 1
        overall[outcome_key] = int(overall.get(outcome_key, 0) or 0) + 1
        brier = (probability / 100.0 - (1.0 if observed else 0.0)) ** 2
        for counters in (slot, overall):
            counters["brier_sum"] = _finite(counters.get("brier_sum")) + brier
            counters["brier_count"] = int(counters.get("brier_count", 0) or 0) + 1

        if observed:
            tstate["hit_streak"] = int(tstate.get("hit_streak", 0) or 0) + 1
            tstate["clear_streak"] = 0
        else:
            tstate["clear_streak"] = int(tstate.get("clear_streak", 0) or 0) + 1
            tstate["hit_streak"] = 0

        # Un solo candidato alert per target resta pendente: evita un FP per frame.
        if predicted and name not in pending_alerts and not bool(tstate.get("active")):
            pending_alerts[name] = {
                "created_ms": timestamp_ms,
                "due_ms": timestamp_ms + horizon_minutes * 60000,
                "probability_percent": probability,
                "eta_minutes": eta,
            }

        onset = not bool(tstate.get("active")) and int(tstate.get("hit_streak", 0)) >= hits_to_open
        if onset:
            tstate["active"] = True
            tstate["episode_started_ms"] = int(timestamp_ms)
            candidates = [
                previous for previous in recent
                if previous.get("target") == name
                and timestamp_ms - horizon_minutes * 60000 <= int(previous.get("timestamp_ms", 0) or 0) < timestamp_ms
            ]
            selected = max(candidates, key=lambda item: _finite(item.get("probability_percent")), default={})
            event_predicted = _finite(selected.get("probability_percent")) >= alert_threshold
            kind = "tp" if event_predicted else "fn"
            event = tstate.setdefault("event_counters", {})
            event[kind] = int(event.get(kind, 0) or 0) + 1
            predicted_arrival = int(selected.get("timestamp_ms", timestamp_ms) or timestamp_ms) + int(_finite(selected.get("eta_minutes")) * 60000)
            eta_error = abs(timestamp_ms - predicted_arrival) / 60000.0 if selected and selected.get("eta_minutes") is not None else None
            if eta_error is not None:
                event["eta_error_sum"] = _finite(event.get("eta_error_sum")) + eta_error
                event["eta_count"] = int(event.get("eta_count", 0) or 0) + 1
            _append_jsonl(event_ledger, {
                "event_type": "onset", "classification": kind, "target": name,
                "timestamp_ms": timestamp_ms, "truth_level": truth_level,
                "forecast": selected, "eta_error_minutes": None if eta_error is None else round(eta_error, 2),
            }, maximum_mb)
            pending_alerts.pop(name, None)

        if bool(tstate.get("active")) and int(tstate.get("clear_streak", 0)) >= clears_to_close:
            tstate["active"] = False
            tstate["episode_ended_ms"] = int(timestamp_ms)

    # Un alert non seguito da onset entro l'orizzonte e' un falso positivo evento.
    for name, pending in list(pending_alerts.items()):
        if timestamp_ms < int(pending.get("due_ms", 0) or 0):
            continue
        tstate = target_state.setdefault(name, {})
        event = tstate.setdefault("event_counters", {})
        event["fp"] = int(event.get("fp", 0) or 0) + 1
        _append_jsonl(event_ledger, {
            "event_type": "forecast_expired", "classification": "fp", "target": name,
            "timestamp_ms": timestamp_ms, "forecast": pending,
        }, maximum_mb)
        pending_alerts.pop(name, None)

    root["target_metrics"] = {
        name: {"slots": _metrics(item.get("slot_counters", {})), "events": _metrics(item.get("event_counters", {}))}
        for name, item in target_state.items()
    }
    # Le metriche evento complessive si sommano dai target; le slot restano in overall.
    event_overall: dict[str, Any] = {}
    for item in target_state.values():
        for key, value in (item.get("event_counters") or {}).items():
            event_overall[key] = _finite(event_overall.get(key)) + _finite(value)
    root["overall"] = {"slots": _metrics(overall), "events": _metrics(event_overall)}
    root["updated_ms"] = int(timestamp_ms)
    root["readiness_percent"] = round(min(100.0, _finite(root["overall"]["slots"].get("slots")) / max(1.0, _finite(vcfg.get("minimum_slots", 100), 100.0)) * 100.0), 1)
    return root
