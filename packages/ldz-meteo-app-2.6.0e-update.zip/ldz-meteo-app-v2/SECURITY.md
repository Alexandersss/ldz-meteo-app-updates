# LDZ Meteo App 2.3.2 - Security Policy

## Confini di sicurezza

La WebGUI gira come utente `meteoalert`, è in ascolto solo su `127.0.0.1` e deve essere pubblicata tramite Apache. Le azioni privilegiate passano da helper root-owned e da una sudoers allowlist senza wildcard.

Gli update richiedono una firma Ed25519 prodotta localmente da root. CRC e SHA-256 verificano l’integrità; la firma verifica anche autenticità e approvazione. Un semplice SHA-256 mostrato nella UI non è un controllo di autenticità.

Il backup WebGUI è un backup applicativo dei dati, non un’immagine di disaster recovery. Non contiene componenti eseguibili.

## Default

- Host allowlist e Origin/Referer check.
- CSRF su tutte le POST, incluso login e logout.
- Cookie `HttpOnly`, `SameSite=Lax`, `Secure` con HTTPS; sessione normale con timeout inattività di 30 minuti e token `Ricordami` firmato, revocabile e limitato a 30 giorni.
- CSP con nonce per gli script; Leaflet locale.
- `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, COOP/CORP, Permissions-Policy e HSTS su HTTPS.
- Login: massimo 5 errori in 15 minuti per indirizzo visto dall’app.
- Azioni root WebGUI disabilitate per default nell’installer; abilitarle solo su una superficie amministrativa protetta.
- Endpoint webhook/SMTP privati bloccati per default; HTTP webhook bloccato per default.
- Update/restore: limiti upload, archive allowlist e snapshot root-owned.
- Precision Engine: cache senza pickle, limiti frame/ensemble/poligoni, esclusione prodotti disallineati e sospensione alert su VMI stale.
- ICON-2I è opzionale, con endpoint HTTPS controllato e fallback radar-only; non è una dipendenza necessaria per continuare il monitoraggio.

## Pubblicazione

Preferire HTTPS con certificato attendibile e una barriera aggiuntiva (VPN, access proxy con MFA o allowlist IP). Non esporre la porta Waitress 8090. Se Apache è dietro un ulteriore proxy, allineare `LDZ_METEO_ALLOWED_HOSTS`, `LDZ_METEO_ALLOWED_ORIGINS` e gli header forwarded.

## Segnalazioni

Non pubblicare token Telegram, backup con segreti, chiavi private, payload operativi o log sensibili. Conservare evidenze e versione esatta, quindi condividere i dettagli tramite un canale privato con il manutentore.
