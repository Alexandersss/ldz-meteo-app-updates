#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec env LDZ_METEO_SOURCE_SECURITY_TOOL="$SCRIPT_DIR/web/security_utils.py" "$SCRIPT_DIR/scripts/ldz-meteo-apply-hotfix" "$@"
