#!/usr/bin/env python3
"""
Meteo Alert Telegram
- Scarica prodotti Radar-DPC ufficiali (VMI, SRI, POH, VIL, ETM, SRT1, IR_108, CAPPI)
- Rileva celle intense vicino ai target configurati
- Stima traiettoria e ETA verso target entro 20 minuti
- Invia alert Telegram solo con rischio grandine/temporale forte
- Genera meteo.jpg con attribuzione fonte Radar-DPC

Nota: sistema informativo personale, NON sostituisce allerte ufficiali.
"""
from __future__ import annotations

import argparse
import csv
import fcntl
import html
import ipaddress
import json
import logging
import math
import os
import re
os.environ.setdefault("MPLCONFIGDIR", "/var/lib/meteo-alert/matplotlib")
import shutil
import smtplib
import socket
import ssl
import subprocess
import sys
import tempfile
import textwrap
import time
from dataclasses import dataclass, asdict, field
from email.message import EmailMessage
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, ListedColormap, BoundaryNorm
import numpy as np
import requests
import yaml
from pyproj import Transformer
from scipy import ndimage as ndi
from scipy.spatial import ConvexHull

try:
    import paho.mqtt.client as mqtt
except Exception:  # Dipendenza opzionale se il sensore MQTT è disabilitato.
    mqtt = None

import rasterio
from rasterio.enums import Resampling
from rasterio.transform import from_bounds as transform_from_bounds
from rasterio.warp import reproject

from precision_engine import (
    COMPAT_MODULE_SOURCE,
    best_forecasts_by_target,
    build_precision_forecasts,
    estimate_optical_flows,
    load_radar_cache,
    save_radar_cache,
    update_tracks,
    update_verification,
)
try:
    from precision_engine import is_duplicate_radar_frame, raster_nowcast_shadow
except ImportError:
    # Compatibilità con il bootstrap/mock delle installazioni 2.6 già in campo:
    # le due analisi restano disattivate finché precision_engine viene sostituito.
    def is_duplicate_radar_frame(*_args: Any, **_kwargs: Any) -> bool:
        return False

    def raster_nowcast_shadow(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
        return {"enabled": False, "available": False, "mode": "shadow", "reason": "precision-engine-legacy"}
from terrain_lifecycle import initiation_watch, terrain_summary, update_lightning_jump
from adaptive_ai import load_batch_candidate
from event_feedback import (
    build_feedback_prompt,
    drain_feedback_inbox,
    mark_prompt_sent,
    pending_feedback_prompts,
    save_replay_snapshots,
    update_incidents,
)
try:
    from event_feedback import load_feedback_secrets
except ImportError:
    # Bootstrap/test con modulo feedback della precedente 2.6.0h.
    def load_feedback_secrets(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
        return {"current": "", "previous": "", "configured": False, "v1_accept_until": 0}
from hail_feedback import apply_candidate as apply_hail_feedback_candidate, build_feature_vector as build_hail_feedback_features
from weather_lab import update_weather_lab
from build_info import log_service_start
from state_store import load_state as load_persistent_state, save_state as save_persistent_state
try:
    from verification_engine import update_complete_verification
except ModuleNotFoundError:
    # Bootstrap in un solo passaggio dall'updater 2.3.1, che non conosceva
    # ancora questo modulo ma distribuiva l'intera WebGUI firmata.
    compatibility_dir = Path(os.environ.get("LDZ_METEO_COMPAT_MODULE_DIR", "/opt/ldz-meteo-web/engine_compat"))
    if not compatibility_dir.is_dir() or compatibility_dir.is_symlink():
        raise
    sys.path.insert(0, str(compatibility_dir))
    from verification_engine import update_complete_verification

EARTH_RADIUS_KM = 6371.0088
RISK_ORDER = {"LOW": 1, "MEDIUM": 2, "HIGH": 3}


RADAR_METRIC_LABELS = {
    "VMI": "VMI · intensità verticale radar",
    "SRI": "SRI · pioggia stimata al suolo",
    "POH": "POH · probabilità grandine",
    "VIL": "VIL · acqua/ghiaccio nella colonna",
    "ETM": "ETM · quota massima eco radar",
    "SRT1": "SRT1 · accumulo precipitazione in un'ora",
    "IR_108": "IR_108 · temperatura sommita' nuvolosa",
    "LGT": "LGT · fulmini reali Radar-DPC",
    "CAPPI": "CAPPI · profilo verticale di riflettività",
    "SITES": "SITES · stato operativo radar nazionali",
}

RADAR_METRIC_SHORT_HELP = {
    "VMI": "quanto è intenso il nucleo visto dal radar in verticale",
    "SRI": "stima della pioggia istantanea vicino al suolo",
    "POH": "probabilità radar che la cella contenga grandine",
    "VIL": "quantità stimata di acqua/ghiaccio nella nube temporalesca",
    "ETM": "altezza massima raggiunta dall'eco radar della cella",
    "SRT1": "quanto la precipitazione e' persistita nell'ultima ora",
    "IR_108": "quanto e' fredda e profonda la sommita' della nube",
    "LGT": "fulmini osservati dal layer Radar-DPC/LAMPINET",
    "CAPPI": "quanto in alto si mantiene il nucleo radar intenso",
    "SITES": "quali radar della rete nazionale risultano attivi o fuori servizio",
}

def radar_metric_label(code: str) -> str:
    return RADAR_METRIC_LABELS.get(str(code).upper(), str(code))

def radar_metric_help(code: str) -> str:
    return RADAR_METRIC_SHORT_HELP.get(str(code).upper(), str(code))

def radar_metrics_legend_line() -> str:
    return "Legenda sigle: VMI=intensità verticale radar, POH=probabilità grandine, VIL=acqua/ghiaccio in nube, ETM=quota massima eco radar."



@dataclass
class Target:
    name: str
    lat: float
    lon: float
    radius_km: float


@dataclass
class RadarFrame:
    product: str
    timestamp_ms: int
    path: str


@dataclass
class Cell:
    cell_id: str
    timestamp_ms: int
    lat: float
    lon: float
    area_km2: float
    radius_km: float
    pixels: int
    max_vmi: float
    mean_vmi: float
    max_sri: Optional[float]
    max_poh: Optional[float]
    max_vil: Optional[float]
    max_etm: Optional[float]
    risk: str
    risk_reasons: list[str]
    nearest_target: str
    nearest_distance_km: float
    footprint_xy_km: list[list[float]]
    pixel_bbox: list[int]
    centroid_row: float
    centroid_col: float
    shape_eccentricity: float
    shape_orientation_deg: float
    max_srt1: Optional[float] = None
    min_ir108: Optional[float] = None
    track_id: str = ""
    track_frames: int = 1
    lifecycle: str = "new"
    core_area_km2: float = 0.0
    core_radius_km: float = 0.0
    core_fraction: float = 0.0
    core_footprint_xy_km: list[list[float]] = field(default_factory=list)
    cappi_profile_dbz: dict[str, float] = field(default_factory=dict)
    cappi_available_levels: int = 0
    cappi_highest_45_km: Optional[float] = None
    cappi_highest_50_km: Optional[float] = None
    cappi_highest_55_km: Optional[float] = None
    cappi_quality_percent: float = 0.0
    cappi_timestamp_ms: Optional[int] = None
    segmentation_method: str = "single-threshold"
    segmentation_parent_id: Optional[int] = None
    product_coverage_percent: dict[str, float] = field(default_factory=dict)


@dataclass
class LightningStrike:
    lat: float
    lon: float
    timestamp_ms: int



class MeteoAlertError(Exception):
    pass


class MeteoAlertTransientRemoteError(MeteoAlertError):
    """Errore temporaneo del servizio remoto Radar-DPC.

    Usato per non far fallire in modo rumoroso timer/installer quando
    l'API risponde 429/5xx. Il run termina senza alert e riprova al giro successivo.
    """
    pass


def allow_private_endpoints(cfg: dict[str, Any]) -> bool:
    return bool(cfg.get("network", {}).get("allow_private_endpoints", False))


def validate_outbound_host(host: str, cfg: dict[str, Any]) -> None:
    host = (host or "").strip().rstrip(".")
    if not host or len(host) > 253:
        raise MeteoAlertError("host remoto assente o non valido")
    try:
        addresses = {item[4][0] for item in socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)}
    except socket.gaierror as exc:
        raise MeteoAlertTransientRemoteError(f"DNS non risolvibile per {host}: {exc}") from exc
    if not addresses:
        raise MeteoAlertTransientRemoteError(f"DNS senza indirizzi per {host}")
    if allow_private_endpoints(cfg):
        return
    for raw in addresses:
        address = ipaddress.ip_address(raw.split("%", 1)[0])
        if not address.is_global:
            raise MeteoAlertError(f"endpoint privato/locale bloccato: {host} -> {address}")


def validate_outbound_url(url: str, cfg: dict[str, Any], *, https_only: bool = True) -> str:
    parsed = urlparse(str(url))
    allowed_schemes = {"https"} if https_only else {"http", "https"}
    if parsed.scheme.lower() not in allowed_schemes or not parsed.hostname:
        raise MeteoAlertError("URL remoto con schema o host non consentito")
    if parsed.username or parsed.password or parsed.fragment:
        raise MeteoAlertError("URL remoto con credenziali o fragment non consentito")
    validate_outbound_host(parsed.hostname, cfg)
    return str(url)


def validate_raster_dataset(dataset: Any, cfg: dict[str, Any], path: str) -> None:
    max_pixels = int(cfg.get("app", {}).get("max_raster_pixels", 30_000_000) or 30_000_000)
    max_pixels = max(1_000_000, min(max_pixels, 100_000_000))
    if dataset.width <= 0 or dataset.height <= 0 or dataset.count <= 0:
        raise MeteoAlertError(f"raster con geometria non valida: {path}")
    if dataset.width * dataset.height > max_pixels or dataset.count > 16:
        raise MeteoAlertError(
            f"raster oltre i limiti: {dataset.width}x{dataset.height} bande={dataset.count} path={path}"
        )


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def ms_to_dt(ms: int) -> datetime:
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc)


def dt_iso(ms: int) -> str:
    return ms_to_dt(ms).astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")


def load_config(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    if isinstance(cfg, dict):
        radar = cfg.setdefault("radar", {})
        api_base = str(radar.get("api_base", "")).rstrip("/")
        # Compatibilita': alcuni installer intermedi impostavano erroneamente /wide/product.
        # Gli endpoint documentati sono relativi alla root, es. /findLastProductByType.
        if api_base.endswith("/wide/product"):
            radar["api_base"] = api_base[: -len("/wide/product")]
    return cfg


class JournalPriorityFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        priority = 3 if record.levelno >= logging.ERROR else 4 if record.levelno >= logging.WARNING else 6
        return f"<{priority}>" + super().format(record)


def setup_logging(cfg: dict[str, Any]) -> None:
    log_dir = Path(cfg["app"]["log_dir"])
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "meteo-alert.log"

    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.handlers.clear()
    fmt = JournalPriorityFormatter("%(asctime)s %(levelname)s %(message)s")

    sh = logging.StreamHandler(sys.stdout)
    sh.addFilter(lambda record: record.levelno < logging.WARNING)
    sh.setFormatter(fmt)
    root.addHandler(sh)

    warning_handler = logging.StreamHandler(sys.stderr)
    warning_handler.setLevel(logging.WARNING)
    warning_handler.setFormatter(fmt)
    root.addHandler(warning_handler)

    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setFormatter(fmt)
    root.addHandler(fh)


def load_state(path: Path) -> dict[str, Any]:
    try:
        return load_persistent_state(path)
    except Exception as exc:
        raise MeteoAlertError(f"State file corrotto: {path}: {exc}") from exc


def save_state(path: Path, state: dict[str, Any]) -> None:
    save_persistent_state(path, state)


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return 2 * EARTH_RADIUS_KM * math.asin(math.sqrt(a))


def lonlat_to_xy_km(lon: float, lat: float, lon0: float, lat0: float) -> tuple[float, float]:
    x = math.radians(lon - lon0) * EARTH_RADIUS_KM * math.cos(math.radians(lat0))
    y = math.radians(lat - lat0) * EARTH_RADIUS_KM
    return x, y


def sanitize_array(arr: np.ndarray, product: str, cfg: dict[str, Any]) -> np.ndarray:
    out = arr.astype("float32", copy=True)
    out[~np.isfinite(out)] = np.nan
    ranges = cfg["thresholds"].get("valid_ranges", {})
    range_key = "CAPPI" if str(product).upper().startswith("CAPPI_") else product
    if range_key in ranges:
        lo, hi = ranges[range_key]
        out[(out < lo) | (out > hi)] = np.nan
    return out


def request_json(session: requests.Session, method: str, url: str, timeout: int, **kwargs: Any) -> dict[str, Any]:
    transient_statuses = {429, 500, 502, 503, 504}
    # retry_attempts indica il numero totale di tentativi, non i soli retry.
    attempts = int(kwargs.pop("retry_attempts", 4))
    retry_sleep_seconds = float(kwargs.pop("retry_sleep_seconds", 8.0))
    last_exc: Exception | None = None
    cfg = kwargs.pop("security_cfg", {})
    validate_outbound_url(url, cfg)

    for attempt in range(1, max(1, attempts) + 1):
        try:
            r = session.request(method, url, timeout=timeout, allow_redirects=False, **kwargs)
            if r.status_code in transient_statuses:
                msg = f"Radar-DPC temporaneamente non disponibile HTTP {r.status_code} per {url}"
                if attempt < attempts:
                    wait = retry_sleep_seconds * attempt
                    logging.warning("%s; retry %s/%s tra %.0fs", msg, attempt, attempts, wait)
                    time.sleep(wait)
                    continue
                raise MeteoAlertTransientRemoteError(msg)
            if r.status_code in {401, 403}:
                # Radar-DPC v2 puo' rifiutare richieste prive di Origin/Referer o non allineate
                # alla piattaforma ufficiale. Lo trattiamo come remoto/non fatale per evitare
                # false rotture del timer: al ciclo successivo riprova automaticamente.
                raise MeteoAlertTransientRemoteError(
                    f"Radar-DPC ha rifiutato la richiesta HTTP {r.status_code} per {url}; "
                    "verificare header Origin/Referer"
                )

            r.raise_for_status()
            if len(r.content) > 2 * 1024 * 1024:
                raise MeteoAlertError(f"risposta JSON troppo grande da {urlparse(url).hostname}")
            data = r.json()
            if not isinstance(data, dict):
                raise MeteoAlertError(f"Risposta non JSON object da {url}")
            return data
        except (requests.Timeout, requests.ConnectionError) as exc:
            last_exc = exc
            if attempt < attempts:
                wait = retry_sleep_seconds * attempt
                logging.warning("Errore rete temporaneo verso Radar-DPC: %s; retry %s/%s tra %.0fs", exc, attempt, attempts, wait)
                time.sleep(wait)
                continue
            raise MeteoAlertTransientRemoteError(f"Radar-DPC non raggiungibile dopo {attempts} tentativi: {exc}") from exc

    raise MeteoAlertTransientRemoteError(f"Radar-DPC temporaneamente non disponibile: {last_exc}")


def fetch_atmospheric_context(session: requests.Session, targets: list[Target], cfg: dict[str, Any], cache_key: str = "italy") -> dict[str, Any]:
    """Consenso atmosferico multi-modello, sempre subordinato al radar."""
    acfg = cfg.get("atmospheric_context", {})
    if not bool(acfg.get("enabled", True)) or not targets:
        return {"enabled": False, "available": False}
    configured_cache = acfg.get("cache_file")
    if configured_cache and cache_key == "italy":
        cache_path = Path(str(configured_cache))
    else:
        safe_key = re.sub(r"[^a-zA-Z0-9_.-]", "-", cache_key)[:64] or "italy"
        cache_path = Path(cfg["app"]["data_dir"]) / "precision" / f"nwp-consensus-{safe_key}.json"
    refresh_minutes = max(15, min(180, int(acfg.get("refresh_minutes", 45) or 45)))
    stale_hours = max(1, min(12, int(acfg.get("stale_cache_hours", 4) or 4)))

    def cached(max_age_minutes: float) -> Optional[dict[str, Any]]:
        try:
            if not cache_path.is_file() or cache_path.is_symlink() or cache_path.stat().st_size > 1024 * 1024:
                return None
            data = json.loads(cache_path.read_text(encoding="utf-8"))
            age = (utc_now().timestamp() * 1000 - int(data.get("fetched_ms", 0))) / 60000.0
            if age <= max_age_minutes:
                data["cache_age_minutes"] = round(max(0.0, age), 1)
                return data
        except Exception:
            return None
        return None

    fresh = cached(refresh_minutes)
    if fresh:
        return fresh

    lat = sum(t.lat for t in targets) / len(targets)
    lon = sum(t.lon for t in targets) / len(targets)
    endpoint = str(acfg.get("api_url", "https://api.open-meteo.com/v1/forecast"))
    try:
        validate_outbound_url(endpoint, cfg)
        models = acfg.get("models")
        if not isinstance(models, list) or not models:
            models = [str(acfg.get("model", "italia_meteo_arpae_icon_2i"))]
        models = [str(model).strip() for model in models[:4] if str(model).strip()]

        def parse_payload(payload: dict[str, Any], model: str) -> dict[str, Any]:
            hourly = payload.get("hourly") or {}
            times = hourly.get("time") or []
            if not times:
                raise MeteoAlertError(f"{model} senza timeline")
            parsed_times = []
            for raw_time in times:
                parsed = datetime.fromisoformat(str(raw_time).replace("Z", "+00:00"))
                if parsed.tzinfo is None:
                    parsed = parsed.replace(tzinfo=timezone.utc)
                parsed_times.append(parsed.astimezone(timezone.utc))
            index = min(range(len(parsed_times)), key=lambda i: abs((parsed_times[i] - utc_now()).total_seconds()))

            def value(name: str) -> Optional[float]:
                values = hourly.get(name) or []
                try:
                    result = float(values[index])
                    return result if math.isfinite(result) else None
                except Exception:
                    return None

            speed700, direction700 = value("wind_speed_700hPa"), value("wind_direction_700hPa")
            speed500, direction500 = value("wind_speed_500hPa"), value("wind_direction_500hPa")
            vectors = []
            for speed, direction, weight in ((speed700, direction700, 0.65), (speed500, direction500, 0.35)):
                if speed is None or direction is None:
                    continue
                radians = math.radians(direction)
                vectors.append((-speed * math.sin(radians), -speed * math.cos(radians), weight))
            if not vectors:
                raise MeteoAlertError(f"{model} senza vento 700/500 hPa")
            weight_sum = sum(row[2] for row in vectors)
            return {
                "model": model,
                "valid_time": times[index],
                "east_kmh": sum(row[0] * row[2] for row in vectors) / weight_sum,
                "north_kmh": sum(row[1] * row[2] for row in vectors) / weight_sum,
                "wind_700_kmh": speed700,
                "wind_700_direction_deg": direction700,
                "wind_500_kmh": speed500,
                "wind_500_direction_deg": direction500,
                "cape_jkg": value("cape"),
                "cin_jkg": value("convective_inhibition"),
                "freezing_level_m": value("freezing_level_height"),
            }

        members = []
        errors = []
        for model in models:
            params = {
                "latitude": f"{lat:.5f}",
                "longitude": f"{lon:.5f}",
                "models": model,
                "hourly": "wind_speed_700hPa,wind_direction_700hPa,wind_speed_500hPa,wind_direction_500hPa,cape,convective_inhibition,freezing_level_height",
                "forecast_hours": "6",
                "wind_speed_unit": "kmh",
                "timezone": "UTC",
            }
            try:
                response = session.get(endpoint, params=params, timeout=(5, 20), allow_redirects=False)
                response.raise_for_status()
                if len(response.content) > 2 * 1024 * 1024:
                    raise MeteoAlertError(f"risposta {model} oltre 2 MiB")
                payload = response.json()
                if not isinstance(payload, dict):
                    raise MeteoAlertError(f"risposta {model} non valida")
                members.append(parse_payload(payload, model))
            except Exception as model_exc:
                errors.append({"model": model, "error": type(model_exc).__name__})
                logging.warning("modello atmosferico %s escluso: %s", model, model_exc)
        if not members:
            raise MeteoAlertError("nessun modello atmosferico disponibile")

        east_values = np.asarray([row["east_kmh"] for row in members], dtype="float64")
        north_values = np.asarray([row["north_kmh"] for row in members], dtype="float64")
        east = float(np.median(east_values))
        north = float(np.median(north_values))
        spread = float(np.sqrt(np.mean((east_values - east) ** 2 + (north_values - north) ** 2)))

        def member_mean(name: str) -> Optional[float]:
            values = [float(row[name]) for row in members if row.get(name) is not None and math.isfinite(float(row[name]))]
            return float(np.mean(values)) if values else None

        primary = members[0]
        context = {
            "enabled": True,
            "available": True,
            "source": "consenso ICON-2I/ICON/ECMWF/GFS via Open-Meteo",
            "model": "nwp-consensus-2.3.2",
            "models_requested": models,
            "models_available": [row["model"] for row in members],
            "members": members,
            "errors": errors,
            "valid_time": primary["valid_time"],
            "fetched_ms": int(utc_now().timestamp() * 1000),
            "steering_east_kmh": round(east, 2),
            "steering_north_kmh": round(north, 2),
            "steering_spread_kmh": round(spread, 2),
            "consensus_quality_percent": round(100.0 * max(0.0, min(1.0, 1.0 - spread / 80.0)), 1),
            "wind_700_kmh": primary.get("wind_700_kmh"),
            "wind_700_direction_deg": primary.get("wind_700_direction_deg"),
            "wind_500_kmh": primary.get("wind_500_kmh"),
            "wind_500_direction_deg": primary.get("wind_500_direction_deg"),
            "cape_jkg": member_mean("cape_jkg"),
            "cin_jkg": member_mean("cin_jkg"),
            "freezing_level_m": member_mean("freezing_level_m"),
        }
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile("w", delete=False, dir=str(cache_path.parent), encoding="utf-8") as handle:
            json.dump(context, handle, ensure_ascii=False)
            handle.flush(); os.fsync(handle.fileno())
            temporary = Path(handle.name)
        temporary.replace(cache_path)
        cache_path.chmod(0o600)
        return context
    except Exception as exc:
        logging.warning("contesto atmosferico multi-modello non disponibile: %s", exc)
        fallback = cached(stale_hours * 60)
        if fallback:
            fallback["stale"] = True
            return fallback
        return {"enabled": True, "available": False, "error": type(exc).__name__}


def fetch_national_atmospheric_context(session: requests.Session, targets: list[Target], cfg: dict[str, Any]) -> dict[str, Any]:
    """Consenso NWP zero-config per target distribuiti su tutta Italia.

    I target vengono raggruppati in cluster geografici; ogni cluster usa il
    proprio profilo atmosferico invece del punto medio nazionale.
    """
    acfg = cfg.get("atmospheric_context", {})
    if not bool(acfg.get("enabled", True)) or not targets:
        return {"enabled": False, "available": False, "by_target": {}}
    radius_km = max(40.0, min(350.0, float(acfg.get("cluster_radius_km", 180.0) or 180.0)))
    max_clusters = max(1, min(20, int(acfg.get("max_clusters", 8) or 8)))
    clusters: list[list[Target]] = []
    for target in targets:
        selected: Optional[list[Target]] = None
        best_distance = float("inf")
        for cluster in clusters:
            center_lat = sum(item.lat for item in cluster) / len(cluster)
            center_lon = sum(item.lon for item in cluster) / len(cluster)
            distance = haversine_km(target.lat, target.lon, center_lat, center_lon)
            if distance <= radius_km and distance < best_distance:
                selected, best_distance = cluster, distance
        if selected is not None:
            selected.append(target)
        elif len(clusters) < max_clusters:
            clusters.append([target])
        else:
            nearest = min(
                clusters,
                key=lambda cluster: haversine_km(
                    target.lat, target.lon,
                    sum(item.lat for item in cluster) / len(cluster),
                    sum(item.lon for item in cluster) / len(cluster),
                ),
            )
            nearest.append(target)

    by_target: dict[str, dict[str, Any]] = {}
    cluster_rows: list[dict[str, Any]] = []
    for index, cluster in enumerate(clusters, start=1):
        center_lat = sum(item.lat for item in cluster) / len(cluster)
        center_lon = sum(item.lon for item in cluster) / len(cluster)
        cache_key = f"cluster-{center_lat:.2f}-{center_lon:.2f}"
        context = fetch_atmospheric_context(session, cluster, cfg, cache_key=cache_key)
        context["cluster_id"] = index
        context["cluster_center"] = {"lat": round(center_lat, 4), "lon": round(center_lon, 4)}
        context["targets"] = [item.name for item in cluster]
        cluster_rows.append(context)
        for target in cluster:
            by_target[target.name] = context

    available = [row for row in cluster_rows if row.get("available")]
    models = sorted({str(model) for row in available for model in (row.get("models_available") or [])})
    return {
        "enabled": True,
        "available": bool(available),
        "source": "consenso NWP nazionale per cluster",
        "model": "national-fusion-nwp-2.3.2",
        "clusters": cluster_rows,
        "cluster_count": len(cluster_rows),
        "available_clusters": len(available),
        "models_available": models,
        "by_target": by_target,
        "fetched_ms": int(utc_now().timestamp() * 1000),
        "consensus_quality_percent": round(sum(float(row.get("consensus_quality_percent", 0.0) or 0.0) for row in available) / len(available), 1) if available else 0.0,
        "steering_spread_kmh": round(sum(float(row.get("steering_spread_kmh", 0.0) or 0.0) for row in available) / len(available), 2) if available else None,
        "cape_jkg": round(sum(float(row.get("cape_jkg", 0.0) or 0.0) for row in available) / len(available), 1) if available else None,
    }


def fetch_terrain_profiles(
    session: requests.Session,
    cells: list[Cell],
    targets: list[Target],
    cfg: dict[str, Any],
) -> dict[str, dict[str, Any]]:
    """Campiona profili altimetrici cella→target con cache a lungo termine."""
    tcfg = cfg.get("terrain_engine", {})
    if not bool(tcfg.get("enabled", True)) or not cells or not targets:
        return {}
    samples = max(3, min(11, int(tcfg.get("profile_samples", 7) or 7)))
    maximum_pairs = max(4, min(80, int(tcfg.get("max_profiles_per_cycle", 32) or 32)))
    endpoint = str(tcfg.get("elevation_api_url", "https://api.open-meteo.com/v1/elevation"))
    validate_outbound_url(endpoint, cfg)
    cache_path = Path(tcfg.get("cache_file", str(Path(cfg["app"]["data_dir"]) / "terrain" / "elevation-cache.json")))
    cache: dict[str, Any] = {"schema": 1, "items": {}}
    try:
        if cache_path.is_file() and not cache_path.is_symlink() and cache_path.stat().st_size <= 8 * 1024 * 1024:
            loaded = json.loads(cache_path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict) and isinstance(loaded.get("items"), dict):
                cache = loaded
    except Exception:
        pass
    items = cache.setdefault("items", {})
    pairs: list[tuple[str, list[tuple[float, float]], list[str]]] = []
    missing: dict[str, tuple[float, float]] = {}
    for cell in cells[:16]:
        for target in targets:
            if len(pairs) >= maximum_pairs:
                break
            # Profili molto lontani non migliorano il nowcast locale e consumano API.
            if haversine_km(cell.lat, cell.lon, target.lat, target.lon) > float(tcfg.get("max_profile_distance_km", 140) or 140):
                continue
            coordinates = [
                (
                    cell.lat + (target.lat - cell.lat) * index / (samples - 1),
                    cell.lon + (target.lon - cell.lon) * index / (samples - 1),
                )
                for index in range(samples)
            ]
            keys = [f"{lat:.3f},{lon:.3f}" for lat, lon in coordinates]
            for key, coordinate in zip(keys, coordinates):
                if key not in items:
                    missing[key] = coordinate
            pairs.append((f"{cell.cell_id}|{target.name}", coordinates, keys))

    missing_rows = list(missing.items())[:400]
    for offset in range(0, len(missing_rows), 90):
        batch = missing_rows[offset:offset + 90]
        params = {
            "latitude": ",".join(f"{coordinate[0]:.5f}" for _, coordinate in batch),
            "longitude": ",".join(f"{coordinate[1]:.5f}" for _, coordinate in batch),
        }
        try:
            response = session.get(endpoint, params=params, timeout=(5, 20), allow_redirects=False)
            response.raise_for_status()
            if len(response.content) > 1024 * 1024:
                raise MeteoAlertError("risposta elevation oltre 1 MiB")
            payload = response.json()
            elevations = payload.get("elevation") if isinstance(payload, dict) else None
            if not isinstance(elevations, list) or len(elevations) != len(batch):
                raise MeteoAlertError("risposta elevation incompleta")
            now_ms = int(utc_now().timestamp() * 1000)
            for (key, _), elevation in zip(batch, elevations):
                value = float(elevation)
                if math.isfinite(value) and -500 <= value <= 9000:
                    items[key] = {"elevation_m": round(value, 1), "fetched_ms": now_ms}
        except Exception as exc:
            logging.warning("profilo altimetrico non aggiornato: %s", exc)
            break

    # Limite anti-crescita: mantiene le entry più recenti.
    if len(items) > 10000:
        newest = sorted(items.items(), key=lambda row: int((row[1] or {}).get("fetched_ms", 0)), reverse=True)[:10000]
        cache["items"] = items = dict(newest)
    try:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile("w", delete=False, dir=str(cache_path.parent), encoding="utf-8") as handle:
            json.dump(cache, handle, ensure_ascii=False, separators=(",", ":"))
            handle.flush(); os.fsync(handle.fileno())
            temporary = Path(handle.name)
        temporary.replace(cache_path)
        cache_path.chmod(0o600)
    except Exception as exc:
        logging.warning("cache terreno non salvata: %s", exc)

    profiles = {}
    for pair_key, _, keys in pairs:
        elevations = [(items.get(key) or {}).get("elevation_m") for key in keys]
        if all(value is not None for value in elevations):
            profiles[pair_key] = terrain_summary([float(value) for value in elevations], cfg)
    return profiles


def _sensor_score(row: dict[str, Any]) -> float:
    rain = max(0.0, float(row.get("rain_rate_mmh", 0.0) or 0.0))
    gust = max(0.0, float(row.get("wind_gust_kmh", 0.0) or 0.0))
    pressure_drop = max(0.0, -float(row.get("pressure_tendency_hpa_h", 0.0) or 0.0))
    return round(100.0 * max(0.0, min(1.0, 0.48 * min(1.0, rain / 20.0) + 0.34 * min(1.0, gust / 70.0) + 0.18 * min(1.0, pressure_drop / 4.0))), 1)


def fetch_local_sensor_context(session: requests.Session, targets: list[Target], cfg: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Ingressi opzionali file/HTTPS/MQTT; confermano, non guidano il radar."""
    scfg = cfg.get("local_sensors", {})
    if not bool(scfg.get("enabled", False)):
        return {}
    rows: list[dict[str, Any]] = []
    snapshot = Path(scfg.get("snapshot_file", str(Path(cfg["app"]["data_dir"]) / "sensors" / "latest.json")))
    try:
        if snapshot.is_file() and not snapshot.is_symlink() and snapshot.stat().st_size <= 512 * 1024:
            payload = json.loads(snapshot.read_text(encoding="utf-8"))
            rows.extend(payload if isinstance(payload, list) else payload.get("sensors", []) if isinstance(payload, dict) else [])
    except Exception as exc:
        logging.warning("snapshot sensori ignorato: %s", exc)

    for endpoint_cfg in (scfg.get("http_endpoints") or [])[:10]:
        if not isinstance(endpoint_cfg, dict) or not endpoint_cfg.get("url"):
            continue
        try:
            endpoint = str(endpoint_cfg["url"])
            sensor_security = dict(cfg)
            sensor_security["network"] = dict(cfg.get("network", {}))
            sensor_security["network"]["allow_private_endpoints"] = bool(scfg.get("allow_private_http", False))
            validate_outbound_url(endpoint, sensor_security)
            response = session.get(endpoint, timeout=(3, 8), allow_redirects=False)
            response.raise_for_status()
            if len(response.content) > 256 * 1024:
                raise MeteoAlertError("risposta sensore troppo grande")
            payload = response.json()
            if isinstance(payload, dict):
                remote_rows = payload.get("sensors") if isinstance(payload.get("sensors"), list) else [payload]
                for remote_row in remote_rows[:100]:
                    if isinstance(remote_row, dict):
                        remote_row = dict(remote_row)
                        remote_row.setdefault("target", endpoint_cfg.get("target"))
                        rows.append(remote_row)
        except Exception as exc:
            logging.warning("sensore HTTP escluso: %s", exc)

    mqtt_cfg = scfg.get("mqtt") or {}
    if bool(mqtt_cfg.get("enabled", False)) and mqtt is not None:
        host = str(mqtt_cfg.get("host", "")).strip()
        port = max(1, min(65535, int(mqtt_cfg.get("port", 8883) or 8883)))
        topics = mqtt_cfg.get("topics") or {}
        if host and isinstance(topics, dict) and topics:
            received: list[dict[str, Any]] = []
            try:
                client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                username = os.environ.get(str(mqtt_cfg.get("username_env", "LDZ_SENSOR_MQTT_USERNAME")), "")
                password = os.environ.get(str(mqtt_cfg.get("password_env", "LDZ_SENSOR_MQTT_PASSWORD")), "")
                if username:
                    client.username_pw_set(username, password)
                if bool(mqtt_cfg.get("tls", True)):
                    client.tls_set()

                def on_message(client_obj: Any, userdata: Any, message: Any) -> None:
                    if len(message.payload) > 65536:
                        return
                    try:
                        payload = json.loads(message.payload.decode("utf-8"))
                        if isinstance(payload, dict):
                            payload.setdefault("target", topics.get(message.topic))
                            received.append(payload)
                    except Exception:
                        return

                client.on_message = on_message
                client.connect(host, port, keepalive=10)
                for topic in list(topics)[:20]:
                    client.subscribe(str(topic), qos=0)
                client.loop_start()
                time.sleep(max(0.2, min(3.0, float(mqtt_cfg.get("collect_seconds", 1.5) or 1.5))))
                client.loop_stop()
                client.disconnect()
                rows.extend(received)
            except Exception as exc:
                logging.warning("sensore MQTT escluso: %s", exc)

    target_names = {target.name for target in targets}
    output: dict[str, dict[str, Any]] = {}
    now_ms = int(utc_now().timestamp() * 1000)
    maximum_age = max(2, min(60, int(scfg.get("max_age_minutes", 15) or 15)))
    for row in rows[:100]:
        if not isinstance(row, dict):
            continue
        try:
            name = str(row.get("target", ""))[:100]
            if name not in target_names:
                continue
            observed_ms = int(row.get("observed_ms", now_ms) or now_ms)
            if abs(now_ms - observed_ms) > maximum_age * 60000:
                continue
            safe = {
                "available": True,
                "source": str(row.get("source", "local_sensor"))[:80],
                "observed_ms": observed_ms,
                "rain_rate_mmh": max(0.0, min(500.0, float(row.get("rain_rate_mmh", 0.0) or 0.0))),
                "wind_gust_kmh": max(0.0, min(250.0, float(row.get("wind_gust_kmh", 0.0) or 0.0))),
                "pressure_tendency_hpa_h": max(-20.0, min(20.0, float(row.get("pressure_tendency_hpa_h", 0.0) or 0.0))),
            }
            if not all(math.isfinite(float(safe[key])) for key in ("rain_rate_mmh", "wind_gust_kmh", "pressure_tendency_hpa_h")):
                continue
            safe["confirmation_score"] = _sensor_score(safe)
            output[name] = safe
        except (TypeError, ValueError, OverflowError):
            continue
    return output


def lightning_context_by_cell(
    strikes: list[LightningStrike],
    cells: list[Cell],
    state: dict[str, Any],
    timestamp_ms: int,
    cfg: dict[str, Any],
    lightning_meta: Optional[dict[str, Any]] = None,
) -> dict[str, dict[str, Any]]:
    radius = max(5.0, min(80.0, float(cfg.get("lifecycle_engine", {}).get("lightning_cell_radius_km", 30) or 30)))
    polygon_margin = max(1.0, min(radius, float(cfg.get("lifecycle_engine", {}).get("lightning_polygon_margin_km", 10) or 10)))
    window_minutes = max(5, min(30, int(cfg.get("lifecycle_engine", {}).get("lightning_jump_window_minutes", 15) or 15)))
    recent_strikes = [
        strike for strike in strikes
        if 0 <= timestamp_ms - int(strike.timestamp_ms) <= window_minutes * 60000
    ]
    lightning_meta = lightning_meta or {}
    expected_slots = max(1, int(lightning_meta.get("expected_slots", 1) or 1))
    used_slots = len(lightning_meta.get("timestamps") or []) if lightning_meta else expected_slots
    coverage = clamp(used_slots / expected_slots, 0.0, 1.0)
    effective_window = float(lightning_meta.get("effective_window_minutes", window_minutes) or window_minutes)
    assigned: dict[str, list[LightningStrike]] = {cell.cell_id: [] for cell in cells}
    # Ogni scarica appartiene a una sola cella: prima distanza dal poligono
    # osservato, poi fallback prudente sulla distanza dal centro. Questo evita
    # che lo stesso fulmine alimenti due Lightning Jump in celle adiacenti.
    for strike in recent_strikes:
        candidates: list[tuple[float, float, str]] = []
        for cell in cells:
            center_distance = haversine_km(cell.lat, cell.lon, strike.lat, strike.lon)
            polygon_distance = center_distance
            raw = getattr(cell, "footprint_xy_km", None) or []
            try:
                polygon = np.asarray(raw, dtype="float64")
                if polygon.ndim == 2 and polygon.shape[0] >= 3 and polygon.shape[1] == 2 and np.all(np.isfinite(polygon)):
                    x, y = lonlat_to_xy_km(strike.lon, strike.lat, cell.lon, cell.lat)
                    polygon_distance = _polygon_distance_local(x, y, polygon)
            except Exception:
                polygon_distance = max(0.0, center_distance - float(getattr(cell, "radius_km", 0.0) or 0.0))
            if polygon_distance <= polygon_margin or center_distance <= radius:
                candidates.append((polygon_distance, center_distance, cell.cell_id))
        if candidates:
            assigned[min(candidates)[2]].append(strike)

    output = {}
    for cell in cells:
        cell_strikes = assigned.get(cell.cell_id, [])
        count = len(cell_strikes)
        lifecycle = str(getattr(cell, "lifecycle", "") or "")
        info = update_lightning_jump(
            cell.track_id or cell.cell_id,
            count,
            timestamp_ms,
            state,
            cfg,
            coverage_percent=coverage * 100.0,
            effective_window_minutes=effective_window,
            association_stable=lifecycle not in {"split", "merge"},
        )
        info.update({
            "radius_km": radius,
            "window_minutes": window_minutes,
            "source": "Radar-DPC LGT",
            "used_slots": used_slots,
            "expected_slots": expected_slots,
            "association_method": "nearest-cell-footprint",
            "association_margin_km": polygon_margin,
            "assigned_strikes": count,
        })
        output[cell.cell_id] = info
    return output


def find_last_product(session: requests.Session, product: str, cfg: dict[str, Any]) -> int:
    api_base = cfg["radar"]["api_base"].rstrip("/")
    timeout = int(cfg["radar"].get("request_timeout_seconds", 25))
    data = request_json(
        session,
        "GET",
        f"{api_base}/findLastProductByType",
        timeout,
        params={"type": product},
        security_cfg=cfg,
        retry_attempts=int(cfg["radar"].get("retry_attempts", 4)),
        retry_sleep_seconds=float(cfg["radar"].get("retry_sleep_seconds", 8)),
    )
    items = data.get("lastProducts") or []
    if not items:
        raise MeteoAlertError(f"Nessun prodotto disponibile per {product}: {data}")
    return int(items[0]["time"])


def download_product(session: requests.Session, product: str, timestamp_ms: int, cfg: dict[str, Any]) -> RadarFrame:
    api_base = cfg["radar"]["api_base"].rstrip("/")
    timeout = int(cfg["radar"].get("request_timeout_seconds", 25))
    data_dir = Path(cfg["app"]["data_dir"])
    frame_dir = data_dir / "frames" / product
    frame_dir.mkdir(parents=True, exist_ok=True)
    out_path = frame_dir / f"{product}_{timestamp_ms}.tif"

    if out_path.exists() and out_path.stat().st_size > 0:
        return RadarFrame(product, timestamp_ms, str(out_path))

    payload = {"productType": product, "productDate": timestamp_ms}
    meta = request_json(
        session,
        "POST",
        f"{api_base}/downloadProduct",
        timeout,
        json=payload,
        security_cfg=cfg,
        retry_attempts=int(cfg["radar"].get("retry_attempts", 4)),
        retry_sleep_seconds=float(cfg["radar"].get("retry_sleep_seconds", 8)),
    )
    url = meta.get("url")
    if not url:
        raise MeteoAlertError(f"downloadProduct non ha restituito URL per {product}: {meta}")
    validate_outbound_url(str(url), cfg)

    logging.info("download product=%s timestamp=%s", product, dt_iso(timestamp_ms))
    attempts = int(cfg["radar"].get("retry_attempts", 4))
    sleep_base = float(cfg["radar"].get("retry_sleep_seconds", 8))
    transient_statuses = {429, 500, 502, 503, 504}
    tmp_path: Path | None = None
    max_download = int(cfg.get("radar", {}).get("max_raster_download_mb", 128) or 128) * 1024 * 1024
    max_download = max(8 * 1024 * 1024, min(max_download, 512 * 1024 * 1024))
    for attempt in range(1, max(1, attempts) + 1):
        try:
            with session.get(url, timeout=timeout, stream=True, allow_redirects=False) as r:
                if r.status_code in transient_statuses:
                    msg = f"download raster Radar-DPC temporaneamente non disponibile HTTP {r.status_code}"
                    if attempt < attempts:
                        wait = sleep_base * attempt
                        logging.warning("%s; retry %s/%s tra %.0fs", msg, attempt, attempts, wait)
                        time.sleep(wait)
                        continue
                    raise MeteoAlertTransientRemoteError(msg)
                if r.status_code in {401, 403}:
                    raise MeteoAlertTransientRemoteError(
                        f"download raster Radar-DPC rifiutato HTTP {r.status_code}; URL remoto non autorizzato o scaduto"
                    )
                r.raise_for_status()
                content_length = int(r.headers.get("Content-Length", "0") or 0)
                if content_length > max_download:
                    raise MeteoAlertError(f"raster remoto oltre il limite: {content_length} byte")
                with tempfile.NamedTemporaryFile(delete=False, dir=str(frame_dir), suffix=".tmp") as tmp:
                    tmp_path = Path(tmp.name)
                    downloaded = 0
                    for chunk in r.iter_content(chunk_size=1024 * 1024):
                        if chunk:
                            downloaded += len(chunk)
                            if downloaded > max_download:
                                raise MeteoAlertError("raster remoto oltre il limite durante lo streaming")
                            tmp.write(chunk)
            break
        except (requests.Timeout, requests.ConnectionError) as exc:
            if tmp_path is not None:
                tmp_path.unlink(missing_ok=True)
                tmp_path = None
            if attempt < attempts:
                wait = sleep_base * attempt
                logging.warning("Errore rete temporaneo durante download raster: %s; retry %s/%s tra %.0fs", exc, attempt, attempts, wait)
                time.sleep(wait)
                continue
            raise MeteoAlertTransientRemoteError(f"download raster Radar-DPC non riuscito dopo {attempts} tentativi: {exc}") from exc
        except Exception:
            if tmp_path is not None:
                tmp_path.unlink(missing_ok=True)
                tmp_path = None
            raise

    if tmp_path is None:
        raise MeteoAlertTransientRemoteError("download raster Radar-DPC non riuscito: file temporaneo non creato")
    tmp_path.replace(out_path)
    return RadarFrame(product, timestamp_ms, str(out_path))


def _normalize_site_status(value: Any) -> Optional[bool]:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(int(value))
    text = str(value or "").strip().lower()
    if text in {"on", "online", "active", "attivo", "operational", "ok", "green", "1", "true"}:
        return True
    if text in {"off", "offline", "inactive", "inattivo", "ko", "red", "0", "false"}:
        return False
    return None


def _site_rows_from_payload(payload: Any) -> list[dict[str, Any]]:
    """Normalizza GeoJSON/JSON SITES senza dipendere da nomi campo fragili."""
    if isinstance(payload, dict) and isinstance(payload.get("features"), list):
        source_rows = payload["features"]
    elif isinstance(payload, dict):
        source_rows = payload.get("sites") or payload.get("radars") or payload.get("data") or []
    elif isinstance(payload, list):
        source_rows = payload
    else:
        source_rows = []
    rows: list[dict[str, Any]] = []
    for raw in source_rows:
        if not isinstance(raw, dict):
            continue
        props = raw.get("properties") if isinstance(raw.get("properties"), dict) else raw
        geometry = raw.get("geometry") if isinstance(raw.get("geometry"), dict) else {}
        coords = geometry.get("coordinates") if isinstance(geometry.get("coordinates"), list) else []
        name = next((props.get(key) for key in ("name", "nome", "site", "radar", "id", "code") if props.get(key) not in (None, "")), "radar")
        status_value = next((props.get(key) for key in ("status", "state", "stato", "active", "enabled", "operational", "online") if key in props), None)
        active = _normalize_site_status(status_value)
        lon = props.get("lon", props.get("longitude"))
        lat = props.get("lat", props.get("latitude"))
        if len(coords) >= 2:
            lon, lat = coords[0], coords[1]
        try:
            lon_value = float(lon) if lon is not None else None
            lat_value = float(lat) if lat is not None else None
            if lon_value is not None and not -180 <= lon_value <= 180:
                lon_value = None
            if lat_value is not None and not -90 <= lat_value <= 90:
                lat_value = None
        except Exception:
            lon_value = lat_value = None
        rows.append({"name": str(name)[:100], "active": active, "lat": lat_value, "lon": lon_value})
    return rows[:200]


def _source_backoff_path(cfg: dict[str, Any]) -> Path:
    return Path(cfg.get("app", {}).get("data_dir", "/var/lib/meteo-alert")) / "source-backoff.json"


def source_backoff_status(cfg: dict[str, Any], source: str, now_epoch: int | None = None) -> dict[str, Any]:
    path = _source_backoff_path(cfg)
    try:
        value = json.loads(path.read_text(encoding="utf-8")) if path.is_file() and not path.is_symlink() else {}
    except (OSError, ValueError, TypeError):
        value = {}
    entry = value.get(source) if isinstance(value.get(source), dict) else {}
    current = int(now_epoch if now_epoch is not None else time.time())
    return {**entry, "blocked": int(entry.get("retry_after_epoch", 0) or 0) > current}


def record_source_backoff(
    cfg: dict[str, Any], source: str, error: str | None, *, seconds: int = 21600, now_epoch: int | None = None
) -> dict[str, Any]:
    path = _source_backoff_path(cfg)
    current = int(now_epoch if now_epoch is not None else time.time())
    try:
        value = json.loads(path.read_text(encoding="utf-8")) if path.is_file() and not path.is_symlink() else {}
    except (OSError, ValueError, TypeError):
        value = {}
    if error is None:
        value.pop(source, None)
        entry: dict[str, Any] = {}
    else:
        previous = value.get(source) if isinstance(value.get(source), dict) else {}
        entry = {
            "failures": int(previous.get("failures", 0) or 0) + 1,
            "last_error_class": str(error)[:120],
            "last_failure_epoch": current,
            "retry_after_epoch": current + max(300, min(86400, int(seconds))),
        }
        value[source] = entry
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", delete=False, dir=str(path.parent), encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
        temporary = Path(handle.name)
    temporary.chmod(0o600)
    temporary.replace(path)
    return entry


def fetch_radar_sites_status(
    session: requests.Session,
    targets: list[Target],
    cfg: dict[str, Any],
) -> dict[str, Any]:
    """Legge il prodotto ufficiale SITES e segnala radar OFF vicini ai target.

    Il formato raw può evolvere: JSON/GeoJSON e CSV sono accettati; un formato
    non riconosciuto resta telemetria non disponibile e non penalizza alla cieca.
    """
    scfg = cfg.get("radar_sites", {})
    if not bool(scfg.get("enabled", True)):
        return {"enabled": False, "available": False}
    timestamp_ms = find_last_product(session, "SITES", cfg)
    api_base = cfg["radar"]["api_base"].rstrip("/")
    timeout = int(cfg["radar"].get("request_timeout_seconds", 25))
    meta = request_json(
        session, "POST", f"{api_base}/downloadProduct", timeout,
        json={"productType": "SITES", "productDate": timestamp_ms},
        security_cfg=cfg,
        retry_attempts=int(cfg["radar"].get("retry_attempts", 4)),
        retry_sleep_seconds=float(cfg["radar"].get("retry_sleep_seconds", 8)),
    )
    url = str(meta.get("url", ""))
    if not url:
        raise MeteoAlertError("downloadProduct non ha restituito URL per SITES")
    validate_outbound_url(url, cfg)
    response = session.get(url, timeout=timeout, allow_redirects=False)
    response.raise_for_status()
    if len(response.content) > 8 * 1024 * 1024:
        raise MeteoAlertError("prodotto SITES oltre il limite di 8 MiB")
    raw = response.content
    rows: list[dict[str, Any]] = []
    parser = "unknown"
    try:
        rows = _site_rows_from_payload(json.loads(raw.decode("utf-8-sig")))
        parser = "json"
    except Exception:
        try:
            text = raw.decode("utf-8-sig")
            delimiter = ";" if text.count(";") > text.count(",") else ","
            parsed = list(csv.DictReader(text.splitlines(), delimiter=delimiter))
            rows = _site_rows_from_payload(parsed)
            parser = "csv"
        except Exception:
            rows = []
    active_rows = [row for row in rows if row.get("active") is True]
    inactive_rows = [row for row in rows if row.get("active") is False]
    relevant_radius = max(50.0, min(350.0, float(scfg.get("relevant_radius_km", 180) or 180)))
    relevant_offline = []
    for row in inactive_rows:
        if row.get("lat") is None or row.get("lon") is None:
            continue
        distance = min(haversine_km(target.lat, target.lon, float(row["lat"]), float(row["lon"])) for target in targets) if targets else 9999.0
        if distance <= relevant_radius:
            relevant_offline.append({**row, "nearest_target_km": round(distance, 1)})
    return {
        "enabled": True,
        "available": bool(rows),
        "timestamp_ms": int(timestamp_ms),
        "age_minutes": round(max(0.0, (utc_now().timestamp() * 1000 - timestamp_ms) / 60000.0), 1),
        "parser": parser,
        "sites_total": len(rows),
        "active": len(active_rows),
        "inactive": len(inactive_rows),
        "unknown": len(rows) - len(active_rows) - len(inactive_rows),
        "relevant_offline": relevant_offline[:12],
        # Le coordinate servono solo a costruire un indicatore di copertura
        # locale. Il mosaico DPC non espone quale radar abbia contribuito a
        # ciascun pixel, quindi non attribuiamo il dato a un singolo sito.
        "sites": rows,
        "source": "Radar-DPC SITES",
    }


def build_temporal_bundle(
    timestamps: dict[str, int],
    product_quality: dict[str, dict[str, Any]],
    lightning_meta: dict[str, Any],
    sites_status: dict[str, Any],
    cfg: dict[str, Any],
    *,
    now_ms: Optional[int] = None,
) -> dict[str, Any]:
    """Crea un pacchetto temporale e una confidenza operativa per prodotto.

    Il punteggio misura solamente disponibilità, freschezza e allineamento.
    Non pretende di quantificare beam blocking, clutter, bright band,
    attenuazione o qualità del singolo pixel del mosaico nazionale.
    """
    current_ms = int(now_ms if now_ms is not None else utc_now().timestamp() * 1000)
    try:
        reference_ms = max(0, int(timestamps.get("VMI", 0) or 0))
    except (TypeError, ValueError, OverflowError):
        reference_ms = 0
    products: dict[str, dict[str, Any]] = {}
    issues: list[str] = []
    critical = ("VMI", "SRI", "POH", "VIL", "ETM")
    weights = {"VMI": 0.50, "SRI": 0.15, "POH": 0.15, "VIL": 0.10, "ETM": 0.10}
    max_age = max(1.0, float(cfg.get("app", {}).get("max_frame_age_minutes", 30) or 30))
    max_skew = max(1.0, float(cfg.get("precision_engine", {}).get("max_product_skew_minutes", 12) or 12))
    for product in sorted(set(timestamps) | set(critical)):
        try:
            timestamp = max(0, int(timestamps.get(product, 0) or 0))
        except (TypeError, ValueError, OverflowError):
            timestamp = 0
            issues.append(f"{product} timestamp corrotto")
        item = dict(product_quality.get(product) or {})
        age = max(0.0, (current_ms - timestamp) / 60000.0) if timestamp else None
        skew = abs(timestamp - reference_ms) / 60000.0 if timestamp and reference_ms else None
        available = bool(timestamp)
        used = available and bool(item.get("used", True))
        if not available:
            score = 0.0
            status = "missing"
        elif not used:
            score = 0.0
            status = "misaligned"
        else:
            # Nessuna penalità entro metà della tolleranza; poi il decadimento
            # è continuo, evitando salti binari vicino alla soglia.
            age_penalty = clamp((float(age) - 0.5 * max_age) / (0.5 * max_age), 0.0, 1.0)
            skew_penalty = clamp((float(skew or 0.0) - 0.5 * max_skew) / (0.5 * max_skew), 0.0, 1.0)
            score = 100.0 * (1.0 - max(age_penalty, skew_penalty))
            status = "fresh" if score >= 85.0 else ("degraded" if score >= 45.0 else "stale")
        item.update({
            "available": available,
            "used": used,
            "timestamp_ms": timestamp or None,
            "age_minutes": None if age is None else round(age, 1),
            "skew_minutes": None if skew is None else round(skew, 1),
            "operational_confidence_percent": round(score, 1),
            "status": status,
        })
        products[product] = item
    for product in critical:
        item = products.get(product)
        if not item or not item.get("available"):
            issues.append(f"{product} non disponibile")
        elif not item.get("used", True):
            issues.append(f"{product} disallineato")
        elif float(item.get("operational_confidence_percent", 0.0) or 0.0) < 85.0:
            issues.append(f"{product} vecchio o vicino al limite temporale")
    radar_core_quality = sum(
        weights[product] * float(products[product].get("operational_confidence_percent", 0.0) or 0.0)
        for product in critical
    )
    vmi_age = products.get("VMI", {}).get("age_minutes")
    if vmi_age is not None and float(vmi_age) > max_age:
        issues.append("VMI oltre la freschezza operativa")
    if lightning_meta.get("enabled"):
        if not lightning_meta.get("available"):
            issues.append("LTG non disponibile")
        elif not lightning_meta.get("fresh"):
            issues.append("LTG in ritardo")
    relevant_offline = sites_status.get("relevant_offline") if isinstance(sites_status.get("relevant_offline"), list) else []
    if relevant_offline:
        issues.append(f"{len(relevant_offline)} radar vicino ai target risulta OFF")
    radar_core_quality = max(0.0, min(100.0, radar_core_quality))
    lightning_enabled = bool(lightning_meta.get("enabled"))
    lightning_quality = 100.0 if lightning_enabled and lightning_meta.get("available") and lightning_meta.get("fresh") else 0.0
    sites_enabled = bool(sites_status.get("enabled"))
    sites_quality = 100.0 if sites_enabled and sites_status.get("available") else 0.0
    accessory_weight = (0.15 if lightning_enabled else 0.0) + (0.05 if sites_enabled else 0.0)
    quality = radar_core_quality * (1.0 - accessory_weight)
    if lightning_enabled:
        quality += 0.15 * lightning_quality
    if sites_enabled:
        quality += 0.05 * sites_quality
    quality = max(0.0, min(100.0, quality))
    status = "aligned"
    if quality < 45 or (vmi_age is not None and float(vmi_age) > float(cfg.get("app", {}).get("max_frame_age_minutes", 30) or 30)):
        status = "stale"
    elif issues or quality < 85:
        status = "degraded"
    return {
        "schema": 2,
        "quality_kind": "operational_confidence_proxy",
        "reference_product": "VMI",
        "reference_timestamp_ms": reference_ms,
        "created_ms": current_ms,
        "status": status,
        "quality_percent": round(quality, 1),
        "components": {
            "radar_core_completeness_percent": round(radar_core_quality, 1),
            "lightning_availability_percent": round(lightning_quality, 1),
            "sites_metadata_availability_percent": round(sites_quality, 1),
            "temporal_synchronization_percent": round(
                sum(100.0 if products[p].get("used") else 0.0 for p in critical) / len(critical), 1
            ),
        },
        "human_summary": (
            "Radar principale completo · Fulmini non disponibili · Confidenza multisensore ridotta"
            if radar_core_quality >= 95 and lightning_enabled and lightning_quality == 0 else
            "Qualità multisensore verificata per componente"
        ),
        "products": products,
        "lightning": {
            "timestamp_ms": lightning_meta.get("latest_timestamp_ms"),
            "age_minutes": lightning_meta.get("age_minutes", lightning_meta.get("age_from_anchor_minutes")),
            "fresh": bool(lightning_meta.get("fresh", False)),
        },
        "radar_sites": sites_status,
        "issues": issues[:12],
        "unassessed_limitations": [
            "beam blocking e orografia non quantificati per pixel",
            "clutter, bright band e attenuazione non quantificati per pixel",
            "radar sorgente del pixel di mosaico non disponibile",
        ],
    }


def build_target_data_quality(
    target: Target,
    temporal_bundle: dict[str, Any],
    sites_status: dict[str, Any],
    cfg: dict[str, Any],
    *,
    ref: Optional[dict[str, Any]] = None,
    arrays: Optional[dict[str, np.ndarray]] = None,
    cell: Optional[Cell] = None,
) -> dict[str, Any]:
    """Deriva un proxy prudente di qualità per target, senza inventare QC fisica."""
    base = clamp(float(temporal_bundle.get("quality_percent", 0.0) or 0.0), 0.0, 100.0)
    rows = sites_status.get("sites") if isinstance(sites_status.get("sites"), list) else []
    positioned = [row for row in rows if row.get("lat") is not None and row.get("lon") is not None]
    active = [
        (haversine_km(target.lat, target.lon, float(row["lat"]), float(row["lon"])), row)
        for row in positioned if row.get("active") is True
    ]
    inactive = [
        (haversine_km(target.lat, target.lon, float(row["lat"]), float(row["lon"])), row)
        for row in positioned if row.get("active") is False
    ]
    radius = max(50.0, min(350.0, float(cfg.get("radar_sites", {}).get("relevant_radius_km", 180) or 180)))
    nearest_active = min(active, default=(None, None), key=lambda value: value[0])
    nearby_active = sum(1 for distance, _ in active if distance <= radius)
    nearby_offline = sum(1 for distance, _ in inactive if distance <= radius)
    limitations: list[str] = []
    coverage_factor = 1.0
    if not sites_status.get("available") or not positioned:
        coverage = "unknown"
        coverage_factor = 0.90
        limitations.append("stato/copertura SITES non valutabile")
    elif nearby_active == 0:
        coverage = "limited"
        coverage_factor = 0.72
        limitations.append(f"nessun radar attivo SITES entro {radius:.0f} km")
    elif nearby_offline:
        coverage = "degraded"
        coverage_factor = max(0.78, 1.0 - 0.08 * nearby_offline)
        limitations.append(f"{nearby_offline} radar SITES OFF entro {radius:.0f} km")
    else:
        coverage = "nominal"
    spatial_products: dict[str, dict[str, Any]] = {}
    spatial_score = 100.0
    critical_weights = {"VMI": 0.50, "SRI": 0.15, "POH": 0.15, "VIL": 0.10, "ETM": 0.10}
    if ref and arrays:
        try:
            transformer = Transformer.from_crs("EPSG:4326", ref["crs"], always_xy=True)
            x, y = transformer.transform(target.lon, target.lat)
            col_f, row_f = (~ref["transform"]) * (x, y)
            row, col = int(round(row_f)), int(round(col_f))
            px_km = max(0.2, math.sqrt(pixel_area_km2(ref["transform"], ref["crs"], target.lat)))
            radius_px = max(2, min(80, int(math.ceil((target.radius_km + 8.0) / px_km))))
            r0, r1 = max(0, row - radius_px), min(int(ref.get("height", arrays["VMI"].shape[0])), row + radius_px + 1)
            c0, c1 = max(0, col - radius_px), min(int(ref.get("width", arrays["VMI"].shape[1])), col + radius_px + 1)
            rr, cc = np.ogrid[r0:r1, c0:c1]
            disk = (rr - row) ** 2 + (cc - col) ** 2 <= radius_px ** 2
            for product, weight in critical_weights.items():
                array = arrays.get(product)
                if array is None or r1 <= r0 or c1 <= c0:
                    valid = 0.0
                else:
                    sample = np.asarray(array[r0:r1, c0:c1])
                    valid = 100.0 * float(np.count_nonzero(np.isfinite(sample) & disk)) / max(1, int(np.count_nonzero(disk)))
                spatial_products[product] = {"valid_percent": round(valid, 1), "weight": weight}
            spatial_score = sum(critical_weights[name] * spatial_products[name]["valid_percent"] for name in critical_weights)
            for product, item in spatial_products.items():
                if float(item["valid_percent"]) < 70.0:
                    limitations.append(f"copertura pixel validi {product} limitata sul target ({item['valid_percent']:.0f}%)")
        except Exception as exc:
            spatial_score = 85.0
            limitations.append(f"copertura spaziale non calcolabile ({type(exc).__name__})")
    else:
        spatial_score = 90.0
        limitations.append("copertura spaziale dei prodotti non disponibile")
    cell_spatial = dict(getattr(cell, "product_coverage_percent", {}) or {}) if cell is not None else {}
    cell_score = sum(critical_weights[name] * float(cell_spatial.get(name, spatial_score)) for name in critical_weights)
    spatial_factor = clamp((0.65 * spatial_score + 0.35 * cell_score) / 100.0, 0.35, 1.0)
    score = base * coverage_factor * spatial_factor
    return {
        "quality_kind": "operational_confidence_proxy",
        "score_percent": round(score, 1),
        "temporal_score_percent": round(base, 1),
        "coverage_status": coverage,
        "nearest_active_radar_km": None if nearest_active[0] is None else round(float(nearest_active[0]), 1),
        "active_radars_within_radius": nearby_active,
        "offline_radars_within_radius": nearby_offline,
        "reference_radius_km": radius,
        "spatial_score_percent": round(spatial_score, 1),
        "cell_spatial_score_percent": round(cell_score, 1),
        "spatial_products": spatial_products,
        "cell_product_coverage_percent": cell_spatial,
        "limitations": limitations + list(temporal_bundle.get("unassessed_limitations") or []),
    }



def parse_dpc_lgt_bin(data: bytes, timestamp_ms: int) -> list[LightningStrike]:
    """Decodifica layer Radar-DPC LGT/lgt_5min_*.bin.

    Formato ricavato dal client pubblico radar.protezionecivile.it:
    byte 0 = versione 2, uint16 BE a offset 1 = numero fulmini.
    Ogni record codifica lon/lat su griglia 18 bit; record da 6 o 8 byte.
    """
    if len(data) < 3:
        return []
    version = data[0]
    if version != 2:
        raise MeteoAlertError(f"Formato LGT non supportato: versione={version}")
    count = int.from_bytes(data[1:3], "big", signed=False)
    out: list[LightningStrike] = []
    offset = 3
    for _ in range(count):
        if offset + 6 > len(data):
            break
        lon_low = int.from_bytes(data[offset:offset + 2], "big", signed=False)
        lat_low = int.from_bytes(data[offset + 2:offset + 4], "big", signed=False)
        packed = data[offset + 4]
        extra_flag = data[offset + 5]
        lon18 = lon_low + (((packed >> 6) & 3) * 65536)
        lat18 = lat_low + (((packed >> 4) & 3) * 65536)
        lon = lon18 * (360.0 / 262144.0) - 180.0
        lat = lat18 * (180.0 / 262144.0) - 90.0
        if -90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0:
            out.append(LightningStrike(lat=float(lat), lon=float(lon), timestamp_ms=int(timestamp_ms)))
        offset += 6 if extra_flag < 255 else 8
    return out


def dpc_lgt_timestamps(anchor_timestamp_ms: int, window_minutes: int, max_lookback_minutes: int | None = None) -> list[int]:
    """Slot da sondare per scoprire l'ultima pubblicazione LTG.

    LTG ha cadenza ufficiale 10 minuti, ma il nome legacy ``lgt_5min`` e la fase
    del timestamp possono cadere su :00/:10 oppure :05/:15. Sondiamo quindi la
    griglia a 5 minuti soltanto per trovare la fase; la finestra operativa viene
    poi costruita dai timestamp reali a passo di 10 minuti.
    """
    step_ms = 5 * 60 * 1000
    base = int(anchor_timestamp_ms // step_ms * step_ms)
    search_minutes = max(window_minutes, max_lookback_minutes or window_minutes)
    slots = max(1, min(288, int(math.ceil(max(1, search_minutes) / 5.0))))
    return [base - i * step_ms for i in range(slots)]


def fetch_dpc_lgt_window(session: requests.Session, anchor_timestamp_ms: int, cfg: dict[str, Any]) -> tuple[list[LightningStrike], dict[str, Any]]:
    lightning = cfg.get("lightning", {}) if isinstance(cfg, dict) else {}
    if not bool(lightning.get("enabled", False)):
        return [], {"enabled": False, "source": "disabled", "available": False}
    source = str(lightning.get("source", "radar_dpc_lgt"))
    if source not in {"radar_dpc_lgt", "dpc_lgt", "radar_dpc"}:
        return [], {"enabled": True, "source": source, "available": False, "reason": "source-not-dpc-lgt"}

    # L'API pubblica Radar-DPC documentata non espone attualmente LTG tra i
    # productType scaricabili. Il precedente probing di oggetti S3 non pubblici
    # generava decine di 403 e non verificava alcuna disponibilità reale.
    return [], {
        "enabled": True,
        "source": "Radar-DPC LTG",
        "status": "not_verified",
        "available": False,
        "fresh": False,
        "reason": "official_api_product_not_listed",
        "backoff_seconds": 21600,
        "anchor_timestamp_ms": int(anchor_timestamp_ms),
        "updated_utc": utc_now().isoformat(),
        "affects_radar_core": False,
    }

def lightning_context_by_target(strikes: list[LightningStrike], targets: list[Target], cfg: dict[str, Any]) -> dict[str, dict[str, Any]]:
    lightning = cfg.get("lightning", {}) if isinstance(cfg, dict) else {}
    radius = float(lightning.get("radius_km", 20) or 20)
    context: dict[str, dict[str, Any]] = {}
    for target in targets:
        distances = [haversine_km(target.lat, target.lon, s.lat, s.lon) for s in strikes]
        within = [d for d in distances if d <= radius]
        context[target.name] = {
            "source": "radar_dpc_lgt",
            "radius_km": radius,
            "count": len(within),
            "nearest_km": min(distances) if distances else None,
        }
    return context


def build_lightning_alert_message(
    target: Target,
    context: dict[str, Any],
    lightning_meta: dict[str, Any],
    *,
    escalation: bool = False,
) -> str:
    count = int(context.get("count", 0) or 0)
    radius = float(context.get("radius_km", 20.0) or 20.0)
    nearest = context.get("nearest_km")
    nearest_txt = "distanza non disponibile" if nearest is None else f"{float(nearest):.1f} km"
    window = int(lightning_meta.get("effective_window_minutes", lightning_meta.get("window_minutes", 20)) or 20)
    urgent_radius = float(context.get("urgent_radius_km", 8.0) or 8.0)
    if nearest is not None and float(nearest) <= urgent_radius:
        level = "molto vicina"
        meaning = "È stata osservata attività elettrica molto vicina alla zona."
    elif count >= int(context.get("high_count", 8) or 8):
        level = "intensa"
        meaning = "Il numero di fulmini indica attività elettrica intensa nelle vicinanze."
    else:
        level = "presente"
        meaning = "Sono stati osservati più fulmini nell'area vicina al target."
    title = "ATTIVITÀ ELETTRICA IN AUMENTO" if escalation else "FULMINI VICINO ALLA ZONA"
    latest_ms = lightning_meta.get("latest_timestamp_ms")
    observed_at = ms_to_dt(int(latest_ms)).astimezone().strftime("%H:%M") if latest_ms else "N/D"
    age_minutes = float(lightning_meta.get("age_minutes", 0.0) or 0.0)
    age_txt = f" · pubblicato {age_minutes:.0f} min fa" if age_minutes >= 1 else " · appena pubblicato"
    return (
        f"⚡ <b>{title}</b>\n\n"
        f"📍 <b>{safe_message_text(target.name, 70)}</b>\n"
        f"▫️ Attività elettrica: <b>{level}</b>\n"
        f"▫️ Fulminazioni nel quadro: <b>{count} negli ultimi circa {window} minuti</b>\n"
        f"▫️ Fulmine più vicino: <b>{nearest_txt}</b>\n"
        f"▫️ Area controllata: <b>{radius:.0f} km dal target</b>\n\n"
        f"📡 <b>Cosa significa</b>\n"
        f"{safe_message_text(meaning, 220)} Anche senza pioggia forte sul punto, i fulmini possono precedere o accompagnare il temporale.\n\n"
        f"🛡️ <b>Indicazioni pratiche</b>\n"
        f"Se sei all'aperto, raggiungi un edificio o un veicolo chiuso. Evita alberi isolati, spazi aperti e oggetti metallici esposti.\n\n"
        f"<i>Quadro fulmini LTG delle {observed_at}{age_txt} · Radar-DPC/LAMPINET · informazione personale, non allerta ufficiale.</i>"
    )


def build_lightning_clear_message(target: Target, previous: dict[str, Any], lightning_meta: dict[str, Any]) -> str:
    previous_count = int(previous.get("peak_count", previous.get("last_count", 0)) or 0)
    previous_nearest = previous.get("minimum_distance_km", previous.get("nearest_km"))
    nearest_txt = "n/d" if previous_nearest is None else f"{float(previous_nearest):.1f} km"
    return (
        f"🟢 <b>ATTIVITÀ ELETTRICA RIDOTTA</b>\n\n"
        f"📍 <b>{safe_message_text(target.name, 70)}</b>\n"
        f"Nelle ultime scansioni non risultano più fulmini sufficienti per mantenere l'avviso vicino alla zona.\n\n"
        f"▫️ Picco osservato: <b>{previous_count} fulmini</b>\n"
        f"▫️ Distanza minima osservata: <b>{nearest_txt}</b>\n\n"
        f"<i>Il controllo Radar-DPC/LAMPINET continua automaticamente.</i>"
    )


def write_lightning_alert_log(
    cfg: dict[str, Any],
    target: Target,
    context: dict[str, Any],
    message: str,
    event_type: str,
) -> None:
    log_dir = Path(cfg["app"]["log_dir"])
    log_dir.mkdir(parents=True, exist_ok=True)
    line = {
        "time_utc": utc_now().isoformat(),
        "event_type": event_type,
        "target": asdict(target),
        "lightning": context,
        "message": message,
    }
    with (log_dir / "alerts.log").open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(line, ensure_ascii=False) + "\n")


def evaluate_lightning_alerts(
    strikes: list[LightningStrike],
    lightning_meta: dict[str, Any],
    state: dict[str, Any],
    targets: list[Target],
    cfg: dict[str, Any],
    dry_run: bool,
    *,
    covered_targets: Optional[set[str]] = None,
) -> list[dict[str, Any]]:
    """Invia alert fulmini autonomi, indipendenti dalla traiettoria radar."""
    lightning = cfg.get("lightning", {}) if isinstance(cfg, dict) else {}
    source = str(lightning.get("source", ""))
    if (
        not bool(lightning.get("enabled", False))
        or source not in {"radar_dpc_lgt", "dpc_lgt", "radar_dpc"}
        or not bool(lightning.get("notify_on_lightning", True))
        or not bool(lightning_meta.get("available", False))
        or not bool(lightning_meta.get("fresh", False))
    ):
        return []

    contexts = lightning_context_by_target(strikes, targets, cfg)
    records = state.setdefault("lightning_alerts", {})
    covered = covered_targets or set()
    min_strikes = max(1, int(lightning.get("alert_min_strikes", 2) or 2))
    high_count = max(min_strikes, int(lightning.get("alert_high_count", 8) or 8))
    urgent_radius = max(1.0, float(lightning.get("alert_urgent_radius_km", 8) or 8))
    clear_windows = max(2, int(lightning.get("alert_clear_windows", 2) or 2))
    cooldown_minutes = max(5.0, float(lightning.get("alert_cooldown_minutes", 20) or 20))
    escalation_delta = max(2, int(lightning.get("alert_escalation_delta", 5) or 5))
    latest_slot = int(lightning_meta.get("latest_timestamp_ms", 0) or 0)
    sent: list[dict[str, Any]] = []

    for target in targets:
        context = dict(contexts.get(target.name) or {})
        context.update({"urgent_radius_km": urgent_radius, "high_count": high_count})
        count = int(context.get("count", 0) or 0)
        nearest = context.get("nearest_km")
        qualifies = count >= min_strikes or (count >= 1 and nearest is not None and float(nearest) <= urgent_radius)
        previous = records.setdefault(target.name, {})
        same_slot = latest_slot and int(previous.get("last_slot_ms", 0) or 0) == latest_slot
        if same_slot:
            continue

        was_active = bool(previous.get("active", False))
        previous_count = int(previous.get("last_count", 0) or 0)
        previous_nearest = previous.get("nearest_km")
        previous.update({
            "last_slot_ms": latest_slot,
            "last_count": count,
            "nearest_km": nearest,
            "updated_utc": utc_now().isoformat(),
        })

        if qualifies:
            previous["active"] = True
            previous["clear_windows"] = 0
            previous["peak_count"] = max(int(previous.get("peak_count", 0) or 0), count)
            if nearest is not None:
                old_minimum = previous.get("minimum_distance_km")
                previous["minimum_distance_km"] = float(nearest) if old_minimum is None else min(float(old_minimum), float(nearest))

            escalation = was_active and (
                count >= previous_count + escalation_delta
                or (
                    nearest is not None
                    and previous_nearest is not None
                    and float(nearest) <= float(previous_nearest) - 3.0
                )
            )
            should_send = not was_active or escalation
            if target.name in covered:
                should_send = False
                previous["covered_by_weather_alert"] = True
            last_sent = int(previous.get("last_sent_ms", 0) or 0)
            if should_send and last_sent:
                should_send = utc_now() - ms_to_dt(last_sent) >= timedelta(minutes=cooldown_minutes)
            quiet_mode = str(cfg.get("quiet_hours", {}).get("mode", "critical_only"))
            if should_send and is_in_quiet_hours(cfg):
                critical = (nearest is not None and float(nearest) <= urgent_radius) or count >= high_count
                if quiet_mode == "mute_all" or not critical:
                    should_send = False
            if should_send:
                message = build_lightning_alert_message(target, context, lightning_meta, escalation=escalation)
                if send_telegram(message, dry_run=dry_run):
                    previous["last_sent_ms"] = int(utc_now().timestamp() * 1000)
                    previous["notified"] = True
                    event_type = "lightning_escalation" if escalation else "lightning_alert"
                    write_lightning_alert_log(cfg, target, context, message, event_type)
                    sent.append({"target": target.name, "mode": event_type, "lightning": context})
            continue

        previous["clear_windows"] = int(previous.get("clear_windows", 0) or 0) + 1
        if not was_active or int(previous["clear_windows"]) < clear_windows:
            continue
        previous["active"] = False
        was_notified = bool(previous.get("notified", False))
        previous["notified"] = False
        if bool(lightning.get("notify_lightning_clear", True)) and was_notified and target.name not in covered:
            message = build_lightning_clear_message(target, previous, lightning_meta)
            if send_telegram(message, dry_run=dry_run):
                write_lightning_alert_log(cfg, target, context, message, "lightning_clear")
                sent.append({"target": target.name, "mode": "lightning_clear", "lightning": context})

    return sent


def read_reference_raster(path: str, product: str, cfg: dict[str, Any]) -> dict[str, Any]:
    with rasterio.open(path) as ds:
        validate_raster_dataset(ds, cfg, path)
        arr = ds.read(1, masked=True).filled(np.nan)
        arr = sanitize_array(arr, product, cfg)
        return {
            "array": arr,
            "transform": ds.transform,
            "crs": ds.crs,
            "width": ds.width,
            "height": ds.height,
            "bounds": ds.bounds,
            "nodata": ds.nodata,
            "path": path,
        }


def read_raster_to_reference(path: str, product: str, ref: dict[str, Any], cfg: dict[str, Any]) -> np.ndarray:
    with rasterio.open(path) as src:
        validate_raster_dataset(src, cfg, path)
        src_arr = src.read(1, masked=True).filled(np.nan).astype("float32")
        src_arr = sanitize_array(src_arr, product, cfg)

        same_grid = (
            src.crs == ref["crs"]
            and src.transform == ref["transform"]
            and src.width == ref["width"]
            and src.height == ref["height"]
        )
        if same_grid:
            return src_arr

        dst = np.full((ref["height"], ref["width"]), np.nan, dtype="float32")
        reproject(
            source=src_arr,
            destination=dst,
            src_transform=src.transform,
            src_crs=src.crs,
            src_nodata=np.nan,
            dst_transform=ref["transform"],
            dst_crs=ref["crs"],
            dst_nodata=np.nan,
            resampling=Resampling.nearest,
        )
        return sanitize_array(dst, product, cfg)


def pixel_area_km2(transform: rasterio.Affine, crs: Any, sample_lat: float) -> float:
    px_w = abs(transform.a)
    px_h = abs(transform.e)
    if crs and getattr(crs, "is_projected", False):
        return (px_w * px_h) / 1_000_000.0
    # Coordinate geografiche in gradi: approssimazione locale più che sufficiente per filtrare area minima.
    km_per_deg_lon = 111.320 * math.cos(math.radians(sample_lat))
    km_per_deg_lat = 110.574
    return abs(px_w * km_per_deg_lon) * abs(px_h * km_per_deg_lat)


def component_stat(arr: Optional[np.ndarray], rows: np.ndarray, cols: np.ndarray, mode: str = "max") -> Optional[float]:
    if arr is None:
        return None
    values = arr[rows, cols]
    values = values[np.isfinite(values)]
    if values.size == 0:
        return None
    if mode == "mean":
        return float(np.nanmean(values))
    if mode == "min":
        return float(np.nanmin(values))
    return float(np.nanmax(values))


def component_percentile(
    arr: Optional[np.ndarray],
    rows: np.ndarray,
    cols: np.ndarray,
    percentile: float = 95.0,
) -> Optional[float]:
    """Valore del nucleo robusto rispetto a un singolo pixel massimo."""
    if arr is None:
        return None
    values = arr[rows, cols]
    values = values[np.isfinite(values)]
    if values.size == 0:
        return None
    return float(np.nanpercentile(values, max(0.0, min(100.0, percentile))))


def component_valid_percent(arr: Optional[np.ndarray], rows: np.ndarray, cols: np.ndarray) -> float:
    if arr is None or rows.size == 0:
        return 0.0
    try:
        return 100.0 * float(np.count_nonzero(np.isfinite(arr[rows, cols]))) / float(rows.size)
    except Exception:
        return 0.0


def multilevel_cell_labels(
    vmi: np.ndarray,
    strong_threshold: float,
    core_threshold: float,
    min_pixels: int,
    sample_lat: float,
    ref: dict[str, Any],
    cfg: dict[str, Any],
) -> tuple[np.ndarray, dict[int, tuple[str, int]]]:
    """Segmentazione seed-and-grow senza dipendenze non presenti nel motore.

    Il corpo convettivo viene trovato alla soglia operativa; due nuclei intensi
    sufficientemente separati diventano seed distinti e si dividono il ponte
    debole tramite distanza euclidea. Un corpo senza seed resta una sola cella.
    """
    outer, count = ndi.label(
        np.isfinite(vmi) & (vmi >= strong_threshold),
        structure=np.ones((3, 3), dtype=np.uint8),
    )
    methods: dict[int, tuple[str, int]] = {}
    scfg = cfg.get("segmentation_engine", {})
    if not bool(scfg.get("enabled", True)) or str(scfg.get("mode", "shadow")) != "active" or count == 0:
        for label_id in range(1, count + 1):
            methods[label_id] = ("single-threshold", label_id)
        return outer, methods

    minimum_core = max(3, int(scfg.get("minimum_core_pixels", max(3, min_pixels // 2)) or 3))
    px_km = max(0.1, math.sqrt(pixel_area_km2(ref["transform"], ref["crs"], sample_lat)))
    minimum_separation_px = max(2.0, float(scfg.get("minimum_seed_separation_km", 5.0) or 5.0) / px_km)
    output = np.zeros_like(outer, dtype="int32")
    next_label = 0
    for parent_id, obj in enumerate(ndi.find_objects(outer), start=1):
        if obj is None:
            continue
        body = outer[obj] == parent_id
        if int(body.sum()) < min_pixels:
            continue
        local_vmi = np.asarray(vmi[obj])
        seeds, seed_count = ndi.label(
            body & np.isfinite(local_vmi) & (local_vmi >= core_threshold),
            structure=np.ones((3, 3), dtype=np.uint8),
        )
        valid_seeds: list[tuple[int, float, float]] = []
        for seed_id in range(1, seed_count + 1):
            rr, cc = np.where(seeds == seed_id)
            if rr.size >= minimum_core:
                valid_seeds.append((seed_id, float(np.mean(rr)), float(np.mean(cc))))
        # Nuclei quasi coincidenti sono frammenti dello stesso massimo, non uno
        # split meteorologico. Conserviamo il più esteso del gruppo.
        retained: list[tuple[int, float, float]] = []
        for candidate in sorted(valid_seeds, key=lambda item: int(np.count_nonzero(seeds == item[0])), reverse=True):
            if all(math.hypot(candidate[1] - row[1], candidate[2] - row[2]) >= minimum_separation_px for row in retained):
                retained.append(candidate)
        if len(retained) < 2:
            next_label += 1
            output[obj][body] = next_label
            methods[next_label] = ("single-threshold", parent_id)
            continue
        marker = np.zeros_like(seeds, dtype="int32")
        for marker_id, (seed_id, _row, _col) in enumerate(retained, start=1):
            marker[seeds == seed_id] = marker_id
        nearest = ndi.distance_transform_edt(marker == 0, return_distances=False, return_indices=True)
        allocation = marker[tuple(nearest)]
        for marker_id in range(1, len(retained) + 1):
            child = body & (allocation == marker_id)
            if int(child.sum()) < min_pixels:
                continue
            next_label += 1
            output[obj][child] = next_label
            methods[next_label] = ("multi-threshold", parent_id)
    return output, methods


def cappi_echo_top_km(profile: dict[str, float], threshold_dbz: float) -> Optional[float]:
    levels = [
        float(level)
        for level, reflectivity in profile.items()
        if math.isfinite(float(reflectivity)) and float(reflectivity) >= threshold_dbz
    ]
    return max(levels) if levels else None


def component_footprint(
    ref: dict[str, Any],
    local_mask: np.ndarray,
    row_offset: int,
    col_offset: int,
    center_lon: float,
    center_lat: float,
    transformer: Transformer,
    max_vertices: int = 48,
) -> tuple[list[list[float]], float, float]:
    """Crea un inviluppo compatto della cella in coordinate locali km."""
    boundary = local_mask & ~ndi.binary_erosion(
        local_mask, structure=np.ones((3, 3), dtype=bool), border_value=0
    )
    rr, cc = np.where(boundary)
    if rr.size < 3:
        rr, cc = np.where(local_mask)
    if rr.size > 2500:
        sample = np.linspace(0, rr.size - 1, 2500, dtype=int)
        rr, cc = rr[sample], cc[sample]
    rows = rr + row_offset
    cols = cc + col_offset
    xs, ys = rasterio.transform.xy(ref["transform"], rows, cols, offset="center")
    lons, lats = transformer.transform(np.asarray(xs), np.asarray(ys))
    points = np.asarray([
        lonlat_to_xy_km(float(lon), float(lat), center_lon, center_lat)
        for lon, lat in zip(lons, lats)
    ], dtype="float64")
    points = points[np.all(np.isfinite(points), axis=1)]
    if len(points) < 3:
        return [], 0.0, 0.0
    try:
        hull = ConvexHull(points)
        polygon = points[hull.vertices]
    except Exception:
        polygon = points
    if len(polygon) > max_vertices:
        indexes = np.linspace(0, len(polygon) - 1, max_vertices, dtype=int)
        polygon = polygon[indexes]

    try:
        covariance = np.cov(points.T)
        values, vectors = np.linalg.eigh(covariance)
        order = np.argsort(values)[::-1]
        major = max(1e-9, float(values[order[0]]))
        minor = max(0.0, float(values[order[1]]))
        eccentricity = math.sqrt(max(0.0, 1.0 - minor / major))
        vector = vectors[:, order[0]]
        orientation = (math.degrees(math.atan2(float(vector[0]), float(vector[1]))) + 360.0) % 180.0
    except Exception:
        eccentricity, orientation = 0.0, 0.0
    return [[round(float(x), 4), round(float(y), 4)] for x, y in polygon], float(eccentricity), float(orientation)


def compute_hail_risk(max_vmi: float, max_poh: Optional[float], max_vil: Optional[float], max_etm: Optional[float], cfg: dict[str, Any]) -> tuple[str, list[str]]:
    th = cfg["thresholds"]
    reasons: list[str] = []
    risk_score = 0

    if max_poh is not None:
        if max_poh >= float(th["poh_high_percent"]):
            risk_score += 3
            reasons.append(f"POH {max_poh:.0f}%")
        elif max_poh >= float(th["poh_medium_percent"]):
            risk_score += 2
            reasons.append(f"POH {max_poh:.0f}%")

    if max_vmi >= float(th["vmi_hail_dbz"]):
        risk_score += 2
        reasons.append(f"VMI {max_vmi:.1f} dBZ")
    elif max_vmi >= float(th["vmi_strong_dbz"]):
        risk_score += 1
        reasons.append(f"VMI {max_vmi:.1f} dBZ")

    if max_vil is not None and max_vil >= float(th["vil_hail_threshold"]):
        risk_score += 1
        reasons.append(f"VIL {max_vil:.1f}")

    if max_etm is not None and max_etm >= float(th["etm_hail_threshold_m"]):
        risk_score += 1
        reasons.append(f"ETM {max_etm:.0f} m")

    if risk_score >= 4:
        return "HIGH", reasons
    if risk_score >= 2:
        return "MEDIUM", reasons
    return "LOW", reasons


def nearest_target(lat: float, lon: float, targets: list[Target]) -> tuple[Target, float]:
    best = min(targets, key=lambda t: haversine_km(lat, lon, t.lat, t.lon))
    return best, haversine_km(lat, lon, best.lat, best.lon)


def detect_cells(
    ref: dict[str, Any],
    products: dict[str, np.ndarray],
    timestamp_ms: int,
    targets: list[Target],
    cfg: dict[str, Any],
    *,
    segmentation_mode: Optional[str] = None,
) -> list[Cell]:
    vmi = products["VMI"]
    sri = products.get("SRI")
    poh = products.get("POH")
    vil = products.get("VIL")
    etm = products.get("ETM")
    srt1 = products.get("SRT1")
    ir108 = products.get("IR_108")
    cappi_products = {
        int(product.split("_", 1)[1]): array
        for product, array in products.items()
        if product.startswith("CAPPI_") and product.split("_", 1)[1].isdigit()
    }
    cappi_expected_levels = max(
        1,
        len(cfg.get("vertical_profile", {}).get("products") or [f"CAPPI_{level}" for level in range(1, 11)]),
    )
    cappi_percentile = float(cfg.get("vertical_profile", {}).get("cell_percentile", 95) or 95)

    th = cfg["thresholds"]
    tr = cfg["tracking"]
    min_pixels = int(tr.get("min_component_pixels", 8))
    max_search_km = float(tr.get("max_search_km", 110))
    strong_threshold = float(th["vmi_strong_dbz"])
    core_threshold = float(th.get("vmi_core_dbz", th.get("vmi_hail_dbz", 55)))

    segmentation_cfg = dict(cfg.get("segmentation_engine", {}) or {})
    if segmentation_mode is not None:
        segmentation_cfg["mode"] = segmentation_mode
    segmentation_view = dict(cfg)
    segmentation_view["segmentation_engine"] = segmentation_cfg
    labels, method_by_label = multilevel_cell_labels(
        vmi, strong_threshold, core_threshold, min_pixels,
        float(targets[0].lat if targets else 42.0), ref, segmentation_view,
    )
    nlabels = int(labels.max())
    if nlabels == 0:
        return []

    transformer = Transformer.from_crs(ref["crs"], "EPSG:4326", always_xy=True)
    objects = ndi.find_objects(labels)
    cells: list[Cell] = []

    for label_id, obj in enumerate(objects, start=1):
        if obj is None:
            continue
        local_labels = labels[obj]
        local_mask = local_labels == label_id
        pixels = int(local_mask.sum())
        if pixels < min_pixels:
            continue

        rr_local, cc_local = np.where(local_mask)
        row_offset = obj[0].start
        col_offset = obj[1].start
        rows = rr_local + row_offset
        cols = cc_local + col_offset

        xs, ys = rasterio.transform.xy(ref["transform"], rows, cols, offset="center")
        cx = float(np.mean(xs))
        cy = float(np.mean(ys))
        lon, lat = transformer.transform(cx, cy)
        lon = float(lon)
        lat = float(lat)

        target, distance = nearest_target(lat, lon, targets)
        if distance > max_search_km:
            continue

        area_px_km2 = pixel_area_km2(ref["transform"], ref["crs"], lat)
        area_km2 = max(0.1, pixels * area_px_km2)
        radius_km = max(1.0, min(18.0, math.sqrt(area_km2 / math.pi)))

        max_vmi = component_stat(vmi, rows, cols, "max") or 0.0
        mean_vmi = component_stat(vmi, rows, cols, "mean") or 0.0
        max_sri = component_stat(sri, rows, cols, "max")
        max_poh = component_stat(poh, rows, cols, "max")
        max_vil = component_stat(vil, rows, cols, "max")
        max_etm = component_stat(etm, rows, cols, "max")
        max_srt1 = component_stat(srt1, rows, cols, "max")
        min_ir108 = component_stat(ir108, rows, cols, "min")
        # IR_108 puo' essere distribuito in kelvin: normalizziamo in Celsius
        # esclusivamente quando il range lo rende inequivocabile.
        if min_ir108 is not None and min_ir108 > 100.0:
            min_ir108 -= 273.15
        cappi_profile: dict[str, float] = {}
        for level, cappi_array in sorted(cappi_products.items()):
            reflectivity = component_percentile(cappi_array, rows, cols, cappi_percentile)
            if reflectivity is not None:
                cappi_profile[str(level)] = round(float(reflectivity), 1)
        cappi_quality = 100.0 * clamp(len(cappi_profile) / float(cappi_expected_levels))
        product_coverage = {
            product: round(component_valid_percent(array, rows, cols), 1)
            for product, array in products.items()
            if product in {"VMI", "SRI", "POH", "VIL", "ETM", "SRT1", "IR_108"}
        }
        for product in ("VMI", "SRI", "POH", "VIL", "ETM"):
            product_coverage.setdefault(product, 0.0)

        risk, reasons = compute_hail_risk(max_vmi, max_poh, max_vil, max_etm, cfg)
        footprint, eccentricity, orientation = component_footprint(
            ref,
            local_mask,
            row_offset,
            col_offset,
            lon,
            lat,
            transformer,
            max_vertices=max(12, min(96, int(cfg.get("precision_engine", {}).get("max_footprint_vertices", 48) or 48))),
        )
        local_vmi = np.asarray(vmi[obj])
        core_mask = local_mask & np.isfinite(local_vmi) & (local_vmi >= core_threshold)
        core_pixels = int(core_mask.sum())
        core_area_km2 = max(0.0, core_pixels * area_px_km2)
        core_radius_km = math.sqrt(core_area_km2 / math.pi) if core_area_km2 > 0.0 else 0.0
        core_fraction = clamp(core_pixels / max(1.0, float(pixels)), 0.0, 1.0)
        core_footprint: list[list[float]] = []
        if core_pixels >= 3:
            core_footprint, _, _ = component_footprint(
                ref,
                core_mask,
                row_offset,
                col_offset,
                lon,
                lat,
                transformer,
                max_vertices=max(12, min(64, int(cfg.get("precision_engine", {}).get("max_footprint_vertices", 48) or 48))),
            )
        cell_id = f"{timestamp_ms}-{label_id}-{round(lat,3)}-{round(lon,3)}"
        cells.append(Cell(
            cell_id=cell_id,
            timestamp_ms=timestamp_ms,
            lat=lat,
            lon=lon,
            area_km2=area_km2,
            radius_km=radius_km,
            pixels=pixels,
            max_vmi=float(max_vmi),
            mean_vmi=float(mean_vmi),
            max_sri=max_sri,
            max_poh=max_poh,
            max_vil=max_vil,
            max_etm=max_etm,
            risk=risk,
            risk_reasons=reasons,
            nearest_target=target.name,
            nearest_distance_km=distance,
            footprint_xy_km=footprint,
            pixel_bbox=[int(rows.min()), int(rows.max()), int(cols.min()), int(cols.max())],
            centroid_row=float(np.mean(rows)),
            centroid_col=float(np.mean(cols)),
            shape_eccentricity=eccentricity,
            shape_orientation_deg=orientation,
            max_srt1=max_srt1,
            min_ir108=min_ir108,
            core_area_km2=core_area_km2,
            core_radius_km=core_radius_km,
            core_fraction=core_fraction,
            core_footprint_xy_km=core_footprint,
            cappi_profile_dbz=cappi_profile,
            cappi_available_levels=len(cappi_profile),
            cappi_highest_45_km=cappi_echo_top_km(cappi_profile, 45.0),
            cappi_highest_50_km=cappi_echo_top_km(cappi_profile, 50.0),
            cappi_highest_55_km=cappi_echo_top_km(cappi_profile, 55.0),
            cappi_quality_percent=cappi_quality,
            cappi_timestamp_ms=(
                None if ref.get("cappi_timestamp_ms") is None else int(ref["cappi_timestamp_ms"])
            ),
            segmentation_method=method_by_label.get(label_id, ("single-threshold", label_id))[0],
            segmentation_parent_id=method_by_label.get(label_id, ("single-threshold", label_id))[1],
            product_coverage_percent=product_coverage,
        ))

    cells.sort(key=lambda c: (RISK_ORDER.get(c.risk, 0), c.max_vmi, -c.nearest_distance_km), reverse=True)
    return cells


def match_previous_cell(cell: Cell, prev_cells: list[dict[str, Any]], cfg: dict[str, Any]) -> Optional[dict[str, Any]]:
    max_match_km = float(cfg["tracking"].get("max_match_km", 35))
    max_gap_min = float(cfg["tracking"].get("max_gap_minutes", 18))
    best = None
    best_dist = 9999.0
    for prev in prev_cells:
        dt_min = (cell.timestamp_ms - int(prev.get("timestamp_ms", 0))) / 60000.0
        if dt_min <= 0 or dt_min > max_gap_min:
            continue
        dist = haversine_km(cell.lat, cell.lon, float(prev["lat"]), float(prev["lon"]))
        if dist <= max_match_km and dist < best_dist:
            best = prev
            best_dist = dist
    return best


def solve_entry_eta_minutes(cell: Cell, prev: dict[str, Any], target: Target, cfg: dict[str, Any]) -> Optional[dict[str, float]]:
    """Stima ETA e probabilita' d'impatto su un target.

    Dalla 2.2.3 la traiettoria non e' piu' un semplice si/no: oltre
    all'intersezione geometrica calcoliamo una probabilita' stimata basata su:
    - distanza minima della traiettoria dal target;
    - margine reale target + raggio cella;
    - incertezza crescente con lead-time e frame-gap;
    - velocita' di avvicinamento verso il target.

    Questo riduce i falsi positivi quando una cella sembra puntare il target
    in un singolo frame ma poi piega di lato.
    """
    dt_min = (cell.timestamp_ms - int(prev["timestamp_ms"])) / 60000.0
    if dt_min <= 0:
        return None

    lon0 = target.lon
    lat0 = target.lat
    cur_x, cur_y = lonlat_to_xy_km(cell.lon, cell.lat, lon0, lat0)
    prev_x, prev_y = lonlat_to_xy_km(float(prev["lon"]), float(prev["lat"]), lon0, lat0)
    tgt_x, tgt_y = 0.0, 0.0

    vx = (cur_x - prev_x) / dt_min
    vy = (cur_y - prev_y) / dt_min
    speed_kmh = math.hypot(vx, vy) * 60.0

    tr = cfg["tracking"]
    if speed_kmh < float(tr.get("min_speed_kmh", 8)):
        return None
    if speed_kmh > float(tr.get("max_speed_kmh", 130)):
        logging.info("skip anomalous speed %.1f km/h for cell=%s", speed_kmh, cell.cell_id)
        return None

    dist_now = math.hypot(cur_x - tgt_x, cur_y - tgt_y)
    dist_prev = math.hypot(prev_x - tgt_x, prev_y - tgt_y)
    approach_delta_km = dist_prev - dist_now
    min_approach_km = float(tr.get("min_approach_km", 0.7))
    if approach_delta_km < min_approach_km:
        return None

    closing_kmh = (approach_delta_km / dt_min) * 60.0
    min_closing_kmh = float(tr.get("min_closing_kmh", 10.0))
    if closing_kmh < min_closing_kmh:
        return None

    effective_radius = float(target.radius_km) + max(2.0, min(10.0, cell.radius_km))
    px = cur_x - tgt_x
    py = cur_y - tgt_y
    a = vx * vx + vy * vy
    b = 2.0 * (px * vx + py * vy)
    c = px * px + py * py - effective_radius * effective_radius
    if a <= 0:
        return None

    t_closest = max(0.0, -b / (2 * a))
    closest_x = cur_x + vx * t_closest
    closest_y = cur_y + vy * t_closest
    min_track_distance = math.hypot(closest_x, closest_y)

    exact_intersection = True
    if c <= 0:
        eta = 0.0
    else:
        disc = b * b - 4 * a * c
        if disc < 0:
            exact_intersection = False
            eta = t_closest
        else:
            sqrt_disc = math.sqrt(disc)
            candidates = [(-b - sqrt_disc) / (2 * a), (-b + sqrt_disc) / (2 * a)]
            candidates = [t for t in candidates if t >= 0]
            if not candidates:
                exact_intersection = False
                eta = t_closest
            else:
                eta = min(candidates)

    base_uncertainty_km = float(tr.get("trajectory_uncertainty_km", 3.0))
    lead_uncertainty_km = min(float(tr.get("max_lead_uncertainty_km", 7.0)), max(0.0, eta) * float(tr.get("lead_uncertainty_km_per_min", 0.12)))
    gap_uncertainty_km = min(4.0, dt_min * 0.18)
    uncertainty_km = max(1.0, base_uncertainty_km + lead_uncertainty_km + gap_uncertainty_km)

    # Se la traiettoria non interseca matematicamente il target, accettiamo solo
    # uno sfioramento entro il margine d'incertezza. L'alert vero scattera' poi
    # solo sopra min_alert_probability_percent.
    if not exact_intersection and min_track_distance > effective_radius + uncertainty_km:
        return None

    miss_km = max(0.0, min_track_distance - effective_radius)
    if min_track_distance <= effective_radius:
        geometry_score = 0.78 + 0.22 * (1.0 - min(1.0, min_track_distance / max(0.1, effective_radius)))
    else:
        geometry_score = max(0.0, 0.78 * (1.0 - miss_km / max(0.1, uncertainty_km)))

    approach_score = max(0.0, min(1.0, (closing_kmh - min_closing_kmh) / 35.0))
    size_score = max(0.0, min(1.0, cell.radius_km / 8.0))
    lead_score = max(0.0, min(1.0, 1.0 - (max(0.0, eta) / max(1.0, float(tr.get("prealert_minutes", 20)) + 10.0)) * 0.35))

    probability = 100.0 * max(0.0, min(1.0, (0.62 * geometry_score) + (0.23 * approach_score) + (0.10 * lead_score) + (0.05 * size_score)))
    probability = max(0.0, min(100.0, probability))

    return {
        "eta_minutes": eta,
        "speed_kmh": speed_kmh,
        "closing_kmh": closing_kmh,
        "distance_now_km": dist_now,
        "distance_prev_km": dist_prev,
        "approach_delta_km": approach_delta_km,
        "effective_radius_km": effective_radius,
        "min_track_distance_km": min_track_distance,
        "closest_approach_km": min_track_distance,
        "trajectory_uncertainty_km": uncertainty_km,
        "impact_probability_percent": probability,
        "exact_intersection": 1.0 if exact_intersection else 0.0,
    }


def risk_allowed(cell: Cell, cfg: dict[str, Any]) -> bool:
    tr = cfg["tracking"]
    if not bool(tr.get("require_hail_risk", True)):
        return cell.max_vmi >= float(cfg["thresholds"]["vmi_strong_dbz"])
    min_level = str(tr.get("min_risk_level", "HIGH")).upper()
    return RISK_ORDER.get(cell.risk, 0) >= RISK_ORDER.get(min_level, 3)


def cooldown_ok(state: dict[str, Any], target_name: str, cfg: dict[str, Any]) -> bool:
    alerts = state.setdefault("alerts", {})
    last_ms = alerts.get(target_name)
    if not last_ms:
        return True
    cooldown = timedelta(minutes=float(cfg["tracking"].get("alert_cooldown_minutes", 35)))
    last_dt = ms_to_dt(int(last_ms))
    return utc_now() - last_dt >= cooldown


def mark_alert_sent(state: dict[str, Any], target_name: str) -> None:
    state.setdefault("alerts", {})[target_name] = int(utc_now().timestamp() * 1000)


def classify_vmi_intensity(max_vmi: float) -> dict[str, str]:
    """Classifica l'intensita' meteorologica in modo leggibile.
    La soglia serve solo per descrivere il messaggio: non cambia gli alert.
    """
    if max_vmi < 20:
        return {
            "level": "DEBOLE",
            "title": "Pioggia debole",
            "emoji": "🌦️",
            "plain": "Fenomeno debole o pioggia leggera in avvicinamento.",
        }
    if max_vmi < 35:
        return {
            "level": "MODERATA",
            "title": "Pioggia moderata",
            "emoji": "🌧️",
            "plain": "Pioggia moderata in avvicinamento.",
        }
    if max_vmi < 45:
        return {
            "level": "INTENSA",
            "title": "Pioggia intensa / temporale in formazione",
            "emoji": "🌧️",
            "plain": "Pioggia intensa o nucleo temporalesco in avvicinamento.",
        }
    if max_vmi < 55:
        return {
            "level": "INTENSA",
            "title": "Temporale con pioggia intensa",
            "emoji": "🌧️",
            "plain": "Nucleo temporalesco con pioggia intensa in avvicinamento.",
        }
    if max_vmi < 62:
        return {
            "level": "FORTE",
            "title": "Temporale forte",
            "emoji": "⛈️",
            "plain": "Temporale forte in avvicinamento.",
        }
    return {
        "level": "MOLTO INTENSA",
        "title": "Temporale molto intenso",
        "emoji": "⛈️",
        "plain": "Temporale molto intenso in avvicinamento.",
    }


def classify_hail(cell: Cell, cfg: dict[str, Any], eta_info: Optional[dict[str, Any]] = None) -> dict[str, str]:
    """Classifica grandine con Hail Fusion 2.3.4.

    POH resta il segnale principale. Gli altri prodotti confermano o riducono
    la stima senza inventare dimensioni dei chicchi non osservabili.
    """
    thresholds = cfg.get("thresholds", {})
    poh_medium = float(thresholds.get("poh_medium_percent", 40))
    poh_high = float(thresholds.get("poh_high_percent", 60))
    poh = cell.max_poh
    ms_ctx = (eta_info or {}).get("multisignal") if isinstance(eta_info, dict) else None
    score = None
    quality = None
    severe_potential = None
    persistence_frames = 0
    engine_level = ""
    factors: list[str] = []
    calibrated_probability = None
    probability_calibrated = False
    if isinstance(ms_ctx, dict):
        try:
            score = float(ms_ctx.get("hail_evidence_score_percent", ms_ctx.get("hail_confidence_percent")))
        except Exception:
            score = None
        probability_calibrated = bool(ms_ctx.get("hail_probability_calibrated"))
        if probability_calibrated:
            try:
                calibrated_probability = float(ms_ctx.get("hail_probability_percent"))
            except Exception:
                calibrated_probability = None
        try:
            quality = float(ms_ctx.get("hail_data_quality_percent"))
        except Exception:
            quality = None
        try:
            severe_potential = float(ms_ctx.get("severe_hail_potential_percent"))
        except Exception:
            severe_potential = None
        persistence_frames = int(ms_ctx.get("hail_persistence_frames", 0) or 0)
        engine_level = str(ms_ctx.get("hail_level", ""))
        factors = [str(x) for x in ms_ctx.get("hail_factors", []) if x]

    if poh is None:
        if score is not None and score >= 40:
            probability_text = (
                f"probabilità calibrata {calibrated_probability:.0f}%"
                if calibrated_probability is not None
                else f"indice di evidenza {score:.0f}/100 (non calibrato)"
            )
            detail = f"{probability_text} · confidenza dati {quality or 0:.0f}/100"
            if factors:
                detail += " · " + "; ".join(factors[:3])
            return {
                "level": "MEDIO",
                "line": f"Grandine: segnali radar compatibili, POH non disponibile ({detail})",
                "action": "Il prodotto POH non è disponibile: i segnali secondari non bastano a quantificare una probabilità. Segui il prossimo aggiornamento.",
                "tag": "medium",
                "score": f"{calibrated_probability:.0f}% calibrata" if calibrated_probability is not None else f"indice {score:.0f}/100",
                "quality": f"{quality or 0:.0f}/100",
                "severe_potential": "n/d" if severe_potential is None else f"indice {severe_potential:.0f}/100",
                "persistence": str(persistence_frames),
            }
        return {
            "level": "N/D",
            "line": "Grandine: dato POH non disponibile",
            "action": "Tieni d'occhio la situazione, ma il radar grandine non è disponibile.",
            "tag": "unknown",
            "score": "n/d",
            "quality": "n/d" if quality is None else f"{quality:.0f}/100",
            "severe_potential": "n/d",
            "persistence": str(persistence_frames),
        }

    poh = float(poh)
    if score is None:
        score = poh
    fused_text = (
        f"probabilità calibrata {calibrated_probability:.0f}%"
        if calibrated_probability is not None
        else f"indice di evidenza {score:.0f}/100 (non calibrato)"
    )
    details = f"POH {poh:.0f}% · {fused_text}"
    if quality is not None:
        details += f" · confidenza dati {quality:.0f}/100"
    if factors:
        details += " · " + "; ".join(factors[:3])

    common = {
        "score": f"{calibrated_probability:.0f}% calibrata" if calibrated_probability is not None else f"indice {score:.0f}/100",
        "quality": "n/d" if quality is None else f"{quality:.0f}/100",
        "severe_potential": "n/d" if severe_potential is None else f"indice {severe_potential:.0f}/100",
        "persistence": str(persistence_frames),
    }
    if engine_level == "ALTO" or (not ms_ctx and poh >= poh_high and score >= 55):
        return {
            "level": "ALTO",
            "line": f"Grandine: evidenza radar FORTE ({details})",
            "action": "Se hai l'auto fuori, valuta subito di spostarla al coperto.",
            "tag": "high",
            **common,
        }
    if engine_level == "MEDIO" or poh >= poh_medium or score >= 40:
        return {
            "level": "MEDIO",
            "line": f"Grandine: evidenza radar MODERATA ({details})",
            "action": "Se l'auto è esposta, valuta se spostarla; rischio non certo ma da tenere d'occhio.",
            "tag": "medium",
            **common,
        }
    if score >= 20:
        return {
            "level": "BASSO",
            "line": f"Grandine: poco probabile, ma alcuni segnali vanno monitorati ({details})",
            "action": "Nessuna indicazione forte di grandine: monitora comunque pioggia, fulmini e vento.",
            "tag": "low",
            **common,
        }
    return {
        "level": "BASSO",
        "line": f"Grandine: non indicata dai radar ({details})",
        "action": "Nessuna indicazione forte di grandine: monitora comunque pioggia, fulmini e vento.",
        "tag": "none",
        **common,
    }


def clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, value))


def probability_label(probability: Optional[float]) -> str:
    if probability is None:
        return "non disponibile"
    if probability >= 80:
        return "alta"
    if probability >= 60:
        return "medio-alta"
    if probability >= 40:
        return "incerta"
    return "bassa"


def confidence_label(value: Optional[float]) -> str:
    if value is None:
        return "non disponibile"
    if value >= 85:
        return "molto alta"
    if value >= 70:
        return "buona"
    if value >= 50:
        return "discreta"
    return "limitata"


def surface_rain_label(rate_mmh: Optional[float]) -> str:
    if rate_mmh is None:
        return "dato non disponibile"
    if rate_mmh < 2.5:
        return "debole"
    if rate_mmh < 10:
        return "moderata"
    if rate_mmh < 30:
        return "intensa"
    if rate_mmh < 50:
        return "molto intensa"
    return "estrema"


def cloud_development_label(etm_m: Optional[float]) -> str:
    if etm_m is None:
        return "dato non disponibile"
    if etm_m < 6000:
        return "contenuto"
    if etm_m < 9000:
        return "elevato"
    if etm_m < 12000:
        return "molto elevato"
    return "eccezionalmente elevato"


def cloud_water_label(vil: Optional[float], cfg: dict[str, Any]) -> str:
    if vil is None:
        return "dato non disponibile"
    reference = max(1.0, float(cfg.get("thresholds", {}).get("vil_hail_threshold", 35) or 35))
    ratio = float(vil) / reference
    if ratio < 0.30:
        return "bassa"
    if ratio < 0.65:
        return "moderata"
    if ratio < 1.0:
        return "elevata"
    return "molto elevata"


def hail_plain_label(hail: dict[str, str]) -> str:
    return {
        "high": "forte evidenza radar",
        "medium": "evidenza radar moderata",
        "low": "evidenza radar debole",
        "none": "non indicata",
        "unknown": "dato non disponibile",
    }.get(str(hail.get("tag", "unknown")), "dato non disponibile")


def practical_alert_advice(cell: Cell, eta_info: dict[str, Any], hail: dict[str, str]) -> str:
    advice: list[str] = []
    if hail.get("tag") == "high":
        advice.append("Se puoi farlo in sicurezza, ripara auto e oggetti esposti.")
    elif hail.get("tag") == "medium":
        advice.append("I segnali radar richiedono prudenza: se hai tempo e puoi farlo in sicurezza, valuta un riparo per l'auto.")
    lightning_count = int(eta_info.get("lightning_count", 0) or 0)
    if lightning_count > 0:
        advice.append("Se sei all'aperto, raggiungi un edificio o un veicolo ed evita alberi isolati e spazi aperti.")
    elif cell.max_vmi >= 45:
        advice.append("Se sei all'aperto, valuta di raggiungere un luogo riparato.")
    if cell.max_sri is not None and float(cell.max_sri) >= 30:
        advice.append("Evita sottopassi e strade già allagate: la pioggia può creare ristagni rapidamente.")
    if not advice:
        advice.append("Segui i prossimi aggiornamenti e valuta le condizioni locali prima di spostarti.")
    return " ".join(advice[:2])


def safe_message_text(value: Any, limit: int = 80) -> str:
    return html.escape(str(value)[:limit], quote=False)


def adjust_eta_for_data_age(
    eta_info: dict[str, Any],
    frame_timestamp_ms: Optional[int],
    cfg: dict[str, Any],
    *,
    now_ms: Optional[int] = None,
) -> dict[str, Any]:
    """Converte l'ETA del frame radar in tempo residuo al momento dell'elaborazione.

    Radar-DPC può pubblicare un volume diversi minuti dopo il timestamp nominale.
    Un ETA di due minuti calcolato su un frame vecchio di sette non deve quindi
    essere notificato come futuro. I timestamp sintetici dei test, palesemente
    fuori dalla finestra operativa, vengono lasciati invariati.
    """
    info = dict(eta_info)
    if frame_timestamp_ms is None:
        return info
    current_ms = int(now_ms if now_ms is not None else utc_now().timestamp() * 1000)
    age_minutes = max(0.0, (current_ms - int(frame_timestamp_ms)) / 60000.0)
    operational_limit = max(
        5.0,
        float(cfg.get("app", {}).get("max_frame_age_minutes", 30) or 30) * 2.0,
    )
    if age_minutes > operational_limit:
        return info

    eta = float(info.get("eta_minutes", 0.0) or 0.0)
    low = float(info.get("eta_low_minutes", eta) if info.get("eta_low_minutes") is not None else eta)
    high = float(info.get("eta_high_minutes", eta) if info.get("eta_high_minutes") is not None else eta)
    info["radar_eta_minutes"] = eta
    info["radar_eta_low_minutes"] = low
    info["radar_eta_high_minutes"] = high
    info["data_age_minutes"] = round(age_minutes, 2)
    info["eta_minutes"] = max(0.0, eta - age_minutes)
    info["eta_low_minutes"] = max(0.0, low - age_minutes)
    info["eta_high_minutes"] = max(0.0, high - age_minutes)
    expiry_grace = max(0.0, float(cfg.get("tracking", {}).get("expired_eta_grace_minutes", 2) or 2))
    info["eta_window_expired"] = high + expiry_grace < age_minutes
    return info


def eta_text_for_people(eta_info: dict[str, Any]) -> str:
    eta = float(eta_info.get("eta_minutes", 0.0) or 0.0)
    low = eta_info.get("eta_low_minutes")
    high = eta_info.get("eta_high_minutes")
    if eta < 1 or (high is not None and float(high) < 1):
        return "adesso / imminente"
    if low is not None and high is not None:
        low_rounded = max(0, int(round(float(low))))
        high_rounded = max(low_rounded, int(round(float(high))))
        if low_rounded == high_rounded:
            return f"circa {low_rounded} minuti"
        if low_rounded == 0:
            return f"entro {high_rounded} minuti"
        return f"tra {low_rounded} e {high_rounded} minuti"
    return f"circa {eta:.0f} minuti"


def forecast_stability_text(eta_info: dict[str, Any]) -> str:
    stability = eta_info.get("forecast_stability_percent")
    if stability is None:
        return "non valutabile con i dati disponibili"
    value = float(stability)
    topology = str(eta_info.get("topology_event", "") or "")
    if topology:
        return f"bassa: recente {topology}, finestra ETA ampliata"
    if value >= 82:
        return "alta: percorso coerente tra le ultime scansioni"
    if value >= 65:
        return "buona: previsione credibile, ma ancora aggiornabile"
    if value >= 50:
        return "media: direzione o velocità possono ancora cambiare"
    return "bassa: previsione preliminare e facilmente variabile"


def forecast_evolution_text(eta_info: dict[str, Any]) -> str:
    """Explain forecast stability without exposing the internal score."""
    stability = eta_info.get("forecast_stability_percent")
    if stability is None:
        return "è ancora presto per capire se aumenterà o diminuirà"
    if eta_info.get("topology_event"):
        return "la traiettoria è cambiata e deve ancora stabilizzarsi"
    value = float(stability)
    if value >= 82:
        return "il percorso è stabile nelle ultime scansioni"
    if value >= 65:
        return "la previsione è abbastanza stabile, ma può ancora cambiare"
    if value >= 50:
        return "direzione o velocità possono ancora cambiare"
    return "la previsione è ancora preliminare"



def get_multisignal_cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    ms = cfg.get("multisignal", {}) if isinstance(cfg, dict) else {}
    return {
        "enabled": bool(ms.get("enabled", True)),
        "impact_weight_trajectory": float(ms.get("impact_weight_trajectory", 0.72)),
        "impact_weight_confirmation": float(ms.get("impact_weight_confirmation", 0.28)),
        "hail_min_poh_for_high": float(ms.get("hail_min_poh_for_high", 35)),
        "hail_min_score_medium": float(ms.get("hail_min_score_medium", 35)),
        "hail_min_score_high": float(ms.get("hail_min_score_high", 65)),
        "confidence_min_for_numeric_100": float(ms.get("confidence_min_for_numeric_100", 92)),
        "hail_min_persistence_frames": max(2, int(ms.get("hail_min_persistence_frames", 2) or 2)),
        "hail_high_min_data_quality": float(ms.get("hail_high_min_data_quality", 65)),
    }


def score_from_range(value: Optional[float], start: float, full: float) -> float:
    if value is None:
        return 0.0
    try:
        if full <= start:
            return 0.0
        return clamp((float(value) - start) / (full - start), 0.0, 1.0)
    except Exception:
        return 0.0


def _point_in_polygon_local(x: float, y: float, polygon: np.ndarray) -> bool:
    inside = False
    j = len(polygon) - 1
    for i in range(len(polygon)):
        xi, yi = polygon[i]
        xj, yj = polygon[j]
        if ((yi > y) != (yj > y)) and x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi:
            inside = not inside
        j = i
    return inside


def _polygon_distance_local(x: float, y: float, polygon: np.ndarray) -> float:
    if len(polygon) < 3:
        return float("inf")
    if _point_in_polygon_local(x, y, polygon):
        return 0.0
    best = float("inf")
    for index in range(len(polygon)):
        ax, ay = polygon[index]
        bx, by = polygon[(index + 1) % len(polygon)]
        dx, dy = bx - ax, by - ay
        denom = dx * dx + dy * dy
        factor = 0.0 if denom <= 1e-12 else clamp(((x - ax) * dx + (y - ay) * dy) / denom)
        best = min(best, math.hypot(x - (ax + factor * dx), y - (ay + factor * dy)))
    return best


def target_echo_edge_distance_km(target: Target, cell: Cell) -> float:
    """Distanza dal target al bordo reale dell'eco, non al solo centro cella."""
    target_x, target_y = lonlat_to_xy_km(target.lon, target.lat, cell.lon, cell.lat)
    raw = getattr(cell, "footprint_xy_km", None) or []
    try:
        polygon = np.asarray(raw, dtype="float64")
        if polygon.ndim == 2 and polygon.shape[0] >= 3 and polygon.shape[1] == 2 and np.all(np.isfinite(polygon)):
            return max(0.0, _polygon_distance_local(target_x, target_y, polygon))
    except Exception:
        pass
    return max(0.0, haversine_km(target.lat, target.lon, cell.lat, cell.lon) - max(0.5, float(cell.radius_km)))


def near_target_observation_context(
    target: Target,
    cell: Cell,
    lt_ctx: dict[str, Any],
    cappi_vertical: dict[str, Any],
    cfg: dict[str, Any],
) -> dict[str, Any]:
    ncfg = cfg.get("near_target_override", {})
    enabled = bool(ncfg.get("enabled", True))
    edge_distance = target_echo_edge_distance_km(target, cell)
    lightning_nearest = lt_ctx.get("nearest_km")
    lightning_close = lightning_nearest is not None and float(lightning_nearest) <= float(ncfg.get("lightning_radius_km", 3.0) or 3.0)
    intense_rain = cell.max_sri is not None and float(cell.max_sri) >= float(ncfg.get("surface_rain_threshold_mmh", 15.0) or 15.0)
    persistent_rain = cell.max_srt1 is not None and float(cell.max_srt1) >= float(ncfg.get("hourly_rain_threshold_mm", 6.0) or 6.0)
    echo_close = edge_distance <= float(target.radius_km) + float(ncfg.get("edge_margin_km", 3.0) or 3.0)
    strong_echo = float(cell.max_vmi) >= float(ncfg.get("minimum_vmi_dbz", 45.0) or 45.0)
    active = bool(enabled and echo_close and strong_echo and (lightning_close or intense_rain or persistent_rain))
    observed_on_target = edge_distance <= float(target.radius_km) and (intense_rain or persistent_rain)
    hail_watch = bool(
        active
        and lightning_close
        and cappi_vertical.get("available")
        and float(cappi_vertical.get("score_percent", 0.0) or 0.0) >= float(ncfg.get("hail_watch_cappi_score_percent", 22.0) or 22.0)
    )
    if observed_on_target:
        reason = "precipitazione convettiva già osservata sull'area target"
    elif lightning_close:
        reason = "bordo dell'eco e fulmini osservati entro pochi chilometri dal target"
    elif intense_rain:
        reason = "bordo dell'eco molto vicino con SRI da pioggia intensa"
    else:
        reason = "eco convettiva molto vicina e persistente"
    return {
        "enabled": enabled,
        "active": active,
        "observed_on_target": observed_on_target,
        "edge_distance_km": round(edge_distance, 2),
        "lightning_nearest_km": None if lightning_nearest is None else round(float(lightning_nearest), 2),
        "intense_rain": intense_rain,
        "persistent_rain": persistent_rain,
        "hail_watch": hail_watch,
        "reason": reason if active else "nessuna evidenza osservata abbastanza vicina",
    }


def cappi_vertical_hail_context(
    cell: Cell,
    freezing_level_m: Optional[float],
    cfg: dict[str, Any],
) -> dict[str, Any]:
    """Evidenza verticale CAPPI, usata come correttore limitato della grandine.

    La metrica confronta le quote massime delle eco 45/50/55 dBZ con lo zero
    termico. Non stima la dimensione dei chicchi e non sostituisce il POH.
    """
    vcfg = cfg.get("vertical_profile", {}) if isinstance(cfg, dict) else {}
    enabled = bool(vcfg.get("enabled", True))
    quality = clamp(float(getattr(cell, "cappi_quality_percent", 0.0) or 0.0) / 100.0)
    levels = int(getattr(cell, "cappi_available_levels", 0) or 0)
    h45 = getattr(cell, "cappi_highest_45_km", None)
    h50 = getattr(cell, "cappi_highest_50_km", None)
    h55 = getattr(cell, "cappi_highest_55_km", None)
    available = enabled and levels > 0 and quality >= float(vcfg.get("minimum_coverage", 0.5) or 0.5)
    base = {
        "enabled": enabled,
        "available": available,
        "levels_available": levels,
        "quality_percent": round(quality * 100.0, 1),
        "highest_45_km": h45,
        "highest_50_km": h50,
        "highest_55_km": h55,
        "freezing_level_km": None if freezing_level_m is None else round(float(freezing_level_m) / 1000.0, 2),
        "score_percent": 0.0,
        "label": "profilo CAPPI non disponibile",
        "detail": "nessuna correzione applicata",
        "adjustment_points": 0.0,
    }
    if not available:
        if enabled and levels:
            base["label"] = "profilo CAPPI incompleto"
        return base
    if freezing_level_m is None:
        base["label"] = "profilo verticale disponibile"
        base["detail"] = "zero termico non disponibile: profilo solo informativo"
        return base

    freezing_km = float(freezing_level_m) / 1000.0
    delta45 = None if h45 is None else float(h45) - freezing_km
    delta50 = None if h50 is None else float(h50) - freezing_km
    delta55 = None if h55 is None else float(h55) - freezing_km
    score45 = score_from_range(delta45, 0.8, 4.8)
    score50 = score_from_range(delta50, 0.4, 4.0)
    score55 = score_from_range(delta55, 0.0, 3.2)
    vertical_score = clamp((0.52 * score45) + (0.30 * score50) + (0.18 * score55)) * quality
    max_influence = max(0.0, min(15.0, float(vcfg.get("max_hail_adjustment_points", 12) or 12)))
    min_influence = max(0.0, min(10.0, float(vcfg.get("max_negative_adjustment_points", 6) or 6)))
    neutral = max(0.1, min(0.7, float(vcfg.get("neutral_score", 0.35) or 0.35)))
    if vertical_score >= neutral:
        adjustment = ((vertical_score - neutral) / max(0.01, 1.0 - neutral)) * max_influence
    else:
        adjustment = -((neutral - vertical_score) / neutral) * min_influence

    if h45 is None:
        label = "nessun nucleo ≥45 dBZ in quota"
        detail = "il profilo verticale indebolisce la stima grandine"
    elif delta45 is not None and delta45 >= 2.5 and h50 is not None:
        label = "forte supporto verticale alla grandine"
        detail = f"eco 45 dBZ fino a {float(h45):.0f} km, {delta45:.1f} km sopra lo zero termico"
    elif delta45 is not None and delta45 >= 1.4:
        label = "profilo compatibile con grandine"
        detail = f"eco 45 dBZ fino a {float(h45):.0f} km, {delta45:.1f} km sopra lo zero termico"
    else:
        label = "supporto verticale debole"
        detail = (
            f"eco 45 dBZ fino a {float(h45):.0f} km"
            if h45 is not None
            else "eco intenso non persistente in quota"
        )
    base.update({
        "score_percent": round(vertical_score * 100.0, 1),
        "label": label,
        "detail": detail,
        "height_45_above_freezing_km": None if delta45 is None else round(delta45, 2),
        "height_50_above_freezing_km": None if delta50 is None else round(delta50, 2),
        "height_55_above_freezing_km": None if delta55 is None else round(delta55, 2),
        "adjustment_points": round(adjustment, 1),
    })
    return base


def single_pol_hail_shadow(
    cell: Cell,
    freezing_level_m: Optional[float],
    cfg: dict[str, Any],
) -> dict[str, Any]:
    """SHI/POSH adattati ai CAPPI disponibili, solo per replay e confronto.

    Segue le equazioni di Witt et al. riportate nello studio Skripnikova &
    Rezacova: flusso energetico 5e-6*10^(0.084Z), pesi 40-50 dBZ,
    integrazione sopra H0 e WT=max(20,57.5*H0-121). Non disponendo della quota
    osservata di -20 C, essa è approssimata e il risultato non è calibrato.
    """
    hcfg = cfg.get("hail_shadow", {})
    base = {
        "enabled": bool(hcfg.get("enabled", True)),
        "available": False,
        "mode": "shadow",
        "calibrated": False,
        "shi_j_m_s": 0.0,
        "posh_index_percent": 0.0,
        "combi_votes": 0,
        "reason": "dati verticali insufficienti",
    }
    profile_raw = getattr(cell, "cappi_profile_dbz", {}) or {}
    if not base["enabled"] or freezing_level_m is None or len(profile_raw) < 3:
        return base
    try:
        profile = sorted(
            (float(height), max(0.0, min(80.0, float(value))))
            for height, value in profile_raw.items()
            if math.isfinite(float(height)) and math.isfinite(float(value))
        )
    except (TypeError, ValueError, OverflowError):
        return base
    h0 = float(freezing_level_m) / 1000.0
    minus20 = h0 + max(2.0, min(4.5, float(hcfg.get("minus20_height_offset_km", 3.0) or 3.0)))

    def integrand(height: float, reflectivity: float) -> float:
        wz = clamp((reflectivity - 40.0) / 10.0)
        wt = clamp((height - h0) / max(0.5, minus20 - h0))
        energy = 5.0e-6 * (10.0 ** (0.084 * reflectivity))
        return wt * wz * energy

    shi = 0.0
    usable = [(height, value) for height, value in profile if height >= h0]
    for (h1, z1), (h2, z2) in zip(usable, usable[1:]):
        delta_m = max(0.0, h2 - h1) * 1000.0
        shi += 0.1 * 0.5 * (integrand(h1, z1) + integrand(h2, z2)) * delta_m
    warning_threshold = max(20.0, 57.5 * h0 - 121.0)
    posh = 0.0 if shi <= 0.0 else clamp((29.0 * math.log(shi / warning_threshold) + 50.0) / 100.0) * 100.0
    h45 = getattr(cell, "cappi_highest_45_km", None)
    if h45 is None:
        h45 = cappi_echo_top_km({str(h): z for h, z in profile}, 45.0)
    waldvogel = h45 is not None and float(h45) >= h0 + float(hcfg.get("waldvogel_delta_km", 1.4) or 1.4)
    votes = int(waldvogel) + int(shi >= float(hcfg.get("shi_reference", 60.0) or 60.0)) + int(posh >= float(hcfg.get("posh_reference_percent", 30.0) or 30.0))
    base.update({
        "available": bool(len(usable) >= 2),
        "shi_j_m_s": round(max(0.0, shi), 2),
        "posh_index_percent": round(posh, 1),
        "warning_threshold": round(warning_threshold, 2),
        "freezing_level_km": round(h0, 2),
        "minus20_height_estimated_km": round(minus20, 2),
        "waldvogel": bool(waldvogel),
        "combi_votes": votes,
        "reason": "indice sperimentale: quota -20 C stimata e nessuna calibrazione italiana",
    })
    return base


def lightning_signal_score(lt_ctx: dict[str, Any], lightning_meta: dict[str, Any], cfg: dict[str, Any]) -> float:
    if not lt_ctx:
        return 0.0
    if isinstance(lightning_meta, dict) and lightning_meta.get("available") and not lightning_meta.get("fresh", True):
        return 0.0
    try:
        count = int(lt_ctx.get("count", 0) or 0)
        nearest = lt_ctx.get("nearest_km")
        radius = float(lt_ctx.get("radius_km", cfg.get("lightning", {}).get("radius_km", 20)) or 20)
        if count <= 0:
            return 0.0
        count_score = clamp(count / 12.0, 0.0, 1.0)
        near_score = 0.45
        if nearest is not None:
            near_score = clamp(1.0 - (float(nearest) / max(1.0, radius)), 0.0, 1.0)
        return clamp((0.55 * count_score) + (0.45 * near_score), 0.0, 1.0)
    except Exception:
        return 0.0


def hail_persistence_context(cell: Cell, state: Optional[dict[str, Any]], cfg: dict[str, Any]) -> dict[str, Any]:
    """Conferma che i segnali grandine persistano su più volumi radar."""
    track_id = str(getattr(cell, "track_id", "") or "")
    observations = []
    if state and track_id:
        observations = (
            ((((state.get("precision") or {}).get("tracks") or {}).get(track_id) or {}).get("observations") or [])
        )[-6:]
    if not observations:
        observations = [asdict(cell)]

    th = cfg.get("thresholds", {})
    vmi_core = float(th.get("vmi_core_dbz", th.get("vmi_hail_dbz", 55)) or 55)
    vil_reference = max(1.0, float(th.get("vil_hail_threshold", 35) or 35))
    evidence: list[bool] = []
    strengths: list[float] = []
    for row in observations:
        vmi = float(row.get("max_vmi", 0.0) or 0.0)
        poh = row.get("max_poh")
        vil = row.get("max_vil")
        etm = row.get("max_etm")
        cappi_45 = row.get("cappi_highest_45_km")
        poh_signal = poh is not None and float(poh) >= 20.0
        vertical_signal = (
            vmi >= vmi_core - 4.0
            and vil is not None and float(vil) >= vil_reference * 0.45
            and etm is not None and float(etm) >= 6500.0
        )
        cappi_signal = cappi_45 is not None and float(cappi_45) >= 6.0
        evidence.append(bool(poh_signal or vertical_signal or cappi_signal))
        strengths.append(clamp(
            0.52 * (0.0 if poh is None else float(poh) / 100.0)
            + 0.22 * score_from_range(vmi, vmi_core - 8.0, vmi_core + 10.0)
            + 0.18 * score_from_range(None if vil is None else float(vil), vil_reference * 0.35, vil_reference)
            + 0.08 * score_from_range(None if cappi_45 is None else float(cappi_45), 4.0, 9.0)
        ))

    consecutive = 0
    for present in reversed(evidence):
        if not present:
            break
        consecutive += 1
    recent = evidence[-3:]
    persistence_score = clamp(
        0.55 * (sum(1 for value in recent if value) / max(1.0, float(len(recent))))
        + 0.45 * clamp((consecutive - 1) / 2.0),
    )
    trend = 0.0
    if len(strengths) >= 2:
        trend = clamp(0.5 + (strengths[-1] - strengths[-2]) * 2.0)
    return {
        "frames_available": len(observations),
        "consecutive_signal_frames": consecutive,
        "persistence_score": persistence_score,
        "trend_score": trend,
    }


def build_multisignal_context(target: Target, cell: Cell, eta_info: dict[str, float], cfg: dict[str, Any], lt_ctx: Optional[dict[str, Any]] = None, lightning_meta: Optional[dict[str, Any]] = None, state: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """Incrocio multi-segnale 2.2.7.

    Non sostituisce Radar-DPC e non usa altri radar: combina i prodotti già
    disponibili (traiettoria/VMI/POH/VIL/ETM/LGT) per rendere la stima più
    robusta e meno binaria.
    """
    ms_cfg = get_multisignal_cfg(cfg)
    th = cfg.get("thresholds", {})
    tr = cfg.get("tracking", {})
    lt_ctx = lt_ctx or {}
    lightning_meta = lightning_meta or {}

    operational_probability = float(eta_info.get("impact_probability_percent", 0.0) or 0.0)
    trajectory_prob = float(eta_info.get("trajectory_probability_percent", operational_probability) or 0.0)
    strong_vmi = float(tr.get("strong_alert_vmi_dbz", th.get("vmi_strong_dbz", 45)) or 45)
    vmi_hail = float(th.get("vmi_hail_dbz", 55) or 55)
    vil_hail = float(th.get("vil_hail_threshold", 35) or 35)
    etm_hail = float(th.get("etm_hail_threshold_m", 9000) or 9000)
    freezing_level = eta_info.get("freezing_level_m")

    vmi_score = score_from_range(cell.max_vmi, max(25.0, strong_vmi - 8.0), max(strong_vmi + 14.0, vmi_hail + 8.0))
    strong_vmi_score = score_from_range(cell.max_vmi, strong_vmi, max(strong_vmi + 18.0, vmi_hail + 10.0))
    poh_score = 0.0 if cell.max_poh is None else clamp(float(cell.max_poh) / 100.0, 0.0, 1.0)
    vil_score = score_from_range(cell.max_vil, max(4.0, vil_hail * 0.35), max(vil_hail, 8.0))
    etm_score = score_from_range(cell.max_etm, max(3500.0, etm_hail * 0.50), max(etm_hail, 6000.0))
    lightning_score = lightning_signal_score(lt_ctx, lightning_meta, cfg)
    persistence = hail_persistence_context(cell, state, cfg)
    cappi_vertical = cappi_vertical_hail_context(cell, freezing_level, cfg)
    hail_shadow = single_pol_hail_shadow(cell, freezing_level, cfg)
    near_target = near_target_observation_context(target, cell, lt_ctx, cappi_vertical, cfg)
    temporal_bundle = eta_info.get("temporal_bundle") if isinstance(eta_info.get("temporal_bundle"), dict) else {}
    target_data_quality = eta_info.get("target_data_quality") if isinstance(eta_info.get("target_data_quality"), dict) else {}
    quality_value = target_data_quality.get("score_percent", temporal_bundle.get("quality_percent", 100.0))
    bundle_quality = clamp(float(quality_value if quality_value is not None else 100.0) / 100.0, 0.35, 1.0)

    closing_kmh = float(eta_info.get("closing_kmh", 0.0) or 0.0)
    min_closing = float(tr.get("min_closing_kmh", 10.0) or 10.0)
    trend_score = clamp((closing_kmh - min_closing) / 45.0, 0.0, 1.0)
    exact_score = 1.0 if float(eta_info.get("exact_intersection", 0.0) or 0.0) >= 0.5 else 0.45
    eta = float(eta_info.get("eta_minutes", 999.0) or 999.0)
    lead_score = clamp(1.0 - (eta / max(1.0, float(tr.get("prealert_minutes", 20)) + 10.0)), 0.0, 1.0)

    vertical_score = clamp((0.40 * strong_vmi_score) + (0.32 * vil_score) + (0.28 * etm_score), 0.0, 1.0)
    confirmation_score = clamp((0.26 * vmi_score) + (0.22 * vertical_score) + (0.20 * trend_score) + (0.18 * lightning_score) + (0.14 * exact_score), 0.0, 1.0)

    if str(eta_info.get("model", "")).startswith((
        "precision-ensemble",
        "terrain-lifecycle",
        "national-fusion-ensemble",
        "stable-impact-ensemble",
    )):
        # Nel Precision Engine i segnali di intensita' non possono spostare
        # geometricamente la cella: aumentano/diminuiscono la confidenza, mentre
        # la probabilita' d'impatto resta quella dell'ensemble di traiettorie.
        impact_prob = operational_probability
        motion_confidence = clamp(float(eta_info.get("motion_confidence_percent", 0.0) or 0.0) / 100.0)
        data_completeness = clamp(
            0.30 * vmi_score +
            0.18 * (1.0 if cell.max_poh is not None else 0.0) +
            0.18 * (1.0 if cell.max_vil is not None else 0.0) +
            0.18 * (1.0 if cell.max_etm is not None else 0.0) +
            0.16 * (lightning_score if lightning_meta.get("available") else 0.45)
        )
        impact_confidence = 100.0 * clamp(0.68 * motion_confidence + 0.32 * data_completeness) * bundle_quality
    elif ms_cfg["enabled"]:
        impact_prob = (ms_cfg["impact_weight_trajectory"] * trajectory_prob) + (ms_cfg["impact_weight_confirmation"] * confirmation_score * 100.0)
        # Evita il 100% visibile salvo casi davvero solidi: una cella può deviare anche all'ultimo.
        impact_confidence = clamp((0.35 * confirmation_score) + (0.30 * (trajectory_prob / 100.0)) + (0.20 * trend_score) + (0.15 * lead_score), 0.0, 1.0) * 100.0 * bundle_quality
        if impact_confidence < ms_cfg["confidence_min_for_numeric_100"]:
            impact_prob = min(95.0, impact_prob)
    else:
        impact_prob = trajectory_prob
        impact_confidence = trajectory_prob

    if near_target["active"]:
        near_cfg = cfg.get("near_target_override", {})
        floor = float(
            near_cfg.get("observed_probability_floor_percent", 74.0)
            if near_target["observed_on_target"]
            else near_cfg.get("near_probability_floor_percent", 68.0)
        )
        impact_prob = max(impact_prob, min(88.0, floor))
        impact_confidence = max(impact_confidence, 70.0 if near_target["observed_on_target"] else 64.0)

    vil_density = None
    if cell.max_vil is not None and cell.max_etm is not None and float(cell.max_etm) > 1000.0:
        vil_density = float(cell.max_vil) * 1000.0 / float(cell.max_etm)
    vil_density_score = score_from_range(vil_density, 1.8, 4.2)
    freezing_depth_score = 0.0
    echo_above_freezing_m = None
    if freezing_level is not None and cell.max_etm is not None:
        echo_above_freezing_m = max(0.0, float(cell.max_etm) - float(freezing_level))
        # ETM non è la quota del 45/50 dBZ: resta quindi un correttore debole,
        # non una seconda implementazione del POH Waldvogel.
        freezing_depth_score = score_from_range(echo_above_freezing_m, 2200.0, 6500.0)
    lightning_jump = eta_info.get("lightning_jump") if isinstance(eta_info.get("lightning_jump"), dict) else {}
    jump_score = clamp(float(lightning_jump.get("jump_score", 0.0) or 0.0) / 100.0)
    lifecycle = eta_info.get("lifecycle") if isinstance(eta_info.get("lifecycle"), dict) else {}
    lifecycle_growth = clamp(
        0.5
        + float(lifecycle.get("vmi_trend_dbz_min", eta_info.get("vmi_trend_dbz_min", 0.0)) or 0.0) / 3.0
        + float(lifecycle.get("vil_trend_min", 0.0) or 0.0) / 12.0,
    )
    growth_score = clamp(0.70 * lifecycle_growth + 0.30 * jump_score)
    cold_cloud_score = score_from_range(
        None if cell.min_ir108 is None else -float(cell.min_ir108),
        35.0,
        70.0,
    )

    baseline_hail_score = 100.0 * clamp(
        (0.46 * poh_score)
        + (0.15 * strong_vmi_score)
        + (0.13 * vil_density_score)
        + (0.08 * freezing_depth_score)
        + (0.12 * float(persistence["persistence_score"]))
        + (0.04 * growth_score)
        + (0.02 * cold_cloud_score),
    )
    baseline_data_quality = 100.0 * clamp(
        (0.35 if cell.max_poh is not None else 0.0)
        + (0.15 if cell.max_vil is not None else 0.0)
        + (0.15 if cell.max_etm is not None else 0.0)
        + (0.15 if freezing_level is not None else 0.0)
        + 0.20 * clamp((int(persistence["frames_available"]) - 1) / 2.0),
    )
    baseline_severe_hail_potential = 100.0 * clamp(
        0.34 * strong_vmi_score
        + 0.26 * vil_density_score
        + 0.18 * freezing_depth_score
        + 0.16 * float(persistence["persistence_score"])
        + 0.06 * growth_score,
    )
    if cappi_vertical["available"] and freezing_level is not None:
        hail_score = clamp(
            baseline_hail_score + float(cappi_vertical["adjustment_points"]),
            0.0,
            100.0,
        )
        cappi_quality = clamp(float(cappi_vertical["quality_percent"]) / 100.0)
        data_quality = clamp(
            0.80 * baseline_data_quality + 20.0 * cappi_quality,
            0.0,
            100.0,
        )
        cappi_score = clamp(float(cappi_vertical["score_percent"]) / 100.0)
        severe_hail_potential = clamp(
            0.78 * baseline_severe_hail_potential + 22.0 * cappi_score,
            0.0,
            100.0,
        )
    else:
        hail_score = baseline_hail_score
        data_quality = baseline_data_quality
        severe_hail_potential = baseline_severe_hail_potential

    data_quality *= bundle_quality
    hail_feedback_features = build_hail_feedback_features({
        "poh": cell.max_poh,
        "vmi": cell.max_vmi,
        "vil_density": vil_density,
        "cappi_vertical": cappi_vertical.get("score_percent"),
        "cappi_45_above_freezing": cappi_vertical.get("height_45_above_freezing_km"),
        "lightning": lightning_score * 100.0,
        "surface_rain": min(100.0, 0.0 if cell.max_sri is None else float(cell.max_sri) / 1.5),
        "persistence": float(persistence["persistence_score"]) * 100.0,
        "data_quality": data_quality,
    })
    hail_evidence_score = float(hail_score)
    hail_feedback_calibration = apply_hail_feedback_candidate(hail_evidence_score, hail_feedback_features, cfg)
    hail_probability_calibrated = bool(hail_feedback_calibration.get("applied"))
    calibrated_hail_probability = (
        float(hail_feedback_calibration.get("probability_percent"))
        if hail_probability_calibrated and hail_feedback_calibration.get("probability_percent") is not None
        else None
    )
    hail_decision_score = calibrated_hail_probability if calibrated_hail_probability is not None else hail_evidence_score

    factors = []
    if cell.max_poh is not None:
        factors.append(f"POH probabilità grandine {float(cell.max_poh):.0f}%")
    if strong_vmi_score >= 0.45:
        factors.append(f"VMI intensità verticale {cell.max_vmi:.1f} dBZ")
    if int(persistence["consecutive_signal_frames"]) >= 2:
        factors.append(f"segnale persistente da {int(persistence['consecutive_signal_frames'])} frame")
    if vil_density is not None and vil_density_score >= 0.45:
        factors.append(f"densità acqua/ghiaccio {vil_density:.1f} g/m³")
    if echo_above_freezing_m is not None and freezing_depth_score >= 0.45:
        factors.append(f"sviluppo {echo_above_freezing_m / 1000.0:.1f} km sopra lo zero termico")
    if jump_score >= 0.45:
        factors.append("attività elettrica in rapido aumento")
    if cappi_vertical["available"]:
        factors.append(str(cappi_vertical["label"]))

    vertical_support_ok = (
        not cappi_vertical["available"]
        or float(cappi_vertical["score_percent"]) >= float(
            cfg.get("vertical_profile", {}).get("minimum_high_support_percent", 22) or 22
        )
    )
    high_evidence = (
        hail_decision_score >= ms_cfg["hail_min_score_high"]
        and data_quality >= ms_cfg["hail_high_min_data_quality"]
        and int(persistence["consecutive_signal_frames"]) >= ms_cfg["hail_min_persistence_frames"]
        and cell.max_poh is not None
        and float(cell.max_poh) >= ms_cfg["hail_min_poh_for_high"]
        and vertical_support_ok
    )
    if high_evidence:
        hail_level = "ALTO"
        hail_label = "forte evidenza radar"
    elif hail_decision_score >= ms_cfg["hail_min_score_medium"]:
        hail_level = "MEDIO"
        hail_label = "evidenza radar moderata"
    else:
        hail_level = "BASSO"
        hail_label = "non indicata"

    return {
        "enabled": bool(ms_cfg["enabled"]),
        "trajectory_probability_percent": round(trajectory_prob, 1),
        "impact_probability_percent": round(clamp(impact_prob, 0.0, 100.0), 1),
        "impact_confidence_percent": round(clamp(impact_confidence, 0.0, 100.0), 1),
        "confirmation_score_percent": round(confirmation_score * 100.0, 1),
        # Questo indice non è una probabilità calibrata: conserva la telemetria
        # storica ma viene presentato esplicitamente come evidenza 0-100.
        "hail_confidence_percent": round(hail_evidence_score, 1),
        "hail_evidence_score_percent": round(hail_evidence_score, 1),
        "hail_probability_percent": None if calibrated_hail_probability is None else round(calibrated_hail_probability, 1),
        "hail_probability_calibrated": hail_probability_calibrated,
        "hail_calibration_baseline_percent": round(hail_evidence_score, 1),
        "hail_data_quality_percent": round(data_quality, 1),
        "severe_hail_potential_percent": round(severe_hail_potential, 1),
        "hail_persistence_frames": int(persistence["consecutive_signal_frames"]),
        "hail_level": hail_level,
        "hail_label": hail_label,
        "hail_factors": factors[:4],
        "cappi_vertical": cappi_vertical,
        "hail_shadow": hail_shadow,
        "near_target_override": near_target,
        "temporal_bundle": temporal_bundle,
        "target_data_quality": target_data_quality,
        "hail_feedback_calibration": hail_feedback_calibration,
        "scores": {
            "vmi": round(vmi_score * 100.0, 1),
            "vertical": round(vertical_score * 100.0, 1),
            "trend": round(trend_score * 100.0, 1),
            "lightning": round(lightning_score * 100.0, 1),
            "poh": round(poh_score * 100.0, 1),
            "vil": round(vil_score * 100.0, 1),
            "vil_density": round(vil_density_score * 100.0, 1),
            "etm": round(etm_score * 100.0, 1),
            "freezing_depth": round(freezing_depth_score * 100.0, 1),
            "persistence": round(float(persistence["persistence_score"]) * 100.0, 1),
            "cappi_vertical": round(float(cappi_vertical["score_percent"]), 1),
        },
    }


def apply_multisignal_context(target: Target, cell: Cell, eta_info: dict[str, float], cfg: dict[str, Any], lt_ctx: Optional[dict[str, Any]] = None, lightning_meta: Optional[dict[str, Any]] = None, state: Optional[dict[str, Any]] = None) -> dict[str, float]:
    info = dict(eta_info)
    existing = info.get("multisignal")
    if isinstance(existing, dict) and existing.get("confidence_shrinkage_applied"):
        ctx = dict(existing)
    else:
        ctx = build_multisignal_context(target, cell, info, cfg, lt_ctx=lt_ctx, lightning_meta=lightning_meta, state=state)
    raw_probability = float(ctx["impact_probability_percent"])
    confidence = float(ctx.get("impact_confidence_percent", 50.0) or 50.0)
    if bool(cfg.get("multisignal", {}).get("confidence_shrinkage_enabled", True)):
        # Quando traiettoria e prodotti non concordano, una percentuale estrema
        # viene riportata prudentemente verso il 50%. Non cambia il segno della
        # previsione e si attenua automaticamente con confidenza elevata.
        reliability = clamp(confidence / 100.0, 0.35, 1.0)
        shrink_factor = 0.55 + 0.45 * reliability
        adjusted_probability = 50.0 + (raw_probability - 50.0) * shrink_factor
        motion_confidence = info.get("motion_confidence_percent")
        if motion_confidence is not None and float(motion_confidence) < 60.0 and int(info.get("track_frames", cell.track_frames) or 1) < 3:
            adjusted_probability = min(adjusted_probability, 70.0)
        near_context = ctx.get("near_target_override") if isinstance(ctx.get("near_target_override"), dict) else {}
        if near_context.get("active"):
            near_cfg = cfg.get("near_target_override", {})
            floor = float(
                near_cfg.get("observed_probability_floor_percent", 74.0)
                if near_context.get("observed_on_target")
                else near_cfg.get("near_probability_floor_percent", 68.0)
            )
            adjusted_probability = max(adjusted_probability, floor)
        ctx["raw_impact_probability_percent"] = round(raw_probability, 1)
        ctx["impact_probability_percent"] = round(clamp(adjusted_probability / 100.0) * 100.0, 1)
        ctx["confidence_shrinkage_applied"] = True
    info["multisignal"] = ctx
    info["trajectory_probability_percent"] = ctx["trajectory_probability_percent"]
    info["impact_confidence_percent"] = ctx["impact_confidence_percent"]
    info["impact_probability_percent"] = ctx["impact_probability_percent"]
    info["hail_confidence_percent"] = ctx["hail_confidence_percent"]
    info["hail_probability_percent"] = ctx["hail_probability_percent"]
    info["hail_evidence_score_percent"] = ctx["hail_evidence_score_percent"]
    info["hail_probability_calibrated"] = ctx["hail_probability_calibrated"]
    info["hail_calibration_baseline_percent"] = ctx["hail_calibration_baseline_percent"]
    info["hail_data_quality_percent"] = ctx["hail_data_quality_percent"]
    info["severe_hail_potential_percent"] = ctx["severe_hail_potential_percent"]
    info["hail_persistence_frames"] = ctx["hail_persistence_frames"]
    info["cappi_vertical"] = ctx.get("cappi_vertical", {})
    info["hail_shadow"] = ctx.get("hail_shadow", {})
    info["near_target_override"] = ctx.get("near_target_override", {})
    info["temporal_bundle"] = ctx.get("temporal_bundle", info.get("temporal_bundle", {}))
    info["target_data_quality"] = ctx.get("target_data_quality", info.get("target_data_quality", {}))
    info["hail_feedback_calibration"] = ctx.get("hail_feedback_calibration", {})
    if isinstance(info["near_target_override"], dict) and info["near_target_override"].get("active"):
        info["mode"] = "observed_precipitation" if info["near_target_override"].get("observed_on_target") else "near_target_observed"
        info["eta_minutes"] = 0.0 if info["near_target_override"].get("observed_on_target") else min(5.0, float(info.get("eta_minutes", 5.0) or 5.0))
        info["eta_low_minutes"] = 0.0
        info["eta_high_minutes"] = min(8.0, float(info.get("eta_high_minutes", 8.0) or 8.0))
    return info


def build_alert_message(target: Target, cell: Cell, eta_info: dict[str, float], cfg: dict[str, Any]) -> str:
    eta = float(eta_info["eta_minutes"])
    eta_txt = eta_text_for_people(eta_info)
    if eta_txt == "adesso / imminente":
        eta_txt = "adesso"
    intensity = classify_vmi_intensity(cell.max_vmi)
    hail = classify_hail(cell, cfg, eta_info)
    related_targets = [str(value) for value in (eta_info.get("related_targets") or []) if str(value) != target.name][:4]
    target_label = target.name if not related_targets else f"{target.name} e {', '.join(related_targets)}"
    target_name = safe_message_text(target_label, 140)
    poh_txt = "n/d" if cell.max_poh is None else f"{cell.max_poh:.0f}%"
    speed = float(eta_info.get("speed_kmh", 0.0) or 0.0)
    probability = eta_info.get("impact_probability_percent")
    impact_calibrated = bool(eta_info.get("calibrated"))
    prob_txt = "non disponibile" if probability is None else (
        f"{float(probability):.0f}%" if impact_calibrated else f"{float(probability):.0f} su 100"
    )
    prob_label = probability_label(float(probability)) if probability is not None else "non disponibile"
    direction = safe_message_text(eta_info.get("direction_cardinal", "N/D"), 16)
    direction_names = {
        "N": "nord", "NE": "nord-est", "E": "est", "SE": "sud-est",
        "S": "sud", "SW": "sud-ovest", "W": "ovest", "NW": "nord-ovest",
    }
    direction_txt = direction_names.get(direction.upper(), direction.lower())
    if speed > 0:
        pace = "rapidamente" if speed >= 60 else "a velocità moderata" if speed >= 25 else "lentamente"
        destination = f" verso {direction_txt}" if direction != "N/D" else ""
        movement_txt = f"si sposta {pace}{destination}, a circa {speed:.0f} km/h"
    elif direction != "N/D":
        movement_txt = f"si sposta verso {direction_txt}; velocità non ancora definita"
    else:
        movement_txt = "direzione e velocità non sono ancora definite"

    lightning_detail = ""
    if eta_info.get("lightning_source") == "radar_dpc_lgt":
        l_count = int(eta_info.get("lightning_count", 0) or 0)
        l_radius = float(eta_info.get("lightning_radius_km", 20.0) or 20.0)
        l_nearest = eta_info.get("lightning_nearest_km")
        if l_count > 0:
            nearest_txt = "n/d" if l_nearest is None else f"{float(l_nearest):.1f} km"
            lightning_detail = f"⚡ Fulmini: <b>{l_count} entro {l_radius:.0f} km</b> · più vicino a {nearest_txt}\n"
    cappi_detail = ""
    cappi_vertical = eta_info.get("cappi_vertical")
    if isinstance(cappi_vertical, dict) and cappi_vertical.get("available"):
        cappi_label = safe_message_text(cappi_vertical.get("label", "profilo verticale disponibile"), 70)
        cappi_explanation = safe_message_text(cappi_vertical.get("detail", ""), 100)
        cappi_detail = (
            f"☁️ Profilo verticale radar: <b>{cappi_label}</b>"
            f"{' · ' + cappi_explanation if cappi_explanation else ''}\n"
        )

    near_context = eta_info.get("near_target_override") if isinstance(eta_info.get("near_target_override"), dict) else {}
    near_detail = ""
    if near_context.get("active"):
        edge = float(near_context.get("edge_distance_km", 0.0) or 0.0)
        near_detail = (
            "📍 Distanza radar: <b>sulla zona</b>\n"
            if near_context.get("observed_on_target")
            else f"📏 Distanza radar: <b>{edge:.1f} km</b>\n"
        )
    data_bundle = eta_info.get("temporal_bundle") if isinstance(eta_info.get("temporal_bundle"), dict) else {}
    target_quality = eta_info.get("target_data_quality") if isinstance(eta_info.get("target_data_quality"), dict) else {}
    bundle_status = str(data_bundle.get("status", "aligned"))
    bundle_detail = ""
    quality_score = target_quality.get("score_percent", data_bundle.get("quality_percent"))
    coverage_status = str(target_quality.get("coverage_status", "unknown"))
    if bundle_status != "aligned" or coverage_status not in {"nominal", "unknown"}:
        issues = data_bundle.get("issues") if isinstance(data_bundle.get("issues"), list) else []
        quality_text = "n/d" if quality_score is None else f"{float(quality_score):.0f}/100"
        bundle_detail = f"⚠️ Qualità dati: <b>{quality_text} · {safe_message_text(bundle_status, 20)} · copertura {safe_message_text(coverage_status, 20)}</b>{' · ' + safe_message_text('; '.join(str(item) for item in issues[:2]), 120) if issues else ''}\n"

    status = "GIÀ SULLA ZONA" if near_context.get("observed_on_target") else "MOLTO VICINO" if near_context.get("active") else "IN CORSO" if eta < 1 else "IN ARRIVO"
    hail_human = hail_plain_label(hail)
    if near_context.get("hail_watch") and str(hail.get("level", "LOW")).upper() == "LOW":
        hail_human = "possibile: segnali da verificare"
    elif hail.get("tag") == "none":
        hail_human = "nessun segnale significativo"
    elif hail.get("tag") == "low":
        hail_human = "segnale debole"
    hail_score_txt = str(hail.get("score", "n/d"))
    hail_persistence = int(hail.get("persistence", "0") or 0)
    if hail_persistence >= 2:
        hail_evidence = f"segnale presente in {hail_persistence} scansioni consecutive"
    elif hail_persistence == 1:
        hail_evidence = "segnale debole visto in una sola scansione"
    else:
        hail_evidence = "nessun segnale persistente"
    advice = safe_message_text(practical_alert_advice(cell, eta_info, hail), 260)
    observed_at = ms_to_dt(int(cell.timestamp_ms)).astimezone().strftime("%H:%M")
    processed_at = utc_now().astimezone().strftime("%H:%M")
    age_minutes = float(eta_info.get("data_age_minutes", 0.0) or 0.0)
    age_text = f" · dato di {age_minutes:.0f} min fa" if age_minutes >= 1 else ""
    evolution = safe_message_text(forecast_evolution_text(eta_info), 150)
    hail_detail = ""
    if hail.get("tag") in {"high", "medium"} or near_context.get("hail_watch"):
        hail_detail = f"🧊 Grandine radar: <b>{safe_message_text(hail_score_txt, 24)} · POH {poh_txt}</b> · {hail_evidence}\n"
    vertical_detail = cappi_detail if hail_detail else ""
    rain_observation = f"intensità radar {cell.max_vmi:.1f} dBZ"
    if cell.max_sri is not None:
        rain_observation += f" · pioggia stimata {cell.max_sri:.1f} mm/h"
    distance_detail = near_detail
    if not distance_detail and getattr(cell, "nearest_distance_km", None) is not None:
        distance_detail = f"📍 Distanza: <b>il temporale è a {float(cell.nearest_distance_km):.1f} km</b>\n"
    main = (
        f"{intensity['emoji']} <b>{safe_message_text(intensity['title'].upper(), 70)} {status}</b>\n\n"
        f"📍 <b>{target_name}</b>\n"
        f"⏱ Arrivo: <b>{safe_message_text(eta_txt, 60)}</b>\n"
        f"🎯 Possibilità stimata: <b>{prob_txt} · {safe_message_text(prob_label, 20)}</b>\n"
        f"🌧️ Fenomeno atteso: <b>pioggia {safe_message_text(intensity['level'].lower(), 30)}</b>\n"
        f"🧊 Grandine: <b>{safe_message_text(hail_human, 48)}</b>\n\n"
        f"🛡️ <b>Cosa fare</b>\n{advice}\n\n"
    )
    details = (
        f"📡 <b>Cosa vede il radar</b>\n"
        f"🌧️ Pioggia: <b>{safe_message_text(intensity['level'].lower(), 30)}</b>\n"
        f"{distance_detail}"
        f"{lightning_detail}"
        f"{hail_detail}"
        f"{vertical_detail}"
        f"{bundle_detail}"
        f"💨 Movimento: <b>{movement_txt}</b>\n"
        f"📈 Evoluzione: <b>{evolution}</b>\n"
        f"<i>{rain_observation}</i>\n\n"
    )
    footer = (
        f"<i>Radar {observed_at} · elaborato {processed_at}{age_text} · "
        f"Protezione Civile. Stima automatica, non allerta ufficiale.</i>"
    )
    msg = main + details + footer
    if len(msg) > 1000:
        compact_details = (
            f"📡 <b>Cosa vede il radar</b>\n"
            f"🌧️ Pioggia: <b>{safe_message_text(intensity['level'].lower(), 30)}</b>\n"
            f"{distance_detail}"
            f"{lightning_detail}"
            f"{hail_detail}"
            f"💨 Movimento: <b>{movement_txt}</b>\n"
            f"📈 Evoluzione: <b>{evolution}</b>\n"
            f"<i>{rain_observation}</i>\n\n"
        )
        msg = main + compact_details + footer
    return msg


def build_clear_message(target: Target, previous: dict[str, Any], cfg: dict[str, Any], context: Optional[dict[str, Any]] = None) -> str:
    prev_prob = previous.get("notified_probability_percent", previous.get("last_probability_percent"))
    prev_calibrated = bool(previous.get("notified_probability_calibrated", previous.get("last_probability_calibrated", False)))
    prev_prob_txt = "non disponibile" if prev_prob is None else (
        f"{float(prev_prob):.0f}%" if prev_calibrated else f"{float(prev_prob):.0f} su 100"
    )
    prev_eta = previous.get("notified_eta_minutes", previous.get("last_eta_minutes"))
    prev_eta_txt = "n/d" if prev_eta is None else ("imminente" if float(prev_eta) < 1 else f"{float(prev_eta):.0f} min")
    ever_core = bool(previous.get("ever_observed_core", False))
    ever_fringe = bool(previous.get("ever_fringe_inside", False))
    if ever_core:
        icon, title = "✅", "FENOMENO TRANSITATO"
        summary = "Il nucleo è stato rilevato sulla zona e ora si sta allontanando."
        outcome = "passaggio confermato dal radar"
    elif ever_fringe:
        icon, title = "🟢", "PASSAGGIO MARGINALE CONCLUSO"
        summary = "La parte periferica della precipitazione ha interessato la zona; il nucleo principale non è transitato sul target."
        outcome = "passaggio marginale, più debole del nucleo monitorato"
    elif context and context.get("probability") is not None:
        icon, title = "↘️", "TRAIETTORIA DEVIATA"
        summary = "La cella è ancora visibile, ma le nuove scansioni indicano che non raggiungerà la zona."
        outcome = "il temporale ha cambiato traiettoria o si è indebolito"
    else:
        icon, title = "ℹ️", "PREVISIONE NON CONFERMATA"
        summary = "Le scansioni successive non hanno rilevato il passaggio del nucleo sulla zona."
        outcome = "il temporale previsto non è stato osservato sulla zona"

    detail = "Il temporale non risulta più diretto verso la zona."
    if context:
        distance = context.get("distance_km")
        probability = context.get("probability")
        if distance is not None and probability is not None:
            detail = (
                f"Ora il temporale è a circa {float(distance):.1f} km. "
                f"La possibilità che raggiunga la zona è scesa a {float(probability):.0f} su 100."
            )
        elif distance is not None:
            detail = f"La cella più vicina è ora a circa {float(distance):.1f} km e non risulta più diretta sul target."

    return (
        f"{icon} <b>{title}</b>\n\n"
        f"📍 <b>{safe_message_text(target.name, 70)}</b>\n"
        f"{safe_message_text(summary, 260)}\n\n"
        f"📍 Situazione attuale: <b>{safe_message_text(detail, 260)}</b>\n"
        f"🎯 Possibilità iniziale: <b>{prev_prob_txt} · arrivo {prev_eta_txt}</b>\n"
        f"🌦️ Cosa è successo: <b>{safe_message_text(outcome, 220)}</b>\n\n"
        f"<i>Il monitoraggio automatico continua.</i>"
    )


def build_threat_update_message(target: Target, previous: dict[str, Any], cell: Cell, eta_info: dict[str, float], kind: str) -> str:
    old_probability = float(previous.get("last_probability_percent", 0.0) or 0.0)
    probability = float(eta_info.get("impact_probability_percent", 0.0) or 0.0)
    probability_human = probability_label(probability)
    probability_calibrated = bool(eta_info.get("calibrated")) and bool(previous.get("last_probability_calibrated"))
    probability_change = (
        f"dal {old_probability:.0f}% al {probability:.0f}%"
        if probability_calibrated
        else f"da {old_probability:.0f} a {probability:.0f} su 100"
    )
    hail_probability = eta_info.get("hail_probability_percent")
    hail_evidence = eta_info.get("hail_evidence_score_percent", eta_info.get("hail_confidence_percent"))
    hail_update = ""
    if bool(eta_info.get("hail_probability_calibrated")) and hail_probability is not None:
        hail_value = float(hail_probability)
        hail_update = f"🧊 Grandine: <b>possibilità {hail_value:.0f}%</b>\n"
    elif hail_evidence is not None:
        hail_value = float(hail_evidence)
        hail_label = "segnali forti" if hail_value >= 65 else "segnali moderati" if hail_value >= 35 else "segnali deboli"
        hail_update = f"🧊 Grandine: <b>{hail_label} · {hail_value:.0f} su 100</b>\n"
    if kind == "escalation":
        icon, title, explanation = "🔴", "RISCHIO AUMENTATO", "Il temporale è più vicino oppure la traiettoria è diventata più favorevole all'impatto."
    else:
        icon, title, explanation = "🟠", "TRAIETTORIA MENO PROBABILE", "La minaccia non è ancora rientrata, ma la probabilità che raggiunga la zona è diminuita."
    return (
        f"{icon} <b>{title}</b>\n\n"
        f"📍 <b>{safe_message_text(target.name, 70)}</b>\n"
        f"🎯 Possibilità: <b>{probability_change} · {safe_message_text(probability_human, 20)}</b>\n"
        f"⏱ Arrivo: <b>{safe_message_text(eta_text_for_people(eta_info).replace('adesso / imminente', 'adesso'), 60)}</b>\n"
        f"🌧️ Pioggia prevista: <b>{safe_message_text(classify_vmi_intensity(cell.max_vmi)['level'].lower(), 30)}</b>\n"
        f"{hail_update}"
        f"📈 Evoluzione: <b>{safe_message_text(forecast_evolution_text(eta_info), 150)}</b>\n\n"
        f"💡 <b>Cosa cambia</b>\n{explanation}\n\n"
        f"<i>Il radar continuerà a controllare automaticamente la situazione.</i>"
    )


def format_eta_range(eta_info: dict[str, Any]) -> str:
    """Return an ETA suitable for people, without ranges such as 20–20 min."""
    low = eta_info.get("eta_low_minutes")
    high = eta_info.get("eta_high_minutes")
    if low is not None and high is not None:
        low_rounded = int(round(float(low)))
        high_rounded = int(round(float(high)))
        if low_rounded == high_rounded:
            return f"{low_rounded} min"
        return f"{low_rounded}–{high_rounded} min"
    return f"{float(eta_info.get('eta_minutes', 0.0) or 0.0):.0f} min"


def build_public_radar_copy(
    best_eta: Optional[dict[str, Any]],
    cells: list[Cell],
    min_alert_probability: float,
    hail_risk_text: str,
) -> tuple[str, str, str, str]:
    """Build concise radar-panel text from the actual target forecast state."""
    if best_eta is not None:
        cell = best_eta["cell"]
        eta_info = best_eta["eta"]
        target_name = str(best_eta["target"])
        probability = float(best_eta.get("probability", 0.0) or 0.0)
        calibrated = bool(eta_info.get("calibrated"))
        impact_text = f"{probability:.0f}% calibrata" if calibrated else f"indice {probability:.0f}/100"
        eta_text = format_eta_range(eta_info)
        direction = str(best_eta.get("direction", "N/D"))
        observed_core = bool(eta_info.get("observed_core_impact", False)) or str(eta_info.get("mode", "")) == "observed_core"

        nearest_distance = getattr(cell, "nearest_distance_km", None)
        nearest_target = getattr(cell, "nearest_target", None)
        if nearest_distance is not None and nearest_target:
            distance_text = f"Il nucleo è a {float(nearest_distance):.0f} km da {nearest_target}"
        else:
            distance_text = "Il nucleo è stato localizzato dal radar"
        motion_text = f" e si muove verso {direction}, in direzione di {target_name}" if direction and direction != "N/D" else ""

        if observed_core:
            status = f"{target_name}: nucleo intenso rilevato"
            color = "#dc2626"
            meaning = "Il radar rileva il nucleo forte già dentro l'area monitorata: è un'osservazione, non una probabilità prevista."
            if hail_risk_text == "Alto":
                action = "Forte evidenza radar di grandine: riparati e proteggi l'auto se puoi farlo in sicurezza."
            else:
                action = "Fenomeno già in corso: resta al riparo e limita gli spostamenti."
        elif probability >= min_alert_probability:
            status = f"{target_name}: traiettoria compatibile ({impact_text})"
            color = "#dc2626"
            meaning = f"{distance_text}{motion_text}. Compatibilità d'impatto {impact_text}, arrivo tra circa {eta_text}."
            if hail_risk_text == "Alto":
                action = "Forte evidenza radar di grandine: valuta subito un riparo sicuro per persone e auto."
            else:
                action = "Preparati a pioggia intensa e possibili raffiche; cerca riparo se sei all'aperto."
        elif probability >= 35.0:
            status = f"{target_name}: avvicinamento da confermare ({impact_text})"
            color = "#ea580c"
            meaning = f"{distance_text}{motion_text}. Impatto possibile ma non confermato: {impact_text}, ETA indicativa {eta_text}."
            action = "Nessuna emergenza ora: attendi la prossima scansione radar."
        elif probability >= 10.0:
            status = f"{target_name}: compatibilità bassa ({impact_text})"
            color = "#d97706"
            meaning = f"{distance_text}{motion_text}. L'ensemble produce {impact_text}; il valore non è una frequenza osservata finché non è calibrato."
            action = "Nessuna azione necessaria ora; il sistema continua a monitorare."
        else:
            status = f"{target_name}: fuori traiettoria ({impact_text})"
            color = "#059669"
            meaning = f"{distance_text}{motion_text}. Compatibilità d'impatto {impact_text}: al momento non è diretto sulla zona."
            action = "Nessuna azione necessaria."
        return status, color, meaning, action

    if cells:
        nearest = min(cells, key=lambda item: float(getattr(item, "nearest_distance_km", float("inf"))))
        target_name = str(getattr(nearest, "nearest_target", "i target"))
        distance = getattr(nearest, "nearest_distance_km", None)
        distance_text = f" a {float(distance):.0f} km da {target_name}" if distance is not None else ""
        return (
            f"{target_name}: temporale fuori traiettoria",
            "#059669",
            f"È presente un nucleo intenso{distance_text}, ma nessuna traiettoria calcolata raggiunge l'area monitorata.",
            "Nessuna azione necessaria; il sistema continua a monitorare.",
        )

    return (
        "Nessun temporale intenso vicino ai target",
        "#059669",
        "Il radar non rileva nuclei temporaleschi forti nelle aree monitorate o lungo traiettorie dirette verso di esse.",
        "Nessuna azione necessaria.",
    )


def strip_html_tags(text: str) -> str:
    out = re.sub(r"<br\s*/?>", "\n", text, flags=re.I)
    out = re.sub(r"<[^>]+>", "", out)
    return html.unescape(out)


def send_webhook_notification(message: str, cfg: dict[str, Any]) -> bool:
    notifications = cfg.get("notifications", {}) if isinstance(cfg, dict) else {}
    if not notifications.get("webhook_enabled"):
        return True
    url = str(notifications.get("webhook_url", "")).strip()
    if not url:
        logging.warning("Webhook abilitato ma URL mancante")
        return False
    payload = {"source": "LDZ Meteo App", "event": "meteo_alert", "time_utc": utc_now().isoformat(), "message_html": message, "message_text": strip_html_tags(message)}
    try:
        allow_http = bool(cfg.get("network", {}).get("allow_http_webhooks", False))
        validate_outbound_url(url, cfg, https_only=not allow_http)
        r = requests.post(url, json=payload, timeout=(5, 20), allow_redirects=False)
        r.raise_for_status()
        logging.info("webhook notification sent status=%s", r.status_code)
        return True
    except Exception as exc:
        logging.error("Errore invio webhook (%s)", type(exc).__name__)
        return False


def send_email_notification(message: str, cfg: dict[str, Any]) -> bool:
    notifications = cfg.get("notifications", {}) if isinstance(cfg, dict) else {}
    if not notifications.get("email_enabled"):
        return True
    host = str(notifications.get("smtp_host", "")).strip()
    port = int(notifications.get("smtp_port", 587) or 587)
    email_to = str(notifications.get("email_to", "")).strip()
    email_from = str(notifications.get("email_from", "") or notifications.get("smtp_user", "") or "ldz-meteo@localhost").strip()
    smtp_user = str(notifications.get("smtp_user", "")).strip()
    smtp_password = str(notifications.get("smtp_password", "")).strip()
    security = str(notifications.get("smtp_security", "starttls" if notifications.get("smtp_starttls", True) else "none"))
    timeout = max(5, min(60, int(notifications.get("smtp_timeout", 25) or 25)))
    if not host or not email_to:
        logging.warning("Email abilitata ma SMTP host o destinatario mancante")
        return False
    try:
        for header_value in (str(notifications.get("email_subject", "LDZ Meteo Alert")), email_from, email_to):
            if "\r" in header_value or "\n" in header_value:
                raise MeteoAlertError("header email con newline non consentito")
        msg = EmailMessage()
        msg["Subject"] = str(notifications.get("email_subject", "LDZ Meteo Alert"))[:200]
        msg["From"] = email_from[:320]
        msg["To"] = email_to[:2000]
        msg.set_content(strip_html_tags(message))
        validate_outbound_host(host, cfg)
        context = ssl.create_default_context()
        smtp_client = smtplib.SMTP_SSL(host, port, timeout=timeout, context=context) if security == "ssl" else smtplib.SMTP(host, port, timeout=timeout)
        with smtp_client as smtp:
            if security == "starttls":
                smtp.starttls(context=context)
            if smtp_user:
                smtp.login(smtp_user, smtp_password)
            smtp.send_message(msg)
        logging.info("email notification sent to=%s", email_to)
        return True
    except Exception as exc:
        logging.error("Errore invio email (%s)", type(exc).__name__)
        return False


def send_extra_notifications(message: str, cfg: dict[str, Any]) -> None:
    send_webhook_notification(message, cfg)
    send_email_notification(message, cfg)


def send_telegram(
    message: str,
    dry_run: bool,
    *,
    reply_markup: Optional[dict[str, Any]] = None,
    force_text: bool = False,
) -> bool:
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip().strip('"')
    chat_id = os.environ.get("TELEGRAM_CHAT_ID", "").strip().strip('"')
    if dry_run:
        logging.info("DRY-RUN telegram message:\n%s", message)
        return True
    if not token or not chat_id:
        logging.error("Telegram non configurato: mancano TELEGRAM_BOT_TOKEN o TELEGRAM_CHAT_ID")
        return False

    tg_cfg = {}
    # Se cfg non e' disponibile in firma, leggiamo path standard solo per sapere se inviare foto.
    # In caso di errore, fallback a solo testo.
    try:
        default_cfg_path = Path("/etc/meteo-alert/config.yml")
        if default_cfg_path.exists():
            tg_cfg = yaml.safe_load(default_cfg_path.read_text(encoding="utf-8")) or {}
    except Exception:
        tg_cfg = {}

    pub = tg_cfg.get("public_image", {}) if isinstance(tg_cfg, dict) else {}
    send_photo = bool(tg_cfg.get("telegram", {}).get("send_photo", True)) if isinstance(tg_cfg, dict) else True
    photo_candidates = []
    publish_cfg = tg_cfg.get("publish", {}) if isinstance(tg_cfg, dict) else {}
    if publish_cfg.get("method") == "local" and publish_cfg.get("local_path"):
        photo_candidates.append(Path(publish_cfg["local_path"]))
    if pub.get("output_file"):
        photo_candidates.append(Path(pub["output_file"]))
    photo_candidates.append(Path("/var/www/html/meteo.jpg"))
    photo_candidates.append(Path("/var/www/guidovitiello.it/public_html/meteo.jpg"))

    data_dir = Path(tg_cfg.get("app", {}).get("data_dir", "/var/lib/meteo-alert")) if isinstance(tg_cfg, dict) else Path("/var/lib/meteo-alert")
    allowed_photo_roots = [(data_dir / "public").resolve(), Path("/var/www/html").resolve()]
    configured_photo_paths: set[Path] = set()
    for configured in (publish_cfg.get("local_path"), pub.get("output_file")):
        if configured and Path(str(configured)).name == "meteo.jpg":
            configured_photo_paths.add(Path(str(configured)).resolve())

    def allowed_photo(path: Path) -> bool:
        try:
            resolved = path.resolve(strict=True)
            inside = any(os.path.commonpath([str(root), str(resolved)]) == str(root) for root in allowed_photo_roots)
            return (inside or resolved in configured_photo_paths) and not path.is_symlink() and path.suffix.lower() in {".jpg", ".jpeg", ".png"} and path.stat().st_size <= 20 * 1024 * 1024
        except (OSError, ValueError):
            return False

    photo_path = next((p for p in photo_candidates if allowed_photo(p)), None)

    try:
        if send_photo and photo_path and not force_text:
            url = f"https://api.telegram.org/bot{token}/sendPhoto"
            with photo_path.open("rb") as photo:
                files = {"photo": photo}
                data = {
                    "chat_id": chat_id,
                    "caption": message,
                    "parse_mode": "HTML",
                    "protect_content": "false",
                }
                if reply_markup:
                    data["reply_markup"] = json.dumps(reply_markup, ensure_ascii=False, separators=(",", ":"))
                r = requests.post(url, data=data, files=files, timeout=(5, 40), allow_redirects=False)
        else:
            url = f"https://api.telegram.org/bot{token}/sendMessage"
            payload = {
                "chat_id": chat_id,
                "text": message,
                "parse_mode": "HTML",
                "disable_web_page_preview": True,
                "protect_content": False,
            }
            if reply_markup:
                payload["reply_markup"] = reply_markup
            r = requests.post(url, json=payload, timeout=(5, 20), allow_redirects=False)
        r.raise_for_status()
        data = r.json()
        if not data.get("ok"):
            logging.error("Telegram error: %s", data)
            return False
        send_extra_notifications(message, tg_cfg if isinstance(tg_cfg, dict) else {})
        return True
    except Exception as exc:
        logging.error("Errore invio Telegram (%s)", type(exc).__name__)
        return False


def poll_telegram_feedback(state: dict[str, Any], cfg: dict[str, Any], dry_run: bool) -> list[dict[str, Any]]:
    """Importa la coda durabile scritta dal listener Telegram dedicato.

    Il listener è l'unico consumer di getUpdates: in questo modo il callback
    viene confermato subito e non aspetta il ciclo radar periodico.
    """
    fcfg = cfg.get("event_feedback", {})
    if dry_run or not bool(fcfg.get("enabled", True)):
        return []
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip().strip('"')
    chat_id = os.environ.get("TELEGRAM_CHAT_ID", "").strip().strip('"')
    if not token or not chat_id:
        return []
    try:
        accepted = drain_feedback_inbox(state, cfg, token, chat_id)
        if accepted:
            logging.info("feedback Telegram elaborati=%d", sum(1 for item in accepted if item.get("ok")))
        return accepted
    except Exception as exc:
        telegram_state = state.setdefault("telegram_feedback", {})
        telegram_state["last_error"] = type(exc).__name__
        telegram_state["last_error_utc"] = utc_now().isoformat()
        logging.warning("coda feedback Telegram non disponibile (%s)", type(exc).__name__)
        return []


def send_due_feedback_prompts(state: dict[str, Any], cfg: dict[str, Any], dry_run: bool) -> int:
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip().strip('"')
    chat_id = os.environ.get("TELEGRAM_CHAT_ID", "").strip().strip('"')
    if not token or not bool(cfg.get("event_feedback", {}).get("enabled", True)):
        return 0
    signing = load_feedback_secrets()
    if not signing.get("current"):
        logging.error("feedback Telegram disabilitato: segreto di firma dedicato assente")
        return 0
    sent = 0
    for event in pending_feedback_prompts(state):
        message_id = send_bound_feedback_prompt(event, str(signing["current"]), token, chat_id, dry_run)
        if message_id is not None:
            mark_prompt_sent(event, message_id=message_id)
            sent += 1
    return sent


def send_bound_feedback_prompt(event: dict[str, Any], secret: str, token: str, chat_id: str, dry_run: bool) -> int | None:
    """Invia e poi lega i pulsanti all'id Telegram realmente assegnato."""
    message, provisional_markup = build_feedback_prompt(event, secret, chat_id, message_id=0)
    if dry_run:
        logging.info("DRY-RUN feedback Telegram event=%s", event.get("event_id"))
        return 0
    payload = {
        "chat_id": chat_id, "text": message, "parse_mode": "HTML",
        "disable_web_page_preview": True, "protect_content": False,
        "reply_markup": provisional_markup,
    }
    try:
        response = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage", json=payload,
            timeout=(5, 20), allow_redirects=False,
        )
        response.raise_for_status(); body = response.json()
        message_id = int((body.get("result") or {}).get("message_id", 0) or 0)
        if not body.get("ok") or message_id <= 0:
            return None
        _, bound_markup = build_feedback_prompt(event, secret, chat_id, message_id=message_id)
        edit = requests.post(
            f"https://api.telegram.org/bot{token}/editMessageReplyMarkup",
            json={"chat_id": chat_id, "message_id": message_id, "reply_markup": bound_markup},
            timeout=(5, 20), allow_redirects=False,
        )
        edit.raise_for_status(); edited = edit.json()
        if not edited.get("ok"):
            logging.error("pulsanti feedback non legati al message_id event=%s", event.get("event_id"))
            return None
        return message_id
    except Exception as exc:
        logging.error("invio feedback Telegram fallito (%s)", type(exc).__name__)
        return None



def is_in_quiet_hours(cfg: dict[str, Any]) -> bool:
    qh = cfg.get("quiet_hours", {}) if isinstance(cfg, dict) else {}
    if not bool(qh.get("enabled", False)):
        return False
    start = str(qh.get("start", "00:00"))
    end = str(qh.get("end", "07:00"))
    def to_min(value: str) -> int:
        try:
            h, m = value.split(":", 1)
            return int(h) * 60 + int(m)
        except Exception:
            return 0
    now = datetime.now().hour * 60 + datetime.now().minute
    s_min = to_min(start)
    e_min = to_min(end)
    if s_min <= e_min:
        return s_min <= now <= e_min
    return now >= s_min or now <= e_min


def should_suppress_for_quiet_hours(cell: Cell, cfg: dict[str, Any]) -> bool:
    if not is_in_quiet_hours(cfg):
        return False
    qh = cfg.get("quiet_hours", {}) if isinstance(cfg, dict) else {}
    mode = str(qh.get("mode", "critical_only"))
    if mode == "mute_all":
        return True
    hail = classify_hail(cell, cfg)
    hail_line = str(hail.get("line", "")).lower()
    hail_threshold = float(cfg.get("thresholds", {}).get("vmi_hail_dbz", 55))
    if cell.max_vmi >= hail_threshold or cell.risk == "HIGH" or "alto" in hail_line or "probabile" in hail_line:
        return False
    return True


def cooldown_ok_bucket(state: dict[str, Any], bucket_name: str, key: str, minutes: float) -> bool:
    bucket = state.setdefault(bucket_name, {})
    last_ms = bucket.get(key)
    if not last_ms:
        return True
    return utc_now() - ms_to_dt(int(last_ms)) >= timedelta(minutes=minutes)


def mark_bucket_sent(state: dict[str, Any], bucket_name: str, key: str) -> None:
    state.setdefault(bucket_name, {})[key] = int(utc_now().timestamp() * 1000)


def remember_active_threat(
    state: dict[str, Any],
    target: Target,
    cell: Cell,
    eta_info: dict[str, float],
    mode: str,
    *,
    notified: bool = False,
) -> None:
    threats = state.setdefault("target_threats", {})
    previous = threats.get(target.name, {}) if isinstance(threats.get(target.name), dict) else {}
    observed_core = mode == "observed_core" or bool(eta_info.get("observed_core_impact", False))
    fringe_inside = mode in {"fringe_inside", "inside"} or bool(eta_info.get("fringe_inside", False))
    record = {
        "active": True,
        "target": target.name,
        "last_seen_ms": int(utc_now().timestamp() * 1000),
        "last_cell_id": cell.cell_id,
        "last_probability_percent": float(eta_info.get("impact_probability_percent", 100.0)),
        "last_probability_calibrated": bool(eta_info.get("calibrated")),
        "last_eta_minutes": float(eta_info.get("eta_minutes", 0.0)),
        "last_distance_km": float(eta_info.get("distance_now_km", haversine_km(cell.lat, cell.lon, target.lat, target.lon))),
        "last_vmi": float(cell.max_vmi),
        "last_sri": None if cell.max_sri is None else float(cell.max_sri),
        "last_risk": cell.risk,
        "last_hail_confidence_percent": float(eta_info.get("hail_confidence_percent", 0.0) or 0.0),
        "last_hail_data_quality_percent": float(eta_info.get("hail_data_quality_percent", 0.0) or 0.0),
        "last_hail_persistence_frames": int(eta_info.get("hail_persistence_frames", 0) or 0),
        "last_severe_hail_potential_percent": float(eta_info.get("severe_hail_potential_percent", 0.0) or 0.0),
        "last_confidence_percent": float(eta_info.get("impact_confidence_percent", 0.0) or 0.0),
        "track_id": eta_info.get("track_id", cell.track_id),
        "track_frames": int(eta_info.get("track_frames", cell.track_frames) or 1),
        "model": eta_info.get("model", "legacy-trajectory"),
        "mode": mode,
        "group_owner": str(eta_info.get("group_owner", target.name)),
        "related_targets": list(eta_info.get("related_targets") or []),
        "ever_observed_core": bool(previous.get("ever_observed_core", False) or observed_core),
        "ever_fringe_inside": bool(previous.get("ever_fringe_inside", False) or fringe_inside),
        "updated_utc": utc_now().isoformat(),
    }
    for key in ("notified_probability_percent", "notified_probability_calibrated", "notified_eta_minutes", "notified_at_ms"):
        if key in previous:
            record[key] = previous[key]
    if notified or "notified_at_ms" not in record:
        record["notified_probability_percent"] = float(eta_info.get("impact_probability_percent", 100.0))
        record["notified_probability_calibrated"] = bool(eta_info.get("calibrated"))
        record["notified_eta_minutes"] = float(eta_info.get("eta_minutes", 0.0))
        record["notified_at_ms"] = int(utc_now().timestamp() * 1000)
    threats[target.name] = record


def mark_threat_cleared(state: dict[str, Any], target_name: str) -> None:
    threat = state.setdefault("target_threats", {}).setdefault(target_name, {})
    threat["active"] = False
    threat["cleared_utc"] = utc_now().isoformat()


def update_candidate_counter(state: dict[str, Any], target_name: str, has_threat: bool, cfg: dict[str, Any], probability: Optional[float] = None, frame_ms: Optional[int] = None) -> int:
    candidates = state.setdefault("target_candidates", {})
    now_ms = int(utc_now().timestamp() * 1000)
    rec = candidates.setdefault(target_name, {})
    if not has_threat:
        rec.update({"consecutive_hits": 0, "last_seen_ms": now_ms, "last_probability_percent": probability})
        return 0

    if frame_ms is not None and int(rec.get("last_frame_ms", 0) or 0) == int(frame_ms):
        rec["last_probability_percent"] = probability
        return int(rec.get("consecutive_hits", 0) or 0)

    max_gap_min = float(cfg["tracking"].get("max_gap_minutes", 18))
    last_seen = int(rec.get("last_seen_ms", 0) or 0)
    if last_seen and (now_ms - last_seen) <= max_gap_min * 2 * 60000:
        count = int(rec.get("consecutive_hits", 0) or 0) + 1
    else:
        count = 1
    rec.update({"consecutive_hits": count, "last_seen_ms": now_ms, "last_frame_ms": frame_ms, "last_probability_percent": probability})
    return count


def update_clear_counter(state: dict[str, Any], target_name: str, is_clear: bool, frame_ms: Optional[int] = None) -> int:
    counters = state.setdefault("target_clear_candidates", {})
    rec = counters.setdefault(target_name, {})
    if not is_clear:
        rec.update({"consecutive_misses": 0, "last_frame_ms": frame_ms})
        return 0
    if frame_ms is not None and int(rec.get("last_frame_ms", 0) or 0) == int(frame_ms):
        return int(rec.get("consecutive_misses", 0) or 0)
    misses = int(rec.get("consecutive_misses", 0) or 0) + 1
    rec.update({"consecutive_misses": misses, "last_frame_ms": frame_ms})
    return misses


def required_alert_confirmations(eta_info: dict[str, Any], mode: str, base_required: int) -> int:
    """Richiede un frame aggiuntivo quando dati o associazione sono degradati."""
    observed_core = mode == "observed_core" and bool(eta_info.get("observed_core_impact", False))
    near_context = eta_info.get("near_target_override") if isinstance(eta_info.get("near_target_override"), dict) else {}
    if observed_core or near_context.get("active"):
        return 1
    required = max(1, int(base_required))
    target_quality = eta_info.get("target_data_quality") if isinstance(eta_info.get("target_data_quality"), dict) else {}
    score = target_quality.get("score_percent")
    degraded_data = score is not None and float(score) < 55.0
    unstable_topology = str(eta_info.get("topology_event", "") or "") in {"split", "merge"}
    return min(4, required + (1 if degraded_data or unstable_topology else 0))


def evaluate_alerts(cells: list[Cell], state: dict[str, Any], targets: list[Target], cfg: dict[str, Any], dry_run: bool, lightning_context: Optional[dict[str, dict[str, Any]]] = None, lightning_meta: Optional[dict[str, Any]] = None, precision_forecasts: Optional[dict[str, dict[str, Any]]] = None, frame_timestamp_ms: Optional[int] = None) -> list[dict[str, Any]]:
    """Valuta alert e rientri con logica probabilistica.

    Logica 2.2.3:
    - una cella forte viene trasformata in minaccia solo se la traiettoria ha una
      probabilita' stimata sufficiente di impattare il target;
    - per gli avvicinamenti non imminenti richiede due conferme consecutive, così
      una deviazione dell'ultimo minuto riduce i falsi positivi;
    - se una minaccia gia' notificata non e' piu' confermata, invia un update di
      temporale in allontanamento / minaccia rientrata.
    """
    prev_cells = state.get("last_cells") or []
    tr = cfg["tracking"]
    prealert = float(tr.get("prealert_minutes", 20))
    strong_vmi = float(tr.get("strong_alert_vmi_dbz", cfg["thresholds"].get("vmi_strong_dbz", 45)))
    min_probability = float(tr.get("min_alert_probability_percent", 60))
    clear_probability = float(tr.get("clear_probability_percent", 35))
    required_hits = max(1, int(tr.get("require_consecutive_hits", 2)))
    clear_misses_needed = max(2, int(tr.get("clear_consecutive_misses", 2)))
    clear_cooldown = float(tr.get("clear_cooldown_minutes", 30))
    threat_memory = float(tr.get("threat_memory_minutes", 120))

    sent: list[dict[str, Any]] = []
    notified_group_tracks: dict[str, str] = {}
    current_threats: dict[str, dict[str, Any]] = {}
    clear_context: dict[str, dict[str, Any]] = {}
    lightning_context = lightning_context or {}
    lightning_meta = lightning_meta or {}
    precision_forecasts = precision_forecasts or {}
    lightning_cfg = cfg.get("lightning", {}) if isinstance(cfg, dict) else {}
    lightning_source = str(lightning_cfg.get("source", ""))
    lightning_gate_active = (
        bool(lightning_cfg.get("enabled", False))
        and lightning_source in {"radar_dpc_lgt", "dpc_lgt", "radar_dpc"}
        and bool(lightning_cfg.get("notify_on_lightning_plus_radar", False))
        and bool(lightning_meta.get("available", False))
        and bool(lightning_meta.get("fresh", True))
    )

    def register_threat(target: Target, cell: Cell, eta_info: dict[str, float], mode: str) -> None:
        lt_ctx = lightning_context.get(target.name) or {}
        eta_info = apply_multisignal_context(target, cell, eta_info, cfg, lt_ctx=lt_ctx, lightning_meta=lightning_meta, state=state)
        eta_info = adjust_eta_for_data_age(eta_info, cell.timestamp_ms, cfg)
        near_context = eta_info.get("near_target_override") if isinstance(eta_info.get("near_target_override"), dict) else {}
        observed_now = (
            (mode == "observed_core" and bool(eta_info.get("observed_core_impact", False)))
            or bool(near_context.get("active"))
        )
        if eta_info.get("eta_window_expired") and not observed_now:
            logging.info(
                "expired forecast suppressed target=%s radar_eta=%.1f-%.1fmin data_age=%.1fmin",
                target.name,
                float(eta_info.get("radar_eta_low_minutes", eta_info.get("eta_minutes", 0.0)) or 0.0),
                float(eta_info.get("radar_eta_high_minutes", eta_info.get("eta_minutes", 0.0)) or 0.0),
                float(eta_info.get("data_age_minutes", 0.0) or 0.0),
            )
            return
        probability = float(eta_info.get("impact_probability_percent", 100.0))
        if probability < min_probability:
            old_ctx = clear_context.get(target.name)
            ctx = {"distance_km": eta_info.get("distance_now_km", haversine_km(cell.lat, cell.lon, target.lat, target.lon)), "probability": probability}
            if old_ctx is None or float(ctx["distance_km"]) < float(old_ctx.get("distance_km", 9999)):
                clear_context[target.name] = ctx
            return
        row = {"target": target, "cell": cell, "eta": eta_info, "mode": mode, "probability": probability}
        old = current_threats.get(target.name)
        if old is None:
            current_threats[target.name] = row
            return
        old_prob = float(old.get("probability", 0.0))
        old_eta = float(old["eta"].get("eta_minutes", 9999.0))
        eta = float(eta_info.get("eta_minutes", 9999.0))
        if mode == "inside" and old.get("mode") != "inside":
            current_threats[target.name] = row
        elif probability > old_prob + 3 or (abs(probability - old_prob) <= 3 and eta < old_eta):
            current_threats[target.name] = row

    for cell in cells:
        if cell.max_vmi < strong_vmi:
            logging.info("cell=%s vmi=%.1f below strong alert threshold %.1f", cell.cell_id, cell.max_vmi, strong_vmi)
            continue

        prev = match_previous_cell(cell, prev_cells, cfg)

        for target in targets:
            precise = precision_forecasts.get(f"{cell.cell_id}|{target.name}")
            if precise is not None:
                eta = float(precise.get("eta_minutes", 999.0))
                eta_now = float(adjust_eta_for_data_age(precise, cell.timestamp_ms, cfg).get("eta_minutes", eta))
                probability = float(precise.get("impact_probability_percent", 0.0))
                mode = str(precise.get("mode", "approaching"))
                logging.info(
                    "precision track=%s cell=%s target=%s frames=%s flow=%.0f%% eta=%.1fmin window=%.1f-%.1f prob=%.0f%% conf=%.0f%% speed=%.1fkm/h direction=%s lifecycle=%s",
                    precise.get("track_id", cell.track_id), cell.cell_id, target.name,
                    precise.get("track_frames", cell.track_frames), precise.get("flow_quality_percent", 0.0),
                    eta, precise.get("eta_low_minutes", eta), precise.get("eta_high_minutes", eta),
                    probability, precise.get("impact_confidence_percent", 0.0), precise.get("speed_kmh", 0.0),
                    precise.get("direction_cardinal", "N/D"), cell.lifecycle,
                )
                if mode in {"observed_core", "fringe_inside", "inside", "near_target_observed", "observed_precipitation"} or eta_now <= prealert:
                    register_threat(target, cell, precise, mode)
                continue

            dist_now = haversine_km(cell.lat, cell.lon, target.lat, target.lon)
            footprint_margin = max(2.0, min(10.0, cell.radius_km))
            effective_radius = float(target.radius_km) + footprint_margin

            # L'eccezione al doppio frame vale solo quando il nucleo >= soglia
            # è fisicamente osservato sopra il target. Il solo alone esterno non
            # può più produrre 100% ed ETA zero al primo frame.
            core_radius = max(0.0, float(getattr(cell, "core_radius_km", 0.0) or 0.0))
            core_observed = core_radius > 0.0 and dist_now <= float(target.radius_km) + core_radius
            if core_observed:
                observed_probability = clamp(float(tr.get("observed_core_probability_percent", 97.0) or 97.0), 90.0, 99.0)
                eta_info = {
                    "eta_minutes": 0.0,
                    "speed_kmh": 0.0,
                    "closing_kmh": 0.0,
                    "distance_now_km": dist_now,
                    "distance_prev_km": dist_now,
                    "approach_delta_km": 0.0,
                    "effective_radius_km": float(target.radius_km) + core_radius,
                    "min_track_distance_km": dist_now,
                    "closest_approach_km": dist_now,
                    "trajectory_uncertainty_km": 0.0,
                    "impact_probability_percent": observed_probability,
                    "exact_intersection": 1.0,
                    "observed_core_impact": True,
                    "fringe_inside": False,
                }
                register_threat(target, cell, eta_info, "observed_core")
                continue

            if not prev:
                logging.info("cell=%s strong but no previous match yet for trajectory target=%s", cell.cell_id, target.name)
                continue

            eta_info = solve_entry_eta_minutes(cell, prev, target, cfg)
            if eta_info is None:
                continue

            eta = float(eta_info["eta_minutes"])
            eta_now = float(adjust_eta_for_data_age(eta_info, cell.timestamp_ms, cfg).get("eta_minutes", eta))
            probability = float(eta_info.get("impact_probability_percent", 0.0))
            logging.info(
                "track cell=%s target=%s eta=%.1fmin prob=%.0f%% speed=%.1fkm/h closing=%.1fkm/h dist=%.1fkm min_track=%.1fkm vmi=%.1f risk=%s",
                cell.cell_id, target.name, eta, probability, eta_info["speed_kmh"], eta_info.get("closing_kmh", 0.0),
                eta_info["distance_now_km"], eta_info.get("min_track_distance_km", 0.0), cell.max_vmi, cell.risk
            )

            if eta_now <= prealert:
                register_threat(target, cell, eta_info, "approaching")

    # Invio alert per le minacce confermate.
    for target in targets:
        threat = current_threats.get(target.name)
        if threat is None:
            update_candidate_counter(state, target.name, False, cfg, None)
            continue

        cell = threat["cell"]
        eta_info = threat["eta"]
        mode = str(threat["mode"])
        probability = float(threat.get("probability", eta_info.get("impact_probability_percent", 100.0)))
        hits = update_candidate_counter(state, target.name, True, cfg, probability, frame_ms=cell.timestamp_ms)
        confirmations_needed = required_alert_confirmations(eta_info, mode, required_hits)
        enough_confirmations = hits >= confirmations_needed

        if not enough_confirmations:
            logging.info(
                "candidate threat target=%s prob=%.0f%% hit=%s/%s eta=%.1fmin: waiting next confirmation",
                target.name, probability, hits, confirmations_needed, eta_info.get("eta_minutes", 0.0)
            )
            continue

        lt_ctx = lightning_context.get(target.name) or {}
        if lt_ctx:
            eta_info = dict(eta_info)
            eta_info["lightning_source"] = lt_ctx.get("source", "radar_dpc_lgt")
            eta_info["lightning_count"] = int(lt_ctx.get("count", 0) or 0)
            eta_info["lightning_nearest_km"] = lt_ctx.get("nearest_km")
            eta_info["lightning_radius_km"] = float(lt_ctx.get("radius_km", lightning_cfg.get("radius_km", 20)) or 20)
            eta_info["lightning_age_from_anchor_minutes"] = lightning_meta.get("age_from_anchor_minutes") if isinstance(lightning_meta, dict) else None

        if lightning_gate_active and int(lt_ctx.get("count", 0) or 0) <= 0:
            logging.info(
                "lightning gate active: alert suppressed target=%s no Radar-DPC LGT within %.0fkm",
                target.name, float(lt_ctx.get("radius_km", lightning_cfg.get("radius_km", 20)) or 20)
            )
            continue

        # Aggiornamenti significativi separati dall'alert iniziale: niente spam
        # ad ogni frame, ma l'utente viene avvisato se la cella devia davvero.
        previous_active = state.get("target_threats", {}).get(target.name, {})
        if previous_active.get("active"):
            if previous_active.get("group_owner") and str(previous_active.get("group_owner")) != target.name:
                remember_active_threat(state, target, cell, eta_info, mode)
                continue
            previous_probability = float(previous_active.get("last_probability_percent", probability) or probability)
            previous_hail = float(previous_active.get("last_hail_confidence_percent", 0.0) or 0.0)
            current_hail = float(eta_info.get("hail_confidence_percent", 0.0) or 0.0)
            update_kind = None
            if mode == "observed_core" and previous_active.get("mode") != "observed_core":
                update_kind = "escalation"
            elif probability - previous_probability >= float(tr.get("update_probability_rise_percent", 15) or 15):
                update_kind = "escalation"
            elif current_hail >= 65 > previous_hail:
                update_kind = "escalation"
            elif previous_probability - probability >= float(tr.get("update_probability_drop_percent", 20) or 20) and probability > clear_probability:
                update_kind = "downgrade"

            update_cooldown = float(tr.get("update_cooldown_minutes", 12) or 12)
            if update_kind and cooldown_ok_bucket(state, "threat_updates", target.name, update_cooldown):
                update_message = build_threat_update_message(target, previous_active, cell, eta_info, update_kind)
                if send_telegram(update_message, dry_run=dry_run):
                    logging.info("threat update sent target=%s kind=%s probability=%.0f%% previous=%.0f%%", target.name, update_kind, probability, previous_probability)
                    mark_bucket_sent(state, "threat_updates", target.name)
                    write_alert_log(cfg, target, cell, eta_info, update_message, event_type=update_kind)
                    sent.append({"target": target.name, "cell": asdict(cell), "eta": eta_info, "mode": update_kind, "probability": probability})
            remember_active_threat(state, target, cell, eta_info, mode)
            continue

        if not cooldown_ok(state, target.name, cfg):
            logging.info("cooldown active target=%s", target.name)
            continue

        if should_suppress_for_quiet_hours(cell, cfg):
            logging.info("quiet-hours active: alert suppressed target=%s vmi=%.1f risk=%s", target.name, cell.max_vmi, cell.risk)
            continue

        logging.info(
            "ALERT confirmed target=%s cell=%s mode=%s eta=%.1fmin prob=%.0f%% conf=%.0f%% hail=%.0f%% vmi=%.1f risk=%s confirmations=%s/%s",
            target.name, cell.cell_id, mode, eta_info.get("eta_minutes", 0.0), probability, float(eta_info.get("impact_confidence_percent", 0.0) or 0.0), float(eta_info.get("hail_confidence_percent", 0.0) or 0.0), cell.max_vmi, cell.risk,
            hits, confirmations_needed
        )
        track_key = str(eta_info.get("track_id", cell.track_id or cell.cell_id))
        merge_distance = max(1.0, min(80.0, float(cfg.get("event_feedback", {}).get("merge_targets_within_km", 25.0) or 25.0)))
        related_targets = []
        for other_target in targets:
            if other_target.name == target.name:
                continue
            other_threat = current_threats.get(other_target.name)
            if not other_threat:
                continue
            other_previous_hits = int(((state.get("target_candidates") or {}).get(other_target.name) or {}).get("consecutive_hits", 0) or 0)
            other_observed = str(other_threat.get("mode", "")) == "observed_core" and bool(other_threat["eta"].get("observed_core_impact", False))
            if not other_observed and other_previous_hits < max(0, required_hits - 1):
                continue
            other_track = str(other_threat["eta"].get("track_id", other_threat["cell"].track_id or other_threat["cell"].cell_id))
            if other_track == track_key and haversine_km(target.lat, target.lon, other_target.lat, other_target.lon) <= merge_distance:
                related_targets.append(other_target.name)
        eta_info = dict(eta_info)
        eta_info["related_targets"] = related_targets
        existing_group_owner = notified_group_tracks.get(track_key)
        if existing_group_owner:
            eta_info["group_owner"] = existing_group_owner
            remember_active_threat(state, target, cell, eta_info, mode, notified=True)
            sent.append({"target": target.name, "cell": asdict(cell), "eta": eta_info, "mode": "grouped", "probability": probability})
            continue
        eta_info["group_owner"] = target.name
        msg = build_alert_message(target, cell, eta_info, cfg)
        if send_telegram(msg, dry_run=dry_run):
            notified_group_tracks[track_key] = target.name
            mark_alert_sent(state, target.name)
            remember_active_threat(state, target, cell, eta_info, mode, notified=True)
            sent.append({"target": target.name, "cell": asdict(cell), "eta": eta_info, "mode": mode, "probability": probability})
            write_alert_log(cfg, target, cell, eta_info, msg, event_type="alert")

    # Invio rientro/allontanamento quando una minaccia gia' notificata non e'
    # piu' confermata dal ciclo radar corrente.
    active_threats = state.setdefault("target_threats", {})
    for target in targets:
        previous = active_threats.get(target.name)
        if not previous or not previous.get("active"):
            continue
        if target.name in current_threats:
            update_clear_counter(state, target.name, False, frame_timestamp_ms)
            continue

        last_seen_ms = int(previous.get("last_seen_ms", 0) or 0)
        if last_seen_ms and utc_now() - ms_to_dt(last_seen_ms) > timedelta(minutes=threat_memory):
            mark_threat_cleared(state, target.name)
            continue

        context = clear_context.get(target.name)
        if context and float(context.get("probability", 0.0)) > clear_probability:
            # Situazione ancora incerta: meglio non dire rientrata troppo presto.
            update_clear_counter(state, target.name, False, frame_timestamp_ms)
            logging.info("clear delayed target=%s probability still %.0f%%", target.name, float(context.get("probability", 0.0)))
            continue

        misses = update_clear_counter(state, target.name, True, frame_timestamp_ms)
        if misses < clear_misses_needed:
            logging.info(
                "clear candidate target=%s miss=%s/%s: waiting next radar frame",
                target.name, misses, clear_misses_needed,
            )
            continue

        if not cooldown_ok_bucket(state, "clear_alerts", target.name, clear_cooldown):
            logging.info("clear cooldown active target=%s", target.name)
            mark_threat_cleared(state, target.name)
            continue

        msg = build_clear_message(target, previous, cfg, context=context)
        if send_telegram(msg, dry_run=dry_run):
            mark_bucket_sent(state, "clear_alerts", target.name)
            mark_threat_cleared(state, target.name)
            update_clear_counter(state, target.name, False, frame_timestamp_ms)
            sent.append({"target": target.name, "mode": "clear", "previous": previous, "context": context})
            write_alert_log(cfg, target, Cell(
                cell_id=str(previous.get("last_cell_id", "clear")),
                timestamp_ms=int(utc_now().timestamp() * 1000),
                lat=target.lat,
                lon=target.lon,
                area_km2=0.0,
                radius_km=0.0,
                pixels=0,
                max_vmi=float(previous.get("last_vmi", 0.0) or 0.0),
                mean_vmi=0.0,
                max_sri=None,
                max_poh=None,
                max_vil=None,
                max_etm=None,
                risk=str(previous.get("last_risk", "LOW")),
                risk_reasons=[],
                nearest_target=target.name,
                nearest_distance_km=0.0,
                footprint_xy_km=[],
                pixel_bbox=[0, 0, 0, 0],
                centroid_row=0.0,
                centroid_col=0.0,
                shape_eccentricity=0.0,
                shape_orientation_deg=0.0,
            ), {"eta_minutes": 0.0, "impact_probability_percent": 0.0}, msg, event_type="clear")

    return sent


def write_alert_log(cfg: dict[str, Any], target: Target, cell: Cell, eta_info: dict[str, float], msg: str, event_type: str = "alert") -> None:
    log_dir = Path(cfg["app"]["log_dir"])
    log_dir.mkdir(parents=True, exist_ok=True)
    line = {
        "time_utc": utc_now().isoformat(),
        "event_type": event_type,
        "target": asdict(target),
        "cell": asdict(cell),
        "eta": eta_info,
        "message": msg,
    }
    with (log_dir / "alerts.log").open("a", encoding="utf-8") as f:
        f.write(json.dumps(line, ensure_ascii=False) + "\n")


def deg_radius_for_km(radius_km: float, lat: float) -> tuple[float, float]:
    """Ritorna (lon_radius_deg, lat_radius_deg) per disegnare cerchi geografici locali."""
    lat_radius = radius_km / 110.574
    lon_radius = radius_km / max(1e-6, 111.320 * math.cos(math.radians(lat)))
    return lon_radius, lat_radius


def public_image_viewport(
    targets: list[Target],
    img_cfg: dict[str, Any],
    width: int,
    height: int,
) -> tuple[float, float, float, float, float]:
    """Calcola un viewport geografico proporzionato all'area mappa del JPEG.

    Target lontani ma quasi allineati in longitudine produrrebbero un bbox molto
    alto e stretto. Matplotlib lo comprimerebbe in una striscia verticale. Qui
    allarghiamo soltanto il lato corto, mantenendo tutti i target, il centro e la
    scala geografica WebMercator. La logica degli alert non usa questi limiti.
    """
    if not targets:
        raise MeteoAlertError("nessun target disponibile per la mappa pubblica")

    def finite_config(name: str, fallback: float, minimum: float, maximum: float) -> float:
        try:
            value = float(img_cfg.get(name, fallback))
        except (TypeError, ValueError):
            value = fallback
        if not math.isfinite(value):
            value = fallback
        return max(minimum, min(maximum, value))

    common_padding = finite_config(
        "zoom_padding_deg",
        finite_config("padding_deg", 0.20, 0.02, 5.0),
        0.02,
        5.0,
    )
    pad_west = finite_config("zoom_padding_west_deg", common_padding, 0.02, 5.0)
    pad_east = finite_config("zoom_padding_east_deg", common_padding, 0.02, 5.0)
    pad_south = finite_config("zoom_padding_south_deg", common_padding, 0.02, 5.0)
    pad_north = finite_config("zoom_padding_north_deg", common_padding, 0.02, 5.0)

    lon_min = min(target.lon for target in targets) - pad_west
    lon_max = max(target.lon for target in targets) + pad_east
    lat_min = min(target.lat for target in targets) - pad_south
    lat_max = max(target.lat for target in targets) + pad_north

    center_lon = (lon_min + lon_max) / 2.0
    center_lat = (lat_min + lat_max) / 2.0
    lon_span = max(0.04, lon_max - lon_min)
    lat_span = max(0.04, lat_max - lat_min)

    # Il secondo pannello occupa il 62% della griglia; colorbar e margini
    # lasciano circa il 55,2% della larghezza e l'84,5% dell'altezza totali.
    default_screen_ratio = (max(320, width) * 0.552) / (max(320, height) * 0.845)
    screen_ratio = finite_config("map_view_screen_ratio", default_screen_ratio, 0.78, 1.65)

    # In WebMercator un grado di latitudine occupa 1/cos(lat) volte un grado di
    # longitudine. Usiamo lo stesso rapporto anche sull'asse Matplotlib.
    latitude_aspect = 1.0 / max(0.20, math.cos(math.radians(center_lat)))
    degree_ratio = screen_ratio * latitude_aspect

    if lon_span / lat_span < degree_ratio:
        lon_span = lat_span * degree_ratio
    else:
        lat_span = lon_span / degree_ratio

    return (
        center_lon - lon_span / 2.0,
        center_lat - lat_span / 2.0,
        center_lon + lon_span / 2.0,
        center_lat + lat_span / 2.0,
        latitude_aspect,
    )


def lonlat_to_tile_xy(lon: float, lat: float, zoom: int) -> tuple[float, float]:
    """Coordinate tile WebMercator frazionarie per OpenStreetMap."""
    lat = max(min(lat, 85.05112878), -85.05112878)
    n = 2 ** zoom
    x = (lon + 180.0) / 360.0 * n
    lat_rad = math.radians(lat)
    y = (1.0 - math.asinh(math.tan(lat_rad)) / math.pi) / 2.0 * n
    return x, y


def fetch_osm_tile(z: int, x: int, y: int, cache_dir: Path, user_agent: str, timeout: int = 20) -> Optional["Image.Image"]:
    """
    Scarica/cache una tile OSM. La cache locale riduce al minimo le richieste e rispetta
    l'uso corretto del servizio pubblico tile.openstreetmap.org.
    """
    from PIL import Image
    from io import BytesIO

    n = 2 ** z
    if x < 0 or y < 0 or x >= n or y >= n:
        return None

    tile_dir = cache_dir / str(z) / str(x)
    tile_dir.mkdir(parents=True, exist_ok=True)
    tile_path = tile_dir / f"{y}.png"

    min_cache_age_days = 7
    if tile_path.exists() and tile_path.stat().st_size > 0:
        age = utc_now() - datetime.fromtimestamp(tile_path.stat().st_mtime, tz=timezone.utc)
        if age < timedelta(days=min_cache_age_days):
            try:
                return Image.open(tile_path, formats=("PNG",)).convert("RGB")
            except Exception:
                logging.warning("tile cache corrotta, riscarico: %s", tile_path)

    url = f"https://tile.openstreetmap.org/{z}/{x}/{y}.png"
    headers = {"User-Agent": user_agent}
    try:
        r = requests.get(url, headers=headers, timeout=(5, timeout), allow_redirects=False)
        r.raise_for_status()
        if len(r.content) > 2 * 1024 * 1024:
            raise MeteoAlertError("tile OSM oltre il limite di 2 MiB")
        img = Image.open(BytesIO(r.content), formats=("PNG",)).convert("RGB")
        if img.size != (256, 256):
            raise MeteoAlertError(f"dimensione tile OSM inattesa: {img.size}")
        tmp = tile_path.with_suffix(".tmp")
        img.save(tmp, format="PNG")
        tmp.replace(tile_path)
        return img
    except Exception as exc:
        logging.warning("impossibile scaricare tile OSM z=%s x=%s y=%s: %s", z, x, y, exc)
        if tile_path.exists() and tile_path.stat().st_size > 0:
            try:
                return Image.open(tile_path, formats=("PNG",)).convert("RGB")
            except Exception:
                pass
        return None


def build_osm_basemap(lon_min: float, lat_min: float, lon_max: float, lat_max: float, width: int, height: int, cfg: dict[str, Any]) -> Optional[np.ndarray]:
    """Crea un basemap OSM per il bounding box richiesto. Ritorna array RGB oppure None."""
    from PIL import Image

    basemap_cfg = cfg.get("basemap", {})
    enabled = bool(basemap_cfg.get("enabled", True))
    if not enabled:
        return None

    zoom = int(basemap_cfg.get("zoom", 10))
    zoom = max(5, min(14, zoom))
    cache_dir = Path(basemap_cfg.get("cache_dir", str(Path(cfg["app"]["data_dir"]) / "osm_tiles")))
    timeout = int(basemap_cfg.get("request_timeout_seconds", 20))
    public_url = cfg.get("public_image", {}).get("public_url", "")
    user_agent = str(basemap_cfg.get("user_agent") or f"MeteoAlertGuido/1.1 (+{public_url or 'personal use'})")

    # Tile coordinate frazionarie: attenzione, y cresce andando verso sud.
    x_left, y_top = lonlat_to_tile_xy(lon_min, lat_max, zoom)
    x_right, y_bottom = lonlat_to_tile_xy(lon_max, lat_min, zoom)

    tx0 = math.floor(x_left)
    tx1 = math.floor(x_right)
    ty0 = math.floor(y_top)
    ty1 = math.floor(y_bottom)

    tile_size = 256
    mosaic_w = (tx1 - tx0 + 1) * tile_size
    mosaic_h = (ty1 - ty0 + 1) * tile_size
    if mosaic_w <= 0 or mosaic_h <= 0:
        return None

    mosaic = Image.new("RGB", (mosaic_w, mosaic_h), (238, 242, 245))
    missing = 0
    total = 0
    for tx in range(tx0, tx1 + 1):
        for ty in range(ty0, ty1 + 1):
            total += 1
            tile = fetch_osm_tile(zoom, tx, ty, cache_dir, user_agent, timeout=timeout)
            if tile is None:
                missing += 1
                continue
            mosaic.paste(tile, ((tx - tx0) * tile_size, (ty - ty0) * tile_size))

    if missing == total:
        return None

    # Crop esatto sul bbox richiesto.
    px_left = int(round((x_left - tx0) * tile_size))
    px_right = int(round((x_right - tx0) * tile_size))
    px_top = int(round((y_top - ty0) * tile_size))
    px_bottom = int(round((y_bottom - ty0) * tile_size))

    px_left = max(0, min(px_left, mosaic_w - 1))
    px_right = max(px_left + 1, min(px_right, mosaic_w))
    px_top = max(0, min(px_top, mosaic_h - 1))
    px_bottom = max(px_top + 1, min(px_bottom, mosaic_h))

    cropped = mosaic.crop((px_left, px_top, px_right, px_bottom))
    resample = getattr(Image, "Resampling", Image).BILINEAR
    resized = cropped.resize((width, height), resample)
    if missing:
        logging.warning("basemap OSM incompleta: tile mancanti %s/%s", missing, total)
    return np.asarray(resized)




def lightning_bolt_marker() -> MplPath:
    """Fulmine vettoriale pieno, leggibile su radar chiaro o scuro."""
    from matplotlib.path import Path as MplPath
    vertices = np.asarray([
        (-0.10, 1.00), (0.48, 1.00), (0.12, 0.25), (0.58, 0.25),
        (-0.42, -1.00), (-0.10, -0.18), (-0.55, -0.18), (-0.10, 1.00),
    ], dtype="float64")
    codes = [MplPath.MOVETO] + [MplPath.LINETO] * 6 + [MplPath.CLOSEPOLY]
    return MplPath(vertices, codes)


def generate_public_image(ref: dict[str, Any], radar_data: Any, cells: list[Cell], targets: list[Target], cfg: dict[str, Any], state: Optional[dict[str, Any]] = None, lightning_strikes: Optional[list[LightningStrike]] = None, precision_forecasts: Optional[dict[str, dict[str, Any]]] = None) -> Optional[Path]:
    """Genera meteo.jpg con pannello sinistro pulito.
    Cambia solo la resa grafica, non la logica degli alert.
    """
    from matplotlib.patches import Ellipse, FancyBboxPatch, Polygon

    lightning_strikes = lightning_strikes or []
    precision_forecasts = precision_forecasts or {}
    img_cfg = cfg.get("public_image", {})
    if not bool(img_cfg.get("enabled", True)):
        return None

    if isinstance(radar_data, dict):
        arrays = radar_data
        vmi = arrays.get("VMI")
    else:
        arrays = {"VMI": radar_data}
        vmi = radar_data
    if vmi is None:
        raise MeteoAlertError("VMI mancante per generazione immagine pubblica")

    width = int(img_cfg.get("width_px", 1600))
    height = int(img_cfg.get("height_px", 1000))
    lon_min, lat_min, lon_max, lat_max, map_axis_aspect = public_image_viewport(
        targets,
        img_cfg,
        width,
        height,
    )

    def reproject_to_view(src_arr: np.ndarray) -> np.ndarray:
        dst_arr = np.full((height, width), np.nan, dtype="float32")
        dst_transform_local = transform_from_bounds(lon_min, lat_min, lon_max, lat_max, width, height)
        reproject(
            source=src_arr,
            destination=dst_arr,
            src_transform=ref["transform"],
            src_crs=ref["crs"],
            src_nodata=np.nan,
            dst_transform=dst_transform_local,
            dst_crs="EPSG:4326",
            dst_nodata=np.nan,
            resampling=Resampling.nearest,
        )
        return dst_arr

    view_arrays: dict[str, np.ndarray] = {}
    for product in ("VMI", "SRI", "POH", "VIL", "ETM"):
        arr = arrays.get(product)
        if arr is None:
            continue
        try:
            view_arrays[product] = reproject_to_view(arr)
        except Exception as exc:
            logging.warning("metriche/render prodotto %s non disponibili: %s", product, exc)

    dst = view_arrays.get("VMI")
    if dst is None:
        dst = reproject_to_view(vmi)
        view_arrays["VMI"] = dst

    def safe_nanmax(arr: Optional[np.ndarray]) -> Optional[float]:
        if arr is None:
            return None
        finite_values = arr[np.isfinite(arr)]
        if finite_values.size == 0:
            return None
        return float(np.nanmax(finite_values))

    def fmt_opt(value: Optional[float], suffix: str, decimals: int = 1) -> str:
        if value is None:
            return "N/D"
        return f"{value:.{decimals}f}{suffix}"

    max_vmi_view = safe_nanmax(view_arrays.get("VMI")) or 0.0
    max_sri_view = safe_nanmax(view_arrays.get("SRI"))
    max_poh_view = safe_nanmax(view_arrays.get("POH"))
    max_vil_view = safe_nanmax(view_arrays.get("VIL"))
    max_etm_view = safe_nanmax(view_arrays.get("ETM"))
    lightning_nearest_target_km: Optional[float] = None
    if lightning_strikes and targets:
        lightning_nearest_target_km = min(
            haversine_km(target.lat, target.lon, strike.lat, strike.lon)
            for target in targets
            for strike in lightning_strikes
        )

    thresholds = cfg.get("thresholds", {})
    poh_medium = float(thresholds.get("poh_medium_percent", 40))
    poh_high = float(thresholds.get("poh_high_percent", 60))
    vmi_hail = float(thresholds.get("vmi_hail_dbz", 55))

    if max_poh_view is not None and max_poh_view >= poh_high:
        hail_risk_text, hail_color = "Alto", "#dc2626"
    elif (max_poh_view is not None and max_poh_view >= poh_medium) or max_vmi_view >= vmi_hail:
        hail_risk_text, hail_color = "Medio", "#f59e0b"
    else:
        hail_risk_text, hail_color = "Basso", "#059669"
    hail_fusion_evidence: Optional[float] = None
    hail_fusion_quality: Optional[float] = None
    if precision_forecasts and cells:
        target_map = {target.name: target for target in targets}
        cell_map = {cell.cell_id: cell for cell in cells}
        hail_rows: list[tuple[float, float]] = []
        for key, forecast in precision_forecasts.items():
            cell_id, _, target_name = key.partition("|")
            cell = cell_map.get(cell_id)
            target = target_map.get(target_name)
            if cell is None or target is None:
                continue
            context = build_multisignal_context(target, cell, forecast, cfg, state=state)
            hail_rows.append((
                float(context.get("hail_evidence_score_percent", context.get("hail_confidence_percent", 0.0)) or 0.0),
                float(context.get("hail_data_quality_percent", 0.0) or 0.0),
            ))
        if hail_rows:
            hail_fusion_evidence, hail_fusion_quality = max(hail_rows, key=lambda row: (row[0], row[1]))
            if hail_fusion_evidence >= float(cfg.get("multisignal", {}).get("hail_min_score_high", 65) or 65):
                hail_risk_text, hail_color = "Alto", "#dc2626"
            elif hail_fusion_evidence >= float(cfg.get("multisignal", {}).get("hail_min_score_medium", 35) or 35):
                hail_risk_text, hail_color = "Medio", "#f59e0b"
            else:
                hail_risk_text, hail_color = "Basso", "#059669"

    if cells:
        high_cells = [c for c in cells if c.risk == "HIGH"]
        if high_cells:
            radar_status, radar_status_color = "Cella intensa in monitoraggio", "#dc2626"
        else:
            radar_status, radar_status_color = "Cella forte rilevata", "#ea580c"
    else:
        radar_status, radar_status_color = "Nessuna cella forte rilevata", "#059669"

    best_eta: Optional[dict[str, Any]] = None
    previous_cells = (state or {}).get("last_cells") or []

    def bearing_degrees(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        phi1 = math.radians(lat1)
        phi2 = math.radians(lat2)
        dlambda = math.radians(lon2 - lon1)
        y = math.sin(dlambda) * math.cos(phi2)
        x = math.cos(phi1) * math.sin(phi2) - math.sin(phi1) * math.cos(phi2) * math.cos(dlambda)
        return (math.degrees(math.atan2(y, x)) + 360.0) % 360.0

    def compass_from_bearing(bearing: float) -> str:
        labels = ["N", "NE", "E", "SE", "S", "SO", "O", "NO"]
        return labels[int((bearing + 22.5) // 45) % 8]

    if precision_forecasts:
        cell_map = {cell.cell_id: cell for cell in cells}
        for target_name, item in best_forecasts_by_target(cells, targets, precision_forecasts).items():
            eta_info = item["forecast"]
            cell = cell_map.get(item["cell_id"])
            if cell is None:
                continue
            row = {
                "target": target_name,
                "cell": cell,
                "eta": eta_info,
                "direction": str(eta_info.get("direction_cardinal", "N/D")),
                "probability": float(eta_info.get("impact_probability_percent", 0.0)),
            }
            if best_eta is None or row["probability"] > best_eta.get("probability", 0.0) or (abs(row["probability"] - best_eta.get("probability", 0.0)) <= 3 and eta_info["eta_minutes"] < best_eta["eta"]["eta_minutes"]):
                best_eta = row
    else:
        for cell in cells:
            prev = match_previous_cell(cell, previous_cells, cfg) if previous_cells else None
            if not prev:
                continue
            direction = compass_from_bearing(bearing_degrees(float(prev["lat"]), float(prev["lon"]), cell.lat, cell.lon))
            for target in targets:
                eta_info = solve_entry_eta_minutes(cell, prev, target, cfg)
                if eta_info is None:
                    continue
                row = {"target": target.name, "cell": cell, "eta": eta_info, "direction": direction, "probability": float(eta_info.get("impact_probability_percent", 0.0))}
                if best_eta is None or row["probability"] > best_eta.get("probability", 0.0) or (abs(row["probability"] - best_eta.get("probability", 0.0)) <= 3 and eta_info["eta_minutes"] < best_eta["eta"]["eta_minutes"]):
                    best_eta = row

    min_probability_view = float(cfg.get("tracking", {}).get("min_alert_probability_percent", 60))
    if best_eta is None:
        nearest_text, direction_text, eta_text, prob_text, confidence_text, track_text = "Non significativo", "N/D", "Nessun impatto previsto", "N/D", "N/D", "in acquisizione"
    else:
        c = best_eta["cell"]
        eta_info = best_eta["eta"]
        nearest_text = f"{c.nearest_distance_km:.0f} km da {c.nearest_target}"
        direction_text = f"{best_eta['direction']} verso {best_eta['target']}"
        eta_text = f"{eta_info['eta_minutes']:.0f} min"
        prob_text = (
            f"{best_eta.get('probability', 0.0):.0f}% calibrata"
            if eta_info.get("calibrated")
            else f"indice {best_eta.get('probability', 0.0):.0f}/100"
        )
        confidence_text = f"{float(eta_info.get('impact_confidence_percent', 0.0)):.0f}/100"
        track_text = f"{int(eta_info.get('track_frames', c.track_frames or 1))} frame · {eta_info.get('growth_state', c.lifecycle)} · sopravv. indice {float(eta_info.get('survival_probability_percent', 50.0) or 50.0):.0f}/100"
        eta_text = format_eta_range(eta_info)

    radar_status, radar_status_color, plain_meaning, suggested_action = build_public_radar_copy(
        best_eta,
        cells,
        min_probability_view,
        hail_risk_text,
    )

    ts_ms = ref.get("timestamp_ms")
    if ts_ms:
        ts = dt_iso(int(ts_ms))
    elif cells:
        ts = dt_iso(int(cells[0].timestamp_ms))
    else:
        ts = utc_now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")
    next_check = (utc_now().astimezone() + timedelta(minutes=int(cfg.get("tracking", {}).get("check_interval_minutes", 5)))).strftime("%H:%M")

    prealert = cfg.get("tracking", {}).get("prealert_minutes", 20)
    radius_values = sorted({int(round(t.radius_km)) for t in targets})
    radius_text = f"{radius_values[0]} km" if len(radius_values) == 1 else ", ".join(f"{r} km" for r in radius_values)
    target_text = ", ".join(t.name for t in targets)

    basemap = build_osm_basemap(lon_min, lat_min, lon_max, lat_max, width, height, cfg)

    fig = plt.figure(figsize=(width / 100.0, height / 100.0), dpi=100)
    fig.patch.set_facecolor("#eef2f7")
    gs = fig.add_gridspec(1, 2, width_ratios=[0.38, 0.62], wspace=0.035)
    panel = fig.add_subplot(gs[0, 0])
    ax = fig.add_subplot(gs[0, 1])
    ax.set_aspect(map_axis_aspect, adjustable="box")

    panel.set_facecolor("#eef2f7")
    panel.set_xticks([])
    panel.set_yticks([])
    for spine in panel.spines.values():
        spine.set_visible(False)

    # Pannello informativo con spaziatura deterministica: ogni blocco ha una
    # propria fascia verticale, così testi e righe non possono sovrapporsi.
    panel.text(0.05, 0.975, "Meteo Alert", transform=panel.transAxes, fontsize=23, fontweight="bold", color="#0f172a", va="top")
    panel.text(0.05, 0.945, "Dashboard radar locale", transform=panel.transAxes, fontsize=10.8, color="#64748b", va="top")
    bg = FancyBboxPatch((0.035, 0.045), 0.92, 0.85, boxstyle="round,pad=0.018,rounding_size=0.030",
                        linewidth=0.9, edgecolor="#dbe4ef", facecolor="white", transform=panel.transAxes, zorder=0)
    panel.add_patch(bg)

    y = 0.855
    panel.text(0.075, y, "Situazione radar", transform=panel.transAxes, fontsize=14.5, fontweight="bold", color="#0f172a", va="top", zorder=3)
    y -= 0.055
    status_box = FancyBboxPatch((0.075, y - 0.034), 0.76, 0.055, boxstyle="round,pad=0.014,rounding_size=0.018",
                                linewidth=0, facecolor=radar_status_color, alpha=0.12, transform=panel.transAxes, zorder=2)
    panel.add_patch(status_box)
    status_fontsize = 9.8 if len(radar_status) > 48 else 11.0 if len(radar_status) > 39 else 12.0
    panel.text(0.095, y - 0.006, radar_status, transform=panel.transAxes, fontsize=status_fontsize, fontweight="bold",
               color=radar_status_color, va="center", zorder=3)
    # Significato e azione sono affiancati e limitati a una fascia dedicata.
    y = 0.710
    for box_x, title, copy, tint in (
        (0.075, "Situazione stimata", plain_meaning, "#f1f5f9"),
        (0.505, "Cosa fare", suggested_action, "#f8fafc"),
    ):
        panel.add_patch(FancyBboxPatch((box_x - 0.010, 0.590), 0.405, 0.135,
                        boxstyle="round,pad=0.010,rounding_size=0.014", linewidth=0.7,
                        edgecolor="#e2e8f0", facecolor=tint, transform=panel.transAxes, zorder=1))
        panel.text(box_x, y, title, transform=panel.transAxes,
                   fontsize=10.1, color="#0f172a", fontweight="bold", va="top", zorder=3)
        panel.text(box_x, y - 0.032, textwrap.fill(copy, width=27), transform=panel.transAxes,
                   fontsize=8.8, color="#334155", va="top", zorder=3, linespacing=1.28)
    y = 0.565
    panel.plot([0.075, 0.91], [y, y], transform=panel.transAxes, color="#e2e8f0", linewidth=1.0, zorder=3)
    y -= 0.030

    panel.text(0.075, y, "Dettagli tecnici", transform=panel.transAxes, fontsize=14.5, fontweight="bold", color="#0f172a", va="top", zorder=3)
    y -= 0.048

    row_number = 0

    def row(label: str, value: str, color: str = "#111827", vsize: float = 10.8):
        nonlocal y, row_number
        if row_number % 2 == 0:
            panel.add_patch(FancyBboxPatch((0.065, y - 0.007), 0.855, 0.028,
                            boxstyle="round,pad=0.004,rounding_size=0.006", linewidth=0,
                            facecolor="#f8fafc", transform=panel.transAxes, zorder=1))
        panel.text(0.075, y, label, transform=panel.transAxes, fontsize=10.1, color="#64748b", va="top", zorder=3)
        panel.text(0.91, y, value, transform=panel.transAxes, fontsize=vsize, color=color, fontweight="bold", va="top", ha="right", zorder=3)
        y -= 0.030
        row_number += 1

    hail_panel_value = hail_risk_text
    if hail_fusion_evidence is not None:
        hail_panel_value += f" · indice {hail_fusion_evidence:.0f}/100"
    if hail_fusion_quality is not None:
        hail_panel_value += f" · dati {hail_fusion_quality:.0f}/100"
    row("Rischio grandine", hail_panel_value, hail_color, 11.0)
    cappi_panel = "in attesa dati"
    if best_eta is not None:
        cappi_context = best_eta["eta"].get("cappi_vertical")
        if isinstance(cappi_context, dict) and cappi_context.get("available"):
            cappi_panel = str(cappi_context.get("label", "disponibile"))
            if cappi_context.get("highest_45_km") is not None:
                cappi_panel += f" · 45 dBZ fino a {float(cappi_context['highest_45_km']):.0f} km"
    row("Profilo verticale CAPPI", cappi_panel, "#7c3aed" if cappi_panel != "in attesa dati" else "#64748b", 8.8)
    row("VMI / SRI", f"{fmt_opt(max_vmi_view, ' dBZ')} · {fmt_opt(max_sri_view, ' mm/h', 1)}", vsize=9.4)
    row("POH max area", fmt_opt(max_poh_view, "%", 0))
    row("VIL max area", fmt_opt(max_vil_view, "", 1))
    row("ETM max area", fmt_opt(max_etm_view, " m", 0))
    row("Nuclei forti visti", str(len(cells)))
    lightning_panel = str(len(lightning_strikes))
    if lightning_nearest_target_km is not None:
        lightning_panel += f" · più vicino {lightning_nearest_target_km:.1f} km"
    row("Fulmini LGT recenti", lightning_panel, "#ea580c" if lightning_strikes else "#059669", 9.4)
    row("Impatto sui target", nearest_text, vsize=10.2)
    row("Direzione stimata", direction_text, vsize=10.2)
    row("ETA stimata", eta_text, vsize=10.2)
    row("Prob. / confidenza", f"{prob_text} · {confidence_text}", vsize=10.0)
    row("Tracking", track_text, vsize=9.4)
    ai_state = (((state or {}).get("precision") or {}).get("adaptive_ai") or {})
    row("Adaptive AI", f"{str(ai_state.get('status', 'collection'))} · peso {float(ai_state.get('influence', 0.0) or 0.0) * 100:.0f}%", vsize=9.2)

    y -= 0.004
    panel.plot([0.075, 0.91], [y, y], transform=panel.transAxes, color="#e2e8f0", linewidth=1.0, zorder=3)
    y -= 0.030
    panel.text(0.075, y, "Monitoraggio", transform=panel.transAxes, fontsize=12.4, fontweight="bold", color="#0f172a", va="top", zorder=3)
    y -= 0.030
    monitoring_lines = textwrap.fill(f"{target_text} · raggio {radius_text} · preavviso {prealert} min", width=54)
    panel.text(0.075, y, monitoring_lines, transform=panel.transAxes,
               fontsize=8.7, color="#111827", fontweight="bold", va="top", ha="left", linespacing=1.25, zorder=3)

    # Nota: frame/check restano nella WebGUI; qui evitiamo overflow nel pannello sinistro.
    # La scala colore è già presente nella colorbar della mappa.
    # Non la duplichiamo nel pannello sinistro per evitare sovrapposizioni
    # con il blocco Monitoraggio e il footer nei render 1920x1080.

    ax.set_facecolor("#eef3f7")
    if basemap is not None:
        ax.imshow(basemap, extent=[lon_min, lon_max, lat_min, lat_max], origin="upper", interpolation="bilinear", zorder=0)
    else:
        ax.axvspan(14.55, lon_max + 1, color="#d9eefb", alpha=0.85, zorder=0)
        logging.warning("basemap OSM non disponibile: uso fallback grafico")

    # Rendering VMI a colori discreti da 0 a 70 dBZ, step 5 dBZ.
    # La logica degli alert usa sempre i valori numerici originali del radar,
    # non i colori della mappa. Questa palette serve solo per visualizzare meglio.
    vmi_bounds = list(range(0, 75, 5))
    vmi_colors = [
        "#ffffff",  # 0-5
        "#cfffff",  # 5-10
        "#8fc8ff",  # 10-15
        "#4f92e6",  # 15-20
        "#2469ff",  # 20-25
        "#003d99",  # 25-30
        "#005b16",  # 30-35
        "#00b81f",  # 35-40
        "#78d900",  # 40-45
        "#e5e500",  # 45-50
        "#ffb000",  # 50-55
        "#ff5a00",  # 55-60
        "#d00000",  # 60-65
        "#4b0000",  # 65-70
    ]
    cmap = ListedColormap(vmi_colors, name="radar_vmi_discrete_5dbz").with_extremes(bad=(0.0, 0.0, 0.0, 0.0))
    norm = BoundaryNorm(vmi_bounds, cmap.N, clip=True)

    radar_mask = np.ma.masked_less_equal(dst, 0.0)
    im = ax.imshow(
        radar_mask,
        extent=[lon_min, lon_max, lat_min, lat_max],
        origin="upper",
        cmap=cmap,
        norm=norm,
        alpha=float(img_cfg.get("radar_alpha", 0.72)),
        interpolation="nearest",
        zorder=2,
    )

    visible_lightning = [s for s in lightning_strikes if lon_min <= s.lon <= lon_max and lat_min <= s.lat <= lat_max]
    if visible_lightning:
        # Limitiamo il numero disegnato per non sporcare la mappa durante eventi molto estesi.
        visible_lightning = visible_lightning[:250]
        latest_lgt = max(int(strike.timestamp_ms) for strike in visible_lightning)
        recent = [strike for strike in visible_lightning if int(strike.timestamp_ms) == latest_lgt]
        previous = [strike for strike in visible_lightning if int(strike.timestamp_ms) != latest_lgt]
        marker = lightning_bolt_marker()
        for group, color, alpha in ((previous, "#fb7c18", 0.72), (recent, "#ffe600", 1.0)):
            if not group:
                continue
            # Primo passaggio: alone bianco. Secondo: fulmine pieno con bordo scuro.
            ax.scatter(
                [strike.lon for strike in group], [strike.lat for strike in group],
                marker=marker, s=250, color="white", edgecolor="white", linewidths=2.2,
                alpha=0.72 * alpha, zorder=16,
            )
            ax.scatter(
                [strike.lon for strike in group], [strike.lat for strike in group],
                marker=marker, s=178, color=color, edgecolor="#111827", linewidths=1.15,
                alpha=alpha, zorder=17, label="Fulmini Radar-DPC" if group is recent else None,
            )
        ax.text(
            0.985,
            0.985,
            f"⚡ {len(visible_lightning)} fulmini recenti nella mappa",
            transform=ax.transAxes,
            fontsize=9.8,
            color="#9a3412",
            va="top",
            ha="right",
            bbox=dict(boxstyle="round,pad=0.24", facecolor="#fff7ed", edgecolor="#fb923c", alpha=0.95),
            zorder=20,
        )

    point_colors = {"Pescara": "#2563eb", "San Giovanni Teatino": "#f97316", "San Vito Chietino": "#16a34a"}
    placed_label_boxes: list[tuple[float, float, float, float]] = []

    def target_label_position(target: Target) -> tuple[float, float, str]:
        """Sceglie una label interna alla mappa e con collisioni minime."""
        lon_span = max(0.01, lon_max - lon_min)
        lat_span = max(0.01, lat_max - lat_min)
        dx = lon_span * 0.020
        dy = lat_span * 0.030
        text_width = lon_span * max(0.055, min(0.22, 0.0082 * len(target.name)))
        text_height = lat_span * 0.032
        prefer_left = target.lon > lon_min + lon_span * 0.64
        prefer_down = target.lat > lat_min + lat_span * 0.76
        horizontal = [(-dx, "right"), (dx, "left")] if prefer_left else [(dx, "left"), (-dx, "right")]
        vertical = [-dy, dy, 0.0] if prefer_down else [dy, -dy, 0.0]
        candidates = [(target.lon + off_x, target.lat + off_y, align) for off_y in vertical for off_x, align in horizontal]
        best: Optional[tuple[float, float, str, tuple[float, float, float, float], float]] = None
        for x, y_pos, align in candidates:
            if align == "left":
                box = (x, y_pos - text_height / 2, x + text_width, y_pos + text_height / 2)
            else:
                box = (x - text_width, y_pos - text_height / 2, x, y_pos + text_height / 2)
            outside = max(0.0, lon_min - box[0]) + max(0.0, box[2] - lon_max) + max(0.0, lat_min - box[1]) + max(0.0, box[3] - lat_max)
            overlaps = sum(1 for other in placed_label_boxes if box[0] < other[2] and box[2] > other[0] and box[1] < other[3] and box[3] > other[1])
            score = outside * 1000.0 + overlaps * 10.0
            if best is None or score < best[4]:
                best = (x, y_pos, align, box, score)
        assert best is not None
        placed_label_boxes.append(best[3])
        return best[0], best[1], best[2]

    for target in targets:
        color = point_colors.get(target.name, "#333333")
        rx, ry = deg_radius_for_km(target.radius_km, target.lat)
        ax.add_patch(Ellipse((target.lon, target.lat), width=2 * rx, height=2 * ry, fill=False, linewidth=2.0,
                             linestyle="--", edgecolor="#111827", alpha=0.92, zorder=5))
        label_x, label_y, label_align = target_label_position(target)
        ax.annotate(target.name, xy=(target.lon, target.lat), xytext=(label_x, label_y), textcoords="data",
                    fontsize=9.6, weight="bold", color="#111827", ha=label_align, va="center", zorder=9,
                    arrowprops=dict(arrowstyle="-", color="#334155", linewidth=0.9, alpha=0.70),
                    bbox=dict(boxstyle="round,pad=0.22", facecolor="white", edgecolor="#64748b", alpha=0.97),
                    annotation_clip=True, clip_on=True)

    for target in targets:
        color = point_colors.get(target.name, "#333333")
        ax.scatter([target.lon], [target.lat], s=118, facecolor=color, edgecolor="white", linewidth=1.8, zorder=12)
        ax.scatter([target.lon], [target.lat], s=118, facecolor="none", edgecolor="#0f172a", linewidth=0.8, zorder=13)

    for cell in cells[:10]:
        if len(cell.footprint_xy_km) >= 3:
            polygon_lonlat = []
            for east, north in cell.footprint_xy_km:
                lat_point = cell.lat + float(north) / 110.574
                lon_point = cell.lon + float(east) / max(1e-6, 111.320 * math.cos(math.radians((lat_point + cell.lat) / 2.0)))
                polygon_lonlat.append((lon_point, lat_point))
            ax.add_patch(Polygon(
                polygon_lonlat,
                closed=True,
                facecolor="#ffb000",
                edgecolor="#111827",
                linewidth=1.5,
                alpha=0.16,
                zorder=11,
            ))
        ax.scatter([cell.lon], [cell.lat], marker="x", s=145, linewidth=2.8, color="#111111", zorder=13)
        # Una cella può essere rilevata appena fuori dall'inquadratura scelta
        # per i target: la sua etichetta non deve invadere il pannello sinistro.
        if lon_min <= cell.lon <= lon_max and lat_min <= cell.lat <= lat_max:
            risk_label = {"HIGH": "Forte", "MEDIUM": "Moderata", "LOW": "Debole"}.get(cell.risk, str(cell.risk).title())
            scan_text = "1 scansione" if int(cell.track_frames or 1) == 1 else f"{int(cell.track_frames or 1)} scansioni"
            label = f"{risk_label} · {cell.max_vmi:.0f} dBZ\n{scan_text}"
            if cell.max_poh is not None:
                label += f" · grandine radar {cell.max_poh:.0f}%"
            longitude_span = max(1e-6, lon_max - lon_min)
            latitude_span = max(1e-6, lat_max - lat_min)
            place_left = cell.lon > lon_min + longitude_span * 0.68
            label_x = cell.lon - longitude_span * 0.012 if place_left else cell.lon + longitude_span * 0.012
            label_y = min(lat_max - latitude_span * 0.035, max(lat_min + latitude_span * 0.035, cell.lat - latitude_span * 0.025))
            ax.annotate(
                label,
                xy=(cell.lon, cell.lat),
                xytext=(label_x, label_y),
                textcoords="data",
                fontsize=8.8,
                weight="bold",
                color="#111111",
                ha="right" if place_left else "left",
                va="center",
                zorder=14,
                annotation_clip=True,
                clip_on=True,
                bbox=dict(boxstyle="round,pad=0.22", facecolor="#fff7d6", edgecolor="#f59e0b", alpha=0.97),
            )

    if best_eta is not None:
        path_points = best_eta["eta"].get("path_points") or []
        if len(path_points) >= 2:
            path_lons = [float(point["lon"]) for point in path_points]
            path_lats = [float(point["lat"]) for point in path_points]
            ax.plot(path_lons, path_lats, color="#8b5cf6", linewidth=2.4, linestyle="--", alpha=0.92, zorder=15)
            ax.scatter(path_lons[1:], path_lats[1:], s=25, color="#8b5cf6", edgecolor="white", linewidth=0.8, zorder=16)
            uncertainty = float(best_eta["eta"].get("trajectory_uncertainty_km", 0.0) or 0.0)
            if uncertainty > 0:
                rx, ry = deg_radius_for_km(uncertainty, path_lats[-1])
                ax.add_patch(Ellipse(
                    (path_lons[-1], path_lats[-1]), width=2 * rx, height=2 * ry,
                    facecolor="#8b5cf6", edgecolor="#6d28d9", linewidth=1.2,
                    alpha=0.13, zorder=14,
                ))

    ax.text(0.015, 0.985, f"Aggiornamento radar: {ts}", transform=ax.transAxes, fontsize=9.8, color="#0f172a", va="top", ha="left",
            bbox=dict(boxstyle="round,pad=0.22", facecolor="white", edgecolor="#cbd5e1", alpha=0.92), zorder=20)

    fig.suptitle("Meteo Alert Radar VMI", fontsize=22, fontweight="bold", y=0.982, color="#0f172a")
    ax.set_xlim(lon_min, lon_max)
    ax.set_ylim(lat_min, lat_max)
    ax.set_xlabel("Longitudine", color="#334155")
    ax.set_ylabel("Latitudine", color="#334155")
    ax.tick_params(axis="both", colors="#334155")
    ax.grid(True, linestyle=":", linewidth=0.55, alpha=0.35, zorder=1)

    cbar = fig.colorbar(im, ax=ax, fraction=0.045, pad=0.016, boundaries=vmi_bounds, ticks=vmi_bounds)
    cbar.set_label("VMI (dBZ)", color="#334155")
    cbar.ax.yaxis.set_tick_params(color="#334155")
    plt.setp(cbar.ax.get_yticklabels(), color="#334155")

    footer = "Fonte dati radar: Radar-DPC / Dipartimento Protezione Civile - licenza CC-BY-SA. Mappa: © OpenStreetMap contributors. Elaborazione personale non ufficiale."
    fig.text(0.012, 0.010, footer, fontsize=8.6, color="#475569")
    fig.subplots_adjust(left=0.025, right=0.975, top=0.90, bottom=0.055, wspace=0.035)

    output = Path(img_cfg.get("output_file", "/var/lib/meteo-alert/public/meteo.jpg"))
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(delete=False, dir=str(output.parent), suffix=".jpg") as tmp:
        tmp_path = Path(tmp.name)
    fig.savefig(tmp_path, format="jpg", pil_kwargs={"quality": 90, "optimize": True})
    plt.close(fig)
    tmp_path.replace(output)
    output.chmod(0o644)
    logging.info("public image written=%s", output)
    generate_public_image_variants(output)
    publish_image(output, cfg)
    return output


def generate_public_image_variants(output: Path) -> None:
    """Crea viste responsive senza alterare il JPEG desktop originale."""
    from PIL import Image

    variants = {
        "map": (0.382, 0.025, 0.995, 0.965),
        "details": (0.012, 0.095, 0.405, 0.965),
    }
    with Image.open(output) as source:
        source.load()
        width, height = source.size
        for name, ratios in variants.items():
            left, top, right, bottom = ratios
            crop = source.crop((int(width * left), int(height * top), int(width * right), int(height * bottom)))
            destination = output.with_name(f"{output.stem}-{name}{output.suffix}")
            with tempfile.NamedTemporaryFile(delete=False, dir=str(output.parent), suffix=".jpg") as tmp:
                temporary = Path(tmp.name)
            crop.save(temporary, format="JPEG", quality=91, optimize=True)
            temporary.replace(destination)
            destination.chmod(0o644)
            logging.info("public image variant written=%s", destination)

def publish_image(local_image: Path, cfg: dict[str, Any]) -> None:
    pub = cfg.get("publish", {})
    method = str(pub.get("method", "local")).lower()
    if method == "local":
        dest = Path(pub.get("local_path", str(local_image)))
        if dest.resolve() != local_image.resolve():
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(local_image, dest)
            dest.chmod(0o644)
            logging.info("published local image=%s", dest)
            for name in ("map", "details"):
                source_variant = local_image.with_name(f"{local_image.stem}-{name}{local_image.suffix}")
                if source_variant.is_file():
                    dest_variant = dest.with_name(f"{dest.stem}-{name}{dest.suffix}")
                    shutil.copy2(source_variant, dest_variant)
                    dest_variant.chmod(0o644)
                    logging.info("published local image variant=%s", dest_variant)
        return

    if method == "scp" and pub.get("scp", {}).get("enabled", False):
        scp_cfg = pub["scp"]
        identity = scp_cfg["identity_file"]
        destination = scp_cfg["destination"]
        strict = "yes" if bool(scp_cfg.get("strict_host_key_checking", True)) else "no"
        cmd = [
            "scp",
            "-i", identity,
            "-o", f"StrictHostKeyChecking={strict}",
            str(local_image),
            destination,
        ]
        subprocess.run(cmd, check=True, timeout=60)
        logging.info("published image via scp destination=%s", destination)
        return

    logging.warning("publish method not active or unsupported: %s", method)


def cleanup_old_frames(cfg: dict[str, Any]) -> None:
    keep_days = int(cfg.get("radar", {}).get("keep_frames_days", 7))
    cutoff = utc_now() - timedelta(days=keep_days)
    frame_root = Path(cfg["app"]["data_dir"]) / "frames"
    if not frame_root.exists():
        return
    for p in frame_root.rglob("*.tif"):
        try:
            mtime = datetime.fromtimestamp(p.stat().st_mtime, tz=timezone.utc)
            if mtime < cutoff:
                p.unlink()
        except Exception:
            logging.exception("cleanup failed for %s", p)
    # Dieci volumi CAPPI nazionali ogni dieci minuti occuperebbero molto spazio
    # senza aggiungere valore al tracking, che persiste già le metriche verticali
    # per cella. Manteniamo quindi solo pochi raster recenti per livello.
    vertical_cfg = cfg.get("vertical_profile", {})
    keep_cappi = max(1, min(12, int(vertical_cfg.get("keep_frames_per_product", 3) or 3)))
    for product in vertical_cfg.get("products") or [f"CAPPI_{level}" for level in range(1, 11)]:
        if not re.fullmatch(r"CAPPI_(?:[1-9]|10)", str(product)):
            continue
        product_dir = frame_root / str(product)
        if not product_dir.is_dir() or product_dir.is_symlink():
            continue
        files = sorted(
            (path for path in product_dir.glob("*.tif") if path.is_file() and not path.is_symlink()),
            key=lambda path: path.stat().st_mtime,
            reverse=True,
        )
        for old_frame in files[keep_cappi:]:
            try:
                old_frame.unlink()
            except Exception:
                logging.exception("cleanup CAPPI failed for %s", old_frame)


def run_once(cfg: dict[str, Any], dry_run: bool) -> int:
    target_keys = {"name", "lat", "lon", "radius_km"}
    targets = [
        Target(**{k: v for k, v in t.items() if k in target_keys})
        for t in cfg["targets"]
        if t.get("enabled", True)
    ]
    data_dir = Path(cfg["app"]["data_dir"])
    data_dir.mkdir(parents=True, exist_ok=True)
    state_path = Path(cfg["app"]["state_file"])
    state = load_state(state_path)
    poll_telegram_feedback(state, cfg, dry_run)
    candidate_result = load_batch_candidate(state, cfg) if bool(cfg.get("adaptive_ai", {}).get("enabled", True)) else {"loaded": False}
    if candidate_result.get("loaded"):
        logging.info("Adaptive AI: nuovo candidato batch caricato in shadow mode")

    session = requests.Session()
    radar_cfg = cfg.get("radar", {})
    session.headers.update({
        "User-Agent": str(radar_cfg.get("user_agent", "LDZMeteoApp/2.6.0h (+https://radar.protezionecivile.it/)")),
        "Accept": "application/json,text/plain,*/*",
        "Accept-Language": "it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "Origin": str(radar_cfg.get("origin", "https://radar.protezionecivile.it")),
        "Referer": str(radar_cfg.get("referer", "https://radar.protezionecivile.it/")),
    })

    products_to_get = list(cfg["radar"].get("products", ["VMI", "SRI", "POH", "VIL", "ETM", "SRT1", "IR_108"]))
    vertical_cfg = cfg.get("vertical_profile", {})
    cappi_products = list(
        vertical_cfg.get("products")
        or [f"CAPPI_{level}" for level in range(1, 11)]
    ) if bool(vertical_cfg.get("enabled", True)) else []
    for product in cappi_products:
        if re.fullmatch(r"CAPPI_(?:[1-9]|10)", str(product)) and product not in products_to_get:
            products_to_get.append(str(product))
    frames: dict[str, RadarFrame] = {}
    timestamps: dict[str, int] = {}

    for product in products_to_get:
        try:
            ts = find_last_product(session, product, cfg)
            timestamps[product] = ts
            frames[product] = download_product(session, product, ts, cfg)
        except MeteoAlertTransientRemoteError as exc:
            logging.warning("Radar-DPC temporaneamente non disponibile durante download %s: %s", product, exc)
            if product == "VMI":
                raise
        except Exception as exc:
            logging.exception("Errore download prodotto %s: %s", product, exc)
            if product == "VMI":
                raise

    # Usiamo VMI come griglia di riferimento; gli altri layer vengono reproiettati se necessario.
    ref = read_reference_raster(frames["VMI"].path, "VMI", cfg)
    arrays: dict[str, np.ndarray] = {"VMI": ref["array"]}
    vmi_ts = frames["VMI"].timestamp_ms
    max_product_skew = float(cfg.get("precision_engine", {}).get("max_product_skew_minutes", 12) or 12)
    product_quality: dict[str, dict[str, Any]] = {
        "VMI": {"available": True, "skew_minutes": 0.0, "used": True}
    }
    for product, frame in frames.items():
        if product == "VMI":
            continue
        skew = abs(frame.timestamp_ms - vmi_ts) / 60000.0
        allowed_skew = (
            float(vertical_cfg.get("max_skew_minutes", 16) or 16)
            if product.startswith("CAPPI_")
            else max_product_skew
        )
        if skew > allowed_skew:
            product_quality[product] = {"available": True, "skew_minutes": round(skew, 1), "used": False, "reason": "stale_vs_vmi"}
            logging.warning("product=%s escluso dal fusion: skew %.1f min rispetto a VMI (max %.1f)", product, skew, allowed_skew)
            continue
        arrays[product] = read_raster_to_reference(frame.path, product, ref, cfg)
        product_quality[product] = {"available": True, "skew_minutes": round(skew, 1), "used": True}

    sites_status: dict[str, Any] = {"enabled": bool(cfg.get("radar_sites", {}).get("enabled", True)), "available": False}
    sites_backoff = source_backoff_status(cfg, "SITES")
    if sites_backoff.get("blocked"):
        sites_status = {
            "enabled": True, "available": False, "status": "backoff", "source": "Radar-DPC SITES",
            "retry_after_epoch": sites_backoff.get("retry_after_epoch"),
            "reason": "official_product_temporarily_unavailable",
        }
    else:
        try:
            sites_status = fetch_radar_sites_status(session, targets, cfg)
            record_source_backoff(cfg, "SITES", None)
        except Exception as exc:
            entry = record_source_backoff(cfg, "SITES", type(exc).__name__)
            sites_status = {
                "enabled": True, "available": False, "status": "backoff", "error": type(exc).__name__,
                "source": "Radar-DPC SITES", "retry_after_epoch": entry.get("retry_after_epoch"),
            }
            logging.warning("stato radar SITES non disponibile (%s); prossimo tentativo dopo il backoff", type(exc).__name__)

    ref["timestamp_ms"] = vmi_ts
    used_cappi_timestamps = [
        frames[product].timestamp_ms
        for product in cappi_products
        if product in frames and product_quality.get(product, {}).get("used")
    ]
    if used_cappi_timestamps:
        ref["cappi_timestamp_ms"] = int(max(used_cappi_timestamps))
    max_age = timedelta(minutes=int(cfg["app"].get("max_frame_age_minutes", 20)))
    vmi_fresh = utc_now() - ms_to_dt(vmi_ts) <= max_age
    if not vmi_fresh:
        logging.warning("VMI frame vecchio: %s", dt_iso(vmi_ts))

    cells = detect_cells(ref, arrays, vmi_ts, targets, cfg)
    segmentation_shadow: dict[str, Any] = {"mode": "disabled", "operational_cells": len(cells)}
    segmentation_mode = str(cfg.get("segmentation_engine", {}).get("mode", "shadow"))
    if bool(cfg.get("segmentation_engine", {}).get("enabled", True)) and segmentation_mode == "shadow":
        try:
            shadow_cells = detect_cells(ref, arrays, vmi_ts, targets, cfg, segmentation_mode="active")
            segmentation_shadow = {
                "mode": "shadow", "affects_alerts": False,
                "operational_cells": len(cells), "shadow_cells": len(shadow_cells),
                "split_delta": len(shadow_cells) - len(cells),
                "shadow": [
                    {"lat": round(cell.lat, 5), "lon": round(cell.lon, 5), "area_km2": round(cell.area_km2, 2),
                     "max_vmi": round(cell.max_vmi, 1), "parent": cell.segmentation_parent_id}
                    for cell in shadow_cells[:40]
                ],
            }
        except Exception as exc:
            segmentation_shadow = {"mode": "shadow", "affects_alerts": False, "available": False, "error": type(exc).__name__}
    precision_enabled = bool(cfg.get("precision_engine", {}).get("enabled", True))
    precision_forecasts: dict[str, dict[str, Any]] = {}
    optical_flows: dict[str, dict[str, Any]] = {}
    atmospheric_context: dict[str, Any] = {"enabled": False, "available": False}
    raster_shadow: dict[str, Any] = {"enabled": False, "available": False, "mode": "shadow"}
    duplicate_frame = False
    cache_path = Path(cfg.get("precision_engine", {}).get("radar_cache_file", str(data_dir / "precision" / "last-vmi.npz")))
    if precision_enabled:
        atmospheric_session = requests.Session()
        atmospheric_session.headers.update({"User-Agent": "LDZMeteoApp/2.6.0h (+local nowcast; contact configured in WebGUI)"})
        atmospheric_context = fetch_national_atmospheric_context(atmospheric_session, targets, cfg)
        previous_cache = load_radar_cache(cache_path, ref, vmi_ts, cfg)
        duplicate_frame = is_duplicate_radar_frame(arrays["VMI"], previous_cache)
        optical_flows = estimate_optical_flows(cells, arrays["VMI"], previous_cache, ref, cfg)
        raster_shadow = raster_nowcast_shadow(arrays["VMI"], previous_cache, ref, targets, vmi_ts, cfg)
        update_tracks(cells, state, cfg, duplicate_frame=duplicate_frame)
    logging.info("detected cells=%d", len(cells))
    for c in cells[:15]:
        logging.info(
            "cell=%s track=%s frames=%s lifecycle=%s risk=%s lat=%.4f lon=%.4f dist=%.1fkm target=%s vmi=%.1f sri=%s poh=%s vil=%s etm=%s cappi45=%s cappi_levels=%s",
            c.cell_id, c.track_id or "legacy", c.track_frames, c.lifecycle, c.risk, c.lat, c.lon, c.nearest_distance_km, c.nearest_target, c.max_vmi,
            "n/d" if c.max_sri is None else f"{c.max_sri:.1f}",
            "n/d" if c.max_poh is None else f"{c.max_poh:.0f}%",
            "n/d" if c.max_vil is None else f"{c.max_vil:.1f}",
            "n/d" if c.max_etm is None else f"{c.max_etm:.0f}",
            "n/d" if c.cappi_highest_45_km is None else f"{c.cappi_highest_45_km:.0f}km",
            c.cappi_available_levels,
        )

    lightning_strikes: list[LightningStrike] = []
    lightning_meta: dict[str, Any] = {}
    lightning_context: dict[str, dict[str, Any]] = {}
    lightning_cells: dict[str, dict[str, Any]] = {}
    try:
        lightning_strikes, lightning_meta = fetch_dpc_lgt_window(session, vmi_ts, cfg)
        if lightning_meta.get("available") and not lightning_meta.get("fresh", True):
            logging.warning(
                "DPC-LGT stale: quadro pubblicato %.0f min fa, max live %.0f min; non usato per overlay/gating/alert",
                float(lightning_meta.get("age_minutes") or 0.0),
                float(lightning_meta.get("max_age_minutes") or 15.0),
            )
            lightning_strikes = []
        lightning_context = lightning_context_by_target(lightning_strikes, targets, cfg) if lightning_strikes or (lightning_meta.get("available") and lightning_meta.get("fresh", True)) else {}
    except Exception as exc:
        logging.warning("Errore modulo Radar-DPC LGT: %s", exc)
        lightning_meta = {"enabled": bool(cfg.get("lightning", {}).get("enabled", False)), "source": cfg.get("lightning", {}).get("source"), "available": False, "error": str(exc)}

    sensor_context: dict[str, dict[str, Any]] = {}
    try:
        sensor_context = fetch_local_sensor_context(session, targets, cfg)
    except Exception as exc:
        logging.warning("Errore sensori locali: %s", exc)

    temporal_bundle = build_temporal_bundle(timestamps, product_quality, lightning_meta, sites_status, cfg)
    logging.info(
        "temporal bundle status=%s quality=%.0f%% issues=%s",
        temporal_bundle.get("status"), float(temporal_bundle.get("quality_percent", 0.0) or 0.0), temporal_bundle.get("issues", []),
    )

    if precision_enabled:
        try:
            lightning_cells = lightning_context_by_cell(lightning_strikes, cells, state, vmi_ts, cfg, lightning_meta)
        except Exception as exc:
            logging.warning("Lightning Jump non disponibile: %s", exc)
            lightning_cells = {}
        terrain_context: dict[str, dict[str, Any]] = {}
        try:
            terrain_context = fetch_terrain_profiles(atmospheric_session, cells, targets, cfg)
        except Exception as exc:
            logging.warning("Terrain Engine non disponibile: %s", exc)
        precision_forecasts = build_precision_forecasts(
            cells,
            targets,
            state,
            cfg,
            optical_flows,
            atmospheric_context,
            terrain_context,
            lightning_cells,
            sensor_context,
        )
        cell_by_id = {cell.cell_id: cell for cell in cells}
        target_by_name = {target.name: target for target in targets}
        for forecast_key, forecast in list(precision_forecasts.items()):
            cell_id, _, target_name = forecast_key.partition("|")
            forecast_cell = cell_by_id.get(cell_id)
            forecast_target = target_by_name.get(target_name)
            if forecast_cell is None or forecast_target is None:
                continue
            forecast = dict(forecast)
            forecast["temporal_bundle"] = temporal_bundle
            forecast["target_data_quality"] = build_target_data_quality(
                forecast_target, temporal_bundle, sites_status, cfg,
                ref=ref, arrays=arrays, cell=forecast_cell,
            )
            precision_forecasts[forecast_key] = apply_multisignal_context(
                forecast_target,
                forecast_cell,
                forecast,
                cfg,
                lt_ctx=lightning_context.get(target_name) or {},
                lightning_meta=lightning_meta,
                state=state,
            )
        save_radar_cache(cache_path, ref, vmi_ts)
        precision_state = state.setdefault("precision", {})
        precision_state["engine_version"] = "2.6.0h"
        precision_state["model"] = "stable-impact-ensemble"
        precision_state["compatibility_mode"] = COMPAT_MODULE_SOURCE
        precision_state["optical_flow_cells"] = len(optical_flows)
        precision_state["forecast_count"] = len(precision_forecasts)
        precision_state["product_quality"] = product_quality
        precision_state["temporal_bundle"] = temporal_bundle
        precision_state["radar_sites"] = sites_status
        precision_state["duplicate_frame"] = duplicate_frame
        precision_state["segmentation_shadow"] = segmentation_shadow
        precision_state["raster_nowcast_shadow"] = raster_shadow
        used_cappi = [
            product for product in cappi_products
            if product_quality.get(product, {}).get("used")
        ]
        precision_state["cappi_profile"] = {
            "enabled": bool(vertical_cfg.get("enabled", True)),
            "expected_levels": len(cappi_products),
            "used_levels": len(used_cappi),
            "products": used_cappi,
            "available": bool(used_cappi),
            "complete": len(used_cappi) == len(cappi_products) and bool(cappi_products),
            "timestamp_ms": max(used_cappi_timestamps) if used_cappi_timestamps else None,
            "source": "Radar-DPC CAPPI 1–10 km",
            "active_in_hail_fusion": bool(used_cappi),
        }
        precision_state["atmospheric_context"] = atmospheric_context
        precision_state["terrain_profiles"] = terrain_context
        precision_state["lightning_jump_cells"] = lightning_cells
        precision_state["local_sensors"] = sensor_context
        initiation_by_target: dict[str, dict[str, Any]] = {}
        atmospheric_by_target = atmospheric_context.get("by_target") if isinstance(atmospheric_context.get("by_target"), dict) else {}
        for target in targets:
            initiation_by_target.update(initiation_watch(
                [target], atmospheric_by_target.get(target.name) or atmospheric_context,
                lightning_context, sensor_context, cfg,
            ))
        precision_state["initiation_watch"] = initiation_by_target

    try:
        generate_public_image(ref, arrays, cells, targets, cfg, state=state, lightning_strikes=lightning_strikes, precision_forecasts=precision_forecasts)
    except Exception as exc:
        logging.exception("Errore generazione immagine pubblica: %s", exc)

    if vmi_fresh:
        sent = evaluate_alerts(
            cells,
            state,
            targets,
            cfg,
            dry_run=dry_run,
            lightning_context=lightning_context,
            lightning_meta=lightning_meta,
            precision_forecasts=precision_forecasts,
            frame_timestamp_ms=vmi_ts,
        )
    else:
        sent = []
        logging.warning("alert temporaleschi e calibrazione sospesi: frame VMI oltre la freschezza massima")

    # LGT è un prodotto indipendente: se è fresco, gli avvisi fulmini devono
    # continuare anche quando il volume VMI è temporaneamente in ritardo.
    covered_lightning_targets = {
        str(item.get("target"))
        for item in sent
        if isinstance(item, dict)
        and isinstance(item.get("eta"), dict)
        and int(item["eta"].get("lightning_count", 0) or 0) > 0
        and str(item.get("mode", "")) != "clear"
    }
    sent.extend(
        evaluate_lightning_alerts(
            lightning_strikes,
            lightning_meta,
            state,
            targets,
            cfg,
            dry_run,
            covered_targets=covered_lightning_targets,
        )
    )
    if sent:
        logging.info("alerts sent=%d", len(sent))
    else:
        logging.info("no alerts sent")

    if precision_enabled and vmi_fresh:
        update_verification(state, cells, targets, precision_forecasts, vmi_ts, cfg)
        try:
            update_complete_verification(
                state, targets, cells, precision_forecasts, vmi_ts, cfg,
                sensor_context=sensor_context,
            )
        except Exception as exc:
            logging.warning("verifica nazionale completa non disponibile: %s", exc)
    # Weather Lab is intentionally executed after the operational decision.
    # Its outputs are archived and compared, but can never alter this cycle's
    # alerts or probabilities.
    try:
        weather_lab_state = update_weather_lab(
            cfg, targets, ref, arrays, precision_forecasts, vmi_ts,
        )
        state.setdefault("precision", {})["weather_lab"] = weather_lab_state
    except Exception as exc:
        logging.warning("Weather Lab non disponibile: %s", type(exc).__name__)
        state.setdefault("precision", {})["weather_lab"] = {
            "enabled": bool(cfg.get("weather_lab", {}).get("enabled", True)),
            "mode": "shadow", "affects_alerts": False,
            "status": "error", "status_label": "In attesa del prossimo ciclo",
            "error": type(exc).__name__,
        }
    try:
        feedback_state = update_incidents(
            state, targets, cells, precision_forecasts, lightning_context, sent, vmi_ts, cfg, temporal_bundle,
        )
        replay_saved = save_replay_snapshots(
            ref, arrays, targets, precision_forecasts, vmi_ts, cfg, temporal_bundle,
            shadow_analysis={
                "segmentation": segmentation_shadow,
                "raster_nowcast": raster_shadow,
                "duplicate_frame": duplicate_frame,
                "hail": {
                    key: value.get("hail_shadow", {}) for key, value in precision_forecasts.items()
                    if isinstance(value, dict) and value.get("hail_shadow")
                },
            },
        )
        feedback_prompts = send_due_feedback_prompts(state, cfg, dry_run)
        logging.info(
            "event feedback incidents=%d open=%d replay_saved=%d prompts=%d",
            int((feedback_state.get("totals") or {}).get("incidents", 0) or 0),
            int((feedback_state.get("totals") or {}).get("open", 0) or 0),
            replay_saved,
            feedback_prompts,
        )
    except Exception as exc:
        logging.warning("event feedback/replay non disponibile: %s", exc)
    state["last_cells"] = [asdict(c) for c in cells]
    state["last_products"] = timestamps
    if isinstance(lightning_meta, dict):
        lightning_meta["targets"] = lightning_context
    state["last_lightning"] = lightning_meta
    state["updated_utc"] = utc_now().isoformat()
    save_state(state_path, state)
    cleanup_old_frames(cfg)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Meteo radar alert Telegram")
    parser.add_argument("--config", default="/etc/meteo-alert/config.yml")
    parser.add_argument("--dry-run", action="store_true", help="Non invia Telegram, logga soltanto")
    args = parser.parse_args()

    cfg = load_config(Path(args.config))
    if args.dry_run:
        cfg["app"]["dry_run"] = True
    dry_run = bool(cfg["app"].get("dry_run", False))

    setup_logging(cfg)
    log_service_start("engine")
    lock_path = Path(cfg.get("app", {}).get("run_lock_file", str(Path(cfg["app"]["data_dir"]) / "meteo-alert.lock")))
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    lock_handle = lock_path.open("a+")
    try:
        try:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            logging.info("ciclo già in esecuzione: trigger duplicato ignorato")
            return 0
        return run_once(cfg, dry_run=dry_run)
    except MeteoAlertTransientRemoteError as exc:
        logging.error("Radar-DPC temporaneamente non disponibile: %s", exc)
        logging.info("Run terminato senza alert: il timer riproverà automaticamente al prossimo ciclo.")
        return 0
    except Exception as exc:
        logging.exception("Fatal error: %s", exc)
        return 2
    finally:
        try:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)
        finally:
            lock_handle.close()


if __name__ == "__main__":
    raise SystemExit(main())
