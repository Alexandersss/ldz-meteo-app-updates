#!/usr/bin/env python3
"""Listener Telegram dedicato: ricevuta immediata e conferma persistente del feedback."""
from __future__ import annotations

import argparse
import fcntl
import html
import json
import logging
import os
import tempfile
import time
from pathlib import Path
from typing import Any

import requests
import yaml

from event_feedback import (
    drain_feedback_inbox,
    feedback_event_is_queued,
    queue_feedback_update,
    validate_feedback_update,
)


MAX_LISTENER_STATE_BYTES = 2 * 1024 * 1024
MAX_ENGINE_STATE_BYTES = 16 * 1024 * 1024


def load_json(
    path: Path,
    default: dict[str, Any],
    maximum_bytes: int = MAX_LISTENER_STATE_BYTES,
) -> dict[str, Any]:
    try:
        if not path.is_file() or path.is_symlink() or path.stat().st_size > maximum_bytes:
            return dict(default)
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else dict(default)
    except (OSError, ValueError, TypeError):
        return dict(default)


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise OSError("state listener symlink non consentito")
    with tempfile.NamedTemporaryFile("w", delete=False, dir=str(path.parent), encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
        temporary = Path(handle.name)
    temporary.chmod(0o600)
    temporary.replace(path)


def telegram_call(token: str, method: str, payload: dict[str, Any], timeout: tuple[int, int] = (5, 20)) -> tuple[bool, dict[str, Any]]:
    try:
        response = requests.post(
            f"https://api.telegram.org/bot{token}/{method}",
            json=payload,
            timeout=timeout,
            allow_redirects=False,
        )
        data = response.json() if response.content else {}
        return bool(response.ok and isinstance(data, dict) and data.get("ok")), data if isinstance(data, dict) else {}
    except Exception as exc:
        return False, {"description": type(exc).__name__}


def ui_job(validated: dict[str, Any], *, duplicate: bool = False) -> dict[str, Any]:
    label = str(validated.get("clean_label", "feedback"))[:120]
    return {
        "callback_id": str(validated.get("callback_id", ""))[:200],
        "chat_id": str(validated.get("chat_id", ""))[:80],
        "message_id": int(validated.get("message_id", 0) or 0),
        "event_id": str(validated.get("event_id", ""))[:120],
        "answer": "Feedback già registrato" if duplicate else "Feedback ricevuto",
        "confirmation": "ℹ️ Feedback già registrato." if duplicate else f"✅ Feedback registrato: {label}",
        "callback_answered": False,
        "markup_removed": False,
        "confirmation_sent": False,
        "attempts": 0,
    }


def process_ui_jobs(token: str, listener_state: dict[str, Any]) -> None:
    pending = listener_state.get("pending_ui") if isinstance(listener_state.get("pending_ui"), list) else []
    remaining: list[dict[str, Any]] = []
    for raw in pending[:100]:
        if not isinstance(raw, dict):
            continue
        job = dict(raw)
        attempts = int(job.get("attempts", 0) or 0) + 1
        job["attempts"] = attempts
        callback_id = str(job.get("callback_id", ""))
        chat_id = str(job.get("chat_id", ""))
        message_id = int(job.get("message_id", 0) or 0)

        if callback_id and not job.get("callback_answered"):
            ok, result = telegram_call(token, "answerCallbackQuery", {
                "callback_query_id": callback_id,
                "text": str(job.get("answer", "Feedback ricevuto"))[:180],
                "show_alert": False,
            })
            description = str(result.get("description", "")).lower()
            if ok or (attempts >= 2 and ("query is too old" in description or "query id is invalid" in description)):
                job["callback_answered"] = True

        if chat_id and message_id > 0 and not job.get("markup_removed"):
            ok, result = telegram_call(token, "editMessageReplyMarkup", {
                "chat_id": chat_id,
                "message_id": message_id,
                "reply_markup": {"inline_keyboard": []},
            })
            description = str(result.get("description", "")).lower()
            if ok or "message is not modified" in description or attempts >= 5:
                job["markup_removed"] = True

        if chat_id and not job.get("confirmation_sent"):
            payload: dict[str, Any] = {
                "chat_id": chat_id,
                "text": html.escape(str(job.get("confirmation", "✅ Feedback registrato."))[:300]),
                "parse_mode": "HTML",
                "disable_web_page_preview": True,
            }
            if message_id > 0:
                payload["reply_to_message_id"] = message_id
                payload["allow_sending_without_reply"] = True
            ok, _ = telegram_call(token, "sendMessage", payload)
            if ok:
                job["confirmation_sent"] = True

        if not (job.get("confirmation_sent") and job.get("markup_removed")):
            remaining.append(job)
    remaining.extend(item for item in pending[100:] if isinstance(item, dict))
    listener_state["pending_ui"] = remaining[-100:]


def save_engine_state(path: Path, state: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", delete=False, dir=str(path.parent), encoding="utf-8") as handle:
        json.dump(state, handle, indent=2, ensure_ascii=False, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
        temporary = Path(handle.name)
    temporary.replace(path)


def try_drain_engine_inbox(cfg: dict[str, Any], token: str, chat_id: str) -> int:
    app_cfg = cfg.get("app", {})
    state_path = Path(app_cfg.get("state_file", "/var/lib/meteo-alert/state.json"))
    lock_path = Path(app_cfg.get("run_lock_file", "/var/lib/meteo-alert/meteo-alert.lock"))
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+") as lock_handle:
        try:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return 0
        try:
            state = load_json(
                state_path,
                {"last_cells": [], "alerts": {}, "last_products": {}},
                maximum_bytes=MAX_ENGINE_STATE_BYTES,
            )
            results = drain_feedback_inbox(state, cfg, token, chat_id)
            if results:
                save_engine_state(state_path, state)
            return sum(1 for item in results if item.get("ok") and not item.get("duplicate"))
        finally:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)


def handle_updates(
    updates: list[dict[str, Any]],
    cfg: dict[str, Any],
    token: str,
    chat_id: str,
    listener_state: dict[str, Any],
) -> int:
    state_path = Path(cfg.get("app", {}).get("state_file", "/var/lib/meteo-alert/state.json"))
    engine_state = load_json(
        state_path,
        {"event_feedback": {"incidents": {}}},
        maximum_bytes=MAX_ENGINE_STATE_BYTES,
    )
    queued = 0
    pending_ui = listener_state.setdefault("pending_ui", [])
    for update in sorted(updates, key=lambda item: int(item.get("update_id", 0) or 0)):
        try:
            update_id = int(update.get("update_id", 0) or 0)
        except (TypeError, ValueError, OverflowError):
            continue
        validated = validate_feedback_update(update, engine_state, token, chat_id)
        callback_id = str(validated.get("callback_id", ""))
        if not validated.get("ok"):
            if callback_id:
                telegram_call(token, "answerCallbackQuery", {
                    "callback_query_id": callback_id,
                    "text": str(validated.get("answer", "Feedback non valido"))[:180],
                    "show_alert": True,
                })
            listener_state["offset"] = max(int(listener_state.get("offset", 0) or 0), update_id + 1)
            continue

        event_id = str(validated.get("event_id", ""))
        duplicate = bool(validated.get("duplicate") or feedback_event_is_queued(cfg, event_id))
        if not duplicate:
            try:
                created = queue_feedback_update(update, cfg)
            except Exception:
                telegram_call(token, "answerCallbackQuery", {
                    "callback_query_id": callback_id,
                    "text": "Feedback non registrato: errore di salvataggio. Riprova.",
                    "show_alert": True,
                })
                listener_state["offset"] = max(int(listener_state.get("offset", 0) or 0), update_id + 1)
                continue
            if created:
                queued += 1
            else:
                duplicate = True
        if not any(str(item.get("callback_id", "")) == callback_id for item in pending_ui if isinstance(item, dict)):
            pending_ui.append(ui_job(validated, duplicate=duplicate))
        listener_state["offset"] = max(int(listener_state.get("offset", 0) or 0), update_id + 1)
    listener_state["pending_ui"] = pending_ui[-100:]
    return queued


def listen(config_path: Path) -> int:
    cfg = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip().strip('"')
    chat_id = os.environ.get("TELEGRAM_CHAT_ID", "").strip().strip('"')
    if not token or not chat_id:
        raise RuntimeError("TELEGRAM_BOT_TOKEN o TELEGRAM_CHAT_ID non configurato")
    data_dir = Path(cfg.get("app", {}).get("data_dir", "/var/lib/meteo-alert"))
    listener_path = data_dir / "feedback" / "telegram-listener-state.json"
    listener_state = load_json(listener_path, {"offset": 0, "pending_ui": []})
    logging.info("listener feedback Telegram attivo")

    while True:
        try:
            process_ui_jobs(token, listener_state)
            processed = try_drain_engine_inbox(cfg, token, chat_id)
            if processed:
                logging.info("feedback Telegram registrati=%d", processed)
            atomic_json(listener_path, listener_state)
            response = requests.get(
                f"https://api.telegram.org/bot{token}/getUpdates",
                params={
                    "offset": int(listener_state.get("offset", 0) or 0),
                    "limit": 100,
                    "timeout": 25,
                    "allowed_updates": json.dumps(["callback_query"]),
                },
                timeout=(5, 35),
                allow_redirects=False,
            )
            response.raise_for_status()
            payload = response.json()
            updates = payload.get("result") if payload.get("ok") and isinstance(payload.get("result"), list) else []
            if updates:
                queued = handle_updates(updates, cfg, token, chat_id, listener_state)
                atomic_json(listener_path, listener_state)
                process_ui_jobs(token, listener_state)
                try_drain_engine_inbox(cfg, token, chat_id)
                atomic_json(listener_path, listener_state)
                logging.info("callback Telegram ricevuti=%d accodati=%d", len(updates), queued)
        except KeyboardInterrupt:
            return 0
        except Exception as exc:
            logging.warning("listener feedback Telegram temporaneamente non disponibile (%s)", type(exc).__name__)
            time.sleep(5)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="/etc/meteo-alert/config.yml")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    return listen(Path(args.config))


if __name__ == "__main__":
    raise SystemExit(main())
