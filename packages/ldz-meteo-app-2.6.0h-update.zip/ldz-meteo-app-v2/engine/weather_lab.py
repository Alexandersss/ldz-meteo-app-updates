#!/usr/bin/env python3
"""Weather Lab shadow collectors for LDZ Meteo.

This module is deliberately isolated from the operational alert path.  Every
result it produces is labelled ``affects_alerts=False`` and failures are
reported in its own status file without stopping the radar cycle.
"""
from __future__ import annotations

import base64
import fcntl
import importlib.metadata
import json
import math
import os
import re
import stat
import tempfile
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import quote

import numpy as np
import requests


METEOHUB_ROOT = "https://meteohub.agenziaitaliameteo.it"
METEOHUB_LOGIN = f"{METEOHUB_ROOT}/auth/login"
METEOHUB_REQUESTS = f"{METEOHUB_ROOT}/api/requests"
METEOHUB_USAGE = f"{METEOHUB_ROOT}/api/usage"
METEOHUB_HOURLY = f"{METEOHUB_ROOT}/api/hourly"
METEOHUB_DATA = f"{METEOHUB_ROOT}/api/data"
SUPPORTED_MODELS = ("WRF_DA_ITA", "ICON-2I-RUC")


class WeatherLabError(RuntimeError):
    pass


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", delete=False, dir=path.parent, encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")
        temporary = Path(handle.name)
    temporary.chmod(0o600)
    temporary.replace(path)


def _read_json(path: Path, default: dict[str, Any] | None = None) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else (default or {})
    except Exception:
        return default or {}


def _append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_APPEND | os.O_CREAT
    if hasattr(os, "O_CLOEXEC"):
        flags |= os.O_CLOEXEC
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    fd = os.open(path, flags, 0o600)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise WeatherLabError("archivio Weather Lab non regolare")
        fcntl.flock(fd, fcntl.LOCK_EX)
        data = (json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)


def _decode_secret(value: str) -> str:
    if not value:
        return ""
    try:
        return base64.b64decode(value.encode("ascii"), validate=True).decode("utf-8")
    except Exception:
        return ""


def load_meteohub_credentials(path: Path) -> tuple[str, str]:
    if not path.is_file() or path.is_symlink():
        return "", ""
    values: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if "=" not in raw or raw.lstrip().startswith("#"):
            continue
        key, value = raw.split("=", 1)
        values[key.strip()] = value.strip()
    return _decode_secret(values.get("METEOHUB_USERNAME_B64", "")), _decode_secret(values.get("METEOHUB_PASSWORD_B64", ""))


def _token(payload: Any) -> str:
    # MeteoHub 0.5.7 returns the access token as the JSON response itself
    # (a JSON string), while older/alternate deployments may wrap it in an
    # object.  Accept both contracts without ever persisting the token.
    if isinstance(payload, str):
        return payload.strip()
    if isinstance(payload, dict):
        for key in ("access_token", "accessToken", "token"):
            if isinstance(payload.get(key), str) and payload[key].strip():
                return payload[key].strip()
        for key in ("data", "result", "response", "payload"):
            found = _token(payload.get(key))
            if found:
                return found
    return ""


def _json_response(response: requests.Response, label: str) -> Any:
    if len(response.content) > 2 * 1024 * 1024:
        raise WeatherLabError(f"{label}: risposta troppo grande")
    if response.status_code in (401, 403):
        raise WeatherLabError("Credenziali MeteoHub non accettate")
    if response.status_code == 429:
        raise WeatherLabError("Limite orario MeteoHub raggiunto")
    if 300 <= response.status_code < 400:
        raise WeatherLabError(f"{label}: reindirizzamento non consentito")
    response.raise_for_status()
    try:
        return response.json()
    except ValueError as exc:
        raise WeatherLabError(f"{label}: risposta non valida") from exc


def _quota_summary(payload: Any) -> dict[str, float | int]:
    """Keep only bounded numeric quota counters; never persist account fields."""
    allowed = {"used", "remaining", "limit", "quota", "total", "requests", "count", "bytes", "used_bytes", "remaining_bytes"}
    if not isinstance(payload, dict):
        return {}
    result: dict[str, float | int] = {}
    for key, value in payload.items():
        normalized = str(key).strip().lower()
        if normalized not in allowed or isinstance(value, bool) or not isinstance(value, (int, float)):
            continue
        if math.isfinite(float(value)) and 0 <= float(value) <= 10**15:
            result[normalized] = value
    return result


class MeteoHubClient:
    """Small fixed-origin MeteoHub client; tokens never touch disk or logs."""

    def __init__(self, username: str, password: str, *, timeout: int = 25) -> None:
        self.username = username.strip()
        self.password = password
        self.timeout = max(5, min(60, int(timeout)))
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "LDZMeteoApp/2.6.0h WeatherLab", "Accept": "application/json"})

    def login(self) -> None:
        if not self.username or not self.password:
            raise WeatherLabError("Credenziali MeteoHub mancanti")
        response = self.session.post(
            METEOHUB_LOGIN,
            json={"username": self.username, "password": self.password},
            timeout=self.timeout,
            allow_redirects=False,
        )
        payload = _json_response(response, "Login MeteoHub")
        token = _token(payload)
        if not token or len(token) > 16384:
            raise WeatherLabError("MeteoHub non ha restituito un token utilizzabile")
        self.session.headers["Authorization"] = f"Bearer {token}"

    def get_json(self, url: str, label: str) -> Any:
        if not url.startswith(f"{METEOHUB_ROOT}/"):
            raise WeatherLabError("Endpoint MeteoHub non consentito")
        return _json_response(self.session.get(url, timeout=self.timeout, allow_redirects=False), label)

    def connection_snapshot(self) -> dict[str, Any]:
        self.login()
        requests_payload = self.get_json(METEOHUB_REQUESTS, "Richieste MeteoHub")
        usage = self.get_json(METEOHUB_USAGE, "Quota MeteoHub")
        hourly = self.get_json(METEOHUB_HOURLY, "Limite MeteoHub")
        return {"requests": requests_payload, "usage": usage, "hourly": hourly}

    def download(self, filename: str, destination: Path, maximum_bytes: int) -> int:
        safe = Path(filename).name
        if not safe or safe != filename or safe in (".", ".."):
            raise WeatherLabError("Nome file MeteoHub non valido")
        url = f"{METEOHUB_DATA}/{quote(safe, safe='')}"
        response = self.session.get(url, timeout=max(30, self.timeout), allow_redirects=False, stream=True)
        if response.status_code in (401, 403):
            raise WeatherLabError("Sessione MeteoHub scaduta")
        if 300 <= response.status_code < 400:
            raise WeatherLabError("Reindirizzamento download MeteoHub non consentito")
        response.raise_for_status()
        declared = int(response.headers.get("Content-Length") or 0)
        if declared > maximum_bytes:
            raise WeatherLabError("File MeteoHub oltre il limite LDZ configurato")
        destination.parent.mkdir(parents=True, exist_ok=True)
        total = 0
        with tempfile.NamedTemporaryFile("wb", delete=False, dir=destination.parent) as handle:
            temporary = Path(handle.name)
            for chunk in response.iter_content(1024 * 1024):
                if not chunk:
                    continue
                total += len(chunk)
                if total > maximum_bytes:
                    handle.close()
                    temporary.unlink(missing_ok=True)
                    raise WeatherLabError("Download MeteoHub interrotto: limite LDZ superato")
                handle.write(chunk)
        temporary.chmod(0o600)
        temporary.replace(destination)
        return total


def _rows(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if isinstance(payload, dict):
        for key in ("requests", "items", "results", "data"):
            if isinstance(payload.get(key), list):
                return [item for item in payload[key] if isinstance(item, dict)]
    return []


def _request_is_weather_lab(item: dict[str, Any]) -> bool:
    text = json.dumps(item, ensure_ascii=False).upper()
    name = str(item.get("request_name") or item.get("name") or "").upper()
    return name.startswith("LDZ-") or any(model in text for model in SUPPORTED_MODELS)


def sync_meteohub(cfg: dict[str, Any], root: Path, previous: dict[str, Any]) -> dict[str, Any]:
    source = cfg.get("meteohub", {}) if isinstance(cfg.get("meteohub"), dict) else {}
    result = dict(previous) if isinstance(previous, dict) else {}
    result.update({"enabled": bool(source.get("enabled", False)), "affects_alerts": False})
    if not result["enabled"]:
        result.update(status="disabled", status_label="Disattivato")
        return result
    interval = max(15, min(360, int(source.get("sync_minutes", 30) or 30)))
    now = time.time()
    if now - float(result.get("last_attempt_epoch", 0) or 0) < interval * 60:
        return result
    result["last_attempt_epoch"] = now
    secret_path = Path(os.environ.get("LDZ_METEO_METEOHUB_SECRETS", "/etc/meteo-alert/meteohub.env"))
    username, password = load_meteohub_credentials(secret_path)
    if not username or not password:
        result.update(status="credentials_missing", status_label="Account da collegare", error="")
        return result
    try:
        client = MeteoHubClient(username, password)
        snapshot = client.connection_snapshot()
        requests_rows = [item for item in _rows(snapshot["requests"]) if _request_is_weather_lab(item)]
        downloaded = set(str(item) for item in result.get("downloaded_files", []) if item)
        max_bytes = max(16, min(1024, int(source.get("maximum_file_mb", 256) or 256))) * 1024 * 1024
        inbox = root / "meteohub" / "inbox"
        for item in requests_rows:
            status = str(item.get("status") or item.get("state") or "").upper()
            filename = str(item.get("fileoutput") or item.get("filename") or "").strip()
            if status not in ("SUCCESS", "COMPLETED", "DONE") or not filename or filename in downloaded:
                continue
            client.download(filename, inbox / Path(filename).name, max_bytes)
            downloaded.add(filename)
        result.update(
            status="connected",
            status_label="Collegato e in ascolto",
            connected=True,
            account_hint=(username[:2] + "…" + username[-2:]) if len(username) > 5 else "configurato",
            matching_requests=len(requests_rows),
            downloaded_files=sorted(downloaded)[-100:],
            downloaded_count=len(downloaded),
            usage=_quota_summary(snapshot.get("usage")),
            hourly=_quota_summary(snapshot.get("hourly")),
            last_success_utc=_utc_now().isoformat(),
            error="",
        )
    except Exception as exc:
        result.update(status="error", status_label="Collegamento da verificare", connected=False, error=str(exc)[:240])
    return result


def _target_value(field: np.ndarray, ref: dict[str, Any], target: Any, step: int = 1) -> float | None:
    try:
        from rasterio.transform import rowcol
        from rasterio.warp import transform as warp_transform

        lon, lat = float(target.lon), float(target.lat)
        crs = ref.get("crs")
        if crs and str(crs).upper() not in ("EPSG:4326", "OGC:CRS84"):
            xs, ys = warp_transform("EPSG:4326", crs, [lon], [lat])
            x, y = xs[0], ys[0]
        else:
            x, y = lon, lat
        row, col = rowcol(ref["transform"], x, y)
        row, col = int(row) // max(1, step), int(col) // max(1, step)
        if row < 0 or col < 0 or row >= field.shape[-2] or col >= field.shape[-1]:
            return None
        value = float(field[..., row, col])
        return value if math.isfinite(value) else None
    except Exception:
        return None


def _store_frame(root: Path, field: np.ndarray, timestamp_ms: int, max_grid: int) -> tuple[list[Path], int]:
    frames = root / "radar-frames"
    frames.mkdir(parents=True, exist_ok=True)
    step = max(1, int(math.ceil(max(field.shape) / max(64, max_grid))))
    compact = np.nan_to_num(field[::step, ::step].astype("float32"), nan=0.0, posinf=0.0, neginf=0.0)
    destination = frames / f"{int(timestamp_ms)}.npz"
    if not destination.exists():
        with tempfile.NamedTemporaryFile("wb", delete=False, dir=frames) as handle:
            np.savez_compressed(handle, field=compact, step=np.array([step], dtype="int16"))
            temporary = Path(handle.name)
        temporary.chmod(0o600)
        temporary.replace(destination)
    paths = sorted((p for p in frames.glob("*.npz") if p.is_file() and not p.is_symlink()), key=lambda p: int(p.stem))
    for old in paths[:-4]:
        old.unlink(missing_ok=True)
    paths = paths[-4:]
    return paths, step


def _run_linda(root: Path, field: np.ndarray, ref: dict[str, Any], targets: Iterable[Any], timestamp_ms: int, cfg: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {"enabled": True, "mode": "shadow", "affects_alerts": False, "available": False}
    lab = cfg.get("weather_lab", {}) if isinstance(cfg.get("weather_lab"), dict) else {}
    linda_cfg = lab.get("linda", {}) if isinstance(lab.get("linda"), dict) else {}
    if not bool(linda_cfg.get("enabled", True)):
        result.update(enabled=False, status_label="Disattivato")
        return result
    paths, step = _store_frame(root, field, timestamp_ms, int(linda_cfg.get("max_grid_pixels", 384) or 384))
    if len(paths) < 3:
        result.update(status="collecting", status_label=f"Raccolta frame {len(paths)}/3", frames=len(paths))
        return result
    selected = paths[-3:]
    stamps = [int(path.stem) for path in selected]
    gaps = [(stamps[index] - stamps[index - 1]) / 60000.0 for index in range(1, len(stamps))]
    timestep = float(sum(gaps) / len(gaps))
    if timestep <= 0 or max(gaps) - min(gaps) > max(2.0, timestep * 0.45):
        result.update(status="collecting", status_label="Attesa frame regolari", frames=len(paths))
        return result
    try:
        import pysteps
        from pysteps.motion import get_method as motion_method
        from pysteps.nowcasts.linda import forecast
    except Exception:
        result.update(status="unavailable", status_label="Componente LINDA non disponibile", reason="pysteps_not_installed")
        return result
    arrays = []
    stored_steps = []
    for path in selected:
        with np.load(path, allow_pickle=False) as payload:
            arrays.append(np.asarray(payload["field"], dtype="float64"))
            stored_steps.append(int(payload["step"][0]))
    if len(set(stored_steps)) != 1 or len({array.shape for array in arrays}) != 1:
        result.update(status="collecting", status_label="Griglia radar cambiata")
        return result
    stack = np.stack(arrays)
    leads = [int(item) for item in linda_cfg.get("lead_minutes", lab.get("lead_minutes", [15, 30, 60, 90])) if 5 <= int(item) <= 180]
    if np.count_nonzero(stack[-1] >= 0.2) < 8:
        forecasts = {
            str(target.name): {
                str(lead): {"probability_percent": 0.0, "median_rain_rate_mmh": 0.0}
                for lead in leads
            }
            for target in targets
        }
        result.update(
            status="ready", status_label="Pronto · nessuna pioggia significativa",
            available=True, frames=3, forecasts=forecasts,
            version=importlib.metadata.version("pysteps"), generated_utc=_utc_now().isoformat(), error="",
        )
        return result
    try:
        velocity = motion_method("constant")(stack)
        relative = [lead / timestep for lead in leads]
        members = max(4, min(20, int(linda_cfg.get("ensemble_members", 8) or 8)))
        try:
            output = forecast(
                stack, velocity, relative, feature_method="domain", add_perturbations=True,
                n_ens_members=members, vel_pert_method=None, num_workers=1,
            )
        except Exception:
            output = forecast(stack, velocity, relative, feature_method="domain", add_perturbations=False, num_workers=1)
        output = np.asarray(output)
        if output.ndim == 3:
            output = output[np.newaxis, ...]
        threshold = max(0.1, min(20.0, float(linda_cfg.get("event_rain_rate_mmh", 2.0) or 2.0)))
        forecasts: dict[str, Any] = {}
        for target in targets:
            per_lead: dict[str, Any] = {}
            for index, lead in enumerate(leads):
                values = []
                for member in output[:, index, :, :]:
                    value = _target_value(member, ref, target, stored_steps[0])
                    if value is not None:
                        values.append(value)
                if values:
                    per_lead[str(lead)] = {
                        "probability_percent": round(100.0 * sum(value >= threshold for value in values) / len(values), 1),
                        "median_rain_rate_mmh": round(float(np.median(values)), 2),
                    }
            forecasts[str(target.name)] = per_lead
        result.update(
            status="ready", status_label="Nowcast LINDA pronto", available=True,
            version=importlib.metadata.version("pysteps"), frames=3, timestep_minutes=round(timestep, 1),
            ensemble_members=int(output.shape[0]), forecasts=forecasts, generated_utc=_utc_now().isoformat(), error="",
        )
    except Exception as exc:
        result.update(status="error", status_label="LINDA in attesa del prossimo ciclo", error=type(exc).__name__)
    return result


def _operational_probabilities(forecasts: dict[str, dict[str, Any]], targets: Iterable[Any], leads: list[int]) -> dict[str, dict[str, float]]:
    result: dict[str, dict[str, float]] = {}
    for target in targets:
        candidates = [value for key, value in forecasts.items() if key.endswith("|" + str(target.name)) and isinstance(value, dict)]
        per_lead: dict[str, float] = {}
        for lead in leads:
            probabilities = []
            for item in candidates:
                eta = item.get("eta_minutes")
                eta_low = item.get("eta_low_minutes", eta)
                if eta_low is not None and float(eta_low) <= lead:
                    probabilities.append(float(item.get("impact_probability_percent", 0.0) or 0.0))
            per_lead[str(lead)] = round(max(probabilities, default=0.0), 1)
        result[str(target.name)] = per_lead
    return result


def _metric_rows(raw: Any) -> list[dict[str, Any]]:
    if not isinstance(raw, dict):
        return []
    rows = []
    for key, value in raw.items():
        if not isinstance(value, dict) or "|" not in key:
            continue
        model, lead_text = key.rsplit("|", 1)
        try:
            lead = int(lead_text)
            samples = int(value.get("samples", 0) or 0)
            brier_sum = float(value.get("brier_sum", 0.0) or 0.0)
            correct = int(value.get("correct", 0) or 0)
        except (TypeError, ValueError):
            continue
        if samples <= 0:
            continue
        rows.append({
            "model": model,
            "model_label": "LDZ Stable Impact" if model == "ldz_operational" else "LINDA (ombra)",
            "lead_minutes": lead,
            "samples": samples,
            "brier": round(brier_sum / samples, 3),
            "accuracy_percent": round(100.0 * correct / samples, 1),
            "enough_samples": samples >= 20,
        })
    return sorted(rows, key=lambda row: (row["lead_minutes"], row["model"]))


def _archive_and_verify(root: Path, targets: Iterable[Any], ref: dict[str, Any], arrays: dict[str, np.ndarray], timestamp_ms: int, operational: dict[str, dict[str, float]], linda: dict[str, Any], cfg: dict[str, Any]) -> dict[str, Any]:
    lab = cfg.get("weather_lab", {}) if isinstance(cfg.get("weather_lab"), dict) else {}
    archive = root / "archive" / f"events-{datetime.fromtimestamp(timestamp_ms / 1000, timezone.utc):%Y%m%d}.jsonl"
    ledger = root / "ledger.json"
    state = _read_json(ledger, {"last_timestamp_ms": 0, "pending": [], "outcomes": 0, "forecasts": 0, "metrics": {}})
    rain = arrays.get("SRI")
    vmi = arrays.get("VMI")
    observed: dict[str, Any] = {}
    for target in targets:
        observed[str(target.name)] = {
            "rain_rate_mmh": _target_value(rain, ref, target) if rain is not None else None,
            "vmi_dbz": _target_value(vmi, ref, target) if vmi is not None else None,
        }
    pending = [item for item in state.get("pending", []) if isinstance(item, dict)]
    remaining = []
    rain_threshold = float((lab.get("linda", {}) or {}).get("event_rain_rate_mmh", 2.0) or 2.0)
    for item in pending:
        valid_at = int(item.get("valid_at_ms", 0) or 0)
        if valid_at <= timestamp_ms <= valid_at + 20 * 60000:
            obs = observed.get(str(item.get("target")), {})
            rain_value = obs.get("rain_rate_mmh")
            vmi_value = obs.get("vmi_dbz")
            event = bool(rain_value >= rain_threshold) if rain_value is not None else bool(vmi_value is not None and vmi_value >= 35.0)
            probability = max(0.0, min(1.0, float(item.get("probability_percent", 0.0)) / 100.0))
            _append_jsonl(archive, {
                "kind": "outcome", "forecast_id": item.get("forecast_id"), "model": item.get("model"),
                "lead_minutes": item.get("lead_minutes"), "target": item.get("target"),
                "probability_percent": round(probability * 100, 1), "event_observed": event,
                "brier": round((probability - float(event)) ** 2, 6), "observed": obs,
                "verified_at_ms": timestamp_ms,
            })
            state["outcomes"] = int(state.get("outcomes", 0) or 0) + 1
            metrics = state.setdefault("metrics", {})
            metric_key = f"{item.get('model')}|{int(item.get('lead_minutes', 0) or 0)}"
            metric = metrics.setdefault(metric_key, {"samples": 0, "brier_sum": 0.0, "correct": 0})
            metric["samples"] = int(metric.get("samples", 0) or 0) + 1
            metric["brier_sum"] = round(float(metric.get("brier_sum", 0.0) or 0.0) + (probability - float(event)) ** 2, 6)
            metric["correct"] = int(metric.get("correct", 0) or 0) + int((probability >= 0.5) == event)
        elif timestamp_ms > valid_at + 20 * 60000:
            continue
        else:
            remaining.append(item)
    if int(state.get("last_timestamp_ms", 0) or 0) != timestamp_ms:
        linda_forecasts = linda.get("forecasts", {}) if isinstance(linda.get("forecasts"), dict) else {}
        leads = [int(item) for item in lab.get("lead_minutes", [15, 30, 60, 90])]
        model_values: list[tuple[str, dict[str, Any]]] = [("ldz_operational", {})]
        if bool(linda.get("available")):
            model_values.append(("pysteps_linda", {}))
        for target in targets:
            name = str(target.name)
            for model, _unused in model_values:
                values = operational.get(name, {}) if model == "ldz_operational" else linda_forecasts.get(name, {})
                for lead in leads:
                    if model == "pysteps_linda" and (not isinstance(values, dict) or str(lead) not in values):
                        continue
                    raw = values.get(str(lead), 0.0) if isinstance(values, dict) else 0.0
                    probability = raw.get("probability_percent", 0.0) if isinstance(raw, dict) else raw
                    forecast_id = f"{timestamp_ms}:{model}:{name}:{lead}"
                    row = {
                        "kind": "forecast", "forecast_id": forecast_id, "model": model, "target": name,
                        "lead_minutes": lead, "probability_percent": round(float(probability or 0.0), 1),
                        "issued_at_ms": timestamp_ms, "valid_at_ms": timestamp_ms + lead * 60000,
                        "affects_alerts": False,
                        "source_is_operational": model == "ldz_operational",
                    }
                    _append_jsonl(archive, row)
                    remaining.append(row)
                    state["forecasts"] = int(state.get("forecasts", 0) or 0) + 1
        state["last_timestamp_ms"] = timestamp_ms
    state["pending"] = remaining[-3000:]
    _atomic_json(ledger, state)
    return {
        "observed": observed,
        "forecasts": int(state.get("forecasts", 0)),
        "outcomes": int(state.get("outcomes", 0)),
        "pending": len(state["pending"]),
        "metrics": _metric_rows(state.get("metrics", {})),
    }


def _cleanup(root: Path, retention_days: int, maximum_mb: int) -> None:
    cutoff = _utc_now() - timedelta(days=max(7, min(365, retention_days)))
    files = [path for path in root.rglob("*") if path.is_file() and not path.is_symlink()]
    for path in files:
        if path.name.startswith("events-") and datetime.fromtimestamp(path.stat().st_mtime, timezone.utc) < cutoff:
            path.unlink(missing_ok=True)
    limit = max(100, min(8192, maximum_mb)) * 1024 * 1024
    protected = {"status.json", "ledger.json"}
    files = sorted((path for path in root.rglob("*") if path.is_file() and not path.is_symlink() and path.name not in protected), key=lambda path: path.stat().st_mtime)
    total = sum(path.stat().st_size for path in files)
    for path in files:
        if total <= limit:
            break
        size = path.stat().st_size
        path.unlink(missing_ok=True)
        total -= size


def update_weather_lab(cfg: dict[str, Any], targets: list[Any], ref: dict[str, Any], arrays: dict[str, np.ndarray], precision_forecasts: dict[str, dict[str, Any]], timestamp_ms: int) -> dict[str, Any]:
    lab = cfg.get("weather_lab", {}) if isinstance(cfg.get("weather_lab"), dict) else {}
    enabled = bool(lab.get("enabled", True))
    root = Path(lab.get("data_dir") or (Path(cfg["app"]["data_dir"]) / "weather-lab"))
    status_path = root / "status.json"
    previous = _read_json(status_path)
    status: dict[str, Any] = {
        "enabled": enabled, "mode": "shadow", "affects_alerts": False,
        "status": "collecting" if enabled else "disabled",
        "status_label": "Raccolta dati in corso" if enabled else "Disattivato",
        "updated_utc": _utc_now().isoformat(),
    }
    if not enabled:
        _atomic_json(status_path, status)
        return status
    rain_field = arrays.get("SRI")
    radar_field = rain_field if rain_field is not None else arrays.get("VMI")
    product = "SRI" if rain_field is not None else "VMI"
    if radar_field is None:
        status.update(status="waiting", status_label="Attesa dati radar")
        _atomic_json(status_path, status)
        return status
    if rain_field is None:
        linda = {
            "enabled": bool((lab.get("linda", {}) or {}).get("enabled", True)),
            "mode": "shadow", "affects_alerts": False, "available": False,
            "status": "waiting_sri", "status_label": "Attesa prodotto pioggia SRI",
        }
    else:
        linda = _run_linda(root, rain_field, ref, targets, timestamp_ms, cfg)
    leads = [int(item) for item in lab.get("lead_minutes", [15, 30, 60, 90])]
    operational = _operational_probabilities(precision_forecasts, targets, leads)
    archive = _archive_and_verify(root, targets, ref, arrays, timestamp_ms, operational, linda, cfg)
    meteohub = sync_meteohub(lab, root, previous.get("meteohub", {}))
    status.update(
        radar={"available": True, "product": product, "timestamp_ms": timestamp_ms},
        linda=linda, meteohub=meteohub, archive=archive,
        status="ready", status_label="Weather Lab operativo",
    )
    _cleanup(root, int(lab.get("retention_days", 90) or 90), int(lab.get("maximum_total_mb", 1024) or 1024))
    _atomic_json(status_path, status)
    return status


__all__ = [
    "METEOHUB_ROOT", "MeteoHubClient", "WeatherLabError", "load_meteohub_credentials",
    "sync_meteohub", "update_weather_lab",
]
