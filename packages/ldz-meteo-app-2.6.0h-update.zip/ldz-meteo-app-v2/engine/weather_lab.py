#!/usr/bin/env python3
"""Weather Lab shadow collectors for LDZ Meteo.

This module is deliberately isolated from the operational alert path.  Every
result it produces is labelled ``affects_alerts=False`` and failures are
reported in its own status file without stopping the radar cycle.
"""
from __future__ import annotations

import base64
import fcntl
import hashlib
import importlib.metadata
import json
import math
import os
import re
import signal
import stat
import sys
import tempfile
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import quote

import numpy as np
import requests


METEOHUB_ROOT = "https://meteohub.agenziaitaliameteo.it"
METEOHUB_LOGIN = f"{METEOHUB_ROOT}/auth/login"
METEOHUB_REQUESTS = f"{METEOHUB_ROOT}/api/requests"
METEOHUB_SCHEDULES = f"{METEOHUB_ROOT}/api/schedules"
METEOHUB_USAGE = f"{METEOHUB_ROOT}/api/usage"
METEOHUB_HOURLY = f"{METEOHUB_ROOT}/api/hourly"
METEOHUB_DATA = f"{METEOHUB_ROOT}/api/data"
SUPPORTED_MODELS = ("WRF_DA_ITA", "ICON-2I-RUC")


class WeatherLabError(RuntimeError):
    pass


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", delete=False, dir=path.parent, encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")
        temporary = Path(handle.name)
    temporary.chmod(0o600)
    temporary.replace(path)


def _read_json(path: Path, default: dict[str, Any] | None = None) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else (default or {})
    except Exception:
        return default or {}


def _append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_APPEND | os.O_CREAT
    if hasattr(os, "O_CLOEXEC"):
        flags |= os.O_CLOEXEC
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    fd = os.open(path, flags, 0o600)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise WeatherLabError("archivio Weather Lab non regolare")
        fcntl.flock(fd, fcntl.LOCK_EX)
        data = (json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _decode_secret(value: str) -> str:
    if not value:
        return ""
    try:
        return base64.b64decode(value.encode("ascii"), validate=True).decode("utf-8")
    except Exception:
        return ""


def load_meteohub_credentials(path: Path) -> tuple[str, str]:
    if not path.is_file() or path.is_symlink():
        return "", ""
    values: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if "=" not in raw or raw.lstrip().startswith("#"):
            continue
        key, value = raw.split("=", 1)
        values[key.strip()] = value.strip()
    return _decode_secret(values.get("METEOHUB_USERNAME_B64", "")), _decode_secret(values.get("METEOHUB_PASSWORD_B64", ""))


def _token(payload: Any) -> str:
    # MeteoHub 0.5.7 returns the access token as the JSON response itself
    # (a JSON string), while older/alternate deployments may wrap it in an
    # object.  Accept both contracts without ever persisting the token.
    if isinstance(payload, str):
        return payload.strip()
    if isinstance(payload, dict):
        for key in ("access_token", "accessToken", "token"):
            if isinstance(payload.get(key), str) and payload[key].strip():
                return payload[key].strip()
        for key in ("data", "result", "response", "payload"):
            found = _token(payload.get(key))
            if found:
                return found
    return ""


def _json_response(response: requests.Response, label: str) -> Any:
    if len(response.content) > 2 * 1024 * 1024:
        raise WeatherLabError(f"{label}: risposta troppo grande")
    if response.status_code in (401, 403):
        raise WeatherLabError("Credenziali MeteoHub non accettate")
    if response.status_code == 429:
        raise WeatherLabError("Limite orario MeteoHub raggiunto")
    if 300 <= response.status_code < 400:
        raise WeatherLabError(f"{label}: reindirizzamento non consentito")
    response.raise_for_status()
    try:
        return response.json()
    except ValueError as exc:
        raise WeatherLabError(f"{label}: risposta non valida") from exc


def _quota_summary(payload: Any) -> dict[str, float | int]:
    """Keep only bounded numeric quota counters; never persist account fields."""
    allowed = {"used", "remaining", "limit", "quota", "total", "requests", "count", "bytes", "used_bytes", "remaining_bytes"}
    if not isinstance(payload, dict):
        return {}
    result: dict[str, float | int] = {}
    for key, value in payload.items():
        normalized = str(key).strip().lower()
        if normalized not in allowed or isinstance(value, bool) or not isinstance(value, (int, float)):
            continue
        if math.isfinite(float(value)) and 0 <= float(value) <= 10**15:
            result[normalized] = value
    return result


class MeteoHubClient:
    """Small fixed-origin MeteoHub client; tokens never touch disk or logs."""

    def __init__(self, username: str, password: str, *, timeout: int = 25) -> None:
        self.username = username.strip()
        self.password = password
        self.timeout = max(5, min(60, int(timeout)))
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "LDZMeteoApp/2.6.0h WeatherLab", "Accept": "application/json"})

    def login(self) -> None:
        if not self.username or not self.password:
            raise WeatherLabError("Credenziali MeteoHub mancanti")
        response = self.session.post(
            METEOHUB_LOGIN,
            json={"username": self.username, "password": self.password},
            timeout=self.timeout,
            allow_redirects=False,
        )
        payload = _json_response(response, "Login MeteoHub")
        token = _token(payload)
        if not token or len(token) > 16384:
            raise WeatherLabError("MeteoHub non ha restituito un token utilizzabile")
        self.session.headers["Authorization"] = f"Bearer {token}"

    def get_json(self, url: str, label: str) -> Any:
        if not url.startswith(f"{METEOHUB_ROOT}/"):
            raise WeatherLabError("Endpoint MeteoHub non consentito")
        return _json_response(self.session.get(url, timeout=self.timeout, allow_redirects=False), label)

    def post_json(self, url: str, payload: dict[str, Any], label: str) -> Any:
        if url not in {METEOHUB_DATA, METEOHUB_SCHEDULES}:
            raise WeatherLabError("Endpoint MeteoHub non consentito")
        return _json_response(
            self.session.post(url, json=payload, timeout=self.timeout, allow_redirects=False), label
        )

    def connection_snapshot(self) -> dict[str, Any]:
        self.login()
        requests_payload = self.get_json(METEOHUB_REQUESTS, "Richieste MeteoHub")
        usage = self.get_json(METEOHUB_USAGE, "Quota MeteoHub")
        hourly = self.get_json(METEOHUB_HOURLY, "Limite MeteoHub")
        return {"requests": requests_payload, "usage": usage, "hourly": hourly}

    def create_on_data_ready_schedule(self, payload: dict[str, Any]) -> Any:
        """Create only an explicit, operator-supplied forecast template."""
        request_name = str(payload.get("request_name") or "")
        datasets = payload.get("dataset_names")
        if not request_name.startswith("LDZ-") or not isinstance(datasets, list) or not datasets:
            raise WeatherLabError("Template MeteoHub LDZ incompleto")
        if payload.get("on-data-ready") is not True:
            raise WeatherLabError("Il template forecast deve usare on-data-ready")
        clean = json.loads(json.dumps(payload))
        if len(json.dumps(clean)) > 256 * 1024:
            raise WeatherLabError("Template MeteoHub troppo grande")
        return self.post_json(METEOHUB_SCHEDULES, clean, "Pianificazione MeteoHub")

    def download(self, filename: str, destination: Path, maximum_bytes: int) -> int:
        safe = Path(filename).name
        if not safe or safe != filename or safe in (".", ".."):
            raise WeatherLabError("Nome file MeteoHub non valido")
        url = f"{METEOHUB_DATA}/{quote(safe, safe='')}"
        response = self.session.get(url, timeout=max(30, self.timeout), allow_redirects=False, stream=True)
        if response.status_code in (401, 403):
            raise WeatherLabError("Sessione MeteoHub scaduta")
        if 300 <= response.status_code < 400:
            raise WeatherLabError("Reindirizzamento download MeteoHub non consentito")
        response.raise_for_status()
        declared = int(response.headers.get("Content-Length") or 0)
        if declared > maximum_bytes:
            raise WeatherLabError("File MeteoHub oltre il limite LDZ configurato")
        destination.parent.mkdir(parents=True, exist_ok=True)
        total = 0
        with tempfile.NamedTemporaryFile("wb", delete=False, dir=destination.parent) as handle:
            temporary = Path(handle.name)
            for chunk in response.iter_content(1024 * 1024):
                if not chunk:
                    continue
                total += len(chunk)
                if total > maximum_bytes:
                    handle.close()
                    temporary.unlink(missing_ok=True)
                    raise WeatherLabError("Download MeteoHub interrotto: limite LDZ superato")
                handle.write(chunk)
        temporary.chmod(0o600)
        temporary.replace(destination)
        return total


def inspect_meteohub_file(path: Path, targets: Iterable[Any], model: str = "") -> dict[str, Any]:
    """Apre davvero NetCDF/GRIB; non restituisce mai uno stato pronto per estensione."""
    try:
        import xarray as xr
    except Exception:
        return {
            "status": "processing_not_configured",
            "status_label": "Download disponibile, elaborazione non configurata",
            "reason": "xarray_not_installed",
        }
    suffix = path.suffix.lower()
    engine = "cfgrib" if suffix in {".grib", ".grib2", ".grb", ".grb2"} else None
    try:
        dataset = xr.open_dataset(path, engine=engine, backend_kwargs={"indexpath": ""}) if engine else xr.open_dataset(path)
        try:
            latitude_name = next((name for name in ("latitude", "lat", "y") if name in dataset.coords), "")
            longitude_name = next((name for name in ("longitude", "lon", "x") if name in dataset.coords), "")
            if not latitude_name or not longitude_name:
                raise WeatherLabError("coordinate geografiche non riconosciute")
            useful_names = [
                name for name in dataset.data_vars
                if any(token in name.lower() for token in ("precip", "rain", "tp", "cape", "wind", "gust", "hail"))
            ]
            inspected_names = useful_names or list(dataset.data_vars)
            variables: list[dict[str, Any]] = []
            for name in inspected_names[:12]:
                variable = dataset[name]
                variables.append({
                    "name": str(name)[:100],
                    "units": str(variable.attrs.get("units", ""))[:50],
                    "dimensions": [str(item)[:50] for item in variable.dims],
                })
            target_points: list[dict[str, Any]] = []
            verification_forecasts: dict[str, dict[str, Any]] = {}
            for target in targets:
                row: dict[str, Any] = {"target": str(target.name)[:100], "values": {}}
                for name in inspected_names[:8]:
                    try:
                        selected = dataset[name].sel(
                            {latitude_name: float(target.lat), longitude_name: float(target.lon)}, method="nearest"
                        )
                        values = np.asarray(selected.values).reshape(-1)
                        finite = [float(item) for item in values[:32] if np.isfinite(item)]
                        if finite:
                            row["values"][name] = finite[:8]
                    except Exception:
                        continue
                target_points.append(row)
                probability_variables = [
                    name for name in inspected_names
                    if "prob" in name.lower() and any(token in name.lower() for token in ("precip", "rain", "tp"))
                ]
                deterministic_variables = [
                    name for name in inspected_names
                    if "prob" not in name.lower() and (name.lower() == "tp" or "precip" in name.lower() or "rain" in name.lower())
                ]
                verification_variable = (probability_variables or deterministic_variables or [""])[0]
                if verification_variable:
                    variable = dataset[verification_variable]
                    units = str(variable.attrs.get("units", "")).strip().lower()
                    for hours in (1, 3, 6):
                        try:
                            selected = variable.sel(
                                {latitude_name: float(target.lat), longitude_name: float(target.lon)}, method="nearest"
                            )
                            if "step" not in selected.coords:
                                continue
                            selected = selected.sel(step=np.timedelta64(hours, "h"), method="nearest")
                            chosen_step = np.asarray(selected.coords["step"].values).astype("timedelta64[s]").astype("int64").reshape(-1)[0]
                            if abs(int(chosen_step) - hours * 3600) > 45 * 60:
                                continue
                            values = np.asarray(selected.values, dtype="float64").reshape(-1)
                            finite = [float(item) for item in values if np.isfinite(item)]
                            if not finite:
                                continue
                            deterministic = verification_variable in deterministic_variables
                            if deterministic:
                                if units in {"m", "metre", "meter"}:
                                    amount_mm = finite[0] * 1000.0
                                elif units in {"mm", "kg m-2", "kg m**-2", "kg/m^2", "mm h-1", "mm/hr"}:
                                    amount_mm = finite[0]
                                else:
                                    continue
                                raw_probability = 100.0 if amount_mm >= 2.0 else 0.0
                            else:
                                raw_probability = finite[0] * (100.0 if units in {"1", "fraction", "proportion"} else 1.0)
                            if 0.0 <= raw_probability <= 100.0:
                                verification_forecasts.setdefault(str(target.name), {})[str(hours * 60)] = {
                                    "probability_percent": round(raw_probability, 1),
                                    "source_variable": str(verification_variable)[:100],
                                    "deterministic_binary_event": deterministic,
                                    **({"precipitation_mm": round(amount_mm, 3)} if deterministic else {}),
                                }
                        except Exception:
                            continue
            time_coordinates = [str(name) for name in ("time", "valid_time", "step") if name in dataset.coords]
            latitude_values = np.asarray(dataset.coords[latitude_name].values, dtype="float64")
            longitude_values = np.asarray(dataset.coords[longitude_name].values, dtype="float64")
            if not np.all(np.isfinite(latitude_values)) or not np.all(np.isfinite(longitude_values)):
                raise WeatherLabError("coordinate non finite")
            if np.nanmin(latitude_values) < -90 or np.nanmax(latitude_values) > 90:
                raise WeatherLabError("latitudine fuori intervallo")
            if np.nanmin(longitude_values) < -360 or np.nanmax(longitude_values) > 360:
                raise WeatherLabError("longitudine fuori intervallo")
            return {
                "status": "parsed",
                "status_label": "File analizzato",
                "parser": "cfgrib" if engine else "xarray",
                "variables": variables,
                "coordinate_names": {"latitude": latitude_name, "longitude": longitude_name, "time": time_coordinates},
                "coordinate_ranges": {
                    "latitude": [float(np.nanmin(latitude_values)), float(np.nanmax(latitude_values))],
                    "longitude": [float(np.nanmin(longitude_values)), float(np.nanmax(longitude_values))],
                },
                "targets": target_points,
                "model": model,
                "verification_forecasts": verification_forecasts,
                "evaluation_horizons_hours": [1, 3, 6],
                "weather_variables_found": bool(useful_names),
            }
        finally:
            dataset.close()
    except Exception as exc:
        return {
            "status": "processing_error",
            "status_label": "Download disponibile, elaborazione da verificare",
            "reason": type(exc).__name__,
        }


def _rows(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if isinstance(payload, dict):
        for key in ("requests", "items", "results", "data"):
            if isinstance(payload.get(key), list):
                return [item for item in payload[key] if isinstance(item, dict)]
    return []


def _request_is_weather_lab(item: dict[str, Any]) -> bool:
    text = json.dumps(item, ensure_ascii=False).upper()
    name = str(item.get("request_name") or item.get("name") or "").upper()
    return name.startswith("LDZ-") or any(model in text for model in SUPPORTED_MODELS)


def _request_model(item: dict[str, Any]) -> str:
    text = json.dumps(item, ensure_ascii=False).upper()
    if "WRF_DA_ITA" in text:
        return "wrf_da_ita"
    if "ICON-2I-RUC" in text or "ICON_2I_RUC" in text:
        return "icon_2i_ruc"
    return ""


def sync_meteohub(
    cfg: dict[str, Any], root: Path, previous: dict[str, Any], targets: Iterable[Any] = ()
) -> dict[str, Any]:
    source = cfg.get("meteohub", {}) if isinstance(cfg.get("meteohub"), dict) else {}
    result = dict(previous) if isinstance(previous, dict) else {}
    historical_files = [
        path for path in (root / "meteohub" / "inbox").glob("*")
        if path.is_file() and not path.is_symlink()
    ] if (root / "meteohub" / "inbox").is_dir() else []
    result.update({
        "enabled": bool(source.get("enabled", False)), "affects_alerts": False,
        "configured": False, "authenticated_now": False, "connected": False,
        "historical_download_count": len(historical_files),
        "catalog": {"status": "not_verified", "reason": "official_catalog_endpoint_not_documented"},
        "scheduling": {"status": "template_required", "mode": "on-data-ready", "requests_created": 0},
    })
    if not result["enabled"]:
        result.update(status="disabled", status_label="Disattivato", configured=False, authenticated_now=False, connected=False)
        return result
    interval = max(15, min(360, int(source.get("sync_minutes", 30) or 30)))
    now = time.time()
    if now - float(result.get("last_attempt_epoch", 0) or 0) < interval * 60:
        return result
    result["last_attempt_epoch"] = now
    secret_path = Path(os.environ.get("LDZ_METEO_METEOHUB_SECRETS", "/etc/meteo-alert/meteohub.env"))
    username, password = load_meteohub_credentials(secret_path)
    if not username or not password:
        result.update(
            status="credentials_missing", status_label="Account da collegare", error="",
            configured=False, authenticated_now=False, connected=False,
            last_error="Credenziali mancanti", data_freshness="non disponibile",
        )
        return result
    result["configured"] = True
    try:
        client = MeteoHubClient(username, password)
        snapshot = client.connection_snapshot()
        templates = source.get("request_templates") if isinstance(source.get("request_templates"), list) else []
        created_fingerprints = set(str(value) for value in result.get("schedule_fingerprints", []) if value)
        schedules_created = 0
        for template in templates[:2]:
            if not isinstance(template, dict):
                continue
            fingerprint = hashlib.sha256(json.dumps(template, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
            if fingerprint in created_fingerprints:
                continue
            client.create_on_data_ready_schedule(template)
            created_fingerprints.add(fingerprint)
            schedules_created += 1
        requests_rows = [item for item in _rows(snapshot["requests"]) if _request_is_weather_lab(item)]
        downloaded = set(str(item) for item in result.get("downloaded_files", []) if item)
        max_bytes = max(16, min(1024, int(source.get("maximum_file_mb", 256) or 256))) * 1024 * 1024
        inbox = root / "meteohub" / "inbox"
        model_results = dict(result.get("model_results", {})) if isinstance(result.get("model_results"), dict) else {}
        for item in requests_rows:
            status = str(item.get("status") or item.get("state") or "").upper()
            filename = str(item.get("fileoutput") or item.get("filename") or "").strip()
            if status not in ("SUCCESS", "COMPLETED", "DONE") or not filename or filename in downloaded:
                continue
            destination = inbox / Path(filename).name
            client.download(filename, destination, max_bytes)
            downloaded.add(filename)
            model = _request_model(item)
            processing = inspect_meteohub_file(destination, targets, model=model)
            result["last_download"] = {
                "filename": destination.name,
                "sha256": _sha256_file(destination),
                "bytes": destination.stat().st_size,
                "processing": processing,
            }
            if model:
                model_results[model] = processing
        newest = max(historical_files + [path for path in inbox.glob("*") if path.is_file() and not path.is_symlink()], key=lambda path: path.stat().st_mtime, default=None)
        freshness = None if newest is None else max(0.0, (time.time() - newest.stat().st_mtime) / 3600.0)
        result.update(
            status="authenticated",
            status_label="Autenticazione verificata · catalogo non verificato",
            connected=True,
            configured=True,
            authenticated_now=True,
            account_hint=(username[:2] + "…" + username[-2:]) if len(username) > 5 else "configurato",
            matching_requests=len(requests_rows),
            downloaded_files=sorted(downloaded)[-100:],
            downloaded_count=len(downloaded), historical_download_count=len(downloaded),
            usage=_quota_summary(snapshot.get("usage")),
            hourly=_quota_summary(snapshot.get("hourly")),
            scheduling={
                "status": "active" if created_fingerprints else "template_required",
                "mode": "on-data-ready", "requests_created": schedules_created,
                "configured_templates": len(templates),
            },
            schedule_fingerprints=sorted(created_fingerprints),
            model_results=model_results,
            last_success_utc=_utc_now().isoformat(), last_success_at=_utc_now().isoformat(),
            data_freshness="nessun file" if freshness is None else f"{freshness:.1f} ore",
            last_error="", error="",
        )
    except Exception as exc:
        result.update(
            status="error", status_label="Collegamento da verificare", connected=False,
            authenticated_now=False, last_error=str(exc)[:240], error=str(exc)[:240],
        )
    return result


def _target_value(field: np.ndarray, ref: dict[str, Any], target: Any, step: int = 1) -> float | None:
    try:
        from rasterio.transform import rowcol
        from rasterio.warp import transform as warp_transform

        lon, lat = float(target.lon), float(target.lat)
        crs = ref.get("crs")
        if crs and str(crs).upper() not in ("EPSG:4326", "OGC:CRS84"):
            xs, ys = warp_transform("EPSG:4326", crs, [lon], [lat])
            x, y = xs[0], ys[0]
        else:
            x, y = lon, lat
        row, col = rowcol(ref["transform"], x, y)
        row, col = int(row) // max(1, step), int(col) // max(1, step)
        if row < 0 or col < 0 or row >= field.shape[-2] or col >= field.shape[-1]:
            return None
        value = float(field[..., row, col])
        return value if math.isfinite(value) else None
    except Exception:
        return None


def _store_frame(
    root: Path, field: np.ndarray, timestamp_ms: int, max_grid: int, *, series: str = "radar-frames", keep: int = 4
) -> tuple[list[Path], int]:
    frames = root / series
    frames.mkdir(parents=True, exist_ok=True)
    step = max(1, int(math.ceil(max(field.shape) / max(64, max_grid))))
    compact = np.nan_to_num(field[::step, ::step].astype("float32"), nan=0.0, posinf=0.0, neginf=0.0)
    destination = frames / f"{int(timestamp_ms)}.npz"
    if not destination.exists():
        with tempfile.NamedTemporaryFile("wb", delete=False, dir=frames) as handle:
            np.savez_compressed(handle, field=compact, step=np.array([step], dtype="int16"))
            temporary = Path(handle.name)
        temporary.chmod(0o600)
        temporary.replace(destination)
    paths = sorted((p for p in frames.glob("*.npz") if p.is_file() and not p.is_symlink()), key=lambda p: int(p.stem))
    bounded_keep = max(3, min(8, int(keep)))
    for old in paths[:-bounded_keep]:
        old.unlink(missing_ok=True)
    paths = paths[-bounded_keep:]
    return paths, step


def _save_verification_field(root: Path, model: str, issued_ms: int, lead: int, field: np.ndarray, step: int, product: str) -> str:
    directory = root / "verification-fields"
    directory.mkdir(parents=True, exist_ok=True)
    destination = directory / f"{model}-{issued_ms}-{lead}.npz"
    with tempfile.NamedTemporaryFile("wb", delete=False, dir=directory) as handle:
        np.savez_compressed(
            handle, field=np.asarray(field, dtype="float32"), step=np.asarray([step], dtype="int16"),
            product=np.asarray([product]),
        )
        temporary = Path(handle.name)
    temporary.chmod(0o600)
    temporary.replace(destination)
    return str(destination)


def _memory_available_mb() -> float | None:
    try:
        for raw in Path("/proc/meminfo").read_text(encoding="ascii").splitlines():
            if raw.startswith("MemAvailable:"):
                return float(raw.split()[1]) / 1024.0
    except (OSError, ValueError, IndexError):
        return None
    return None


def _process_peak_memory_mb() -> float | None:
    try:
        import resource
        value = float(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        if sys.platform == "darwin":
            value /= 1024.0
        return round(value / 1024.0, 1)
    except Exception:
        return None


def _run_with_timeout(callback: Any, seconds: float) -> Any:
    """Timeout reale su Linux; nessun thread concorrente per i challenger."""
    bounded = max(5.0, min(180.0, float(seconds)))
    if not hasattr(signal, "SIGALRM") or threading.current_thread() is not threading.main_thread():
        return callback()
    previous = signal.getsignal(signal.SIGALRM)

    def expired(_signum: int, _frame: Any) -> None:
        raise TimeoutError(f"challenger oltre {bounded:.0f}s")

    signal.signal(signal.SIGALRM, expired)
    signal.setitimer(signal.ITIMER_REAL, bounded)
    try:
        return callback()
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous)


def _resource_gate(cfg: dict[str, Any]) -> dict[str, Any]:
    lab = cfg.get("weather_lab", {}) if isinstance(cfg.get("weather_lab"), dict) else {}
    guard = lab.get("resource_guard", {}) if isinstance(lab.get("resource_guard"), dict) else {}
    minimum_mb = max(256.0, min(1024.0, float(guard.get("minimum_available_memory_mb", 420) or 420)))
    available_mb = _memory_available_mb()
    data_dir = Path(cfg.get("app", {}).get("data_dir", "/var/lib/meteo-alert"))
    block_path = Path(guard.get("optional_jobs_block_file") or (data_dir / "optional-jobs-blocked"))
    disk_blocked = block_path.is_file() and not block_path.is_symlink()
    allowed = not disk_blocked and (available_mb is None or available_mb >= minimum_mb)
    reason = "disk_pressure" if disk_blocked else "ok" if allowed else "memory_pressure"
    return {
        "allowed": allowed,
        "available_memory_mb": None if available_mb is None else round(available_mb, 1),
        "minimum_available_memory_mb": minimum_mb,
        "reason": reason,
        "optional_jobs_blocked": disk_blocked,
    }


def fractions_skill_score(forecast: np.ndarray, observed: np.ndarray, threshold: float, scale: int = 1) -> float | None:
    """FSS deterministico su due campi allineati; None se non c'è alcun evento."""
    left = (np.nan_to_num(np.asarray(forecast, dtype="float64"), nan=0.0) >= float(threshold)).astype("float64")
    right = (np.nan_to_num(np.asarray(observed, dtype="float64"), nan=0.0) >= float(threshold)).astype("float64")
    if left.shape != right.shape or left.ndim != 2:
        raise ValueError("campi FSS non allineati")
    width = max(1, min(101, int(scale)))

    def fraction(field: np.ndarray) -> np.ndarray:
        if width == 1:
            return field
        before = width // 2
        after = width - before - 1
        padded = np.pad(field, ((before, after), (before, after)), mode="constant")
        integral = np.pad(padded.cumsum(0).cumsum(1), ((1, 0), (1, 0)), mode="constant")
        total = integral[width:, width:] - integral[:-width, width:] - integral[width:, :-width] + integral[:-width, :-width]
        return total / float(width * width)

    forecast_fraction, observed_fraction = fraction(left), fraction(right)
    denominator = float(np.mean(forecast_fraction ** 2 + observed_fraction ** 2))
    if denominator <= 0:
        return None
    return max(0.0, min(1.0, 1.0 - float(np.mean((forecast_fraction - observed_fraction) ** 2)) / denominator))


def crps_ensemble(members: Iterable[float], observed: float) -> float | None:
    values = np.asarray([float(item) for item in members if math.isfinite(float(item))], dtype="float64")
    if values.size == 0 or not math.isfinite(float(observed)):
        return None
    first = float(np.mean(np.abs(values - float(observed))))
    second = 0.5 * float(np.mean(np.abs(values[:, None] - values[None, :])))
    return max(0.0, first - second)


def ensemble_rank(members: Iterable[float], observed: float) -> int | None:
    values = sorted(float(item) for item in members if math.isfinite(float(item)))
    if not values or not math.isfinite(float(observed)):
        return None
    return sum(1 for value in values if value < float(observed))


def _relevant_rain_gate(field: np.ndarray, ref: dict[str, Any], targets: Iterable[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    lab = cfg.get("weather_lab", {}) if isinstance(cfg.get("weather_lab"), dict) else {}
    guard = lab.get("resource_guard", {}) if isinstance(lab.get("resource_guard"), dict) else {}
    rain_threshold = max(0.05, min(10.0, float(guard.get("minimum_rain_rate_mmh", 0.2) or 0.2)))
    minimum_fraction = max(0.00001, min(0.05, float(guard.get("minimum_domain_rain_fraction", 0.0005) or 0.0005)))
    radius_pixels = max(2, min(32, int(guard.get("target_window_pixels", 10) or 10)))
    clean = np.nan_to_num(np.asarray(field, dtype="float64"), nan=0.0, posinf=0.0, neginf=0.0)
    fraction = float(np.count_nonzero(clean >= rain_threshold)) / max(1, clean.size)
    relevant_pixels = 0
    relevant_max = 0.0
    try:
        from rasterio.transform import rowcol
        from rasterio.warp import transform as warp_transform
        for target in targets:
            lon, lat = float(target.lon), float(target.lat)
            crs = ref.get("crs")
            if crs and str(crs).upper() not in ("EPSG:4326", "OGC:CRS84"):
                xs, ys = warp_transform("EPSG:4326", crs, [lon], [lat])
                lon, lat = xs[0], ys[0]
            row, col = (int(value) for value in rowcol(ref["transform"], lon, lat))
            window = clean[
                max(0, row - radius_pixels):min(clean.shape[-2], row + radius_pixels + 1),
                max(0, col - radius_pixels):min(clean.shape[-1], col + radius_pixels + 1),
            ]
            if window.size:
                relevant_pixels += int(np.count_nonzero(window >= rain_threshold))
                relevant_max = max(relevant_max, float(np.max(window)))
    except Exception:
        relevant_pixels = 0
    allowed = relevant_pixels > 0 or fraction >= minimum_fraction
    return {
        "allowed": allowed,
        "reason": "ok" if allowed else "insufficient_relevant_rain",
        "domain_rain_fraction": round(fraction, 7),
        "minimum_domain_rain_fraction": minimum_fraction,
        "relevant_rain_pixels": relevant_pixels,
        "relevant_max_mmh": round(relevant_max, 2),
        "threshold_mmh": rain_threshold,
    }


def _run_linda(root: Path, field: np.ndarray, ref: dict[str, Any], targets: Iterable[Any], timestamp_ms: int, cfg: dict[str, Any]) -> dict[str, Any]:
    started = time.monotonic()
    result: dict[str, Any] = {"enabled": True, "mode": "shadow", "affects_alerts": False, "available": False, "process_peak_memory_mb": _process_peak_memory_mb()}
    lab = cfg.get("weather_lab", {}) if isinstance(cfg.get("weather_lab"), dict) else {}
    linda_cfg = lab.get("linda", {}) if isinstance(lab.get("linda"), dict) else {}
    runtime_budget = float((lab.get("resource_guard", {}) or {}).get("maximum_runtime_seconds", 55) or 55)
    if not bool(linda_cfg.get("enabled", True)):
        result.update(enabled=False, status_label="Disattivato")
        return result
    resources = _resource_gate(cfg)
    rain_gate = _relevant_rain_gate(field, ref, targets, cfg)
    result["resource_guard"] = {**resources, **rain_gate}
    if not resources["allowed"]:
        result.update(status="not_run", status_label="Non eseguito · risorse riservate agli avvisi", reason=resources["reason"], duration_seconds=round(time.monotonic() - started, 3))
        return result
    if not rain_gate["allowed"]:
        result.update(status="not_run", status_label="Non eseguito · pioggia rilevante insufficiente", reason="insufficient_relevant_rain", duration_seconds=round(time.monotonic() - started, 3))
        return result
    paths, step = _store_frame(root, field, timestamp_ms, int(linda_cfg.get("max_grid_pixels", 384) or 384))
    if len(paths) < 3:
        result.update(status="collecting", status_label=f"Raccolta frame {len(paths)}/3", frames=len(paths))
        return result
    selected = paths[-3:]
    stamps = [int(path.stem) for path in selected]
    gaps = [(stamps[index] - stamps[index - 1]) / 60000.0 for index in range(1, len(stamps))]
    timestep = float(sum(gaps) / len(gaps))
    if timestep <= 0 or max(gaps) - min(gaps) > max(2.0, timestep * 0.45):
        result.update(status="collecting", status_label="Attesa frame regolari", frames=len(paths))
        return result
    try:
        import pysteps
        from pysteps.motion import get_method as motion_method
        from pysteps.nowcasts.linda import forecast
    except Exception:
        result.update(status="unavailable", status_label="Componente LINDA non disponibile", reason="pysteps_not_installed")
        return result
    arrays = []
    stored_steps = []
    for path in selected:
        with np.load(path, allow_pickle=False) as payload:
            arrays.append(np.asarray(payload["field"], dtype="float64"))
            stored_steps.append(int(payload["step"][0]))
    if len(set(stored_steps)) != 1 or len({array.shape for array in arrays}) != 1:
        result.update(status="collecting", status_label="Griglia radar cambiata")
        return result
    stack = np.stack(arrays)
    leads = [int(item) for item in linda_cfg.get("lead_minutes", lab.get("lead_minutes", [15, 30, 60, 90])) if 5 <= int(item) <= 180]
    if np.count_nonzero(stack[-1] >= 0.2) < 8:
        result.update(status="not_run", status_label="Non eseguito · pioggia rilevante insufficiente", reason="insufficient_relevant_rain", frames=3, duration_seconds=round(time.monotonic() - started, 3))
        return result
    try:
        velocity = motion_method("constant")(stack)
        relative = [lead / timestep for lead in leads]
        members = max(4, min(20, int(linda_cfg.get("ensemble_members", 8) or 8)))
        try:
            output = _run_with_timeout(lambda: forecast(
                stack, velocity, relative, feature_method="domain", add_perturbations=True,
                n_ens_members=members, vel_pert_method=None, num_workers=1,
            ), runtime_budget)
        except TimeoutError:
            raise
        except Exception:
            output = _run_with_timeout(
                lambda: forecast(stack, velocity, relative, feature_method="domain", add_perturbations=False, num_workers=1),
                runtime_budget,
            )
        output = np.asarray(output)
        if output.ndim == 3:
            output = output[np.newaxis, ...]
        threshold = max(0.1, min(20.0, float(linda_cfg.get("event_rain_rate_mmh", 2.0) or 2.0)))
        forecasts: dict[str, Any] = {}
        for target in targets:
            per_lead: dict[str, Any] = {}
            for index, lead in enumerate(leads):
                values = []
                for member in output[:, index, :, :]:
                    value = _target_value(member, ref, target, stored_steps[0])
                    if value is not None:
                        values.append(value)
                if values:
                    per_lead[str(lead)] = {
                        "probability_percent": round(100.0 * sum(value >= threshold for value in values) / len(values), 1),
                        "median_rain_rate_mmh": round(float(np.median(values)), 2),
                        "ensemble_values_mmh": [round(float(value), 3) for value in values[:20]],
                    }
            forecasts[str(target.name)] = per_lead
        result.update(
            status="ready", status_label="Nowcast LINDA pronto", available=True,
            version=importlib.metadata.version("pysteps"), frames=3, timestep_minutes=round(timestep, 1),
            ensemble_members=int(output.shape[0]), forecasts=forecasts, generated_utc=_utc_now().isoformat(), error="",
            duration_seconds=round(time.monotonic() - started, 3),
            process_peak_memory_mb=_process_peak_memory_mb(),
        )
        result["verification_fields"] = [
            {
                "model": "pysteps_linda", "lead_minutes": lead, "product": "SRI",
                "path": _save_verification_field(root, "pysteps_linda", timestamp_ms, lead, np.mean(output[:, index], axis=0), stored_steps[0], "SRI"),
            }
            for index, lead in enumerate(leads)
        ]
    except Exception as exc:
        timed_out = isinstance(exc, TimeoutError)
        result.update(
            status="not_run" if timed_out else "error",
            status_label="Non eseguito · tempo massimo superato" if timed_out else "LINDA in attesa del prossimo ciclo",
            reason="timeout" if timed_out else type(exc).__name__,
            error=type(exc).__name__, duration_seconds=round(time.monotonic() - started, 3),
            process_peak_memory_mb=_process_peak_memory_mb(),
        )
    return result


def _run_anvil(root: Path, field: np.ndarray, ref: dict[str, Any], targets: Iterable[Any], timestamp_ms: int, cfg: dict[str, Any]) -> dict[str, Any]:
    started = time.monotonic()
    result: dict[str, Any] = {"enabled": True, "mode": "shadow", "affects_alerts": False, "available": False, "input_product": "VIL", "process_peak_memory_mb": _process_peak_memory_mb()}
    lab = cfg.get("weather_lab", {}) if isinstance(cfg.get("weather_lab"), dict) else {}
    anvil_cfg = lab.get("anvil", {}) if isinstance(lab.get("anvil"), dict) else {}
    runtime_budget = float((lab.get("resource_guard", {}) or {}).get("maximum_runtime_seconds", 55) or 55)
    if not bool(anvil_cfg.get("enabled", True)):
        result.update(enabled=False, status="disabled", status_label="Disattivato")
        return result
    resources = _resource_gate(cfg)
    result["resource_guard"] = resources
    if not resources["allowed"]:
        result.update(status="not_run", status_label="Non eseguito · risorse riservate agli avvisi", reason=resources["reason"])
        return result
    paths, step = _store_frame(root, field, timestamp_ms, int(anvil_cfg.get("max_grid_pixels", 320) or 320), series="vil-frames", keep=5)
    if len(paths) < 4:
        result.update(status="collecting", status_label=f"Raccolta VIL {len(paths)}/4", frames=len(paths))
        return result
    selected = paths[-4:]
    stamps = [int(path.stem) for path in selected]
    gaps = [(stamps[index] - stamps[index - 1]) / 60000.0 for index in range(1, len(stamps))]
    timestep = float(sum(gaps) / len(gaps))
    if timestep <= 0 or max(gaps) - min(gaps) > max(2.0, timestep * 0.45):
        result.update(status="collecting", status_label="Attesa sequenza VIL regolare", frames=len(paths))
        return result
    try:
        from pysteps.motion import get_method as motion_method
        from pysteps.nowcasts.anvil import forecast as anvil_forecast
        arrays: list[np.ndarray] = []
        stored_steps: list[int] = []
        for path in selected:
            with np.load(path, allow_pickle=False) as payload:
                arrays.append(np.asarray(payload["field"], dtype="float64"))
                stored_steps.append(int(payload["step"][0]))
        if len(set(stored_steps)) != 1 or len({array.shape for array in arrays}) != 1:
            raise WeatherLabError("griglia VIL cambiata")
        stack = np.stack(arrays)
        if np.count_nonzero(stack[-1] > 0) < 8:
            result.update(status="not_run", status_label="Non eseguito · VIL convettivo insufficiente", reason="insufficient_relevant_vil", frames=4)
            return result
        velocity = motion_method("lucaskanade")(stack)
        leads = [int(item) for item in anvil_cfg.get("lead_minutes", [15, 30, 60, 90]) if 5 <= int(item) <= 180]
        relative = [lead / timestep for lead in leads]
        output = np.asarray(_run_with_timeout(
            lambda: anvil_forecast(stack, velocity, relative, ar_order=2, num_workers=1), runtime_budget,
        ))
        forecasts: dict[str, Any] = {}
        for target in targets:
            per_lead: dict[str, Any] = {}
            for index, lead in enumerate(leads):
                value = _target_value(output[index], ref, target, stored_steps[0])
                if value is not None:
                    per_lead[str(lead)] = {
                        "vil_forecast_value": round(max(0.0, value), 2),
                        "units": "input_vil_units", "calibrated": False, "probability": False,
                    }
            forecasts[str(target.name)] = per_lead
        result.update(
            status="ready", status_label="ANVIL VIL pronto · nessun effetto sugli avvisi", available=True,
            frames=4, timestep_minutes=round(timestep, 1), forecasts=forecasts,
            version=importlib.metadata.version("pysteps"), generated_utc=_utc_now().isoformat(),
            duration_seconds=round(time.monotonic() - started, 3),
            process_peak_memory_mb=_process_peak_memory_mb(),
        )
        result["verification_fields"] = [
            {
                "model": "pysteps_anvil", "lead_minutes": lead, "product": "VIL",
                "path": _save_verification_field(root, "pysteps_anvil", timestamp_ms, lead, output[index], stored_steps[0], "VIL"),
            }
            for index, lead in enumerate(leads)
        ]
    except Exception as exc:
        timed_out = isinstance(exc, TimeoutError)
        result.update(
            status="not_run" if timed_out else "unavailable",
            status_label="Non eseguito · tempo massimo superato" if timed_out else "ANVIL non disponibile",
            reason="timeout" if timed_out else type(exc).__name__, duration_seconds=round(time.monotonic() - started, 3),
            process_peak_memory_mb=_process_peak_memory_mb(),
        )
    return result


def _operational_probabilities(forecasts: dict[str, dict[str, Any]], targets: Iterable[Any], leads: list[int]) -> dict[str, dict[str, float]]:
    result: dict[str, dict[str, float]] = {}
    for target in targets:
        candidates = [value for key, value in forecasts.items() if key.endswith("|" + str(target.name)) and isinstance(value, dict)]
        per_lead: dict[str, float] = {}
        for lead in leads:
            probabilities = []
            for item in candidates:
                eta = item.get("eta_minutes")
                eta_low = item.get("eta_low_minutes", eta)
                if eta_low is not None and float(eta_low) <= lead:
                    probabilities.append(float(item.get("impact_probability_percent", 0.0) or 0.0))
            per_lead[str(lead)] = round(max(probabilities, default=0.0), 1)
        result[str(target.name)] = per_lead
    return result


def _metric_rows(raw: Any) -> list[dict[str, Any]]:
    if not isinstance(raw, dict):
        return []
    rows = []
    for key, value in raw.items():
        if not isinstance(value, dict) or "|" not in key:
            continue
        model, lead_text = key.rsplit("|", 1)
        try:
            lead = int(lead_text)
            samples = int(value.get("samples", 0) or 0)
            brier_sum = float(value.get("brier_sum", 0.0) or 0.0)
            correct = int(value.get("correct", 0) or 0)
            positives = int(value.get("positives", 0) or 0)
            negatives = int(value.get("negatives", 0) or 0)
            tp, fp = int(value.get("tp", 0) or 0), int(value.get("fp", 0) or 0)
            fn, tn = int(value.get("fn", 0) or 0), int(value.get("tn", 0) or 0)
            climatology_brier = float(value.get("climatology_brier_sum", 0.0) or 0.0) / samples
            persistence_brier = float(value.get("persistence_brier_sum", 0.0) or 0.0) / samples
        except (TypeError, ValueError):
            continue
        if samples <= 0:
            continue
        brier = brier_sum / samples
        bss_climatology = None if climatology_brier <= 0 else 1.0 - brier / climatology_brier
        bss_persistence = None if persistence_brier <= 0 else 1.0 - brier / persistence_brier
        storms = len(set(str(item) for item in value.get("storm_ids", []) if item))
        reliability_bins = value.get("reliability_bins") if isinstance(value.get("reliability_bins"), dict) else {}
        calibration = []
        for bin_name, bin_value in sorted(reliability_bins.items()):
            if not isinstance(bin_value, dict) or int(bin_value.get("samples", 0) or 0) <= 0:
                continue
            count = int(bin_value["samples"])
            calibration.append({
                "bin": bin_name, "samples": count,
                "mean_forecast_percent": round(100.0 * float(bin_value.get("forecast_sum", 0.0) or 0.0) / count, 1),
                "observed_frequency_percent": round(100.0 * float(bin_value.get("observed_sum", 0.0) or 0.0) / count, 1),
            })
        storm_results = value.get("storm_results") if isinstance(value.get("storm_results"), dict) else {}
        independent_total = len(storm_results)
        independent_correct = sum(bool(item.get("correct")) for item in storm_results.values() if isinstance(item, dict))
        confidence_interval = _wilson_interval(independent_correct, independent_total)
        labels = {
            "ldz_operational": "LDZ Nowcast Fusion",
            "pysteps_linda": "LINDA (ombra)",
            "pysteps_anvil": "ANVIL VIL (ombra)",
            "wrf_da_ita": "WRF_DA_ITA (ombra)",
            "icon_2i_ruc": "ICON-2I-RUC (ombra)",
        }
        crps_samples = int(value.get("crps_samples", 0) or 0)
        rows.append({
            "model": model,
            "model_label": labels.get(model, f"{model} (ombra)"),
            "lead_minutes": lead,
            "samples": samples,
            "positives": positives, "negatives": negatives, "independent_storms": storms,
            "brier": round(brier, 3),
            "bss_climatology": None if bss_climatology is None else round(bss_climatology, 3),
            "bss_persistence": None if bss_persistence is None else round(bss_persistence, 3),
            "accuracy_percent": round(100.0 * correct / samples, 1),
            "precision": None if tp + fp == 0 else round(tp / (tp + fp), 3),
            "recall_pod": None if tp + fn == 0 else round(tp / (tp + fn), 3),
            "false_alarm_ratio": None if tp + fp == 0 else round(fp / (tp + fp), 3),
            "false_negative_rate": None if fn + tp == 0 else round(fn / (fn + tp), 3),
            "sharpness_stddev": round(math.sqrt(max(0.0, float(value.get("probability_sq_sum", 0.0) or 0.0) / samples - (float(value.get("probability_sum", 0.0) or 0.0) / samples) ** 2)), 3),
            "reliability": calibration,
            "crps": None if crps_samples <= 0 else round(float(value.get("crps_sum", 0.0) or 0.0) / crps_samples, 3),
            "crps_samples": crps_samples,
            "rank_histogram": value.get("rank_histogram", {}) if isinstance(value.get("rank_histogram"), dict) else {},
            "independent_event_accuracy_95ci": confidence_interval,
            "confidence_interval_basis": "independent_storm_id",
            "enough_samples": samples >= 20,
            "promotion_sample_ready": samples >= 100 and storms >= 20 and positives >= 20 and negatives >= 20,
            "promotion_eligible": bool(samples >= 100 and storms >= 20 and positives >= 20 and negatives >= 20 and bss_climatology is not None and bss_climatology >= 0.10),
        })
    return sorted(rows, key=lambda row: (row["lead_minutes"], row["model"]))


def _wilson_interval(successes: int, total: int, z: float = 1.959963984540054) -> list[float] | None:
    """Wilson 95% interval, used only after grouping correlated forecasts by storm id."""
    if total <= 0:
        return None
    proportion = max(0.0, min(1.0, float(successes) / total))
    denominator = 1.0 + z * z / total
    centre = (proportion + z * z / (2.0 * total)) / denominator
    margin = z * math.sqrt(proportion * (1.0 - proportion) / total + z * z / (4.0 * total * total)) / denominator
    return [round(max(0.0, centre - margin), 3), round(min(1.0, centre + margin), 3)]


def _archive_and_verify(root: Path, targets: Iterable[Any], ref: dict[str, Any], arrays: dict[str, np.ndarray], timestamp_ms: int, operational: dict[str, dict[str, float]], linda: dict[str, Any], cfg: dict[str, Any], challengers: dict[str, dict[str, Any]] | None = None, field_challengers: Iterable[dict[str, Any]] = ()) -> dict[str, Any]:
    lab = cfg.get("weather_lab", {}) if isinstance(cfg.get("weather_lab"), dict) else {}
    archive = root / "archive" / f"events-{datetime.fromtimestamp(timestamp_ms / 1000, timezone.utc):%Y%m%d}.jsonl"
    ledger = root / "ledger.json"
    state = _read_json(ledger, {"last_timestamp_ms": 0, "pending": [], "outcomes": 0, "forecasts": 0, "metrics": {}})
    rain = arrays.get("SRI")
    vmi = arrays.get("VMI")
    observed: dict[str, Any] = {}
    for target in targets:
        observed[str(target.name)] = {
            "rain_rate_mmh": _target_value(rain, ref, target) if rain is not None else None,
            "vmi_dbz": _target_value(vmi, ref, target) if vmi is not None else None,
        }
    pending = [item for item in state.get("pending", []) if isinstance(item, dict)]
    field_pending = [item for item in state.get("field_pending", []) if isinstance(item, dict)]
    remaining = []
    rain_threshold = float((lab.get("linda", {}) or {}).get("event_rain_rate_mmh", 2.0) or 2.0)
    for item in pending:
        valid_at = int(item.get("valid_at_ms", 0) or 0)
        if valid_at <= timestamp_ms <= valid_at + 20 * 60000:
            obs = observed.get(str(item.get("target")), {})
            rain_value = obs.get("rain_rate_mmh")
            vmi_value = obs.get("vmi_dbz")
            event = bool(rain_value >= rain_threshold) if rain_value is not None else bool(vmi_value is not None and vmi_value >= 35.0)
            probability = max(0.0, min(1.0, float(item.get("probability_percent", 0.0)) / 100.0))
            _append_jsonl(archive, {
                "kind": "outcome", "forecast_id": item.get("forecast_id"), "model": item.get("model"),
                "lead_minutes": item.get("lead_minutes"), "target": item.get("target"),
                "probability_percent": round(probability * 100, 1), "event_observed": event,
                "brier": round((probability - float(event)) ** 2, 6), "observed": obs,
                "verified_at_ms": timestamp_ms,
            })
            state["outcomes"] = int(state.get("outcomes", 0) or 0) + 1
            metrics = state.setdefault("metrics", {})
            metric_key = f"{item.get('model')}|{int(item.get('lead_minutes', 0) or 0)}"
            metric = metrics.setdefault(metric_key, {
                "samples": 0, "brier_sum": 0.0, "correct": 0,
                "positives": 0, "negatives": 0, "tp": 0, "fp": 0, "fn": 0, "tn": 0,
                "climatology_brier_sum": 0.0, "persistence_brier_sum": 0.0,
                "probability_sum": 0.0, "probability_sq_sum": 0.0,
                "reliability_bins": {}, "storm_ids": [],
                "storm_results": {},
            })
            previous_samples = int(metric.get("samples", 0) or 0)
            previous_positive = int(metric.get("positives", 0) or 0)
            climatology_probability = previous_positive / previous_samples if previous_samples else 0.10
            persistence_probability = max(0.0, min(1.0, float(item.get("persistence_probability_percent", 0.0) or 0.0) / 100.0))
            metric["samples"] = int(metric.get("samples", 0) or 0) + 1
            metric["brier_sum"] = round(float(metric.get("brier_sum", 0.0) or 0.0) + (probability - float(event)) ** 2, 6)
            metric["correct"] = int(metric.get("correct", 0) or 0) + int((probability >= 0.5) == event)
            metric["positives"] = previous_positive + int(event)
            metric["negatives"] = int(metric.get("negatives", 0) or 0) + int(not event)
            predicted = probability >= 0.5
            for key, matched in (("tp", predicted and event), ("fp", predicted and not event), ("fn", not predicted and event), ("tn", not predicted and not event)):
                metric[key] = int(metric.get(key, 0) or 0) + int(matched)
            metric["climatology_brier_sum"] = round(float(metric.get("climatology_brier_sum", 0.0) or 0.0) + (climatology_probability - float(event)) ** 2, 6)
            metric["persistence_brier_sum"] = round(float(metric.get("persistence_brier_sum", 0.0) or 0.0) + (persistence_probability - float(event)) ** 2, 6)
            metric["probability_sum"] = round(float(metric.get("probability_sum", 0.0) or 0.0) + probability, 6)
            metric["probability_sq_sum"] = round(float(metric.get("probability_sq_sum", 0.0) or 0.0) + probability * probability, 6)
            bin_name = f"{min(9, int(probability * 10)) * 10:02d}-{min(100, (min(9, int(probability * 10)) + 1) * 10):02d}"
            bins = metric.setdefault("reliability_bins", {})
            bin_state = bins.setdefault(bin_name, {"samples": 0, "forecast_sum": 0.0, "observed_sum": 0})
            bin_state["samples"] = int(bin_state.get("samples", 0) or 0) + 1
            bin_state["forecast_sum"] = round(float(bin_state.get("forecast_sum", 0.0) or 0.0) + probability, 6)
            bin_state["observed_sum"] = int(bin_state.get("observed_sum", 0) or 0) + int(event)
            storm_ids = [str(value) for value in metric.get("storm_ids", []) if value]
            storm_id = str(item.get("storm_id", ""))
            if storm_id and storm_id not in storm_ids:
                storm_ids.append(storm_id)
            metric["storm_ids"] = storm_ids[-500:]
            if storm_id:
                storm_results = metric.setdefault("storm_results", {})
                storm_results[storm_id] = {"correct": bool((probability >= 0.5) == event), "event": event}
                if len(storm_results) > 500:
                    for stale_id in list(storm_results)[:-500]:
                        storm_results.pop(stale_id, None)
            ensemble_values = item.get("ensemble_values_mmh") if isinstance(item.get("ensemble_values_mmh"), list) else []
            rain_observed = observed.get(str(item.get("target")), {}).get("rain_rate_mmh")
            if ensemble_values and rain_observed is not None:
                crps = crps_ensemble(ensemble_values, float(rain_observed))
                rank = ensemble_rank(ensemble_values, float(rain_observed))
                if crps is not None:
                    metric["crps_sum"] = round(float(metric.get("crps_sum", 0.0) or 0.0) + crps, 6)
                    metric["crps_samples"] = int(metric.get("crps_samples", 0) or 0) + 1
                if rank is not None:
                    histogram = metric.setdefault("rank_histogram", {})
                    histogram[str(rank)] = int(histogram.get(str(rank), 0) or 0) + 1
        elif timestamp_ms > valid_at + 20 * 60000:
            continue
        else:
            remaining.append(item)
    remaining_fields: list[dict[str, Any]] = []
    field_metrics = state.setdefault("field_metrics", {})
    for item in field_pending:
        valid_at = int(item.get("valid_at_ms", 0) or 0)
        forecast_path = Path(str(item.get("path") or ""))
        if valid_at <= timestamp_ms <= valid_at + 20 * 60000:
            observed_field = arrays.get(str(item.get("product") or ""))
            try:
                if observed_field is None or not forecast_path.is_file() or forecast_path.is_symlink():
                    raise WeatherLabError("campo di verifica non disponibile")
                with np.load(forecast_path, allow_pickle=False) as payload:
                    forecast_field = np.asarray(payload["field"], dtype="float64")
                    field_step = max(1, int(payload["step"][0]))
                aligned_observed = np.asarray(observed_field[::field_step, ::field_step], dtype="float64")
                if aligned_observed.shape != forecast_field.shape:
                    raise WeatherLabError("griglia di verifica cambiata")
                threshold = 2.0 if item.get("product") == "SRI" else 5.0
                scores = {str(scale): fractions_skill_score(forecast_field, aligned_observed, threshold, scale) for scale in (1, 3, 9)}
                scores = {key: value for key, value in scores.items() if value is not None}
                metric_key = f"{item.get('model')}|{int(item.get('lead_minutes', 0) or 0)}"
                metric = field_metrics.setdefault(metric_key, {"samples": 0, "fss_sum": {}})
                metric["samples"] = int(metric.get("samples", 0) or 0) + 1
                for scale, value in scores.items():
                    metric.setdefault("fss_sum", {})[scale] = round(float(metric.get("fss_sum", {}).get(scale, 0.0) or 0.0) + float(value), 6)
                _append_jsonl(archive, {
                    "kind": "field_outcome", "model": item.get("model"), "lead_minutes": item.get("lead_minutes"),
                    "product": item.get("product"), "fss": scores, "verified_at_ms": timestamp_ms,
                })
            except Exception:
                pass
            finally:
                forecast_path.unlink(missing_ok=True)
        elif timestamp_ms <= valid_at + 20 * 60000:
            remaining_fields.append(item)
        else:
            forecast_path.unlink(missing_ok=True)
    if int(state.get("last_timestamp_ms", 0) or 0) != timestamp_ms:
        linda_forecasts = linda.get("forecasts", {}) if isinstance(linda.get("forecasts"), dict) else {}
        leads = [int(item) for item in lab.get("lead_minutes", [15, 30, 60, 90])]
        model_values: list[tuple[str, dict[str, Any]]] = [("ldz_operational", operational)]
        if bool(linda.get("available")):
            model_values.append(("pysteps_linda", linda_forecasts))
        for model, values in (challengers or {}).items():
            if model in {"pysteps_anvil", "wrf_da_ita", "icon_2i_ruc"} and isinstance(values, dict):
                model_values.append((model, values))
        for target in targets:
            name = str(target.name)
            for model, model_forecasts in model_values:
                values = model_forecasts.get(name, {}) if isinstance(model_forecasts, dict) else {}
                model_leads = leads
                if model in {"wrf_da_ita", "icon_2i_ruc"} and isinstance(values, dict):
                    model_leads = sorted({int(value) for value in values if str(value).isdigit() and int(value) in (60, 180, 360)})
                for lead in model_leads:
                    if model != "ldz_operational" and (not isinstance(values, dict) or str(lead) not in values):
                        continue
                    raw = values.get(str(lead), 0.0) if isinstance(values, dict) else 0.0
                    probability = raw.get("probability_percent", 0.0) if isinstance(raw, dict) else raw
                    forecast_id = f"{timestamp_ms}:{model}:{name}:{lead}"
                    row = {
                        "kind": "forecast", "forecast_id": forecast_id, "model": model, "target": name,
                        "lead_minutes": lead, "probability_percent": round(float(probability or 0.0), 1),
                        "issued_at_ms": timestamp_ms, "valid_at_ms": timestamp_ms + lead * 60000,
                        "affects_alerts": False,
                        "source_is_operational": model == "ldz_operational",
                        "persistence_probability_percent": 100.0 if bool(
                            observed.get(name, {}).get("rain_rate_mmh") is not None and
                            observed.get(name, {}).get("rain_rate_mmh") >= rain_threshold
                        ) else 0.0,
                        "storm_id": f"{name}:{datetime.fromtimestamp(timestamp_ms / 1000, timezone.utc):%Y%m%d}",
                        "season": ("winter" if datetime.fromtimestamp(timestamp_ms / 1000, timezone.utc).month in (12, 1, 2) else "spring" if datetime.fromtimestamp(timestamp_ms / 1000, timezone.utc).month in (3, 4, 5) else "summer" if datetime.fromtimestamp(timestamp_ms / 1000, timezone.utc).month in (6, 7, 8) else "autumn"),
                        "severity": "high" if float(probability or 0.0) >= 70 else "medium" if float(probability or 0.0) >= 40 else "low",
                    }
                    if isinstance(raw, dict) and isinstance(raw.get("ensemble_values_mmh"), list):
                        row["ensemble_values_mmh"] = raw["ensemble_values_mmh"][:20]
                    _append_jsonl(archive, row)
                    remaining.append(row)
                    state["forecasts"] = int(state.get("forecasts", 0) or 0) + 1
        state["last_timestamp_ms"] = timestamp_ms
        for item in field_challengers:
            if not isinstance(item, dict) or item.get("model") not in {"pysteps_linda", "pysteps_anvil"}:
                continue
            lead = int(item.get("lead_minutes", 0) or 0)
            path = Path(str(item.get("path") or ""))
            if lead not in leads or not path.is_file() or path.is_symlink():
                continue
            remaining_fields.append({
                "model": item["model"], "lead_minutes": lead, "product": str(item.get("product") or ""),
                "path": str(path), "issued_at_ms": timestamp_ms, "valid_at_ms": timestamp_ms + lead * 60000,
            })
    state["pending"] = remaining[-3000:]
    state["field_pending"] = remaining_fields[-100:]
    _atomic_json(ledger, state)
    return {
        "observed": observed,
        "forecasts": int(state.get("forecasts", 0)),
        "outcomes": int(state.get("outcomes", 0)),
        "pending": len(state["pending"]),
        "metrics": _metric_rows(state.get("metrics", {})),
        "field_metrics": [
            {
                "model": key.rsplit("|", 1)[0], "lead_minutes": int(key.rsplit("|", 1)[1]),
                "samples": int(value.get("samples", 0) or 0),
                "fss": {scale: round(float(total) / max(1, int(value.get("samples", 0) or 0)), 3) for scale, total in (value.get("fss_sum", {}) or {}).items()},
            }
            for key, value in sorted(field_metrics.items()) if isinstance(value, dict) and "|" in key
        ],
    }


def _cleanup(root: Path, retention_days: int, maximum_mb: int) -> None:
    cutoff = _utc_now() - timedelta(days=max(7, min(365, retention_days)))
    files = [path for path in root.rglob("*") if path.is_file() and not path.is_symlink()]
    for path in files:
        if path.name.startswith("events-") and datetime.fromtimestamp(path.stat().st_mtime, timezone.utc) < cutoff:
            path.unlink(missing_ok=True)
    limit = max(100, min(8192, maximum_mb)) * 1024 * 1024
    protected = {"status.json", "ledger.json"}
    files = sorted((path for path in root.rglob("*") if path.is_file() and not path.is_symlink() and path.name not in protected), key=lambda path: path.stat().st_mtime)
    total = sum(path.stat().st_size for path in files)
    for path in files:
        if total <= limit:
            break
        size = path.stat().st_size
        path.unlink(missing_ok=True)
        total -= size


def update_weather_lab(cfg: dict[str, Any], targets: list[Any], ref: dict[str, Any], arrays: dict[str, np.ndarray], precision_forecasts: dict[str, dict[str, Any]], timestamp_ms: int) -> dict[str, Any]:
    lab = cfg.get("weather_lab", {}) if isinstance(cfg.get("weather_lab"), dict) else {}
    enabled = bool(lab.get("enabled", True))
    root = Path(lab.get("data_dir") or (Path(cfg["app"]["data_dir"]) / "weather-lab"))
    status_path = root / "status.json"
    previous = _read_json(status_path)
    status: dict[str, Any] = {
        "enabled": enabled, "mode": "shadow", "affects_alerts": False,
        "status": "collecting" if enabled else "disabled",
        "status_label": "Raccolta dati in corso" if enabled else "Disattivato",
        "updated_utc": _utc_now().isoformat(),
    }
    if not enabled:
        _atomic_json(status_path, status)
        return status
    rain_field = arrays.get("SRI")
    radar_field = rain_field if rain_field is not None else arrays.get("VMI")
    product = "SRI" if rain_field is not None else "VMI"
    if radar_field is None:
        status.update(status="waiting", status_label="Attesa dati radar")
        _atomic_json(status_path, status)
        return status
    if rain_field is None:
        linda = {
            "enabled": bool((lab.get("linda", {}) or {}).get("enabled", True)),
            "mode": "shadow", "affects_alerts": False, "available": False,
            "status": "waiting_sri", "status_label": "Attesa prodotto pioggia SRI",
        }
    else:
        linda = _run_linda(root, rain_field, ref, targets, timestamp_ms, cfg)
    leads = [int(item) for item in lab.get("lead_minutes", [15, 30, 60, 90])]
    operational = _operational_probabilities(precision_forecasts, targets, leads)
    # I challenger sono volutamente sequenziali: prima LINDA, poi ANVIL, infine
    # l'eventuale I/O MeteoHub. Nessun job shadow compete con gli alert.
    vil_field = arrays.get("VIL")
    anvil = _run_anvil(root, vil_field, ref, targets, timestamp_ms, cfg) if vil_field is not None else {
        "enabled": True, "mode": "shadow", "affects_alerts": False, "available": False,
        "status": "waiting_vil", "status_label": "Attesa prodotto VIL",
    }
    meteohub = sync_meteohub(lab, root, previous.get("meteohub", {}), targets)
    challenger_forecasts: dict[str, dict[str, Any]] = {}
    for model, processing in (meteohub.get("model_results", {}) or {}).items():
        if model in {"wrf_da_ita", "icon_2i_ruc"} and isinstance(processing, dict):
            forecasts = processing.get("verification_forecasts")
            if isinstance(forecasts, dict):
                challenger_forecasts[model] = forecasts
    archive = _archive_and_verify(
        root, targets, ref, arrays, timestamp_ms, operational, linda, cfg,
        challengers=challenger_forecasts,
        field_challengers=[*(linda.get("verification_fields", []) or []), *(anvil.get("verification_fields", []) or [])],
    )
    status.update(
        radar={"available": True, "product": product, "timestamp_ms": timestamp_ms},
        linda=linda, anvil=anvil,
        hrd={
            "enabled": True, "mode": "shadow", "affects_alerts": False, "available": False,
            "status": "not_verified", "status_label": "Accesso/formato ufficiale non verificato",
            "reason": "official_api_product_not_listed",
        },
        meteohub=meteohub, archive=archive,
        status="ready", status_label="Weather Lab operativo",
    )
    _cleanup(root, int(lab.get("retention_days", 90) or 90), int(lab.get("maximum_total_mb", 1024) or 1024))
    _atomic_json(status_path, status)
    return status


__all__ = [
    "METEOHUB_ROOT", "MeteoHubClient", "WeatherLabError", "load_meteohub_credentials",
    "sync_meteohub", "update_weather_lab",
]
