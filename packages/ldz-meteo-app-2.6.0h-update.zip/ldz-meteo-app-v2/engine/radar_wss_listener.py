#!/usr/bin/env python3
"""Listener STOMP del WebSocket ufficiale Radar-DPC con timer di fallback."""
from __future__ import annotations

import argparse
import json
import logging
import os
import random
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

import websocket
import yaml
from build_info import configure_service_logging, log_service_start


BACKOFF_SECONDS = (10.0, 30.0, 60.0, 120.0, 300.0)


def retry_delay(failures: int, jitter: float = 1.0) -> float:
    base = BACKOFF_SECONDS[min(max(0, int(failures) - 1), len(BACKOFF_SECONDS) - 1)]
    return max(1.0, min(360.0, base * max(0.8, min(1.2, float(jitter)))))


def atomic_state(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise OSError("state WebSocket symlink non consentito")
    with tempfile.NamedTemporaryFile("w", delete=False, dir=str(path.parent), encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
        temporary = Path(handle.name)
    temporary.chmod(0o600)
    temporary.replace(path)


def parse_stomp_frame(frame: str | bytes) -> tuple[str, dict[str, str], str]:
    text = frame.decode("utf-8", errors="replace") if isinstance(frame, bytes) else str(frame)
    text = text.rstrip("\x00")
    if text in {"", "\n"}:
        return "HEARTBEAT", {}, ""
    head, _, body = text.partition("\n\n")
    lines = head.splitlines()
    command = lines[0].strip() if lines else ""
    headers: dict[str, str] = {}
    for line in lines[1:]:
        if ":" in line:
            key, value = line.split(":", 1)
            headers[key.strip()] = value.strip()
    return command, headers, body.strip()


def message_product(frame: str | bytes) -> dict[str, Any] | None:
    command, _, body = parse_stomp_frame(frame)
    if command != "MESSAGE" or not body:
        return None
    try:
        payload = json.loads(body)
        return payload if isinstance(payload, dict) else None
    except Exception:
        return None


def run_engine(config_path: Path, engine_path: Path, settle_seconds: float) -> int:
    time.sleep(max(0.0, min(90.0, settle_seconds)))
    result = subprocess.run(
        [sys.executable, str(engine_path), "--config", str(config_path)],
        check=False,
        timeout=300,
        env=os.environ.copy(),
    )
    return int(result.returncode)


def listen(config_path: Path, engine_path: Path) -> int:
    cfg = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    radar = cfg.get("radar", {})
    wss = cfg.get("radar_websocket", {})
    if not bool(wss.get("enabled", True)):
        logging.info("Radar-DPC WebSocket disattivato; resta il timer fallback")
        return 0
    url = str(wss.get("url", "wss://radar-wss.protezionecivile.it"))
    settle = float(wss.get("settle_seconds", 35) or 35)
    trigger_product = str(wss.get("trigger_product", "VMI"))
    circuit_after = max(3, min(20, int(wss.get("circuit_breaker_failures", 5) or 5)))
    circuit_seconds = max(300.0, min(3600.0, float(wss.get("circuit_breaker_seconds", 900) or 900)))
    summary_seconds = max(300.0, min(3600.0, float(wss.get("summary_log_seconds", 900) or 900)))
    origin = str(radar.get("origin", "https://radar.protezionecivile.it"))
    user_agent = str(radar.get("user_agent", "LDZMeteoApp/2.4.0"))
    data_dir = Path(cfg.get("app", {}).get("data_dir", "/var/lib/meteo-alert"))
    state_path = data_dir / "radar-websocket-state.json"
    last_timestamp = 0
    failures = 0
    first_failure_at = 0.0
    last_summary_at = 0.0
    connected_before = False
    while True:
        ws = None
        try:
            ws = websocket.create_connection(
                url,
                timeout=45,
                origin=origin,
                header=[f"User-Agent: {user_agent}"],
                enable_multithread=False,
            )
            ws.send("CONNECT\naccept-version:1.2\nheart-beat:10000,10000\n\n\x00")
            command, _, _ = parse_stomp_frame(ws.recv())
            if command != "CONNECTED":
                raise RuntimeError(f"handshake STOMP inatteso: {command}")
            ws.send("SUBSCRIBE\nid:ldz-meteo-2.4\ndestination:/topic/product\nack:auto\n\n\x00")
            if failures or not connected_before:
                logging.info("Radar-DPC WebSocket connesso; trigger=%s fallback_timer=standby", trigger_product)
            failures = 0
            first_failure_at = 0.0
            connected_before = True
            atomic_state(state_path, {
                "connected": True, "fallback_polling_active": False, "circuit_open": False,
                "last_transition_epoch": int(time.time()), "last_product_timestamp": last_timestamp,
            })
            while True:
                raw = ws.recv()
                product = message_product(raw)
                if not product or str(product.get("productType", "")) != trigger_product:
                    continue
                timestamp = int(product.get("time", 0) or 0)
                if timestamp <= last_timestamp:
                    continue
                last_timestamp = timestamp
                atomic_state(state_path, {
                    "connected": True, "fallback_polling_active": False, "circuit_open": False,
                    "last_transition_epoch": int(time.time()), "last_product_timestamp": last_timestamp,
                })
                logging.info("nuovo prodotto %s timestamp=%s; attendo coerenza pacchetto", trigger_product, timestamp)
                code = run_engine(config_path, engine_path, settle)
                logging.info("ciclo Radar-DPC event-driven terminato code=%s", code)
        except KeyboardInterrupt:
            return 0
        except Exception as exc:
            now = time.monotonic()
            failures += 1
            first_failure_at = first_failure_at or now
            connected_before = False
            circuit_open = failures >= circuit_after
            delay = circuit_seconds if circuit_open else retry_delay(failures, random.uniform(0.85, 1.15))
            atomic_state(state_path, {
                "connected": False,
                "fallback_polling_active": True,
                "fallback_reason": "websocket_unavailable",
                "circuit_open": circuit_open,
                "failures": failures,
                "retry_after_seconds": round(delay, 1),
                "last_error_class": type(exc).__name__,
                "last_transition_epoch": int(time.time()),
                "last_product_timestamp": last_timestamp,
            })
            if failures == 1:
                logging.warning(
                    "Radar-DPC WebSocket non disponibile (%s); polling timer operativo, retry con backoff",
                    type(exc).__name__,
                )
            elif failures == circuit_after:
                logging.warning(
                    "circuit breaker WebSocket aperto dopo %d errori; polling timer resta operativo, pausa %.0fs",
                    failures, delay,
                )
            elif now - last_summary_at >= summary_seconds:
                logging.warning(
                    "riepilogo WebSocket: indisponibile da %.0fs errori=%d prossimo_retry=%.0fs polling=attivo",
                    now - first_failure_at, failures, delay,
                )
                last_summary_at = now
            time.sleep(delay)
        finally:
            if ws is not None:
                try:
                    ws.close()
                except Exception:
                    pass


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="/etc/meteo-alert/config.yml")
    parser.add_argument("--engine", default="/opt/meteo-alert/meteo_alert.py")
    args = parser.parse_args()
    configure_service_logging()
    log_service_start("radar-events")
    return listen(Path(args.config), Path(args.engine))


if __name__ == "__main__":
    raise SystemExit(main())
