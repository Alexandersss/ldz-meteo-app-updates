"""Persistenza separata per runtime volatile e storico eventi/feedback.

La migrazione dal vecchio ``state.json`` e' deliberatamente ripetibile: il
file originale viene rinominato in backup soltanto dopo che database e nuovo
runtime sono stati scritti e sincronizzati.
"""
from __future__ import annotations

import json
import os
import shutil
import sqlite3
import tempfile
from pathlib import Path
from typing import Any


SCHEMA_VERSION = "2"
DEFAULT_STATE = {"last_cells": [], "alerts": {}, "last_products": {}}
HISTORICAL_STATE_KEYS = ("precision", "verification", "requests", "request_state")


class StateStoreError(RuntimeError):
    pass


def store_paths(legacy_path: Path) -> tuple[Path, Path, Path]:
    root = legacy_path.parent
    return root / "runtime.json", root / "events.sqlite3", root / "state.pre-split.json"


def _read_json(path: Path, maximum_bytes: int = 64 * 1024 * 1024) -> dict[str, Any]:
    if not path.is_file() or path.is_symlink():
        return {}
    if path.stat().st_size > maximum_bytes:
        raise StateStoreError(f"state file troppo grande: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError) as exc:
        raise StateStoreError(f"state file corrotto: {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise StateStoreError(f"state file non valido: {path}")
    return value


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise StateStoreError(f"symlink non consentito: {path}")
    with tempfile.NamedTemporaryFile("w", delete=False, dir=str(path.parent), encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
        temporary = Path(handle.name)
    temporary.chmod(0o600)
    temporary.replace(path)


def _connect(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.is_symlink():
        raise StateStoreError(f"database symlink non consentito: {path}")
    connection = sqlite3.connect(path, timeout=15.0)
    connection.execute("PRAGMA busy_timeout=15000")
    # La VM in campo usa SQLite 3.46.1: niente WAL, cosi' non dipendiamo dalle
    # correzioni WAL recenti e il backup rimane un singolo file coerente.
    mode = str(connection.execute("PRAGMA journal_mode=DELETE").fetchone()[0]).lower()
    if mode != "delete":
        connection.close()
        raise StateStoreError(f"journal_mode SQLite inatteso: {mode}")
    connection.execute("PRAGMA synchronous=FULL")
    connection.execute("PRAGMA foreign_keys=ON")
    connection.executescript(
        """
        CREATE TABLE IF NOT EXISTS metadata (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS incidents (
            event_id TEXT PRIMARY KEY,
            target TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT '',
            feedback_status TEXT NOT NULL DEFAULT '',
            started_ms INTEGER NOT NULL DEFAULT 0,
            last_seen_ms INTEGER NOT NULL DEFAULT 0,
            updated_ms INTEGER NOT NULL DEFAULT 0,
            payload_json TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS incidents_status_idx ON incidents(status, last_seen_ms);
        CREATE INDEX IF NOT EXISTS incidents_feedback_idx ON incidents(feedback_status, updated_ms);
        CREATE INDEX IF NOT EXISTS incidents_target_idx ON incidents(target, last_seen_ms);
        CREATE TABLE IF NOT EXISTS state_records (
            namespace TEXT PRIMARY KEY,
            updated_ms INTEGER NOT NULL DEFAULT 0,
            payload_json TEXT NOT NULL
        );
        """
    )
    connection.execute(
        "INSERT INTO metadata(key, value) VALUES('schema_version', ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (SCHEMA_VERSION,),
    )
    connection.commit()
    path.chmod(0o600)
    return connection


def _incidents_from_state(state: dict[str, Any]) -> dict[str, dict[str, Any]]:
    feedback = state.get("event_feedback") if isinstance(state.get("event_feedback"), dict) else {}
    raw = feedback.get("incidents") if isinstance(feedback.get("incidents"), dict) else {}
    return {str(key): value for key, value in raw.items() if isinstance(value, dict) and str(key)}


def _write_incidents(connection: sqlite3.Connection, incidents: dict[str, dict[str, Any]]) -> None:
    keys = sorted(incidents)
    with connection:
        for event_id in keys:
            event = incidents[event_id]
            connection.execute(
                """
                INSERT INTO incidents(
                    event_id, target, status, feedback_status,
                    started_ms, last_seen_ms, updated_ms, payload_json
                ) VALUES(?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(event_id) DO UPDATE SET
                    target=excluded.target,
                    status=excluded.status,
                    feedback_status=excluded.feedback_status,
                    started_ms=excluded.started_ms,
                    last_seen_ms=excluded.last_seen_ms,
                    updated_ms=excluded.updated_ms,
                    payload_json=excluded.payload_json
                """,
                (
                    event_id,
                    str(event.get("target", ""))[:300],
                    str(event.get("status", ""))[:80],
                    str(event.get("feedback_status", ""))[:80],
                    int(event.get("started_ms", 0) or 0),
                    int(event.get("last_seen_ms", 0) or 0),
                    int(event.get("updated_ms", 0) or 0),
                    json.dumps(event, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
                ),
            )
        if keys:
            placeholders = ",".join("?" for _ in keys)
            connection.execute(f"DELETE FROM incidents WHERE event_id NOT IN ({placeholders})", keys)
        else:
            connection.execute("DELETE FROM incidents")


def _read_incidents(connection: sqlite3.Connection) -> dict[str, dict[str, Any]]:
    incidents: dict[str, dict[str, Any]] = {}
    for event_id, payload in connection.execute("SELECT event_id, payload_json FROM incidents ORDER BY event_id"):
        try:
            value = json.loads(payload)
        except (TypeError, ValueError) as exc:
            raise StateStoreError(f"payload evento corrotto: {event_id}") from exc
        if isinstance(value, dict):
            incidents[str(event_id)] = value
    return incidents


def _write_state_records(connection: sqlite3.Connection, state: dict[str, Any]) -> None:
    present: list[str] = []
    with connection:
        for namespace in HISTORICAL_STATE_KEYS:
            if namespace not in state:
                continue
            present.append(namespace)
            payload = json.dumps(state[namespace], ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            connection.execute(
                "INSERT INTO state_records(namespace, updated_ms, payload_json) VALUES(?, ?, ?) "
                "ON CONFLICT(namespace) DO UPDATE SET updated_ms=excluded.updated_ms, payload_json=excluded.payload_json",
                (namespace, int(state.get("updated_ms", 0) or 0), payload),
            )
        if present:
            placeholders = ",".join("?" for _ in present)
            connection.execute(f"DELETE FROM state_records WHERE namespace NOT IN ({placeholders})", present)
        else:
            connection.execute("DELETE FROM state_records")


def _read_state_records(connection: sqlite3.Connection) -> dict[str, Any]:
    records: dict[str, Any] = {}
    for namespace, payload in connection.execute("SELECT namespace, payload_json FROM state_records ORDER BY namespace"):
        try:
            records[str(namespace)] = json.loads(payload)
        except (TypeError, ValueError) as exc:
            raise StateStoreError(f"payload storico corrotto: {namespace}") from exc
    return records


def _runtime_only(state: dict[str, Any]) -> dict[str, Any]:
    runtime = dict(state)
    feedback = dict(runtime.get("event_feedback") or {})
    feedback.pop("incidents", None)
    runtime["event_feedback"] = feedback
    for namespace in HISTORICAL_STATE_KEYS:
        runtime.pop(namespace, None)
    runtime["state_store"] = {"schema_version": SCHEMA_VERSION, "events_backend": "sqlite-delete"}
    return runtime


def load_state(legacy_path: Path) -> dict[str, Any]:
    runtime_path, database_path, backup_path = store_paths(legacy_path)
    source_is_legacy = not runtime_path.exists() and legacy_path.exists()
    pending_legacy_rename = runtime_path.exists() and legacy_path.exists()
    base = _read_json(legacy_path if source_is_legacy else runtime_path) if (source_is_legacy or runtime_path.exists()) else dict(DEFAULT_STATE)
    incidents = _incidents_from_state(base)
    connection = _connect(database_path)
    try:
        if source_is_legacy:
            _write_incidents(connection, incidents)
            _write_state_records(connection, base)
            stored = _read_incidents(connection)
            historical = _read_state_records(connection)
            if len(stored) != len(incidents):
                raise StateStoreError("conteggio incidenti non preservato durante la migrazione")
            expected_records = sum(namespace in base for namespace in HISTORICAL_STATE_KEYS)
            if len(historical) != expected_records:
                raise StateStoreError("conteggio record storici non preservato durante la migrazione")
            _atomic_json(runtime_path, _runtime_only(base))
        else:
            stored = _read_incidents(connection)
            historical = _read_state_records(connection)
        # Se il processo si interrompe dopo il runtime atomico ma prima del
        # rename, il passaggio successivo finalizza la stessa migrazione.
        if (source_is_legacy or pending_legacy_rename) and legacy_path.exists():
            if not backup_path.exists():
                legacy_path.replace(backup_path)
            else:
                legacy_path.unlink()
    finally:
        connection.close()
    result = dict(DEFAULT_STATE)
    result.update(base)
    result.update(historical)
    feedback = dict(result.get("event_feedback") or {})
    feedback["incidents"] = stored
    result["event_feedback"] = feedback
    return result


def save_state(legacy_path: Path, state: dict[str, Any]) -> None:
    runtime_path, database_path, _ = store_paths(legacy_path)
    incidents = _incidents_from_state(state)
    connection = _connect(database_path)
    try:
        _write_incidents(connection, incidents)
        _write_state_records(connection, state)
        check = str(connection.execute("PRAGMA integrity_check").fetchone()[0])
        if check.lower() != "ok":
            raise StateStoreError(f"integrity_check SQLite fallito: {check}")
    finally:
        connection.close()
    _atomic_json(runtime_path, _runtime_only(state))


def integrity_report(legacy_path: Path) -> dict[str, Any]:
    runtime_path, database_path, backup_path = store_paths(legacy_path)
    connection = _connect(database_path)
    try:
        result = str(connection.execute("PRAGMA integrity_check").fetchone()[0])
        count = int(connection.execute("SELECT COUNT(*) FROM incidents").fetchone()[0])
        records = int(connection.execute("SELECT COUNT(*) FROM state_records").fetchone()[0])
        mode = str(connection.execute("PRAGMA journal_mode").fetchone()[0]).lower()
    finally:
        connection.close()
    return {
        "ok": result.lower() == "ok",
        "integrity_check": result,
        "journal_mode": mode,
        "incidents": count,
        "historical_records": records,
        "runtime_exists": runtime_path.is_file(),
        "legacy_backup_exists": backup_path.is_file(),
    }


def restore_legacy_backup(legacy_path: Path) -> bool:
    runtime_path, database_path, backup_path = store_paths(legacy_path)
    if not backup_path.is_file() or backup_path.is_symlink():
        return False
    if legacy_path.exists():
        raise StateStoreError(f"destinazione legacy gia' presente: {legacy_path}")
    shutil.copy2(backup_path, legacy_path)
    runtime_path.unlink(missing_ok=True)
    database_path.unlink(missing_ok=True)
    return True
