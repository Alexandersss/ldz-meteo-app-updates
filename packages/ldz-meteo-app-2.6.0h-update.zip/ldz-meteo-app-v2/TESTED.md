# LDZ Meteo App 2.6.0h - Test Evidence

## Verifica correttiva 2.6.0h

- Identità pacchetto verificata con versione visibile invariata, `BUILD_ID` immutabile, commit e SHA-256 propagati a manifest, stato updater e feed.
- Migrazione reale di uno stato oltre 3 MB con 420 incidenti: conteggi e metriche identici, ripresa idempotente dopo interruzione, SQLite integro e rollback legacy disponibile.
- Callback v2 coperte per rotazione, scadenza, evento chiuso/assente, firma o messaggio errati, replay/doppio click e finestra v1.
- Prova Linux di due processi della stessa `2.6.0h`: PID diverso, nuovo `BUILD_ID` caricato e boot ID invariato; il postflight systemd verifica inoltre PID/start timestamp/marker di ogni servizio.
- Weather Lab verificato con fixture GRIB ECMWF reale e checksum fissato, coordinate/unità controllate, LINDA asciutto/memoria/timeout, ANVIL su quattro VIL regolari, FSS/CRPS/rank e scoring separato dei cinque motori.
- Soak simulato di 24 ore (288 cicli) con coda bounded e crescita archivio sotto 5 MB nel fixture; retention e support bundle redatto superati.
- Suite locale Windows: 222 test eseguiti; i nuovi gate sono verdi. Restano attesi soltanto i casi POSIX non eseguibili senza Bash/Node/OpenSSL, permessi Unix e `fcntl`; la CI Ubuntu è il gate bloccante che deve azzerarli prima del merge.
- Bootstrap updater verificato con unità oneshot asincrona (`systemd-run --no-block`) e progresso affidato al job figlio.
- Dipendenze core verificate separatamente da pySTEPS/LINDA opzionale; un errore di compilazione LINDA non annulla il deploy.
- Popup disponibilità e operazione verificati con X accessibile, chiusura persistente durante il polling e target touch da 44 px su mobile.
- Gate esplicito `[republish-v2.6.0h]` richiesto per sostituire asset e checksum senza cambiare numero di versione.

## Verifica 2.6.0h stabile

- Archivio verificato con scadenze dovute, risultati reali, Brier aggregato e separazione completa `affects_alerts=false`.
- LINDA indisponibile escluso dall'archivio; output valido incluso soltanto con disponibilità esplicita e prodotto SRI.
- MeteoHub verificato con credenziali dedicate, filtro dei soli risultati compatibili, protezione percorso e limite file.
- Route autenticata, CSRF, credenziali non riflesse, valori server-side bounded e rendering della pagina Weather Lab verificati.
- Layout coperto da regressioni su gerarchia guidata, testi esplicativi, label, breakpoint 1100/700 px e tabella mobile a schede senza min-width residuo.
- Pre-gate locale: 173 test eseguiti con 62 skip dovuti alle dipendenze scientifiche non presenti nel runner; i test Weather Lab e Flask mirati passano usando il set di dipendenze disponibile. Il workflow release installa i requirements completi e blocca la pubblicazione se la suite integrale fallisce.
- Percorso di aggiornamento verificato: `2.6.0f < 2.6.0h`.

## Verifica 2.6.0f stabile

- Avviso iniziale, rischio aumentato, traiettoria meno probabile, chiusura evento e richiesta feedback verificati con testi Telegram bilanciati e senza gergo diagnostico in primo piano.
- Preservati HTML Telegram bilanciato, limite didascalia, callback firmate e segnalazione condizionale di grandine, fulmini e qualità dati.
- Percorso di aggiornamento verificato: `2.6.0e < 2.6.0f`.

## Verifica 2.6.0e stabile

- Dataset diagnostico reale: il vecchio batch misura `−121,42%`; il correttore residuo misura `+6,89%` sul holdout separato per track e viene correttamente respinto perché sotto `+10%` e sopra il limite falsi negativi.
- Migrazione simulata da 212 aggiornamenti legacy: influenza azzerata, pesi incompatibili rimossi, storico JSONL conservato e valutazione live ripartita senza metriche contaminate.
- Conteggio reale verificato sul dataset: 154 chiavi track-target diventano 68 track complessivi; 57 track restano nel sottoinsieme valutabile escluso il warm-up.
- Suite completa con dipendenze WebGUI/scientifiche: **185/185 test superati, nessuno skip**.

## Verifica 2.6.0d stabile

- Workflow verificato: il ramo prerelease scrive soltanto i feed Beta; i rami stabile e revisione scrivono soltanto i feed Stabile.
- Il generatore rifiuta una versione stabile richiesta con `--channel beta` e non crea il file di output.
- Il client rifiuta un feed Beta con `prerelease=false`, anche se il campo `channel` è stato falsamente impostato a `beta`.
- WebGUI verificata con etichette Stabile/Beta esclusive e protezione downgrade invariata.
- Ripristino del feed contaminato verificato su una cronologia Git sintetica: viene recuperata l'ultima vera prerelease e replicata nei due feed Beta.
- Popup globale verificato con le sole azioni “Installa ora” e “Dettagli”, mantenendo download, verifica e installazione nello stesso consenso esplicito.
- Suite completa con dipendenze WebGUI/scientifiche: **181/181 test superati, nessuno skip**.

## Verifica 2.6.0c stabile

- Due check consecutivi della stessa `version` producono chiavi di completamento diverse basate su `job_id`.
- Il test JavaScript reale viene eseguito con Node e fallisce se i due terminali vengono deduplicati come nella 2.6.0b.
- Check e download asincroni hanno un limite assoluto rispettivamente di 90 e 900 secondi, con stato `error` terminale.
- Suite completa con dipendenze WebGUI/scientifiche: **179/179 test superati, nessuno skip**.

## Verifica 2.6.0b stabile

- Check e scansione iniziale verificati come job asincroni con risposta HTTP `202`, senza bloccare l'API di telemetria.
- Conferma post-installazione verificata atomicamente: `restarting` diventa `completed` solo quando `APP_VERSION` coincide; una versione inattesa resta in attesa.
- Contaminazione tra job bloccata nel client e nel backend tramite operazione attiva e `job_id` stabile.
- Polling durante installazione/riavvio verificato senza `systemctl` per richiesta; snapshot scheduler limitato dalla cache temporale.
- Template WebGUI renderizzato e tutti gli script inline validati con `node --check`; popup e pagina includono stati running/reconnecting/completed/error e fallback `prefers-reduced-motion`.
- Suite completa con dipendenze WebGUI/scientifiche: **177/177 test superati, nessuno skip**.

## Verifica 2.6.0a stabile

- Suite completa con dipendenze WebGUI/scientifiche: **174/174 test superati, nessuno skip**.
- Audit Chromium di 18 pagine su 9 viewport (360, 390, 412, 430, 768, 1366, 1440, 1920 e 2560 px): zero overflow orizzontali, microtesti, testi trasparenti, controlli coperti e risposte pagina in errore.
- Redirect “posticipa 24h” verificato con proxy legacy: destinazione `/ldzmeteoapp/update`.
- Segmentazione multi-soglia, overlap/lineage, duplicate-frame guard, raster shadow, lifecycle al lead, copertura spaziale, fulmini univoci, SHI/POSH shadow e replay negativo coperti da regressioni sintetiche.

## Verifica 2.6.0 stabile

- Promozione verificata dalla 2.5.3 e dalla 2.6.0-beta.2 senza modifiche al motore scientifico della beta.2.
- Ordinamento verificato: `2.6.0-beta.2 < 2.6.0 < 2.6.0a < 2.6.0b < 2.6.0c < 2.6.0d < 2.6.0e < 2.6.0f < 2.6.0h`; `beta.10` è successiva a `beta.2` ma precedente alla stabile.
- Feed legacy e v2 separati: i client 2.5.x ricevono la 2.6.0 base, mentre i client 2.6.0+ accettano le revisioni letterali future.
- Validatore ZIP, asset name, feed builder, helper privilegiato e blocco downgrade testati con `2.6.0a`/`2.6.0b`.
- Suite completa con dipendenze WebGUI/scientifiche: **162/162 test superati, nessuno skip**.

## Verifica 2.6.0-beta.2

- Pacchetto operativo verificato contro la policy top-level storica della 2.5.3.
- Le note `SCIENTIFIC_METHODS_*.md` sono escluse dall'update e conservate nel sorgente completo.
- Manifest operativo e checksum sono rigenerati esclusivamente dai file realmente inclusi.
- Suite completa con dipendenze WebGUI/scientifiche: **157/157 test superati, nessuno skip**; `py_compile`, `bash -n`, `node --check` e `git diff --check`: OK.

## Verifica 2.6.0-beta.1

- Test sintetici aggiunti per qualità temporale mancante, disallineata e corrotta; proxy SITES per target; split, merge, svolta, cella stazionaria, Lightning Jump incompleto e pioggia intensa senza grandine.
- Gli indici non calibrati sono verificati come tali; nessuna percentuale grandine combinata viene emessa senza candidato feedback attivo.
- Suite completa con dipendenze WebGUI/scientifiche: **157/157 test superati, nessuno skip**.
- `py_compile`, `bash -n`, `node --check`, `git diff --check`, JSON manifest e sincronizzazione moduli bootstrap: OK.

## Verifica 2.5.1

- Suite completa locale: **148/148 test superati, nessuno skip**.
- Restore funzionale con archivio reale temporaneo, snapshot pre-restore, applicazione data-only e rollback su errore servizio: OK.
- Scheduler manuale/orario/giornaliero/settimanale in `Europe/Rome`, inclusi CET/CEST e casi prima/dopo l'orario: OK.
- Filtri data/tipo, paginazione, live refresh, anteprime canale, conferme distruttive e Kiosk operativo: test backend/rendering OK.
- `py_compile`, `bash -n`, `git diff --check` e controlli di sicurezza applicativa: OK.
- Systemd, Telegram, SMTP e webhook reali restano oggetto della validazione post-installazione autorizzata dall'amministratore.

- Backup settings bounded, timezone `Europe/Rome`, retention count/days/space, ZIP allowlist e checksum: test unitari OK.
- Landing manutenzione e API `503`, login disponibile e bypass amministratore con banner: test Flask OK.
- Template variables, paginazione bounded e redazione segreti nei log: test unitari OK.
- Webhook privato/locale bloccato e progress updater stale riportato a idle: test Flask OK.
- Scheduler updater non considera `schedule_activated_epoch` come falso controllo; prossimo controllo locale calcolato: test deterministico OK.
- Lock single-flight, unità transient univoca, snooze 1/6/24 ore, retry e dettagli tecnici: controllo unitario/statico OK.
- Installer e hotfix distribuiscono backup timer/manager e helper repair con sudoers a comandi esatti: controllo statico e `bash -n` OK.
- Login usa `login-italy-radar.jpg`; vecchia geografia SVG esclusa dal rendering; Connessione e Data stream hanno componenti animati dedicati: test DOM/CSS OK.

- Master Design implementato con DOM/CSS e asset locali; immagine completa mai usata come background: OK.
- Asset orbitale separato locale, Terra e sole leggibili senza dipendenze esterne: OK.
- Radar scenografico con Italia leggibile, eco locali, reticolo, sweep e blip dedicati: OK.
- Nessuna richiesta a `meteo-map.jpg`, `meteo.jpg`, target, celle o diagnostica dalla login: OK.
- Form mobile nel primo viewport, testato a 360/390/412/430/768 px: OK.
- Desktop confrontato a 1366×768, 1440×900, 1920×1080 e 2560×1440: OK.
- Autofill scuro, password visibility, CSRF, rate limit e remember-me: OK.

- Popup aggiornamenti globale, incluso nella pagina Aggiornamenti: rendering Flask e regressione DOM OK.
- Check, download e installazione con azioni asincrone e risposte JSON protette da CSRF: OK.
- Avanzamento reale per download, verifica, dipendenze, backup, deploy, servizi e riavvio: OK.
- Installazione in unità systemd transitoria non bloccante, con progress persistente e rollback: controllo bash/statico OK.
- Frequenze Manuale, Oraria, Giornaliera e Settimanale con minuto/orario/giorno: calcolo deterministico OK.
- Salvataggio esplicito univoco delle preferenze, controllo iniziale e visualizzazione prossimo controllo: rendering Flask OK.

- Callback accodato atomicamente prima della conferma Telegram: OK.
- Conferma persistente **“Feedback registrato”** e rimozione tastiera inline: OK.
- Prima scelta terminale, inclusa “Non ero sul posto”; sovrascrittura e dataset duplicato bloccati: OK.
- Listener systemd dedicato presente in installer, updater, diagnostica, repair e rollback: OK.
- Motore radar privo di un secondo consumer `getUpdates`; importazione coda sotto lock: OK.

- Suite completa con dipendenze WebGUI e scientifiche reali: **133/133 test superati, nessuno skip**.
- Feed pubblico stabile e beta validati con versione, nome pacchetto, dimensione e SHA-256: OK.
- Stabile rifiuta prerelease; Beta rifiuta release stabili; downgrade tra canali bloccato: OK.
- Checker privo di API privata, header Authorization, token o URL controllabili dalla WebGUI: OK.
- Redirect e download consentiti soltanto sotto la radice HTTPS LDZ Update Network: OK.
- Pagina compatta con switch accessibili, card canale e pulsante Salva a larghezza contenuto: OK.
- Output reale del checker mostrato in caso di errore; stringa generica “consulta lo stato updater” assente: OK.
- Pipeline del repository privato pubblica `stable.json`, `beta.json` e i soli pacchetti operativi nel repository pubblico dedicato: OK.

- Log reale allegato: `WARNING stato radar SITES non disponibile (HTTPError)` classificato come warning, non come errore applicativo: OK.
- Riga strutturata con livello `ERROR` continua a impostare correttamente `Rischio: Attenzione`: OK.
- Pagina Aggiornamenti con stable/beta, frequenze manuale/oraria/giornaliera/settimanale e download verificato: OK.
- Popup futuristico globale con versione, polling live ogni 5 secondi, download interattivo e rinvio di 24 ore: OK.
- Nessuna credenziale di distribuzione presente nello stato, nei log o nella riga di comando: OK.
- Helper privilegiato senza URL o argomenti utente; installazione automatica assente: OK.
- Workflow release immutabile: test e verifica archivio precedono la pubblicazione; una release esistente non viene sovrascritta: OK.

- Protocollo STOMP ufficiale Radar-DPC con `productType`, `time` e `period`: parsing OK.
- Lock anti-concorrenza tra WebSocket e timer: controllo statico e compilazione OK.
- LTG con due quadri distanti 10 minuti e ultimo dato pubblicato 13 minuti prima: età reale 13,0 min e finestra corretta OK.
- LTG oltre soglia 10 minuti: `stale=true`, escluso dai nuovi alert OK.
- Alert fulmini indica “Quadro fulmini LTG” e tempo dalla pubblicazione, non ritardo di Telegram: OK.
- Near-target con pioggia intensa e bordo eco vicino: alert al primo frame anche con traiettoria in allontanamento e baseline 10% OK.
- Previsione urgente senza fenomeno osservato: doppia conferma ancora obbligatoria OK.
- Callback Telegram firmato accettato solo dalla chat configurata; firma/chat errate rifiutate: OK.
- “Non ero sul posto” registrato ma non scritto nel dataset di verità a terra: OK.
- Chiusura incidente programma una sola domanda post-evento: OK.
- Calibrazione grandine con split cronologico 70/30, Brier migliore e guardia falsi negativi: OK.
- Influenza operativa candidata limitata dal peso 0,18 e dal delta massimo: OK.
- Pagina WebGUI Eventi & feedback, nuove impostazioni bounded, stato WebSocket/watchdog: rendering Flask reale OK.
- Policy update richiede moduli feedback, calibrazione, WebSocket e watchdog: OK.
- Installer/updater: watchdog leggibile da `meteoalert` e rollback integrale: controlli statici/bash OK.

- CAPPI verticale forte aumenta in modo limitato la stima grandine: OK.
- CAPPI verticale debole riduce in modo limitato la stima grandine: OK.
- POH resta obbligatorio per classificare alto il rischio grandine: OK.
- CAPPI assente mantiene il calcolo Hail Fusion precedente: OK.
- Evidenza CAPPI presente nel messaggio Telegram e sotto il limite caption: OK.
- CAPPI visibile in mappa, dashboard e impostazioni: controllo statico OK.
- Riapertura diretta di `/login` con cookie valido: redirect automatico alla dashboard OK.
- Cookie persistente `Path=/`, migrazione/rimozione del vecchio path applicativo: OK.
- Titolo Fusion senza suffisso `2.3.4`: OK.

- Alert fulmini autonomo inviato una sola volta per slot LGT: OK.
- Nessun duplicato quando l'alert temporalesco dello stesso ciclo include già i fulmini: OK.
- ETA radar 8–14 min con frame vecchio di 7 min trasformato in ETA live 1–7 min: OK.
- Finestra ETA già scaduta riconosciuta e non presentata come previsione futura: OK.
- Rientro collegato alla probabilità e all'ETA dell'avviso realmente inviato: OK.
- Esiti distinti tra transito, passaggio marginale, deviazione e previsione non confermata: OK.
- Alert Telegram senza “da confermare”, “Affidabilità della stima” o “Perché ricevi questo avviso”: OK.
- Migrazione sorgente fulmini legacy `open_meteo` a `radar_dpc_lgt`: controllo statico OK.

- Stati target-specific per probabilità 1%, 22%, 46% e 72%: OK.
- Stato nucleo forte osservato sul target: OK.
- Stati fuori traiettoria e nessun temporale intenso: OK.
- ETA `20–20 min` compattata in `20 min`: OK.
- Nessuna occorrenza di “traiettoria incerta” nei nuovi testi: OK.
- Etichette tecniche mappa tradotte e ritagliate ai bordi dell'area cartografica: OK.

- Alert Telegram leggibile, HTML bilanciato e sotto il limite caption di 1.024 caratteri: OK.
- VMI/SRI/POH/VIL/ETM tradotti senza perdere i valori originali: OK.
- Permessi persistenti per `meteo.jpg`, `meteo-map.jpg` e `meteo-details.jpg`: OK.
- Due frame coerenti richiesti anche per gli eventi urgenti, salvo nucleo forte già osservato sul target: OK.
- Rientro notificato soltanto dopo due frame radar negativi consecutivi: OK.
- Hail Fusion con POH dominante, qualità dati e persistenza multi-frame separate: OK.

Data: 3 agosto 2026.

## Risultato

Runner completo con dipendenze scientifiche e WebGUI: **107 test eseguiti,
107 superati, 0 fallimenti**.

La suite comprende il riavvio simulato del browser su `/login`, l'estrazione
CAPPI da raster sintetici reali, il rendering radar completo, LTG a cadenza
reale, near-target, callback Telegram, holdout grandine, WebGUI e policy update.

## Controlli statici

```bash
python3 -m py_compile web/app.py web/security_utils.py engine/*.py web/engine_compat/*.py
bash -n install.sh apply_hotfix.sh scripts/ldz-meteo-* scripts/build-release-package tests/run_tests.sh
```

Esito: OK.

Verificata inoltre l’assenza nei sorgenti applicativi di `shell=True`, loader YAML unsafe, `innerHTML`/`onclick` nella pagina target e wildcard sudo per restore/update/repair.

## Precision Engine

- Identità del track preservata su quattro frame coerenti: OK.
- Timestamp Radar-DPC duplicato: non crea un track né una conferma artificiale.
- Percorso diretto verso il target: probabilità almeno 25 punti sopra un percorso perpendicolare.
- Phase correlation su traslazione sintetica 4×6 pixel: spostamento recuperato entro 0,5 pixel.
- ICON-2I contrario al moto radar: peso limitato al 10% e direzione radar ancora dominante.
- Ensemble con intervallo ETA, forma cella, nucleo forte separato dall'alone e modello `stable-impact-ensemble-2.4.0`: OK.
- Contatto del solo inviluppo: non produce più automaticamente 100% ed ETA zero.
- Nucleo forte realmente osservato sul target: probabilità operativa 97%, mai 100% artificiale.
- Evento urgente senza nucleo osservato: richiede due scansioni radar coerenti.
- Minaccia rientrata: richiede due scansioni radar negative consecutive.
- Verifica completa: un evento osservato senza previsione viene contato come FN, mentre una previsione anticipata corretta viene associata come TP.
- Verifica automatica di un miss all’80%: Brier Score atteso 0,64 e record JSONL creato.
- Parametri WebGUI fuori range: limitati lato server a history 12, ensemble 256, optical flow 0,45 e soglie consentite.
- Lifecycle sintetico in crescita contro decadimento: stato e sopravvivenza distinti correttamente.
- Nuovo candidato batch: forzato nuovamente in shadow con influenza zero.
- Bootstrap 2.2.9 senza moduli nativi: import da copia firmata WebGUI e telemetria compatibility mode.

## Adaptive AI e trainer

- Collection/shadow non possono modificare la probabilità operativa: OK.
- Modello residuo neutro identico alla baseline; nessun salto iniziale artificiale al 50%: OK.
- Holdout batch 70/30 separato per track e candidato migliore della baseline sintetica: OK.
- Candidato con Brier peggiore, vantaggio insufficiente o falsi negativi oltre soglia: respinto senza sostituire i pesi in uso.
- Warm-up e righe prive di `baseline_probability`: esclusi dal trainer anziché ricevere una baseline fittizia del 50%.
- Feature fuori intervallo e righe JSONL invalide: scartate.
- Pubblicazione candidato atomica e mode `0600`: OK.
- Copie bootstrap byte-identiche ai moduli engine nativi: OK.
- Nessun formato `pickle`; candidato con schema/feature/generazione non validi rifiutato.
- Trainer systemd separato con `ProtectSystem=strict`, `NoNewPrivileges`, CPUQuota e MemoryMax: controllo statico OK.

## Contesti esterni simulati

- Tre payload NWP indipendenti: consenso mediano, spread e qualità calcolati correttamente.
- Profilo altimetrico a sette campioni: risultato disponibile e cache atomica creata.
- Riga sensore malformata seguita da una valida: la prima viene scartata senza perdere la seconda.
- Lightning Jump: un fulmine fuori dalla finestra recente non entra nel conteggio.
- Hail Fusion: il livello alto richiede POH presente, qualità almeno 65% e persistenza su almeno due frame.
- POH mancante o segnale verticale isolato: non può produrre da solo un livello grandine alto.
- Telegram: stima grandine, qualità dati e stato della conferma temporale mostrati con termini comprensibili.
- Render sintetico radar 1280×720: JPEG desktop più viste mobili Mappa/Dettagli valide e con ritaglio coerente.
- Token Ricordami firmato: una nuova sessione browser viene ripristinata senza password; parametro vista radar non valido rifiutato con HTTP 400.
- Updater: permessi normalizzati e accesso a WebGUI/virtualenv verificato come utente `meteoalert` prima del riavvio.

## Archive/update/restore

- Update con cartella radice e manifest schema 2: accettato.
- Signer della nuova sorgente con policy installata precedente: la policy locale
  viene usata solo se signer e policy coincidono con gli hash del manifest ZIP.
- Estrazione safe nello staging: accettata.
- Firma Ed25519 corretta: accettata.
- ZIP alterato dopo la firma: firma rifiutata.
- Entry `../outside`: rifiutata.
- Compression ratio da ZIP bomb: rifiutato.
- SHA-256 per-file non corrispondente: rifiutato.
- Backup contenente unità systemd: rifiutato.

## Test WebGUI Flask reali

- CSP con nonce e senza `unsafe-inline` in `script-src`: OK.
- `Cache-Control: private, no-store`: OK.
- HSTS su base URL HTTPS: OK.
- Login corretto: HTTP 302 atteso.
- Tre errori con limite test pari a tre; richiesta successiva: HTTP 429 atteso.
- Logout GET: HTTP 405; logout POST con CSRF: HTTP 302.
- Login senza `Ricordami`: cookie di sessione senza scadenza persistente e timeout inattività verificato.
- Login con `Ricordami`: `Expires`, `Secure`, `HttpOnly`, `SameSite=Lax` e limite assoluto lato server verificati.
- Payload innocuo `O'Brien <img ...>`: codificato come testo, nessun elemento `img` creato.
- Rendering autenticato HTTP 200: Dashboard, Target, Aspetto, Regole, Telegram, Template, Canali, Fulmini, Storico, Log, Backup, Manutenzione, Aggiorna, Sistema, Diagnostica, Kiosk, Readiness e Changelog.
- Changelog: un solo sistema di card/righe responsive per timeline recente e storico legacy, con cache-busting CSS.
- Dashboard e Regole Precision Engine renderizzate con telemetria, controlli e fallback radar: OK.
- Render grafico sintetico 1920×1080 con SRI, forma cella, percorso, cono d’incertezza ed ETA: JPEG valido, pannello senza overflow dopo correzione.

## Packaging

- Permessi eseguibili preservati per installer e helper.
- Leaflet 1.9.4 presente localmente con JS, CSS e immagini.
- Il build script rigenera `manifest.files`, crea lo ZIP con cartella radice e preserva gli attributi Unix.
- Entrambi i pacchetti finali vengono riaperti con la stessa policy usata dall’updater e verificati con `unzip -t` e SHA-256.

## Limiti del test locale

Non sono stati eseguiti in questo ambiente: `dnf` su AlmaLinux reale, systemd/Apache/SELinux reali, chiamate Telegram con token, ciclo Radar-DPC live, sensori MQTT/HTTPS reali e invio SMTP/webhook. Il rendering end-to-end di un GeoTIFF Radar-DPC reale resta un test di staging. L’installer usa la suite Python 3.12 documentata per RHEL 9.4+; virtualenv, servizi e ciclo radar devono comunque essere provati prima in una VM equivalente al server di produzione.
