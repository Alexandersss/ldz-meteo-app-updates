#!/usr/bin/env bash
set -euo pipefail

APP_NAME="LDZ Meteo App 2.6.0h Weather Lab"
ENGINE_DIR="/opt/meteo-alert"
WEB_DIR="/opt/ldz-meteo-web"
ENGINE_ETC="/etc/meteo-alert"
WEB_ETC="/etc/ldz-meteo-web"
ENGINE_VAR="/var/lib/meteo-alert"
ENGINE_LOG="/var/log/meteo-alert"
WEB_VAR="/var/lib/ldz-meteo-web"
WEB_LOG="/var/log/ldz-meteo-web"

# UI setup: colori, contatore fasi e banner leggibile anche via SSH.
if [[ -t 1 ]]; then
  C_RESET="\033[0m"; C_BOLD="\033[1m"; C_DIM="\033[2m"; C_BLUE="\033[38;5;39m"; C_CYAN="\033[38;5;51m"; C_GREEN="\033[38;5;82m"; C_YELLOW="\033[38;5;220m"; C_RED="\033[38;5;203m"; C_PURPLE="\033[38;5;141m"; C_WHITE="\033[38;5;255m"
else
  C_RESET=""; C_BOLD=""; C_DIM=""; C_BLUE=""; C_CYAN=""; C_GREEN=""; C_YELLOW=""; C_RED=""; C_PURPLE=""; C_WHITE=""
fi
TOTAL_STEPS=15
CURRENT_STEP=0

banner() {
  [[ -t 1 ]] && clear 2>/dev/null || true
  echo -e "${C_CYAN}${C_BOLD}"
  cat <<'EOF'
╔════════════════════════════════════════════════════════════════════╗
║                                                                    ║
║        ██╗     ██████╗ ███████╗    ███╗   ███╗███████╗████████╗   ║
║        ██║     ██╔══██╗╚══███╔╝    ████╗ ████║██╔════╝╚══██╔══╝   ║
║        ██║     ██║  ██║  ███╔╝     ██╔████╔██║█████╗     ██║      ║
║        ██║     ██║  ██║ ███╔╝      ██║╚██╔╝██║██╔══╝     ██║      ║
║        ███████╗██████╔╝███████╗    ██║ ╚═╝ ██║███████╗   ██║      ║
║        ╚══════╝╚═════╝ ╚══════╝    ╚═╝     ╚═╝╚══════╝   ╚═╝      ║
║                                                                    ║
║         S C I E N T I F I C  Q U A L I T Y  ·  2.6 stable       ║
║       Multi-scale Flow · Shadow AI · Ensemble Nowcasting          ║
║                                                                    ║
╚════════════════════════════════════════════════════════════════════╝
EOF
  echo -e "${C_RESET}${C_DIM}  Secure deployment console · Radar-DPC mission control${C_RESET}\n"
}

say() {
  CURRENT_STEP=$((CURRENT_STEP + 1))
  local width=30 filled=$((CURRENT_STEP * 30 / TOTAL_STEPS)) bar="" empty=""
  local i
  for ((i=0; i<filled; i++)); do bar+="█"; done
  for ((i=filled; i<width; i++)); do empty+="░"; done
  printf "\n${C_BLUE}${C_BOLD}┌─ PHASE %02d/%02d · %s${C_RESET}\n" "$CURRENT_STEP" "$TOTAL_STEPS" "$*"
  printf "${C_BLUE}│${C_RESET} ${C_CYAN}%s${C_DIM}%s${C_RESET} ${C_WHITE}%3d%%${C_RESET}\n" "$bar" "$empty" "$((CURRENT_STEP * 100 / TOTAL_STEPS))"
  printf "${C_BLUE}└────────────────────────────────────────────────────────────${C_RESET}\n"
}

info() { echo -e "  ${C_CYAN}◈${C_RESET} $*"; }
warn() { echo -e "  ${C_YELLOW}▲${C_RESET} $*"; }
ok() { echo -e "  ${C_GREEN}◆${C_RESET} $*"; }
panel() {
  local title="$1"; shift
  printf "\n${C_PURPLE}╭─ %s ─────────────────────────────────────────────${C_RESET}\n" "$title"
  while (($#)); do printf "${C_PURPLE}│${C_RESET}  %s\n" "$1"; shift; done
  printf "${C_PURPLE}╰────────────────────────────────────────────────────────────${C_RESET}\n"
}

run_silent() {
  local label="$1"; shift
  local log="/tmp/ldz-meteo-install-${CURRENT_STEP}.log"
  printf "  ${C_CYAN}◌${C_RESET} %s " "$label"
  "$@" >"$log" 2>&1 &
  local pid=$!
  local -a spin=("◐" "◓" "◑" "◒")
  local i=0
  local started=$SECONDS
  while kill -0 "$pid" 2>/dev/null; do
    printf "\r  ${C_CYAN}%s${C_RESET} %s ${C_DIM}(%ss)${C_RESET}" "${spin[$((i%4))]}" "$label" "$((SECONDS-started))"
    i=$((i + 1))
    sleep 0.18
  done
  if wait "$pid"; then
    printf "\r  ${C_GREEN}●${C_RESET} %s ${C_GREEN}READY${C_RESET}                    \n" "$label"
  else
    printf "\r  ${C_RED}●${C_RESET} %s ${C_RED}FAILED${C_RESET}                   \n" "$label"
    echo "---- log $log ----"
    tail -80 "$log" || true
    exit 1
  fi
}

require_root() {
  if [[ "$(id -u)" -ne 0 ]]; then
    echo "Esegui come root o con sudo."
    exit 1
  fi
}

require_safe_scalar() {
  local label="$1" value="$2"
  [[ "$value" != *$'\n'* && "$value" != *$'\r'* && "$value" != *'"'* ]] || {
    echo "Valore non valido per $label: newline e doppi apici non sono consentiti."
    exit 1
  }
}

detect_ip() {
  hostname -I 2>/dev/null | awk '{print $1}'
}

ask() {
  local prompt="$1"
  local default="$2"
  local value
  read -rp "$prompt [$default]: " value
  echo "${value:-$default}"
}

ask_yes_no() {
  local prompt="$1"
  local default="$2"
  local value
  read -rp "$prompt [$default]: " value
  value="${value:-$default}"
  case "$value" in
    y|Y|yes|YES|s|S|si|SI) return 0 ;;
    *) return 1 ;;
  esac
}

require_root

banner
say "$APP_NAME installer"
panel "BOOT SEQUENCE" \
  "Security profile : signed updates / root isolation" \
  "Forecast model   : Kalman + cell geometry + optical flow" \
  "Runtime target   : AlmaLinux/RHEL 9.4+ · Python 3.12"

SERVER_IP_DEFAULT="$(detect_ip)"
SERVER_IP="${SERVER_IP_DEFAULT:-127.0.0.1}"
info "Inserisci hostname/IP SENZA porta. Esempi: 192.168.10.145 oppure radar.guidovitiello.it"
SERVER_IP="$(ask "Hostname/IP pubblico o interno WebGUI" "$SERVER_IP")"
[[ "$SERVER_IP" =~ ^([A-Za-z0-9.-]+|[0-9A-Fa-f:]+)$ ]] || { echo "Hostname/IP non valido"; exit 1; }
APP_PREFIX="$(ask "Path pubblico WebGUI" "/ldzmeteoapp")"
if [[ "$APP_PREFIX" != /* ]]; then
  APP_PREFIX="/$APP_PREFIX"
fi
APP_PREFIX="${APP_PREFIX%/}"
[[ "$APP_PREFIX" =~ ^/[A-Za-z0-9._~/-]*$ && "$APP_PREFIX" != *".."* ]] || { echo "Path WebGUI non valido"; exit 1; }
WEB_PORT="$(ask "Porta interna locale WebGUI (solo 127.0.0.1 dietro Apache)" "8090")"
DOCROOT="$(ask "DocumentRoot Apache dove pubblicare meteo.jpg" "/var/www/html")"
[[ "$WEB_PORT" =~ ^[0-9]{1,5}$ && "$WEB_PORT" -ge 1024 && "$WEB_PORT" -le 65535 ]] || { echo "Porta WebGUI non valida"; exit 1; }
[[ "$DOCROOT" == /* && "$DOCROOT" != "/" ]] || { echo "DocumentRoot non valida"; exit 1; }
require_safe_scalar "DocumentRoot" "$DOCROOT"
PUBLISH_MODE="$(ask "Modalità pubblicazione Apache: http / https-selfsigned / https-existing" "http")"
case "$PUBLISH_MODE" in
  http|https-selfsigned|https-existing) ;;
  *) warn "Modalità non valida, uso http"; PUBLISH_MODE="http" ;;
esac
PUBLIC_SCHEME="http"
CERT_FILE=""
KEY_FILE=""
DEFAULT_PUBLIC_PORT="80"
if [[ "$PUBLISH_MODE" != "http" ]]; then
  PUBLIC_SCHEME="https"
  DEFAULT_PUBLIC_PORT="443"
fi

echo
info "Porte e URL:"
info "- Porta interna: ${WEB_PORT} resta locale sulla VM; NON esporla su Internet."
info "- Porta esterna: è quella pubblica di Apache/reverse proxy. Standard: 80/443. Esempio Cloudflare HTTPS alternativo: 2053."
info "- Se usi 2053, l'URL sarà: https://radar.guidovitiello.it:2053${APP_PREFIX}/"
PUBLIC_PORT="$(ask "Porta esterna pubblica Apache" "$DEFAULT_PUBLIC_PORT")"
PUBLIC_PORT="${PUBLIC_PORT:-$DEFAULT_PUBLIC_PORT}"
[[ "$PUBLIC_PORT" =~ ^[0-9]{1,5}$ && "$PUBLIC_PORT" -ge 1 && "$PUBLIC_PORT" -le 65535 ]] || { echo "Porta pubblica non valida"; exit 1; }
if [[ "$PUBLIC_PORT" == "80" && "$PUBLIC_SCHEME" == "http" ]] || [[ "$PUBLIC_PORT" == "443" && "$PUBLIC_SCHEME" == "https" ]]; then
  PUBLIC_PORT_SUFFIX=""
else
  PUBLIC_PORT_SUFFIX=":${PUBLIC_PORT}"
fi
PUBLIC_ORIGIN="${PUBLIC_SCHEME}://${SERVER_IP}${PUBLIC_PORT_SUFFIX}"
PUBLIC_BASE_URL="${PUBLIC_ORIGIN}${APP_PREFIX}"

echo
info "Esempio configurazione consentiti:"
info "- Host consentiti: ${SERVER_IP},localhost,127.0.0.1  (senza porta)"
info "- Origin consentiti: ${PUBLIC_ORIGIN}  (con porta, se diversa da 80/443)"
info "- Public base URL: ${PUBLIC_BASE_URL}/"

if [[ "$PUBLISH_MODE" == "https-existing" ]]; then
  CERT_FILE="$(ask "Percorso certificato SSL esistente" "/etc/pki/tls/certs/ldz-meteo.crt")"
  KEY_FILE="$(ask "Percorso chiave privata SSL esistente" "/etc/pki/tls/private/ldz-meteo.key")"
fi
PUBLIC_IMAGE_URL="$(ask "URL pubblico meteo.jpg" "${PUBLIC_ORIGIN}/meteo.jpg")"
[[ "$PUBLIC_IMAGE_URL" =~ ^https?://[^[:space:]]+$ ]] || { echo "URL meteo.jpg non valido"; exit 1; }
require_safe_scalar "URL meteo.jpg" "$PUBLIC_IMAGE_URL"

echo
echo "Hardening WebGUI"
if ask_yes_no "Abilitare azioni root dalla WebGUI? (sync timer/restore/repair/update firmati)" "n"; then
  ROOT_ACTIONS_ENABLED="true"
else
  ROOT_ACTIONS_ENABLED="false"
fi
if ask_yes_no "Abilitare asset esterni Leaflet/OpenStreetMap per mappa click target?" "y"; then
  ALLOW_EXTERNAL_ASSETS="true"
else
  ALLOW_EXTERNAL_ASSETS="false"
fi
ALLOWED_HOSTS_DEFAULT="${SERVER_IP},localhost,127.0.0.1"
ALLOWED_HOSTS="$(ask "Host consentiti WebGUI, separati da virgola" "$ALLOWED_HOSTS_DEFAULT")"
if [[ "$ALLOWED_HOSTS" == *"/"* ]]; then
  echo "ATTENZIONE: qui servono hostname/IP del sito, non subnet CIDR. Esempio: ${SERVER_IP},localhost,127.0.0.1"
fi
ALLOWED_ORIGINS_DEFAULT="${PUBLIC_ORIGIN}"
ALLOWED_ORIGINS="$(ask "Origin consentiti WebGUI, separati da virgola" "$ALLOWED_ORIGINS_DEFAULT")"
# Apache gestisce HTTPS davanti; Flask resta dietro proxy su HTTP locale per evitare redirect loop.
REQUIRE_HTTPS="false"

WEB_USER="$(ask "Username WebGUI" "admin")"
[[ "$WEB_USER" =~ ^[A-Za-z0-9._-]{1,64}$ ]] || { echo "Username WebGUI non valido"; exit 1; }
while true; do
  read -rsp "Password WebGUI: " WEB_PASS
  echo
  read -rsp "Ripeti password WebGUI: " WEB_PASS2
  echo
  [[ "$WEB_PASS" == "$WEB_PASS2" && -n "$WEB_PASS" ]] && break
  echo "Le password non coincidono o sono vuote. Riprova."
done

echo
echo "Configurazione Telegram"
read -rsp "TELEGRAM_BOT_TOKEN: " TELEGRAM_TOKEN
echo
read -rp "TELEGRAM_CHAT_ID: " TELEGRAM_CHAT_ID
if [[ -n "$TELEGRAM_TOKEN" && ! "$TELEGRAM_TOKEN" =~ ^[0-9]{5,15}:[A-Za-z0-9_-]{20,100}$ ]]; then
  echo "Formato TELEGRAM_BOT_TOKEN non valido"; exit 1
fi
if [[ -n "$TELEGRAM_CHAT_ID" && ! "$TELEGRAM_CHAT_ID" =~ ^-?[0-9]{5,20}$ ]]; then
  echo "Formato TELEGRAM_CHAT_ID non valido"; exit 1
fi
if [[ -z "$TELEGRAM_TOKEN" || -z "$TELEGRAM_CHAT_ID" ]]; then
  echo "ATTENZIONE: token o chat ID vuoto. Telegram non sarà operativo finché non configuri /etc/meteo-alert/secrets.env"
fi

PREALERT="$(ask "Preavviso ETA minuti" "20")"
CHECK_INTERVAL="$(ask "Intervallo check minuti" "5")"
STRONG_VMI="$(ask "Soglia temporale forte VMI dBZ" "45")"
TARGET_RADIUS="$(ask "Raggio target default km" "7")"
COOLDOWN="$(ask "Cooldown alert minuti" "35")"

USE_DEFAULT_TARGETS="y"
if ask_yes_no "Usare target default Pescara / San Giovanni Teatino / San Vito Chietino?" "y"; then
  TARGETS_YAML=$(cat <<EOF
targets:
  - name: Pescara
    lat: 42.4618
    lon: 14.2161
    radius_km: ${TARGET_RADIUS}
    enabled: true
  - name: San Giovanni Teatino
    lat: 42.4216
    lon: 14.2019
    radius_km: ${TARGET_RADIUS}
    enabled: true
  - name: San Vito Chietino
    lat: 42.2969
    lon: 14.4448
    radius_km: ${TARGET_RADIUS}
    enabled: true
EOF
)
else
  read -rp "Quanti target vuoi configurare? [1]: " TARGET_COUNT
  TARGET_COUNT="${TARGET_COUNT:-1}"
  TARGETS_YAML="targets:"
  for i in $(seq 1 "$TARGET_COUNT"); do
    echo "Target $i"
    read -rp "  Nome: " T_NAME
    read -rp "  Latitudine: " T_LAT
    read -rp "  Longitudine: " T_LON
    read -rp "  Raggio km [${TARGET_RADIUS}]: " T_RADIUS
    T_RADIUS="${T_RADIUS:-$TARGET_RADIUS}"
    TARGETS_YAML="${TARGETS_YAML}
  - name: ${T_NAME}
    lat: ${T_LAT}
    lon: ${T_LON}
    radius_km: ${T_RADIUS}
    enabled: true"
  done
fi

LIGHTNING_SOURCE="$(ask "Fonte attività elettrica: none/radar_dpc_lgt/open_meteo/openweather" "radar_dpc_lgt")"
OPENWEATHER_KEY=""
if [[ "$LIGHTNING_SOURCE" == "openweather" ]]; then
  read -rsp "OpenWeather API key: " OPENWEATHER_KEY
  echo
  [[ "$OPENWEATHER_KEY" =~ ^[A-Za-z0-9_-]{8,128}$ ]] || { echo "OpenWeather API key non valida"; exit 1; }
fi

panel "DEPLOYMENT PLAN" \
  "Web console       : ${PUBLIC_BASE_URL}/" \
  "Radar image       : ${PUBLIC_IMAGE_URL}" \
  "Check / prealert  : ${CHECK_INTERVAL} min / ${PREALERT} min" \
  "Target radius     : ${TARGET_RADIUS} km" \
  "Precision Engine  : 6 frame · 72 ensemble · SRI/VMI/POH/VIL/ETM/LGT"

say "Pacchetti sistema"
run_silent "Installazione pacchetti sistema" dnf install -y python3.12 python3.12-pip python3.12-devel gcc gcc-c++ make httpd mod_ssl openssl curl unzip tar sudo
PYTHON_BIN="/usr/bin/python3.12"
[[ -x "$PYTHON_BIN" ]] || { echo "Python 3.12 non disponibile"; exit 1; }

if ! id meteoalert >/dev/null 2>&1; then
  useradd --system --home-dir /var/lib/meteo-alert --shell /sbin/nologin meteoalert
fi

say "Directory"
mkdir -p "$ENGINE_DIR" "$WEB_DIR" "$ENGINE_ETC" "$WEB_ETC"
mkdir -p "$ENGINE_VAR/public" "$ENGINE_VAR/matplotlib" "$ENGINE_VAR/frames" "$ENGINE_LOG"
mkdir -p "$WEB_VAR/backups" "$WEB_VAR/exports" "$WEB_VAR/uploads" "$WEB_VAR/updates" "$WEB_VAR/update-work" "$WEB_LOG"
mkdir -p "$DOCROOT"

if [[ -d "$ENGINE_DIR" && -f "$ENGINE_DIR/meteo_alert.py" ]]; then
  TS="$(date +%Y%m%d-%H%M%S)"
  echo "Backup engine esistente: ${ENGINE_DIR}.bak.${TS}"
  cp -a "$ENGINE_DIR" "${ENGINE_DIR}.bak.${TS}"
fi
if [[ -d "$WEB_DIR" && -f "$WEB_DIR/app.py" ]]; then
  TS="$(date +%Y%m%d-%H%M%S)"
  echo "Backup WebGUI esistente: ${WEB_DIR}.bak.${TS}"
  cp -a "$WEB_DIR" "${WEB_DIR}.bak.${TS}"
fi

say "Installazione motore radar"
ENGINE_MODULES=(engine/*.py)
[[ "${#ENGINE_MODULES[@]}" -gt 0 ]] || fail "nessun modulo Python presente nel motore"
cp -a "${ENGINE_MODULES[@]}" "$ENGINE_DIR"/
cp -a engine/requirements.txt "$ENGINE_DIR/requirements.txt"
chmod 644 "$ENGINE_DIR"/*.py
for engine_executable in meteo_alert.py adaptive_ai_trainer.py radar_wss_listener.py telegram_feedback_listener.py; do
  [[ -f "$ENGINE_DIR/$engine_executable" ]] || fail "entrypoint motore mancante: $engine_executable"
  chmod 755 "$ENGINE_DIR/$engine_executable"
done
[[ -f "$ENGINE_DIR/weather_lab.py" ]] || fail "modulo Weather Lab non distribuito"
chown -R root:root "$ENGINE_DIR"
chmod -R u=rwX,go=rX "$ENGINE_DIR"

"$PYTHON_BIN" -m venv "$ENGINE_DIR/venv"
run_silent "Installazione dipendenze motore radar" "$ENGINE_DIR/venv/bin/pip" install --upgrade --only-binary=:all: -r "$ENGINE_DIR/requirements.txt"
if "$ENGINE_DIR/venv/bin/pip" install --upgrade "pysteps==1.21.4" >>"$INSTALL_LOG" 2>&1; then
  "$ENGINE_DIR/venv/bin/python" -c 'import cv2; from pysteps.motion import get_method; from pysteps.nowcasts.anvil import forecast; assert callable(get_method("lucaskanade")) and callable(forecast)' >>"$INSTALL_LOG" 2>&1 \
    || fail "smoke test pySTEPS/LINDA/ANVIL/OpenCV fallito"
  log "pySTEPS/LINDA/ANVIL e OpenCV installati"
else
  log "pySTEPS/LINDA non compilabile su questo host: installazione principale proseguita in modalità Weather Lab senza LINDA"
fi
"$ENGINE_DIR/venv/bin/pip" check >>"$INSTALL_LOG" 2>&1 || fail "dipendenze motore incoerenti dopo il tentativo pySTEPS"
/usr/sbin/runuser -u meteoalert -- /usr/bin/env PYTHONPATH="$ENGINE_DIR" "$ENGINE_DIR/venv/bin/python" -c 'import meteo_alert, weather_lab' >>"$INSTALL_LOG" 2>&1 \
  || fail "smoke test import motore/Weather Lab fallito"

say "Installazione WebGUI"
cp -a web/app.py web/build_info.py web/management.py web/security_utils.py web/state_reader.py web/requirements.txt web/templates web/static "$WEB_DIR"/
install -o root -g root -m 640 manifest.json "$WEB_DIR/manifest.json"
chown -R root:root "$WEB_DIR"
chmod -R u=rwX,go=rX "$WEB_DIR"

"$PYTHON_BIN" -m venv "$WEB_DIR/venv"
run_silent "Installazione dipendenze WebGUI" "$WEB_DIR/venv/bin/pip" install --upgrade --only-binary=:all: -r "$WEB_DIR/requirements.txt"

say "Configurazione radar"
if [[ -f "$ENGINE_ETC/config.yml" ]]; then
  cp -a "$ENGINE_ETC/config.yml" "$ENGINE_ETC/config.yml.bak.$(date +%Y%m%d-%H%M%S)"
fi

cat > "$ENGINE_ETC/config.yml" <<EOF
app:
  data_dir: ${ENGINE_VAR}
  log_dir: ${ENGINE_LOG}
  state_file: ${ENGINE_VAR}/state.json
  run_lock_file: ${ENGINE_VAR}/meteo-alert.lock
  verification_file: ${ENGINE_VAR}/precision/forecast-verification.jsonl
  max_frame_age_minutes: 30
  max_raster_pixels: 30000000

radar:
  api_base: https://radar-api.protezionecivile.it
  products:
    - VMI
    - SRI
    - POH
    - VIL
    - ETM
    - SRT1
    - IR_108
  request_timeout_seconds: 30
  keep_frames_days: 3
  retry_attempts: 4
  retry_sleep_seconds: 8
  max_raster_download_mb: 128
  origin: https://radar.protezionecivile.it
  referer: https://radar.protezionecivile.it/
  user_agent: LDZMeteoApp/2.6.0h (+https://radar.protezionecivile.it/)

radar_websocket:
  enabled: true
  url: wss://radar-wss.protezionecivile.it
  trigger_product: VMI
  settle_seconds: 35
  circuit_breaker_failures: 5
  circuit_breaker_seconds: 900
  summary_log_seconds: 900

radar_sites:
  enabled: true
  relevant_radius_km: 180

network:
  allow_private_endpoints: false
  allow_http_webhooks: false

thresholds:
  vmi_strong_dbz: ${STRONG_VMI}
  vmi_core_dbz: 55
  vmi_hail_dbz: 55
  poh_medium_percent: 40
  poh_high_percent: 60
  vil_hail_threshold: 35
  etm_hail_threshold_m: 9000
  valid_ranges:
    VMI: [-10, 80]
    SRI: [0, 500]
    POH: [0, 100]
    VIL: [0, 100]
    ETM: [0, 20000]
    SRT1: [0, 500]
    IR_108: [150, 350]
    CAPPI: [-10, 80]

vertical_profile:
  enabled: true
  products: [CAPPI_1, CAPPI_2, CAPPI_3, CAPPI_4, CAPPI_5, CAPPI_6, CAPPI_7, CAPPI_8, CAPPI_9, CAPPI_10]
  max_skew_minutes: 16
  cell_percentile: 95
  minimum_coverage: 0.50
  max_hail_adjustment_points: 12
  max_negative_adjustment_points: 6
  neutral_score: 0.35
  minimum_high_support_percent: 22
  keep_frames_per_product: 3

near_target_override:
  enabled: true
  edge_margin_km: 3
  lightning_radius_km: 3
  surface_rain_threshold_mmh: 15
  hourly_rain_threshold_mm: 6
  minimum_vmi_dbz: 45
  near_probability_floor_percent: 68
  observed_probability_floor_percent: 74
  hail_watch_cappi_score_percent: 22

event_feedback:
  enabled: true
  minimum_capture_probability_percent: 15
  close_after_minutes: 30
  prompt_delay_minutes: 25
  retention_days: 60
  merge_targets_within_km: 25

event_replay:
  enabled: true
  minimum_probability_percent: 15
  crop_radius_pixels: 48
  products: [VMI, SRI, POH, VIL, ETM]
  directory: ${ENGINE_VAR}/replay
  retention_days: 60
  maximum_total_mb: 750
  negative_sampling_interval_minutes: 30

hail_feedback_calibration:
  enabled: true
  auto_activate: true
  minimum_events: 40
  minimum_positive_events: 8
  minimum_negative_events: 20
  minimum_validation_events: 12
  minimum_brier_improvement_percent: 10
  guarded_influence: 0.18
  maximum_probability_delta_percent: 10
  dataset_file: ${ENGINE_VAR}/feedback/ground-truth.jsonl
  candidate_model_file: ${ENGINE_VAR}/feedback/hail-candidate.json
  training_report_file: ${ENGINE_VAR}/feedback/hail-training-report.json
  maximum_dataset_mb: 50

watchdog:
  enabled: true
  stale_after_minutes: 20
  notify_recovery: true
  state_file: ${ENGINE_VAR}/watchdog-state.json

multisignal:
  enabled: true
  impact_weight_trajectory: 0.72
  impact_weight_confirmation: 0.28
  confidence_shrinkage_enabled: true
  hail_min_score_medium: 35
  hail_min_score_high: 65
  hail_min_poh_for_high: 35
  hail_min_persistence_frames: 2
  hail_high_min_data_quality: 65
  confidence_min_for_numeric_100: 92

precision_engine:
  enabled: true
  history_frames: 6
  ensemble_members: 72
  ensemble_step_minutes: 1
  max_footprint_vertices: 48
  measurement_noise_km: 1.2
  acceleration_noise_km_min2: 0.018
  poor_track_residual_km: 6.0
  optical_flow_weight: 0.30
  optical_flow_patch_padding_pixels: 36
  optical_flow_scale_factors: [0.55, 1.0, 1.55]
  max_flow_disagreement_kmh: 55
  nwp_steering_weight: 0.10
  max_nwp_disagreement_kmh: 75
  ensemble_velocity_sigma_kmh: 10
  ensemble_growth_sigma_km_min: 0.045
  max_product_skew_minutes: 12
  association_max_cost: 0.82
  association_overlap_weight: 0.28
  overlap_lineage_threshold: 0.08
  split_distance_km: 16
  merge_distance_km: 14
  topology_uncertainty_minutes: 15
  topology_confidence_factor: 0.65
  topology_covariance_multiplier: 3.0
  verification_enabled: true
  verification_min_probability_percent: 15
  verification_grace_minutes: 10
  calibration_min_samples: 30

segmentation_engine:
  enabled: true
  mode: shadow
  minimum_core_pixels: 6
  minimum_seed_separation_km: 5

raster_nowcast_shadow:
  enabled: true
  minimum_motion_quality: 0.08
  lead_minutes: [5, 10, 15, 20, 30]

hail_shadow:
  enabled: true
  minus20_height_offset_km: 3.0
  waldvogel_delta_km: 1.4
  shi_reference: 60
  posh_reference_percent: 30

verification_engine:
  enabled: true
  episode_open_hits: 2
  episode_close_misses: 3
  event_match_minutes: 20
  minimum_slots: 100
  max_ledger_mb: 50

terrain_engine:
  enabled: true
  elevation_api_url: https://api.open-meteo.com/v1/elevation
  profile_samples: 7
  max_profiles_per_cycle: 32
  max_profile_distance_km: 140
  max_survival_adjustment: 0.12

lifecycle_engine:
  enabled: true
  survival_weight: 0.34
  sensor_confirmation_weight: 0.06
  lightning_cell_radius_km: 30
  lightning_polygon_margin_km: 10
  lead_trend_damping: 0.72
  lightning_jump_window_minutes: 15
  lightning_jump_min_delta: 4
  lightning_jump_min_count: 6
  lightning_jump_baseline_points: 3
  lightning_jump_min_coverage_percent: 75
  lightning_history_minutes: 90

adaptive_ai:
  enabled: true
  auto_activate: true
  shadow_warmup_events: 25
  activation_min_events: 80
  activation_min_unique_storms: 12
  activation_min_positive: 20
  activation_min_negative: 20
  activation_min_brier_improvement_percent: 10
  activation_required_streak: 3
  candidate_guard_events: 25
  guarded_influence: 0.20
  max_influence: 0.30
  max_probability_delta_percent: 18
  max_false_negative_rate: 0.35
  evaluation_window_events: 120
  learning_rate: 0.055
  l2_regularization: 0.002
  suspend_brier_ratio: 1.05
  max_dataset_mb: 50
  batch_max_events: 5000
  batch_epochs: 120
  batch_learning_rate: 0.08
  dataset_file: ${ENGINE_VAR}/adaptive-ai/events.jsonl
  candidate_model_file: ${ENGINE_VAR}/adaptive-ai/candidate-model.json
  training_report_file: ${ENGINE_VAR}/adaptive-ai/training-report.json

local_sensors:
  enabled: false
  snapshot_file: ${ENGINE_VAR}/sensors/latest.json
  max_age_minutes: 15
  allow_private_http: false
  http_endpoints: []
  mqtt:
    enabled: false
    host: ""
    port: 8883
    tls: true
    collect_seconds: 1.5
    username_env: LDZ_SENSOR_MQTT_USERNAME
    password_env: LDZ_SENSOR_MQTT_PASSWORD
    topics: {}

atmospheric_context:
  enabled: true
  models:
    - italia_meteo_arpae_icon_2i
    - icon_seamless
    - ecmwf_ifs025
    - gfs_seamless
  api_url: https://api.open-meteo.com/v1/forecast
  refresh_minutes: 45
  stale_cache_hours: 4
  cluster_radius_km: 180
  max_clusters: 8

weather_lab:
  enabled: true
  data_dir: ${ENGINE_VAR}/weather-lab
  retention_days: 90
  maximum_total_mb: 1024
  lead_minutes: [15, 30, 60, 90]
  resource_guard:
    minimum_available_memory_mb: 420
    maximum_runtime_seconds: 55
    minimum_rain_rate_mmh: 0.2
    minimum_domain_rain_fraction: 0.0005
    target_window_pixels: 10
  linda:
    enabled: true
    ensemble_members: 8
    max_grid_pixels: 384
    event_rain_rate_mmh: 2.0
    lead_minutes: [15, 30, 60, 90]
  anvil:
    enabled: true
    max_grid_pixels: 320
    lead_minutes: [15, 30, 60, 90]
  meteohub:
    enabled: false
    sync_minutes: 30
    maximum_file_mb: 256
    evaluation_hours: [1, 3, 6]


tracking:
  check_interval_minutes: ${CHECK_INTERVAL}
  prealert_minutes: ${PREALERT}
  strong_alert_vmi_dbz: ${STRONG_VMI}
  alert_cooldown_minutes: ${COOLDOWN}
  clear_cooldown_minutes: 30
  update_cooldown_minutes: 12
  update_probability_rise_percent: 15
  update_probability_drop_percent: 20
  expired_eta_grace_minutes: 2
  threat_memory_minutes: 120
  min_alert_probability_percent: 60
  clear_probability_percent: 35
  require_consecutive_hits: 2
  clear_consecutive_misses: 2
  observed_core_probability_percent: 97
  max_match_km: 35
  max_gap_minutes: 18
  min_speed_kmh: 8
  max_speed_kmh: 130
  min_closing_kmh: 10
  min_approach_km: 0.7
  trajectory_uncertainty_km: 3.0
  lead_uncertainty_km_per_min: 0.12
  max_lead_uncertainty_km: 7.0
  max_search_km: 110
  min_component_pixels: 8
  require_hail_risk: false
  min_risk_level: MEDIUM

public_image:
  enabled: true
  output_file: ${ENGINE_VAR}/public/meteo.jpg
  public_url: ${PUBLIC_IMAGE_URL}
  width_px: 1920
  height_px: 1080
  radar_alpha: 0.72
  zoom_padding_west_deg: 0.24
  zoom_padding_east_deg: 0.08
  zoom_padding_south_deg: 0.10
  zoom_padding_north_deg: 0.16

publish:
  method: local
  local_path: ${DOCROOT}/meteo.jpg

telegram:
  send_photo: true
  include_public_image_url: false

basemap:
  enabled: true
  zoom: 11
  cache_dir: ${ENGINE_VAR}/osm_tiles
  request_timeout_seconds: 20
  user_agent: "LDZMeteoApp/2.6.0h (+${PUBLIC_IMAGE_URL})"

lightning:
  enabled: true
  source: ${LIGHTNING_SOURCE}
  dpc_lgt_base_url: "https://s3-prod-dpc-radar-webp-cache.s3.eu-south-1.amazonaws.com"
  radius_km: 20
  window_minutes: 20
  official_cadence_minutes: 10
  dpc_lgt_max_age_minutes: 15
  dpc_lgt_max_lookback_minutes: 180
  severity_boost: true
  notify_on_lightning: true
  notify_lightning_clear: true
  alert_min_strikes: 2
  alert_high_count: 8
  alert_urgent_radius_km: 8
  alert_cooldown_minutes: 20
  alert_escalation_delta: 5
  alert_clear_windows: 2
  notify_on_lightning_plus_radar: false
  openweather_api_key: "${OPENWEATHER_KEY}"

quiet_hours:
  enabled: false
  start: "00:00"
  end: "07:00"
  mode: critical_only

telegram_templates:
  enabled: false
  alert: ""

notifications:
  webhook_enabled: false
  webhook_url: ""
  email_enabled: false
  smtp_host: ""
  smtp_port: 587
  smtp_starttls: true
  smtp_user: ""
  smtp_password: ""
  email_from: ""
  email_to: ""
  email_subject: "LDZ Meteo Alert"

webui:
  theme: dark

${TARGETS_YAML}
EOF

chown root:meteoalert "$ENGINE_ETC/config.yml"
chmod 660 "$ENGINE_ETC/config.yml"

say "Secrets"
if [[ -f "$ENGINE_ETC/secrets.env" ]]; then
  cp -a "$ENGINE_ETC/secrets.env" "$ENGINE_ETC/secrets.env.bak.$(date +%Y%m%d-%H%M%S)"
fi

cat > "$ENGINE_ETC/secrets.env" <<EOF
TELEGRAM_BOT_TOKEN="${TELEGRAM_TOKEN}"
TELEGRAM_CHAT_ID="${TELEGRAM_CHAT_ID}"
OPENWEATHER_API_KEY="${OPENWEATHER_KEY}"
EOF

chown root:meteoalert "$ENGINE_ETC/secrets.env"
chmod 640 "$ENGINE_ETC/secrets.env"

# Segreto distinto dal token bot: non viene incluso nei backup applicativi.
FEEDBACK_SIGNING_FILE="$ENGINE_ETC/feedback-signing.env"
if [[ -L "$FEEDBACK_SIGNING_FILE" ]]; then
  echo "ERRORE: feedback-signing.env non può essere un link simbolico" >&2
  exit 1
fi
if [[ ! -s "$FEEDBACK_SIGNING_FILE" ]]; then
  FEEDBACK_SECRET="$(openssl rand -hex 32)"
  V1_ACCEPT_UNTIL="$(( $(date +%s) + 7 * 24 * 60 * 60 ))"
  cat > "$FEEDBACK_SIGNING_FILE" <<EOF
LDZ_FEEDBACK_SIGNING_SECRET="$FEEDBACK_SECRET"
LDZ_FEEDBACK_PREVIOUS_SECRET=""
LDZ_FEEDBACK_V1_ACCEPT_UNTIL="$V1_ACCEPT_UNTIL"
EOF
  unset FEEDBACK_SECRET
fi
chown root:meteoalert "$FEEDBACK_SIGNING_FILE"
chmod 640 "$FEEDBACK_SIGNING_FILE"

# Credenziali MeteoHub separate: mai incluse nei backup/config YAML e
# scrivibili soltanto dal servizio amministrativo locale.
if [[ -L "$ENGINE_ETC/meteohub.env" ]]; then
  echo "ERRORE: meteohub.env non può essere un link simbolico" >&2
  exit 1
fi
if [[ ! -f "$ENGINE_ETC/meteohub.env" ]]; then
  install -o root -g meteoalert -m 660 /dev/null "$ENGINE_ETC/meteohub.env"
else
  chown root:meteoalert "$ENGINE_ETC/meteohub.env"
  chmod 660 "$ENGINE_ETC/meteohub.env"
fi

say "WebGUI env"
HASH="$(printf '%s' "$WEB_PASS" | "$WEB_DIR/venv/bin/python" -c 'import sys; from werkzeug.security import generate_password_hash; print(generate_password_hash(sys.stdin.read()))')"
unset WEB_PASS WEB_PASS2

SECRET=$("$WEB_DIR/venv/bin/python" - <<'PY'
import secrets
print(secrets.token_hex(32))
PY
)

cat > "$WEB_ETC/web.env" <<EOF
LDZ_METEO_WEB_USERNAME="$WEB_USER"
LDZ_METEO_WEB_PASSWORD_HASH="$HASH"
LDZ_METEO_WEB_SECRET_KEY="$SECRET"
LDZ_METEO_WEB_HOST="127.0.0.1"
LDZ_METEO_WEB_PORT="$WEB_PORT"
LDZ_METEO_APP_PREFIX="$APP_PREFIX"
LDZ_METEO_PUBLIC_BASE_URL="${PUBLIC_BASE_URL}"
LDZ_METEO_CONFIG="${ENGINE_ETC}/config.yml"
LDZ_METEO_SECRETS="${ENGINE_ETC}/secrets.env"
LDZ_METEO_METEOHUB_SECRETS="${ENGINE_ETC}/meteohub.env"
LDZ_METEO_WEATHER_LAB_STATUS="${ENGINE_VAR}/weather-lab/status.json"
LDZ_METEO_PYTHON="${ENGINE_DIR}/venv/bin/python"
LDZ_METEO_SCRIPT="${ENGINE_DIR}/meteo_alert.py"
LDZ_METEO_LOG="${ENGINE_LOG}/meteo-alert.log"
LDZ_METEO_PUBLIC_IMAGE="${DOCROOT}/meteo.jpg"
LDZ_METEO_BACKUP_DIR="${WEB_VAR}/backups"
LDZ_METEO_BACKUP_EXPORT_DIR="${WEB_VAR}/exports"
LDZ_METEO_BACKUP_SETTINGS="${WEB_VAR}/backup-settings.json"
LDZ_METEO_BACKUP_STATE="${WEB_VAR}/backup-state.json"
LDZ_METEO_BACKUP_JOBS="${WEB_VAR}/backup-jobs.jsonl"
LDZ_METEO_BACKUP_PROGRESS="${WEB_VAR}/backup-progress.json"
LDZ_METEO_BACKUP_LOCK="${WEB_VAR}/backup.lock"
LDZ_METEO_BACKUP_HELPER="/usr/local/sbin/ldz-meteo-backup-now"
LDZ_METEO_RESTORE_UPLOAD_DIR="${WEB_VAR}/uploads"
LDZ_METEO_UPDATE_UPLOAD_DIR="${WEB_VAR}/updates"
LDZ_METEO_GEOCODE_CACHE="${WEB_VAR}/geocode_cache.json"
LDZ_METEO_GEOCODE_USER_AGENT="LDZMeteoApp/2.6.0h (${PUBLIC_IMAGE_URL})"
LDZ_METEO_REQUIRE_HTTPS="${REQUIRE_HTTPS}"
LDZ_METEO_ALLOWED_HOSTS="${ALLOWED_HOSTS}"
LDZ_METEO_ALLOWED_ORIGINS="${ALLOWED_ORIGINS}"
LDZ_METEO_ROOT_ACTIONS_ENABLED="${ROOT_ACTIONS_ENABLED}"
LDZ_METEO_ALLOW_EXTERNAL_ASSETS="${ALLOW_EXTERNAL_ASSETS}"
LDZ_METEO_UPDATE_SIGNING_PUBLIC_KEY="${WEB_ETC}/update-signing-public.pem"
LDZ_METEO_PENDING_UPDATE_FILE="${WEB_VAR}/pending-update"
LDZ_METEO_PENDING_RESTORE_FILE="${WEB_VAR}/pending-restore"
LDZ_METEO_UPDATE_STATE="${WEB_VAR}/update-state.json"
LDZ_METEO_UPDATE_SETTINGS="${WEB_VAR}/update-settings.json"
LDZ_METEO_UPDATE_PROGRESS="${WEB_VAR}/update-progress.json"
LDZ_METEO_UPDATE_LOCK="${WEB_VAR}/update-check.lock"
LDZ_METEO_UPDATE_CHECKER="/usr/local/sbin/ldz-meteo-update-check"
LDZ_METEO_UPDATE_NETWORK_ROOT="https://alexandersss.github.io/ldz-meteo-app-updates"
LDZ_METEO_LOGIN_WINDOW_SECONDS="900"
LDZ_METEO_LOGIN_MAX_FAILURES="5"
LDZ_METEO_SESSION_MINUTES="30"
LDZ_METEO_REMEMBER_DAYS="30"
MPLCONFIGDIR="${ENGINE_VAR}/matplotlib"
EOF

chown root:meteoalert "$WEB_ETC/web.env"
chmod 640 "$WEB_ETC/web.env"
rm -f "$WEB_VAR/update-token"

say "Permessi"
chown -R meteoalert:meteoalert "$ENGINE_VAR" "$ENGINE_LOG" "$WEB_VAR" "$WEB_LOG"
chown -R meteoalert:meteoalert "$ENGINE_VAR/matplotlib"
chown -R meteoalert:meteoalert "$ENGINE_VAR/public"
for public_image in \
  "${DOCROOT}/meteo.jpg" \
  "${DOCROOT}/meteo-map.jpg" \
  "${DOCROOT}/meteo-details.jpg"; do
  if [[ -L "$public_image" ]]; then
    echo "ERRORE: immagine pubblica non può essere un link simbolico: $public_image" >&2
    exit 1
  fi
  touch "$public_image"
  chown meteoalert:meteoalert "$public_image"
  chmod 0644 "$public_image"
done
chown root:root "$WEB_VAR/update-work"
chmod 700 "$WEB_VAR/update-work"
mkdir -p "$WEB_VAR/restore-work"
chown root:root "$WEB_VAR/restore-work"
chmod 700 "$WEB_VAR/restore-work"
chmod 755 "$DOCROOT" 2>/dev/null || true

if [[ ! -s "$WEB_ETC/update-signing-private.pem" || ! -s "$WEB_ETC/update-signing-public.pem" ]]; then
  openssl genpkey -algorithm ED25519 -out "$WEB_ETC/update-signing-private.pem"
  openssl pkey -in "$WEB_ETC/update-signing-private.pem" -pubout -out "$WEB_ETC/update-signing-public.pem"
fi
chown root:root "$WEB_ETC"/update-signing-*.pem
chmod 600 "$WEB_ETC/update-signing-private.pem"
chmod 644 "$WEB_ETC/update-signing-public.pem"

say "Helper script"
install -o root -g root -m 750 scripts/ldz-meteo-sync-timer /usr/local/sbin/ldz-meteo-sync-timer
install -o root -g root -m 750 scripts/ldz-meteo-restore-backup /usr/local/sbin/ldz-meteo-restore-backup
install -o root -g meteoalert -m 750 scripts/ldz-meteo-backup-manager /usr/local/sbin/ldz-meteo-backup-manager
install -o root -g root -m 750 scripts/ldz-meteo-backup-now /usr/local/sbin/ldz-meteo-backup-now
install -o root -g root -m 750 scripts/ldz-meteo-backup-sync /usr/local/sbin/ldz-meteo-backup-sync
install -o root -g root -m 750 scripts/ldz-meteo-repair-feedback /usr/local/sbin/ldz-meteo-repair-feedback
install -o root -g root -m 750 scripts/ldz-meteo-repair-update-scheduler /usr/local/sbin/ldz-meteo-repair-update-scheduler
install -o root -g root -m 750 scripts/ldz-meteo-get-chat-id /usr/local/sbin/ldz-meteo-get-chat-id
install -o root -g root -m 750 scripts/ldz-meteo-repair /usr/local/sbin/ldz-meteo-repair
install -o root -g root -m 750 scripts/ldz-meteo-apply-hotfix /usr/local/sbin/ldz-meteo-apply-hotfix
install -o root -g meteoalert -m 750 scripts/ldz-meteo-update-check /usr/local/sbin/ldz-meteo-update-check
install -o root -g root -m 750 scripts/ldz-meteo-approve-update /usr/local/sbin/ldz-meteo-approve-update
install -o root -g meteoalert -m 750 scripts/ldz-meteo-watchdog /usr/local/sbin/ldz-meteo-watchdog
install -o root -g root -m 750 scripts/ldz-meteo-storage-guard /usr/local/sbin/ldz-meteo-storage-guard
install -o root -g root -m 750 scripts/ldz-meteo-support-bundle /usr/local/sbin/ldz-meteo-support-bundle
install -o root -g root -m 700 scripts/ldz-meteo-sign-update /usr/local/sbin/ldz-meteo-sign-update
install -o root -g root -m 750 scripts/ldz-meteo-rotate-feedback-secret /usr/local/sbin/ldz-meteo-rotate-feedback-secret

cat > /etc/sudoers.d/ldz-meteo-web <<'EOF'
Cmnd_Alias LDZ_METEO_WEB_ACTIONS = /usr/local/sbin/ldz-meteo-sync-timer, /usr/local/sbin/ldz-meteo-restore-backup, /usr/local/sbin/ldz-meteo-backup-now, /usr/local/sbin/ldz-meteo-backup-sync, /usr/local/sbin/ldz-meteo-repair-feedback, /usr/local/sbin/ldz-meteo-repair-update-scheduler, /usr/local/sbin/ldz-meteo-repair --web-safe, /usr/local/sbin/ldz-meteo-apply-hotfix, /usr/local/sbin/ldz-meteo-approve-update, /usr/local/sbin/ldz-meteo-support-bundle
meteoalert ALL=(root) NOPASSWD: LDZ_METEO_WEB_ACTIONS
EOF
chmod 440 /etc/sudoers.d/ldz-meteo-web
visudo -cf /etc/sudoers.d/ldz-meteo-web >/dev/null

say "Systemd motore radar"
cat > /etc/systemd/system/meteo-alert.service <<EOF
[Unit]
Description=LDZ Meteo radar alert Telegram
Wants=network-online.target
After=network-online.target

[Service]
Type=oneshot
User=meteoalert
Group=meteoalert
EnvironmentFile=${ENGINE_ETC}/secrets.env
EnvironmentFile=${ENGINE_ETC}/feedback-signing.env
Environment=MPLCONFIGDIR=${ENGINE_VAR}/matplotlib
Environment=LDZ_METEO_METEOHUB_SECRETS=${ENGINE_ETC}/meteohub.env
WorkingDirectory=${ENGINE_DIR}
ExecStart=${ENGINE_DIR}/venv/bin/python ${ENGINE_DIR}/meteo_alert.py --config ${ENGINE_ETC}/config.yml
TimeoutStartSec=8min
CPUQuota=85%
MemoryHigh=1100M
MemoryMax=1350M
SyslogLevelPrefix=true
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=${ENGINE_VAR} ${ENGINE_LOG} ${DOCROOT}
UMask=0027
PrivateDevices=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictNamespaces=true
LockPersonality=true
RestrictSUIDSGID=true
SystemCallArchitectures=native
EOF

cat > /etc/systemd/system/meteo-alert.timer <<EOF
[Unit]
Description=Run LDZ Meteo radar alert periodically

[Timer]
OnBootSec=2min
OnUnitActiveSec=${CHECK_INTERVAL}min
AccuracySec=30s
Persistent=true

[Install]
WantedBy=timers.target
EOF

cat > /etc/systemd/system/meteo-alert-radar-events.service <<EOF
[Unit]
Description=LDZ Meteo Radar-DPC WebSocket event trigger
Wants=network-online.target
After=network-online.target

[Service]
Type=simple
User=meteoalert
Group=meteoalert
EnvironmentFile=${ENGINE_ETC}/secrets.env
EnvironmentFile=${ENGINE_ETC}/feedback-signing.env
Environment=MPLCONFIGDIR=${ENGINE_VAR}/matplotlib
Environment=LDZ_METEO_METEOHUB_SECRETS=${ENGINE_ETC}/meteohub.env
WorkingDirectory=${ENGINE_DIR}
ExecStart=${ENGINE_DIR}/venv/bin/python ${ENGINE_DIR}/radar_wss_listener.py --config ${ENGINE_ETC}/config.yml --engine ${ENGINE_DIR}/meteo_alert.py
MemoryMax=256M
SyslogLevelPrefix=true
Restart=always
RestartSec=10
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadOnlyPaths=${ENGINE_ETC}/config.yml ${ENGINE_ETC}/secrets.env ${ENGINE_ETC}/feedback-signing.env
ReadWritePaths=${ENGINE_VAR} ${ENGINE_LOG} ${DOCROOT}
UMask=0027
PrivateDevices=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictNamespaces=true
LockPersonality=true
RestrictSUIDSGID=true
SystemCallArchitectures=native

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/meteo-alert-telegram-feedback.service <<EOF
[Unit]
Description=LDZ Meteo immediate Telegram feedback listener
Wants=network-online.target
After=network-online.target

[Service]
Type=simple
User=meteoalert
Group=meteoalert
EnvironmentFile=${ENGINE_ETC}/secrets.env
EnvironmentFile=${ENGINE_ETC}/feedback-signing.env
WorkingDirectory=${ENGINE_DIR}
ExecStart=${ENGINE_DIR}/venv/bin/python ${ENGINE_DIR}/telegram_feedback_listener.py --config ${ENGINE_ETC}/config.yml
SyslogLevelPrefix=true
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadOnlyPaths=${ENGINE_ETC}/config.yml ${ENGINE_ETC}/secrets.env ${ENGINE_ETC}/feedback-signing.env
ReadWritePaths=${ENGINE_VAR} ${ENGINE_LOG}
UMask=0077
MemoryMax=192M
PrivateDevices=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictNamespaces=true
LockPersonality=true
RestrictSUIDSGID=true
SystemCallArchitectures=native

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/meteo-alert-watchdog.service <<EOF
[Unit]
Description=LDZ Meteo external data watchdog
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
User=meteoalert
Group=meteoalert
EnvironmentFile=${ENGINE_ETC}/secrets.env
Environment=LDZ_METEO_CONFIG=${ENGINE_ETC}/config.yml
ExecStart=${ENGINE_DIR}/venv/bin/python /usr/local/sbin/ldz-meteo-watchdog
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadOnlyPaths=${ENGINE_ETC}/config.yml ${ENGINE_ETC}/secrets.env
ReadWritePaths=${ENGINE_VAR} ${ENGINE_LOG}
UMask=0077
PrivateDevices=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictNamespaces=true
LockPersonality=true
RestrictSUIDSGID=true
SystemCallArchitectures=native
EOF

cat > /etc/systemd/system/meteo-alert-watchdog.timer <<'EOF'
[Unit]
Description=Check LDZ Meteo engine heartbeat

[Timer]
OnBootSec=5min
OnUnitActiveSec=5min
AccuracySec=30s
Persistent=true

[Install]
WantedBy=timers.target
EOF

cat > /etc/systemd/system/meteo-alert-ai-trainer.service <<EOF
[Unit]
Description=LDZ Meteo Adaptive AI batch trainer
After=meteo-alert.service

[Service]
Type=oneshot
User=meteoalert
Group=meteoalert
WorkingDirectory=${ENGINE_DIR}
ExecStart=${ENGINE_DIR}/venv/bin/python ${ENGINE_DIR}/adaptive_ai_trainer.py --config ${ENGINE_ETC}/config.yml
NoNewPrivileges=true
PrivateTmp=true
PrivateNetwork=true
PrivateIPC=true
ProtectSystem=strict
ProtectHome=true
ProtectClock=true
ProtectHostname=true
ProtectProc=invisible
ProcSubset=pid
ReadOnlyPaths=${ENGINE_ETC}/config.yml
ReadWritePaths=${ENGINE_VAR} ${ENGINE_LOG}
UMask=0077
Nice=15
CPUQuota=35%
MemoryMax=512M
CapabilityBoundingSet=
AmbientCapabilities=
RestrictAddressFamilies=AF_UNIX
IPAddressDeny=any
SystemCallFilter=@system-service
SystemCallErrorNumber=EPERM
RestrictRealtime=true
PrivateDevices=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictNamespaces=true
LockPersonality=true
RestrictSUIDSGID=true
SystemCallArchitectures=native
EOF

cat > /etc/systemd/system/meteo-alert-ai-trainer.timer <<EOF
[Unit]
Description=Train LDZ Meteo Adaptive AI candidate daily

[Timer]
OnCalendar=*-*-* 03:17:00
RandomizedDelaySec=20min
Persistent=true

[Install]
WantedBy=timers.target
EOF

cat > /etc/systemd/system/ldz-meteo-update-check.service <<EOF
[Unit]
Description=LDZ Meteo Update Network checker
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
User=meteoalert
Group=meteoalert
EnvironmentFile=${WEB_ETC}/web.env
ExecStart=${WEB_DIR}/venv/bin/python /usr/local/sbin/ldz-meteo-update-check --scheduled
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadOnlyPaths=${WEB_DIR} ${WEB_ETC}/web.env
ReadWritePaths=${WEB_VAR}
UMask=0077
PrivateDevices=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictNamespaces=true
LockPersonality=true
RestrictSUIDSGID=true
SystemCallArchitectures=native

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/ldz-meteo-update-check.timer <<'EOF'
[Unit]
Description=Schedule LDZ Meteo release checks

[Timer]
OnBootSec=1min
OnCalendar=*-*-* *:*:00
AccuracySec=15s
Persistent=true

[Install]
WantedBy=timers.target
EOF

cat > /etc/systemd/system/ldz-meteo-backup.service <<EOF
[Unit]
Description=LDZ Meteo scheduled verified backup
After=local-fs.target

[Service]
Type=oneshot
User=meteoalert
Group=meteoalert
EnvironmentFile=${WEB_ETC}/web.env
ExecStart=${WEB_DIR}/venv/bin/python /usr/local/sbin/ldz-meteo-backup-manager --scheduled
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadOnlyPaths=${WEB_DIR} ${WEB_ETC}/web.env ${ENGINE_ETC}
ReadWritePaths=${WEB_VAR}
UMask=0077
PrivateDevices=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictNamespaces=true
LockPersonality=true
RestrictSUIDSGID=true
SystemCallArchitectures=native
EOF

cat > /etc/systemd/system/ldz-meteo-backup.timer <<'EOF'
[Unit]
Description=Schedule LDZ Meteo verified backups

[Timer]
OnBootSec=2min
OnCalendar=*-*-* *:*:00
AccuracySec=15s
Persistent=true

[Install]
WantedBy=timers.target
EOF

cat > /etc/systemd/system/ldz-meteo-storage-guard.service <<EOF
[Unit]
Description=LDZ Meteo global storage guard
After=local-fs.target

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/ldz-meteo-storage-guard
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/ldz-meteo-web /var/lib/meteo-alert ${DOCROOT}
UMask=0077
EOF

cat > /etc/systemd/system/ldz-meteo-storage-guard.timer <<'EOF'
[Unit]
Description=Schedule LDZ Meteo storage guard

[Timer]
OnBootSec=3min
OnUnitActiveSec=30min
RandomizedDelaySec=2min
Persistent=true

[Install]
WantedBy=timers.target
EOF

mkdir -p /etc/systemd/journald.conf.d
cat > /etc/systemd/journald.conf.d/ldz-meteo.conf <<'EOF'
[Journal]
Storage=persistent
SystemMaxUse=200M
RuntimeMaxUse=64M
MaxRetentionSec=14day
EOF

say "Systemd WebGUI"
cat > /etc/systemd/system/ldz-meteo-web.service <<EOF
[Unit]
Description=LDZ Meteo App 2.6.0h Weather Lab WebGUI
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=meteoalert
Group=meteoalert
EnvironmentFile=${WEB_ETC}/web.env
WorkingDirectory=${WEB_DIR}
ExecStart=${WEB_DIR}/venv/bin/python ${WEB_DIR}/app.py
Restart=on-failure
RestartSec=5
NoNewPrivileges=false
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=${ENGINE_ETC} ${ENGINE_VAR} ${ENGINE_LOG} ${WEB_VAR} ${WEB_LOG} ${DOCROOT}
Environment=MPLCONFIGDIR=${ENGINE_VAR}/matplotlib
UMask=0027
PrivateDevices=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictNamespaces=true
LockPersonality=true
RestrictSUIDSGID=true
SystemCallArchitectures=native

[Install]
WantedBy=multi-user.target
EOF

chmod 644 /etc/systemd/system/meteo-alert.service /etc/systemd/system/meteo-alert.timer /etc/systemd/system/meteo-alert-radar-events.service /etc/systemd/system/meteo-alert-telegram-feedback.service /etc/systemd/system/meteo-alert-watchdog.service /etc/systemd/system/meteo-alert-watchdog.timer /etc/systemd/system/meteo-alert-ai-trainer.service /etc/systemd/system/meteo-alert-ai-trainer.timer /etc/systemd/system/ldz-meteo-update-check.service /etc/systemd/system/ldz-meteo-update-check.timer /etc/systemd/system/ldz-meteo-backup.service /etc/systemd/system/ldz-meteo-backup.timer /etc/systemd/system/ldz-meteo-storage-guard.service /etc/systemd/system/ldz-meteo-storage-guard.timer /etc/systemd/system/ldz-meteo-web.service
restorecon -Rv /etc/systemd/system/meteo-alert.service /etc/systemd/system/meteo-alert.timer /etc/systemd/system/meteo-alert-radar-events.service /etc/systemd/system/meteo-alert-telegram-feedback.service /etc/systemd/system/meteo-alert-watchdog.service /etc/systemd/system/meteo-alert-watchdog.timer /etc/systemd/system/meteo-alert-ai-trainer.service /etc/systemd/system/meteo-alert-ai-trainer.timer /etc/systemd/system/ldz-meteo-update-check.service /etc/systemd/system/ldz-meteo-update-check.timer /etc/systemd/system/ldz-meteo-backup.service /etc/systemd/system/ldz-meteo-backup.timer /etc/systemd/system/ldz-meteo-storage-guard.service /etc/systemd/system/ldz-meteo-storage-guard.timer /etc/systemd/system/ldz-meteo-web.service /etc/systemd/journald.conf.d/ldz-meteo.conf 2>/dev/null || true

systemctl daemon-reload
systemctl try-restart systemd-journald.service
systemctl enable --now meteo-alert.timer
systemctl enable --now meteo-alert-radar-events.service
systemctl enable --now meteo-alert-telegram-feedback.service
systemctl enable --now meteo-alert-watchdog.timer
systemctl enable --now meteo-alert-ai-trainer.timer
systemctl enable --now ldz-meteo-update-check.timer
systemctl enable --now ldz-meteo-backup.timer
systemctl enable --now ldz-meteo-storage-guard.timer
systemctl enable --now ldz-meteo-web.service

say "Apache"
ensure_apache_default_ssl_cert() {
  # mod_ssl su Alma/RHEL può caricare /etc/httpd/conf.d/ssl.conf con localhost.crt/key.
  # Se mancano, apachectl configtest fallisce anche se il nostro vhost è corretto.
  if [[ ! -s /etc/pki/tls/certs/localhost.crt || ! -s /etc/pki/tls/private/localhost.key ]]; then
    mkdir -p /etc/pki/tls/certs /etc/pki/tls/private
    openssl req -x509 -newkey rsa:2048 -nodes -days 3650 \
      -subj "/CN=${SERVER_IP}" \
      -keyout /etc/pki/tls/private/localhost.key \
      -out /etc/pki/tls/certs/localhost.crt >/dev/null 2>&1
    chmod 600 /etc/pki/tls/private/localhost.key
    chmod 644 /etc/pki/tls/certs/localhost.crt
  fi
}

create_selfsigned_cert() {
  CERT_FILE="/etc/pki/tls/certs/ldz-meteo-${SERVER_IP}.crt"
  KEY_FILE="/etc/pki/tls/private/ldz-meteo-${SERVER_IP}.key"
  mkdir -p /etc/pki/tls/certs /etc/pki/tls/private
  openssl req -x509 -newkey rsa:4096 -nodes -days 825 \
    -subj "/CN=${SERVER_IP}" \
    -addext "subjectAltName=DNS:${SERVER_IP},IP:${SERVER_IP}" \
    -keyout "$KEY_FILE" \
    -out "$CERT_FILE" >/dev/null 2>&1 || \
  openssl req -x509 -newkey rsa:4096 -nodes -days 825 \
    -subj "/CN=${SERVER_IP}" \
    -keyout "$KEY_FILE" \
    -out "$CERT_FILE" >/dev/null 2>&1
  chmod 600 "$KEY_FILE"
  chmod 644 "$CERT_FILE"
}

if ask_yes_no "Configurare Apache automaticamente?" "y"; then
  cat > /etc/httpd/conf.d/00-ldz-servername.conf <<EOF
ServerName ${SERVER_IP}
EOF

  CONF="/etc/httpd/conf.d/ldzmeteoapp.conf"
  LISTEN_CONF="/etc/httpd/conf.d/00-ldz-meteo-listen.conf"
  : > "$LISTEN_CONF"
  if [[ "$PUBLIC_PORT" != "80" && "$PUBLIC_PORT" != "443" ]]; then
    echo "Listen ${PUBLIC_PORT}" > "$LISTEN_CONF"
  fi

  if [[ "$PUBLISH_MODE" == "http" ]]; then
    cat > "$CONF" <<EOF
# LDZ Meteo App 2.6 stable reverse proxy - HTTP
<VirtualHost *:${PUBLIC_PORT}>
    ServerName ${SERVER_IP}
    ProxyPreserveHost On
    ProxyTimeout 330
    LimitRequestBody 94371840
    RequestHeader set X-Forwarded-Prefix "${APP_PREFIX}"
    RequestHeader set X-Forwarded-Proto "http"
    ProxyPass        ${APP_PREFIX}/ http://127.0.0.1:${WEB_PORT}/
    ProxyPassReverse ${APP_PREFIX}/ http://127.0.0.1:${WEB_PORT}/
    RedirectMatch 302 ^${APP_PREFIX}$ ${APP_PREFIX}/
    <Files "meteo.jpg">
        Header set Cache-Control "no-cache, no-store, must-revalidate"
        Header set Pragma "no-cache"
        Header set Expires "0"
    </Files>
</VirtualHost>
EOF
  else
    ensure_apache_default_ssl_cert
    if [[ "$PUBLISH_MODE" == "https-selfsigned" ]]; then
      create_selfsigned_cert
    fi
    if [[ ! -s "$CERT_FILE" || ! -s "$KEY_FILE" ]]; then
      echo "Certificato o chiave SSL non trovati: $CERT_FILE / $KEY_FILE"
      exit 1
    fi
    cat > "$CONF" <<EOF
# LDZ Meteo App 2.6 stable reverse proxy - HTTPS
<VirtualHost *:80>
    ServerName ${SERVER_IP}
    Redirect permanent / ${PUBLIC_ORIGIN}/
</VirtualHost>

<VirtualHost *:${PUBLIC_PORT}>
    ServerName ${SERVER_IP}
    SSLEngine on
    SSLCertificateFile ${CERT_FILE}
    SSLCertificateKeyFile ${KEY_FILE}

    ProxyPreserveHost On
    ProxyTimeout 330
    LimitRequestBody 94371840
    RequestHeader set X-Forwarded-Prefix "${APP_PREFIX}"
    RequestHeader set X-Forwarded-Proto "https"
    RequestHeader set X-Forwarded-SSL "on"

    ProxyPass        ${APP_PREFIX}/ http://127.0.0.1:${WEB_PORT}/
    ProxyPassReverse ${APP_PREFIX}/ http://127.0.0.1:${WEB_PORT}/
    RedirectMatch 302 ^${APP_PREFIX}$ ${APP_PREFIX}/

    Header always set Strict-Transport-Security "max-age=31536000"

    <Files "meteo.jpg">
        Header set Cache-Control "no-cache, no-store, must-revalidate"
        Header set Pragma "no-cache"
        Header set Expires "0"
    </Files>
</VirtualHost>
EOF
  fi

  if command -v setsebool >/dev/null 2>&1; then
    setsebool -P httpd_can_network_connect 1 || true
  fi

  apachectl configtest
  systemctl enable --now httpd
  systemctl restart httpd
fi

say "Dry-run iniziale"
sudo -u meteoalert MPLCONFIGDIR="${ENGINE_VAR}/matplotlib" "${ENGINE_DIR}/venv/bin/python" "${ENGINE_DIR}/meteo_alert.py" --config "${ENGINE_ETC}/config.yml" --dry-run || true

if [[ -n "$TELEGRAM_TOKEN" && -n "$TELEGRAM_CHAT_ID" ]]; then
  if ask_yes_no "Inviare messaggio Telegram di test?" "y"; then
    "${WEB_DIR}/venv/bin/python" - <<PY || true
import urllib.parse, urllib.request
token = """$TELEGRAM_TOKEN"""
chat_id = """$TELEGRAM_CHAT_ID"""
text = "✅ Test LDZ Meteo App 2.6.0h OK\\nInstallazione completata. Console di gestione, Weather Lab, feedback Telegram e backup sono operativi."
data = urllib.parse.urlencode({"chat_id": chat_id, "parse_mode": "HTML", "text": text}).encode()
url = f"https://api.telegram.org/bot{token}/sendMessage"
try:
    with urllib.request.urlopen(url, data=data, timeout=20) as r:
        print(r.read().decode())
except Exception as e:
    print(f"Errore test Telegram: {e}")
PY
  fi
fi

say "Verifiche"
systemctl status meteo-alert.timer --no-pager || true
systemctl status ldz-meteo-web.service --no-pager || true
curl -I "http://127.0.0.1:${WEB_PORT}/login" || true
curl -k -I "${PUBLIC_SCHEME}://127.0.0.1${PUBLIC_PORT_SUFFIX}${APP_PREFIX}/" || true
curl -k -I "${PUBLIC_SCHEME}://127.0.0.1${PUBLIC_PORT_SUFFIX}${APP_PREFIX}/radar-image" || true

echo
panel "MISSION COMPLETE" \
  "LDZ Meteo App 2.6.0h è operativa" \
  "WebGUI            : ${PUBLIC_BASE_URL}/" \
  "Radar pubblico    : ${PUBLIC_IMAGE_URL}" \
  "Timer             : meteo-alert.timer" \
  "Modello           : stable-impact-ensemble"
ok "Installazione completata. Apri la WebGUI e controlla Terrain & Lifecycle Engine nella dashboard."
echo "WebGUI:      ${PUBLIC_BASE_URL}/"
echo "meteo.jpg:   ${PUBLIC_IMAGE_URL}"
echo "Config:      ${ENGINE_ETC}/config.yml"
echo "Secrets:     ${ENGINE_ETC}/secrets.env"
echo "Radar log:   ${ENGINE_LOG}/meteo-alert.log"
echo "WebGUI log:  journalctl -u ldz-meteo-web.service -n 100 --no-pager"
