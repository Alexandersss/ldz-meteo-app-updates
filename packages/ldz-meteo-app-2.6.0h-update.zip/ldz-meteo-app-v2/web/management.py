"""Funzioni pure e bounded per la console di gestione LDZ Meteo.

Il modulo non esegue comandi privilegiati: prepara/valida dati usati dalla
WebGUI e dagli helper allowlisted. Questo mantiene testabili retention,
pianificazione, template, log e metriche senza allargare sudoers.
"""

from __future__ import annotations

import csv
import hashlib
import hmac
import io
import json
import math
import os
import re
import string
import time
import zipfile
from collections import deque
from datetime import datetime, timedelta, timezone
from html import escape
from pathlib import Path
from typing import Any, Callable, Iterable
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


ROME_TZ = "Europe/Rome"
BACKUP_FREQUENCIES = {"daily", "weekly", "custom"}
RETENTION_MODES = {"count", "days"}
TEMPLATE_VARIABLES = {
    "target", "eta", "intensity", "intensity_title", "vmi", "poh", "vil",
    "etm", "speed", "hail", "action", "source", "probability", "event_type",
}
SAMPLE_TEMPLATE_DATA = {
    "target": "Pescasseroli", "eta": "25–35 minuti", "intensity": "Forte",
    "intensity_title": "Temporale in avvicinamento", "vmi": "56.4", "poh": "42%",
    "vil": "31", "etm": "11.8 km", "speed": "38 km/h", "hail": "Grandine possibile",
    "action": "Segui i prossimi aggiornamenti e ripara gli oggetti esposti.",
    "source": "Radar-DPC", "probability": "68%", "event_type": "Temporale forte",
}


def safe_timezone(name: Any) -> ZoneInfo:
    candidate = str(name or ROME_TZ)
    if candidate != ROME_TZ:
        candidate = ROME_TZ
    try:
        return ZoneInfo(candidate)
    except ZoneInfoNotFoundError:
        return ZoneInfo("UTC")


def normalize_backup_settings(value: dict[str, Any] | None) -> dict[str, Any]:
    raw = value if isinstance(value, dict) else {}
    frequency = str(raw.get("frequency", "daily"))
    retention_mode = str(raw.get("retention_mode", "count"))
    schedule_time = str(raw.get("schedule_time", "02:30"))
    start_date = str(raw.get("start_date", ""))
    if frequency not in BACKUP_FREQUENCIES:
        frequency = "daily"
    if retention_mode not in RETENTION_MODES:
        retention_mode = "count"
    if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", schedule_time):
        schedule_time = "02:30"
    if start_date and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", start_date):
        start_date = ""
    return {
        "enabled": bool(raw.get("enabled", False)),
        "frequency": frequency,
        "schedule_time": schedule_time,
        "weekday": max(0, min(6, _safe_int(raw.get("weekday"), 0))),
        "custom_days": max(1, min(365, _safe_int(raw.get("custom_days"), 2))),
        "start_date": start_date,
        "timezone": ROME_TZ,
        "include_secrets": bool(raw.get("include_secrets", False)),
        "retention_mode": retention_mode,
        "retention_count": max(1, min(500, _safe_int(raw.get("retention_count"), 20))),
        "retention_days": max(1, min(3650, _safe_int(raw.get("retention_days"), 30))),
        "max_space_mb": max(0, min(102400, _safe_int(raw.get("max_space_mb"), 0))),
        "last_changed_epoch": max(0, _safe_int(raw.get("last_changed_epoch"), 0)),
    }


def next_backup_epoch(settings: dict[str, Any], now_epoch: float | None = None) -> float | None:
    cfg = normalize_backup_settings(settings)
    if not cfg["enabled"]:
        return None
    tz = safe_timezone(cfg["timezone"])
    now = datetime.fromtimestamp(now_epoch if now_epoch is not None else time.time(), tz)
    hour, minute = (int(part) for part in cfg["schedule_time"].split(":", 1))
    candidate = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if cfg["frequency"] == "daily":
        if candidate <= now:
            candidate += timedelta(days=1)
    elif cfg["frequency"] == "weekly":
        candidate += timedelta(days=(cfg["weekday"] - now.weekday()) % 7)
        if candidate <= now:
            candidate += timedelta(days=7)
    else:
        start = now.date()
        if cfg["start_date"]:
            try:
                start = datetime.strptime(cfg["start_date"], "%Y-%m-%d").date()
            except ValueError:
                pass
        days = cfg["custom_days"]
        elapsed = max(0, (now.date() - start).days)
        offset = (-elapsed) % days
        candidate = datetime.combine(now.date() + timedelta(days=offset), datetime.min.time(), tzinfo=tz).replace(hour=hour, minute=minute)
        if candidate <= now:
            candidate += timedelta(days=days)
    return candidate.timestamp()


def backup_due(settings: dict[str, Any], state: dict[str, Any], now_epoch: float | None = None) -> bool:
    cfg = normalize_backup_settings(settings)
    if not cfg["enabled"]:
        return False
    now = float(now_epoch if now_epoch is not None else time.time())
    last = float(state.get("last_success_epoch", 0) or 0)
    # Calcola l'occorrenza precedente senza usare last_changed come falsa esecuzione.
    probe = next_backup_epoch(cfg, now - 370 * 86400)
    due = None
    while probe is not None and probe <= now:
        due = probe
        probe = next_backup_epoch(cfg, probe + 1)
    return due is not None and last < due


def retention_victims(paths: Iterable[Path], settings: dict[str, Any], now_epoch: float | None = None) -> list[Path]:
    cfg = normalize_backup_settings(settings)
    now = float(now_epoch if now_epoch is not None else time.time())
    items = sorted((p for p in paths if p.is_file() and not p.is_symlink()), key=lambda p: p.stat().st_mtime, reverse=True)
    victims: set[Path] = set()
    if cfg["retention_mode"] == "count":
        victims.update(items[cfg["retention_count"]:])
    else:
        cutoff = now - cfg["retention_days"] * 86400
        victims.update(p for p in items if p.stat().st_mtime < cutoff)
    max_bytes = cfg["max_space_mb"] * 1024 * 1024
    kept = [p for p in items if p not in victims]
    if max_bytes:
        total = sum(p.stat().st_size for p in kept)
        for path in reversed(kept):
            if total <= max_bytes:
                break
            victims.add(path)
            total -= path.stat().st_size
    return sorted(victims, key=lambda p: p.stat().st_mtime)


def inspect_backup(path: Path, verify_hashes: bool = True) -> dict[str, Any]:
    result = {"ok": False, "name": path.name, "error": "", "files": [], "manifest": {}, "sha256": ""}
    try:
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 16 * 1024 * 1024:
            raise ValueError("Archivio assente, simbolico o oltre il limite")
        result["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
            if "manifest.json" not in names:
                raise ValueError("Manifest backup mancante")
            manifest = json.loads(archive.read("manifest.json"))
            allowed = {"etc/meteo-alert/config.yml", "etc/meteo-alert/secrets.env"}
            files = manifest.get("files", {}) if isinstance(manifest, dict) else {}
            if manifest.get("type") != "configuration-backup" or not isinstance(files, dict):
                raise ValueError("Manifest backup non riconosciuto")
            if set(files) - allowed or set(names) - allowed - {"manifest.json"}:
                raise ValueError("Il backup contiene percorsi non autorizzati")
            if "etc/meteo-alert/config.yml" not in files:
                raise ValueError("config.yml mancante")
            if verify_hashes:
                for name, expected in files.items():
                    digest = hashlib.sha256(archive.read(name)).hexdigest()
                    if digest != str(expected).lower():
                        raise ValueError(f"Checksum non valido per {name}")
            result.update(ok=True, files=sorted(files), manifest=manifest)
    except (OSError, ValueError, KeyError, json.JSONDecodeError, zipfile.BadZipFile) as exc:
        result["error"] = str(exc)[:400]
    return result


def read_json_lines(path: Path, limit: int = 1000) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    try:
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 16 * 1024 * 1024:
            return rows
        with path.open(encoding="utf-8", errors="replace") as handle:
            for line in handle:
                try:
                    value = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(value, dict):
                    rows.append(value)
                    if len(rows) > limit:
                        rows.pop(0)
    except OSError:
        return []
    return rows


def template_variables(body: str) -> tuple[set[str], set[str]]:
    found: set[str] = set()
    invalid: set[str] = set()
    try:
        for _literal, field, _spec, _conversion in string.Formatter().parse(body):
            if field:
                (found if field in TEMPLATE_VARIABLES else invalid).add(field)
    except ValueError:
        invalid.add("sintassi")
    return found, invalid


def validate_template(body: str) -> tuple[bool, str]:
    value = str(body or "").strip()
    if not value:
        return False, "Il template non può essere vuoto"
    if len(value) > 8000:
        return False, "Il template supera 8.000 caratteri"
    _known, invalid = template_variables(value)
    if invalid:
        return False, "Variabili non riconosciute: " + ", ".join(sorted(invalid))
    try:
        value.format_map(SAMPLE_TEMPLATE_DATA)
    except (KeyError, ValueError) as exc:
        return False, f"Template non valido: {exc}"
    return True, "Template valido"


def render_template_sample(body: str) -> str:
    ok, message = validate_template(body)
    if not ok:
        raise ValueError(message)
    return body.format_map(SAMPLE_TEMPLATE_DATA)


SECRET_RE = re.compile(
    r"(?i)(authorization\s*[:=]\s*(?:bearer\s+)?|token\s*[:=]\s*|password\s*[:=]\s*|cookie\s*[:=]\s*|api[_-]?key\s*[:=]\s*)([^\s,;]+)"
)
TELEGRAM_TOKEN_RE = re.compile(r"\b\d{6,12}:[A-Za-z0-9_-]{20,}\b")


def redact_log_line(line: Any) -> str:
    value = str(line or "")[:4000]
    value = SECRET_RE.sub(lambda m: m.group(1) + "[REDACTED]", value)
    return TELEGRAM_TOKEN_RE.sub("[REDACTED_TELEGRAM_TOKEN]", value)


WEATHER_LAB_EXPORT_MAX_JSON_BYTES = 8 * 1024 * 1024
WEATHER_LAB_EXPORT_MAX_ARCHIVE_BYTES = 256 * 1024 * 1024
WEATHER_LAB_EXPORT_MAX_OUTCOMES = 1_000_000
WEATHER_LAB_EXPORT_RECENT_OUTCOMES = 50_000
WEATHER_LAB_EXPORT_MAX_ZIP_BYTES = 64 * 1024 * 1024
WEATHER_LAB_EXPORT_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
WEATHER_LAB_EXPORT_JWT_RE = re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b")
WEATHER_LAB_EXPORT_COORD_RE = re.compile(
    r"(?i)\b(lat|lon|latitude|longitude)\b\s*[:=]\s*-?\d{1,3}(?:\.\d+)?"
)
WEATHER_LAB_EXPORT_IP_RE = re.compile(r"(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])")


def _weather_lab_read_json(path: Path) -> dict[str, Any]:
    try:
        if not path.is_file() or path.is_symlink():
            return {}
        if path.stat().st_size > WEATHER_LAB_EXPORT_MAX_JSON_BYTES:
            return {}
        value = json.loads(path.read_text(encoding="utf-8", errors="replace"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def _weather_lab_number(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return number if math.isfinite(number) else None


def _weather_lab_target_alias(name: Any, secret: str) -> str:
    normalized = str(name or "").strip()
    if not normalized:
        return "TARGET_UNKNOWN"
    digest = hmac.new(
        str(secret).encode("utf-8", errors="replace"),
        ("weather-lab-export-target:" + normalized).encode("utf-8", errors="replace"),
        hashlib.sha256,
    ).hexdigest()[:8].upper()
    return f"TARGET_{digest}"


def _weather_lab_anonymize_text(value: Any, aliases: dict[str, str]) -> str:
    text = redact_log_line(value)
    text = WEATHER_LAB_EXPORT_EMAIL_RE.sub("[EMAIL_REDACTED]", text)
    text = WEATHER_LAB_EXPORT_JWT_RE.sub("[TOKEN_REDACTED]", text)
    text = WEATHER_LAB_EXPORT_COORD_RE.sub(lambda match: f"{match.group(1)}=[REDACTED]", text)
    text = WEATHER_LAB_EXPORT_IP_RE.sub("[IP_REDACTED]", text)
    for name, alias in sorted(aliases.items(), key=lambda item: len(item[0]), reverse=True):
        if name:
            text = re.sub(re.escape(name), alias, text, flags=re.IGNORECASE)
    return text[:4000]


def _weather_lab_csv(rows: Iterable[dict[str, Any]], fields: tuple[str, ...]) -> bytes:
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore", lineterminator="\n")
    writer.writeheader()
    for row in rows:
        writer.writerow({key: row.get(key, "") for key in fields})
    return output.getvalue().encode("utf-8")


def _weather_lab_metric_bucket() -> dict[str, Any]:
    return {
        "samples": 0, "brier_sum": 0.0, "correct": 0,
        "events": 0, "dry": 0, "true_positive": 0, "true_negative": 0,
        "false_alarms": 0, "missed_events": 0, "continuous_samples": 0,
        "absolute_error_sum": 0.0, "squared_error_sum": 0.0, "bias_sum": 0.0,
    }


def _weather_lab_add_outcome(bucket: dict[str, Any], row: dict[str, Any]) -> None:
    probability = _weather_lab_number(row.get("probability_percent"))
    if probability is None:
        return
    probability = max(0.0, min(100.0, probability)) / 100.0
    observed = row.get("event_observed") is True
    predicted = probability >= 0.5
    bucket["samples"] += 1
    bucket["brier_sum"] += (probability - float(observed)) ** 2
    bucket["correct"] += int(predicted == observed)
    bucket["events"] += int(observed)
    bucket["dry"] += int(not observed)
    bucket["true_positive"] += int(predicted and observed)
    bucket["true_negative"] += int(not predicted and not observed)
    bucket["false_alarms"] += int(predicted and not observed)
    bucket["missed_events"] += int(not predicted and observed)
    absolute = _weather_lab_number(row.get("absolute_error_mmh"))
    squared = _weather_lab_number(row.get("squared_error_mmh"))
    bias = _weather_lab_number(row.get("bias_mmh"))
    if absolute is not None and squared is not None and bias is not None:
        bucket["continuous_samples"] += 1
        bucket["absolute_error_sum"] += abs(absolute)
        bucket["squared_error_sum"] += max(0.0, squared)
        bucket["bias_sum"] += bias


def _weather_lab_finish_metric(target: str, model: str, lead: int, bucket: dict[str, Any], day: str = "") -> dict[str, Any]:
    samples = int(bucket.get("samples", 0) or 0)
    continuous = int(bucket.get("continuous_samples", 0) or 0)
    predicted_events = int(bucket.get("true_positive", 0) or 0) + int(bucket.get("false_alarms", 0) or 0)
    observed_events = int(bucket.get("true_positive", 0) or 0) + int(bucket.get("missed_events", 0) or 0)
    return {
        "day_utc": day,
        "target": target,
        "model": model,
        "lead_minutes": lead,
        "samples": samples,
        "observed_events": int(bucket.get("events", 0) or 0),
        "observed_dry": int(bucket.get("dry", 0) or 0),
        "accuracy_percent": round(100.0 * int(bucket.get("correct", 0) or 0) / samples, 2) if samples else "",
        "brier": round(float(bucket.get("brier_sum", 0.0) or 0.0) / samples, 6) if samples else "",
        "false_alarms": int(bucket.get("false_alarms", 0) or 0),
        "missed_events": int(bucket.get("missed_events", 0) or 0),
        "false_alarm_percent": round(100.0 * int(bucket.get("false_alarms", 0) or 0) / predicted_events, 2) if predicted_events else "",
        "missed_event_percent": round(100.0 * int(bucket.get("missed_events", 0) or 0) / observed_events, 2) if observed_events else "",
        "continuous_samples": continuous,
        "mae_mmh": round(float(bucket.get("absolute_error_sum", 0.0) or 0.0) / continuous, 6) if continuous else "",
        "rmse_mmh": round(math.sqrt(float(bucket.get("squared_error_sum", 0.0) or 0.0) / continuous), 6) if continuous else "",
        "bias_mmh": round(float(bucket.get("bias_sum", 0.0) or 0.0) / continuous, 6) if continuous else "",
    }


def _weather_lab_status_summary(status: dict[str, Any]) -> dict[str, Any]:
    radar = status.get("radar", {}) if isinstance(status.get("radar"), dict) else {}
    linda = status.get("linda", {}) if isinstance(status.get("linda"), dict) else {}
    meteohub = status.get("meteohub", {}) if isinstance(status.get("meteohub"), dict) else {}
    archive = status.get("archive", {}) if isinstance(status.get("archive"), dict) else {}
    return {
        "weather_lab": {
            "enabled": bool(status.get("enabled")), "status": str(status.get("status") or "unknown")[:40],
            "status_label": str(status.get("status_label") or "")[:160], "mode": str(status.get("mode") or "shadow")[:40],
            "affects_alerts": bool(status.get("affects_alerts")), "updated_utc": str(status.get("updated_utc") or "")[:80],
        },
        "radar_dpc": {
            "available": bool(radar.get("available")), "product": str(radar.get("product") or "")[:40],
            "timestamp_ms": _safe_int(radar.get("timestamp_ms"), 0),
        },
        "linda": {
            "enabled": bool(linda.get("enabled")), "available": bool(linda.get("available")),
            "status": str(linda.get("status") or "unknown")[:40], "status_label": str(linda.get("status_label") or "")[:160],
            "frames": _safe_int(linda.get("frames"), 0), "timestep_minutes": _weather_lab_number(linda.get("timestep_minutes")),
            "ensemble_members": _safe_int(linda.get("ensemble_members"), 0), "version": str(linda.get("version") or "")[:80],
            "error": str(linda.get("error") or linda.get("reason") or "")[:160], "affects_alerts": bool(linda.get("affects_alerts")),
        },
        "meteohub_icon": {
            "enabled": bool(meteohub.get("enabled")), "connected": bool(meteohub.get("connected")),
            "status": str(meteohub.get("status") or "unknown")[:40], "status_label": str(meteohub.get("status_label") or "")[:160],
            "source_mode": str(meteohub.get("source_mode") or "")[:80], "latest_run": str(meteohub.get("latest_run") or "")[:32],
            "processed_count": _safe_int(meteohub.get("processed_count"), 0), "failed_count": _safe_int(meteohub.get("failed_count"), 0),
            "forecast_count": _safe_int(meteohub.get("forecast_count"), 0), "last_success_utc": str(meteohub.get("last_success_utc") or "")[:80],
            "error": str(meteohub.get("error") or "")[:200], "affects_alerts": bool(meteohub.get("affects_alerts")),
        },
        "archive": {
            "forecasts": _safe_int(archive.get("forecasts"), 0), "outcomes": _safe_int(archive.get("outcomes"), 0),
            "pending": _safe_int(archive.get("pending"), 0),
        },
    }


def build_weather_lab_export(
    root: Path,
    cfg: dict[str, Any],
    *,
    app_version: str,
    secret: str,
    mode: str = "quick",
    diagnostic_lines: Iterable[str] = (),
    now: datetime | None = None,
) -> tuple[bytes, dict[str, Any]]:
    """Create a bounded, anonymized Weather Lab analysis package."""
    selected_mode = str(mode or "quick").strip().lower()
    if selected_mode not in {"quick", "complete"}:
        raise ValueError("Modalità export Weather Lab non valida")
    data_root = Path(root)
    if data_root.is_symlink():
        raise ValueError("Directory Weather Lab non valida")
    generated = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    status = _weather_lab_read_json(data_root / "status.json")
    ledger = _weather_lab_read_json(data_root / "ledger.json")
    configured_targets = cfg.get("targets", []) if isinstance(cfg.get("targets"), list) else []
    aliases = {
        str(item.get("name") or ""): _weather_lab_target_alias(item.get("name"), secret)
        for item in configured_targets if isinstance(item, dict) and str(item.get("name") or "").strip()
    }

    def alias_for(value: Any) -> str:
        name = str(value or "").strip()
        return aliases.setdefault(name, _weather_lab_target_alias(name, secret))

    summary: dict[str, Any] = {
        "schema_version": 1,
        "app": "LDZ Meteo App",
        "app_version": str(app_version),
        "generated_utc": generated.isoformat(),
        "export_mode": selected_mode,
        "privacy": {
            "target_names_anonymized": True, "coordinates_excluded": True,
            "credentials_excluded": True, "telegram_configuration_excluded": True,
            "grib_and_radar_images_excluded": True, "target_aliases_stable_for_this_installation": True,
        },
        "status": _weather_lab_status_summary(status),
        "coverage": {
            "archive_files": 0, "archive_bytes_scanned": 0, "outcomes_scanned": 0,
            "invalid_rows": 0, "truncated": False, "first_verified_utc": "", "last_verified_utc": "",
        },
    }
    for section in ("weather_lab", "linda", "meteohub_icon"):
        item = summary["status"].get(section, {})
        for key in ("status_label", "error"):
            if key in item:
                item[key] = _weather_lab_anonymize_text(item[key], aliases)

    metric_fields = (
        "target", "model", "lead_minutes", "samples", "observed_events", "observed_dry",
        "accuracy_percent", "brier", "false_alarms", "missed_events", "false_alarm_percent",
        "missed_event_percent", "continuous_samples", "mae_mmh", "rmse_mmh", "bias_mmh",
    )
    overall: dict[tuple[str, str, int], dict[str, Any]] = {}
    daily: dict[tuple[str, str, str, int], dict[str, Any]] = {}
    recent: deque[dict[str, Any]] = deque(maxlen=WEATHER_LAB_EXPORT_RECENT_OUTCOMES)

    if selected_mode == "complete":
        lab_cfg = cfg.get("weather_lab", {}) if isinstance(cfg.get("weather_lab"), dict) else {}
        retention_days = max(7, min(365, int(lab_cfg.get("retention_days", 90) or 90)))
        cutoff = (generated - timedelta(days=retention_days)).date()
        archive_dir = data_root / "archive"
        files = [] if archive_dir.is_symlink() else sorted(archive_dir.glob("events-*.jsonl"))
        for path in files:
            match = re.fullmatch(r"events-(\d{8})\.jsonl", path.name)
            try:
                file_day = datetime.strptime(match.group(1), "%Y%m%d").date() if match else None
                size = path.stat().st_size
            except (OSError, ValueError):
                summary["coverage"]["invalid_rows"] += 1
                continue
            if file_day is None or file_day < cutoff or not path.is_file() or path.is_symlink():
                continue
            if summary["coverage"]["archive_bytes_scanned"] + size > WEATHER_LAB_EXPORT_MAX_ARCHIVE_BYTES:
                summary["coverage"]["truncated"] = True
                break
            summary["coverage"]["archive_files"] += 1
            summary["coverage"]["archive_bytes_scanned"] += size
            try:
                with path.open("r", encoding="utf-8", errors="replace") as handle:
                    for raw_line in handle:
                        if len(raw_line) > 32768:
                            summary["coverage"]["invalid_rows"] += 1
                            continue
                        try:
                            row = json.loads(raw_line)
                        except (ValueError, TypeError):
                            summary["coverage"]["invalid_rows"] += 1
                            continue
                        if not isinstance(row, dict) or row.get("kind") != "outcome":
                            continue
                        if summary["coverage"]["outcomes_scanned"] >= WEATHER_LAB_EXPORT_MAX_OUTCOMES:
                            summary["coverage"]["truncated"] = True
                            break
                        lead = _safe_int(row.get("lead_minutes"), 0)
                        if lead < 1 or lead > 1440:
                            summary["coverage"]["invalid_rows"] += 1
                            continue
                        if not isinstance(row.get("event_observed"), bool):
                            summary["coverage"]["invalid_rows"] += 1
                            continue
                        target = alias_for(row.get("target"))
                        model = re.sub(r"[^A-Za-z0-9_.-]", "_", str(row.get("model") or "unknown"))[:80]
                        verified_ms = _safe_int(row.get("verified_at_ms"), 0)
                        try:
                            verified = datetime.fromtimestamp(verified_ms / 1000, timezone.utc)
                        except (OSError, ValueError, OverflowError):
                            summary["coverage"]["invalid_rows"] += 1
                            continue
                        day = verified.strftime("%Y-%m-%d")
                        overall_bucket = overall.setdefault((target, model, lead), _weather_lab_metric_bucket())
                        daily_bucket = daily.setdefault((day, target, model, lead), _weather_lab_metric_bucket())
                        _weather_lab_add_outcome(overall_bucket, row)
                        _weather_lab_add_outcome(daily_bucket, row)
                        probability = _weather_lab_number(row.get("probability_percent"))
                        observed = row.get("observed", {}) if isinstance(row.get("observed"), dict) else {}
                        recent.append({
                            "verified_utc": verified.isoformat(), "target": target, "model": model,
                            "lead_minutes": lead, "probability_percent": round(probability, 3) if probability is not None else "",
                            "event_observed": row.get("event_observed") is True,
                            "rain_rate_mmh": _weather_lab_number(observed.get("rain_rate_mmh")),
                            "vmi_dbz": _weather_lab_number(observed.get("vmi_dbz")),
                            "predicted_precipitation_rate_mmh": _weather_lab_number(row.get("predicted_precipitation_rate_mmh")),
                            "absolute_error_mmh": _weather_lab_number(row.get("absolute_error_mmh")),
                            "bias_mmh": _weather_lab_number(row.get("bias_mmh")),
                        })
                        summary["coverage"]["outcomes_scanned"] += 1
                        if not summary["coverage"]["first_verified_utc"]:
                            summary["coverage"]["first_verified_utc"] = verified.isoformat()
                        summary["coverage"]["last_verified_utc"] = verified.isoformat()
            except OSError:
                summary["coverage"]["invalid_rows"] += 1
            if summary["coverage"]["truncated"]:
                break

    metrics: list[dict[str, Any]] = []
    daily_metrics: list[dict[str, Any]] = []
    if overall:
        metrics = [
            _weather_lab_finish_metric(target, model, lead, bucket)
            for (target, model, lead), bucket in sorted(overall.items())
        ]
        daily_metrics = [
            _weather_lab_finish_metric(target, model, lead, bucket, day)
            for (day, target, model, lead), bucket in sorted(daily.items())
        ]
    else:
        raw_metrics = ((status.get("archive") or {}).get("metrics") or []) if isinstance(status.get("archive"), dict) else []
        for row in raw_metrics if isinstance(raw_metrics, list) else []:
            if not isinstance(row, dict):
                continue
            metrics.append({
                "target": "ALL_TARGETS", "model": str(row.get("model") or "unknown")[:80],
                "lead_minutes": _safe_int(row.get("lead_minutes"), 0), "samples": _safe_int(row.get("samples"), 0),
                "observed_events": "", "observed_dry": "", "accuracy_percent": row.get("accuracy_percent", ""),
                "brier": row.get("brier", ""), "false_alarms": "", "missed_events": "",
                "false_alarm_percent": "", "missed_event_percent": "",
                "continuous_samples": _safe_int(row.get("continuous_samples"), 0), "mae_mmh": row.get("mae_mmh", ""),
                "rmse_mmh": row.get("rmse_mmh", ""), "bias_mmh": row.get("bias_mmh", ""),
            })

    diagnostic_events: list[dict[str, Any]] = []
    for source_key, source_label in (("radar_dpc", "Radar-DPC"), ("linda", "LINDA"), ("meteohub_icon", "MeteoHub ICON")):
        source = summary["status"].get(source_key, {})
        diagnostic_events.append({
            "time_utc": summary["status"].get("weather_lab", {}).get("updated_utc", ""),
            "source": source_label, "status": source.get("status", "available" if source.get("available") else "unknown"),
            "detail": _weather_lab_anonymize_text(source.get("status_label") or source.get("error") or "", aliases),
        })
    meteohub_status = status.get("meteohub", {}) if isinstance(status.get("meteohub"), dict) else {}
    artifacts = meteohub_status.get("artifacts", []) if isinstance(meteohub_status.get("artifacts"), list) else []
    for artifact in artifacts[-100:]:
        if not isinstance(artifact, dict):
            continue
        diagnostic_events.append({
            "time_utc": str(artifact.get("downloaded_utc") or "")[:80], "source": "MeteoHub ICON run",
            "status": str(artifact.get("status") or "unknown")[:40],
            "detail": _weather_lab_anonymize_text(
                f"run={str(artifact.get('run') or '')[:20]} forecasts={_safe_int(artifact.get('forecasts'), 0)} error={str(artifact.get('error') or '')[:160]}",
                aliases,
            ),
        })

    pending_rows: list[dict[str, Any]] = []
    pending = ledger.get("pending", []) if isinstance(ledger.get("pending"), list) else []
    for row in pending[-3000:]:
        if not isinstance(row, dict):
            continue
        pending_rows.append({
            "target": alias_for(row.get("target")), "model": str(row.get("model") or "unknown")[:80],
            "lead_minutes": _safe_int(row.get("lead_minutes"), 0),
            "probability_percent": _weather_lab_number(row.get("probability_percent")),
            "issued_at_ms": _safe_int(row.get("issued_at_ms"), 0), "valid_at_ms": _safe_int(row.get("valid_at_ms"), 0),
            "affects_alerts": bool(row.get("affects_alerts")),
        })

    safe_diagnostics = []
    for line in diagnostic_lines:
        sanitized = _weather_lab_anonymize_text(line, aliases)
        if sanitized:
            safe_diagnostics.append(sanitized)
        if len(safe_diagnostics) >= 500:
            break

    summary["analysis"] = {
        "metric_rows": len(metrics), "daily_metric_rows": len(daily_metrics),
        "recent_outcomes_included": len(recent), "pending_forecasts_included": len(pending_rows),
        "target_aliases_seen": len({row.get("target") for row in metrics if row.get("target") not in (None, "", "ALL_TARGETS")}),
    }
    table_rows = "".join(
        "<tr>" + "".join(f"<td>{escape(str(row.get(key, '')))}</td>" for key in ("target", "model", "lead_minutes", "samples", "accuracy_percent", "brier", "false_alarms", "missed_events", "mae_mmh", "bias_mmh")) + "</tr>"
        for row in metrics[:250]
    ) or "<tr><td colspan='10'>Dati verificati non ancora sufficienti.</td></tr>"
    report = f"""<!doctype html><html lang='it'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>LDZ Weather Lab · Analisi</title><style>body{{font-family:system-ui,sans-serif;margin:28px;background:#07111d;color:#eaf2ff}}h1,h2{{color:#fff}}.card{{background:#0d1d2e;border:1px solid #24415f;border-radius:14px;padding:18px;margin:14px 0}}table{{border-collapse:collapse;width:100%;font-size:13px}}th,td{{border-bottom:1px solid #29445e;padding:8px;text-align:left}}th{{color:#8dc8ff}}code{{color:#8dc8ff}}.ok{{color:#66e0a3}}</style></head><body><h1>LDZ Weather Lab · Pacchetto per analisi</h1><p>Generato {escape(summary['generated_utc'])} · modalità <b>{escape(selected_mode)}</b> · versione {escape(str(app_version))}</p><div class='card'><h2>Privacy</h2><p class='ok'>Nomi e coordinate dei target, password, token, configurazione Telegram, GRIB e immagini radar sono esclusi.</p><p>Gli identificatori <code>TARGET_…</code> restano stabili per questa installazione.</p></div><div class='card'><h2>Copertura</h2><p>{summary['coverage']['outcomes_scanned']} esiti verificati · {summary['coverage']['archive_files']} archivi · dal {escape(summary['coverage']['first_verified_utc'] or 'N/D')} al {escape(summary['coverage']['last_verified_utc'] or 'N/D')} · troncato: {str(summary['coverage']['truncated']).lower()}</p></div><div class='card'><h2>Stato motori</h2><p>Radar-DPC: {escape(str(summary['status']['radar_dpc']))}</p><p>LINDA: {escape(str(summary['status']['linda']))}</p><p>MeteoHub ICON: {escape(str(summary['status']['meteohub_icon']))}</p></div><div class='card'><h2>Metriche</h2><table><thead><tr><th>Target</th><th>Modello</th><th>Lead</th><th>Casi</th><th>Accuratezza %</th><th>Brier</th><th>Falsi allarmi</th><th>Mancati</th><th>MAE</th><th>Bias</th></tr></thead><tbody>{table_rows}</tbody></table></div><div class='card'><h2>Come usarlo</h2><p>Allega l'intero ZIP alla conversazione. <code>summary.json</code> contiene lo stato generale; i CSV permettono il confronto per motore, target anonimizzato e scadenza.</p></div></body></html>"""

    entries: dict[str, bytes] = {
        "README.txt": (
            "LDZ Weather Lab - pacchetto anonimizzato per analisi\n\n"
            "Allega l'intero ZIP alla conversazione. Nessuna credenziale, coordinata, immagine radar o GRIB e inclusa.\n"
            "report.html offre una lettura immediata; summary.json e i CSV contengono i dati tecnici.\n"
        ).encode("utf-8"),
        "report.html": report.encode("utf-8"),
        "summary.json": (json.dumps(summary, indent=2, ensure_ascii=False, sort_keys=True) + "\n").encode("utf-8"),
        "metrics.csv": _weather_lab_csv(metrics, metric_fields),
        "diagnostic_events.csv": _weather_lab_csv(diagnostic_events, ("time_utc", "source", "status", "detail")),
        "pending_forecasts.csv": _weather_lab_csv(pending_rows, ("target", "model", "lead_minutes", "probability_percent", "issued_at_ms", "valid_at_ms", "affects_alerts")),
        "diagnostic.log": ("\n".join(safe_diagnostics) + ("\n" if safe_diagnostics else "")).encode("utf-8"),
    }
    if selected_mode == "complete":
        entries["daily_metrics.csv"] = _weather_lab_csv(daily_metrics, ("day_utc",) + metric_fields)
        entries["recent_outcomes.csv"] = _weather_lab_csv(
            list(recent),
            ("verified_utc", "target", "model", "lead_minutes", "probability_percent", "event_observed", "rain_rate_mmh", "vmi_dbz", "predicted_precipitation_rate_mmh", "absolute_error_mmh", "bias_mmh"),
        )

    forbidden = (
        WEATHER_LAB_EXPORT_EMAIL_RE, WEATHER_LAB_EXPORT_JWT_RE, TELEGRAM_TOKEN_RE,
        re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/-]{12,}"),
        re.compile(r"(?i)\b(?:password|passwd|token|api[_-]?key|authorization)\b\s*[:=]\s*(?!\[REDACTED(?:_[A-Z]+)?\])[^\s,;\]}]{4,}"),
        re.compile(r"(?i)\b(?:lat|lon|latitude|longitude)\b\s*[:=]\s*-?\d"),
    )
    for name, data in entries.items():
        decoded = data.decode("utf-8", errors="replace")
        if any(pattern.search(decoded) for pattern in forbidden):
            raise ValueError(f"Export bloccato dal controllo privacy: {name}")

    manifest = {
        "schema_version": 1, "type": "ldz-weather-lab-analysis", "mode": selected_mode,
        "created_utc": generated.isoformat(), "files": {
            name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
            for name, data in sorted(entries.items())
        },
    }
    entries["manifest.json"] = (json.dumps(manifest, indent=2, ensure_ascii=False, sort_keys=True) + "\n").encode("utf-8")
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(entries.items()):
            archive.writestr(name, data)
    package = output.getvalue()
    if len(package) > WEATHER_LAB_EXPORT_MAX_ZIP_BYTES:
        raise ValueError("Export Weather Lab oltre il limite massimo di 64 MiB")
    return package, {
        "mode": selected_mode, "bytes": len(package), "sha256": hashlib.sha256(package).hexdigest(),
        "outcomes": summary["coverage"]["outcomes_scanned"], "truncated": summary["coverage"]["truncated"],
    }


def filter_paginate(
    rows: Iterable[dict[str, Any]], *, query: str = "", level: str = "", component: str = "",
    event_type: str = "", start_date: str = "", end_date: str = "",
    order: str = "desc", page: int = 1, per_page: int = 50,
) -> dict[str, Any]:
    q = str(query or "").casefold()[:200]
    wanted_level = str(level or "").casefold()[:20]
    wanted_component = str(component or "").casefold()[:80]
    wanted_event = str(event_type or "").casefold()[:80]
    start_epoch = _date_boundary(start_date, end=False)
    end_epoch = _date_boundary(end_date, end=True)
    selected = []
    for raw in rows:
        row = {str(k): v for k, v in raw.items()}
        haystack = " ".join(str(v) for v in row.values()).casefold()
        if q and q not in haystack:
            continue
        if wanted_level and str(row.get("level", row.get("risk", ""))).casefold() != wanted_level:
            continue
        if wanted_component and str(row.get("component", row.get("target", ""))).casefold() != wanted_component:
            continue
        if wanted_event and str(row.get("event_type", row.get("type", ""))).casefold() != wanted_event:
            continue
        row_epoch = _row_epoch(row)
        if start_epoch is not None and (row_epoch is None or row_epoch < start_epoch):
            continue
        if end_epoch is not None and (row_epoch is None or row_epoch > end_epoch):
            continue
        selected.append(row)
    selected.sort(
        key=lambda item: (_row_epoch(item) or 0, str(item.get("time", item.get("timestamp", "")))),
        reverse=(order != "asc"),
    )
    bounded_page = max(1, int(page or 1))
    bounded_size = max(10, min(100, int(per_page or 50)))
    start = (bounded_page - 1) * bounded_size
    return {
        "items": selected[start:start + bounded_size], "total": len(selected), "page": bounded_page,
        "per_page": bounded_size, "pages": max(1, (len(selected) + bounded_size - 1) // bounded_size),
    }


def _date_boundary(value: Any, *, end: bool) -> float | None:
    candidate = str(value or "")[:10]
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", candidate):
        return None
    try:
        parsed = datetime.strptime(candidate, "%Y-%m-%d").replace(tzinfo=safe_timezone(ROME_TZ))
    except ValueError:
        return None
    if end:
        parsed += timedelta(days=1, microseconds=-1)
    return parsed.timestamp()


def _row_epoch(row: dict[str, Any]) -> float | None:
    for key in ("timestamp_epoch", "time_epoch", "started_epoch"):
        try:
            value = float(row.get(key, 0) or 0)
        except (TypeError, ValueError):
            value = 0
        if value > 0:
            return value
    raw = str(row.get("time", row.get("timestamp", "")) or "").strip()
    if not raw:
        return None
    normalized = raw.replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError:
        for pattern in ("%d/%m/%Y %H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
            try:
                parsed = datetime.strptime(raw[:19], pattern)
                break
            except ValueError:
                parsed = None
        if parsed is None:
            return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=safe_timezone(ROME_TZ))
    return parsed.timestamp()


def system_metrics() -> dict[str, Any]:
    result: dict[str, Any] = {"cpu_percent": None, "memory_percent": None, "disk_percent": None, "uptime_seconds": None}
    try:
        result["uptime_seconds"] = int(float(Path("/proc/uptime").read_text().split()[0]))
        load1 = os.getloadavg()[0]
        result["cpu_percent"] = round(min(100.0, load1 / max(1, os.cpu_count() or 1) * 100.0), 1)
    except (OSError, ValueError):
        pass
    try:
        mem = {}
        for line in Path("/proc/meminfo").read_text().splitlines():
            key, value = line.split(":", 1)
            mem[key] = int(value.strip().split()[0])
        total, available = mem.get("MemTotal", 0), mem.get("MemAvailable", 0)
        if total:
            result["memory_percent"] = round((total - available) / total * 100.0, 1)
    except (OSError, ValueError):
        pass
    try:
        if hasattr(os, "statvfs"):
            disk = os.statvfs("/")
            total = disk.f_blocks * disk.f_frsize
            available = disk.f_bavail * disk.f_frsize
        else:
            import shutil
            disk = shutil.disk_usage(Path.cwd().anchor or Path.cwd())
            total, available = disk.total, disk.free
        if total:
            result["disk_percent"] = round((total - available) / total * 100.0, 1)
    except (OSError, AttributeError):
        pass
    return result


def unit_snapshot(name: str, runner: Callable[[list[str], int], tuple[int, str]]) -> dict[str, Any]:
    safe_name = str(name)
    if not re.fullmatch(r"[A-Za-z0-9@_.-]+\.(?:service|timer)", safe_name):
        return {"name": safe_name, "state": "error", "detail": "Nome unità non valido"}
    code, output = runner([
        "systemctl", "show", safe_name, "--no-pager",
        "--property=LoadState,ActiveState,SubState,UnitFileState,Result,ExecMainStatus,LastTriggerUSec,NextElapseUSecRealtime",
    ], 12)
    props: dict[str, str] = {}
    for line in output.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            props[key] = value
    active = props.get("ActiveState", "unknown")
    result = props.get("Result", "")
    if active == "failed" or result not in {"", "success"}:
        state = "error"
    elif active == "active" and safe_name.endswith(".timer") and not props.get("NextElapseUSecRealtime"):
        state = "delayed"
    elif active == "active":
        state = "operational"
    else:
        state = "disabled" if active in {"inactive", "unknown"} else "error"
    return {"name": safe_name, "state": state, "exit": code, "properties": props, "detail": output[-800:]}


def _safe_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default
