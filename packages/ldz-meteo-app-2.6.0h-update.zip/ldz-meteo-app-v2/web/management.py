"""Funzioni pure e bounded per la console di gestione LDZ Meteo.

Il modulo non esegue comandi privilegiati: prepara/valida dati usati dalla
WebGUI e dagli helper allowlisted. Questo mantiene testabili retention,
pianificazione, template, log e metriche senza allargare sudoers.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import string
import time
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Iterable
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


ROME_TZ = "Europe/Rome"
BACKUP_FREQUENCIES = {"daily", "weekly", "custom"}
RETENTION_MODES = {"count", "days"}
TEMPLATE_VARIABLES = {
    "target", "eta", "intensity", "intensity_title", "vmi", "poh", "vil",
    "etm", "speed", "hail", "action", "source", "probability", "event_type",
}
SAMPLE_TEMPLATE_DATA = {
    "target": "Pescasseroli", "eta": "25–35 minuti", "intensity": "Forte",
    "intensity_title": "Temporale in avvicinamento", "vmi": "56.4", "poh": "42%",
    "vil": "31", "etm": "11.8 km", "speed": "38 km/h", "hail": "Grandine possibile",
    "action": "Segui i prossimi aggiornamenti e ripara gli oggetti esposti.",
    "source": "Radar-DPC", "probability": "68%", "event_type": "Temporale forte",
}


def safe_timezone(name: Any) -> ZoneInfo:
    candidate = str(name or ROME_TZ)
    if candidate != ROME_TZ:
        candidate = ROME_TZ
    try:
        return ZoneInfo(candidate)
    except ZoneInfoNotFoundError:
        return ZoneInfo("UTC")


def normalize_backup_settings(value: dict[str, Any] | None) -> dict[str, Any]:
    raw = value if isinstance(value, dict) else {}
    frequency = str(raw.get("frequency", "daily"))
    retention_mode = str(raw.get("retention_mode", "count"))
    schedule_time = str(raw.get("schedule_time", "02:30"))
    start_date = str(raw.get("start_date", ""))
    if frequency not in BACKUP_FREQUENCIES:
        frequency = "daily"
    if retention_mode not in RETENTION_MODES:
        retention_mode = "count"
    if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", schedule_time):
        schedule_time = "02:30"
    if start_date and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", start_date):
        start_date = ""
    return {
        "enabled": bool(raw.get("enabled", False)),
        "frequency": frequency,
        "schedule_time": schedule_time,
        "weekday": max(0, min(6, _safe_int(raw.get("weekday"), 0))),
        "custom_days": max(1, min(365, _safe_int(raw.get("custom_days"), 2))),
        "start_date": start_date,
        "timezone": ROME_TZ,
        "include_secrets": bool(raw.get("include_secrets", False)),
        "retention_mode": retention_mode,
        "retention_count": max(1, min(500, _safe_int(raw.get("retention_count"), 20))),
        "retention_days": max(1, min(3650, _safe_int(raw.get("retention_days"), 30))),
        "max_space_mb": max(0, min(102400, _safe_int(raw.get("max_space_mb"), 0))),
        "last_changed_epoch": max(0, _safe_int(raw.get("last_changed_epoch"), 0)),
    }


def next_backup_epoch(settings: dict[str, Any], now_epoch: float | None = None) -> float | None:
    cfg = normalize_backup_settings(settings)
    if not cfg["enabled"]:
        return None
    tz = safe_timezone(cfg["timezone"])
    now = datetime.fromtimestamp(now_epoch if now_epoch is not None else time.time(), tz)
    hour, minute = (int(part) for part in cfg["schedule_time"].split(":", 1))
    candidate = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if cfg["frequency"] == "daily":
        if candidate <= now:
            candidate += timedelta(days=1)
    elif cfg["frequency"] == "weekly":
        candidate += timedelta(days=(cfg["weekday"] - now.weekday()) % 7)
        if candidate <= now:
            candidate += timedelta(days=7)
    else:
        start = now.date()
        if cfg["start_date"]:
            try:
                start = datetime.strptime(cfg["start_date"], "%Y-%m-%d").date()
            except ValueError:
                pass
        days = cfg["custom_days"]
        elapsed = max(0, (now.date() - start).days)
        offset = (-elapsed) % days
        candidate = datetime.combine(now.date() + timedelta(days=offset), datetime.min.time(), tzinfo=tz).replace(hour=hour, minute=minute)
        if candidate <= now:
            candidate += timedelta(days=days)
    return candidate.timestamp()


def backup_due(settings: dict[str, Any], state: dict[str, Any], now_epoch: float | None = None) -> bool:
    cfg = normalize_backup_settings(settings)
    if not cfg["enabled"]:
        return False
    now = float(now_epoch if now_epoch is not None else time.time())
    last = float(state.get("last_success_epoch", 0) or 0)
    # Calcola l'occorrenza precedente senza usare last_changed come falsa esecuzione.
    probe = next_backup_epoch(cfg, now - 370 * 86400)
    due = None
    while probe is not None and probe <= now:
        due = probe
        probe = next_backup_epoch(cfg, probe + 1)
    return due is not None and last < due


def retention_victims(paths: Iterable[Path], settings: dict[str, Any], now_epoch: float | None = None) -> list[Path]:
    cfg = normalize_backup_settings(settings)
    now = float(now_epoch if now_epoch is not None else time.time())
    items = sorted((p for p in paths if p.is_file() and not p.is_symlink()), key=lambda p: p.stat().st_mtime, reverse=True)
    victims: set[Path] = set()
    if cfg["retention_mode"] == "count":
        victims.update(items[cfg["retention_count"]:])
    else:
        cutoff = now - cfg["retention_days"] * 86400
        victims.update(p for p in items if p.stat().st_mtime < cutoff)
    max_bytes = cfg["max_space_mb"] * 1024 * 1024
    kept = [p for p in items if p not in victims]
    if max_bytes:
        total = sum(p.stat().st_size for p in kept)
        for path in reversed(kept):
            if total <= max_bytes:
                break
            victims.add(path)
            total -= path.stat().st_size
    return sorted(victims, key=lambda p: p.stat().st_mtime)


def inspect_backup(path: Path, verify_hashes: bool = True) -> dict[str, Any]:
    result = {"ok": False, "name": path.name, "error": "", "files": [], "manifest": {}, "sha256": ""}
    try:
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 16 * 1024 * 1024:
            raise ValueError("Archivio assente, simbolico o oltre il limite")
        result["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
            if "manifest.json" not in names:
                raise ValueError("Manifest backup mancante")
            manifest = json.loads(archive.read("manifest.json"))
            allowed = {"etc/meteo-alert/config.yml", "etc/meteo-alert/secrets.env"}
            files = manifest.get("files", {}) if isinstance(manifest, dict) else {}
            if manifest.get("type") != "configuration-backup" or not isinstance(files, dict):
                raise ValueError("Manifest backup non riconosciuto")
            if set(files) - allowed or set(names) - allowed - {"manifest.json"}:
                raise ValueError("Il backup contiene percorsi non autorizzati")
            if "etc/meteo-alert/config.yml" not in files:
                raise ValueError("config.yml mancante")
            if verify_hashes:
                for name, expected in files.items():
                    digest = hashlib.sha256(archive.read(name)).hexdigest()
                    if digest != str(expected).lower():
                        raise ValueError(f"Checksum non valido per {name}")
            result.update(ok=True, files=sorted(files), manifest=manifest)
    except (OSError, ValueError, KeyError, json.JSONDecodeError, zipfile.BadZipFile) as exc:
        result["error"] = str(exc)[:400]
    return result


def read_json_lines(path: Path, limit: int = 1000) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    try:
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 16 * 1024 * 1024:
            return rows
        with path.open(encoding="utf-8", errors="replace") as handle:
            for line in handle:
                try:
                    value = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(value, dict):
                    rows.append(value)
                    if len(rows) > limit:
                        rows.pop(0)
    except OSError:
        return []
    return rows


def template_variables(body: str) -> tuple[set[str], set[str]]:
    found: set[str] = set()
    invalid: set[str] = set()
    try:
        for _literal, field, _spec, _conversion in string.Formatter().parse(body):
            if field:
                (found if field in TEMPLATE_VARIABLES else invalid).add(field)
    except ValueError:
        invalid.add("sintassi")
    return found, invalid


def validate_template(body: str) -> tuple[bool, str]:
    value = str(body or "").strip()
    if not value:
        return False, "Il template non può essere vuoto"
    if len(value) > 8000:
        return False, "Il template supera 8.000 caratteri"
    _known, invalid = template_variables(value)
    if invalid:
        return False, "Variabili non riconosciute: " + ", ".join(sorted(invalid))
    try:
        value.format_map(SAMPLE_TEMPLATE_DATA)
    except (KeyError, ValueError) as exc:
        return False, f"Template non valido: {exc}"
    return True, "Template valido"


def render_template_sample(body: str) -> str:
    ok, message = validate_template(body)
    if not ok:
        raise ValueError(message)
    return body.format_map(SAMPLE_TEMPLATE_DATA)


SECRET_RE = re.compile(
    r"(?i)(authorization\s*[:=]\s*(?:bearer\s+)?|token\s*[:=]\s*|password\s*[:=]\s*|cookie\s*[:=]\s*|api[_-]?key\s*[:=]\s*)([^\s,;]+)"
)
TELEGRAM_TOKEN_RE = re.compile(r"\b\d{6,12}:[A-Za-z0-9_-]{20,}\b")


def redact_log_line(line: Any) -> str:
    value = str(line or "")[:4000]
    value = SECRET_RE.sub(lambda m: m.group(1) + "[REDACTED]", value)
    return TELEGRAM_TOKEN_RE.sub("[REDACTED_TELEGRAM_TOKEN]", value)


def filter_paginate(
    rows: Iterable[dict[str, Any]], *, query: str = "", level: str = "", component: str = "",
    event_type: str = "", start_date: str = "", end_date: str = "",
    order: str = "desc", page: int = 1, per_page: int = 50,
) -> dict[str, Any]:
    q = str(query or "").casefold()[:200]
    wanted_level = str(level or "").casefold()[:20]
    wanted_component = str(component or "").casefold()[:80]
    wanted_event = str(event_type or "").casefold()[:80]
    start_epoch = _date_boundary(start_date, end=False)
    end_epoch = _date_boundary(end_date, end=True)
    selected = []
    for raw in rows:
        row = {str(k): v for k, v in raw.items()}
        haystack = " ".join(str(v) for v in row.values()).casefold()
        if q and q not in haystack:
            continue
        if wanted_level and str(row.get("level", row.get("risk", ""))).casefold() != wanted_level:
            continue
        if wanted_component and str(row.get("component", row.get("target", ""))).casefold() != wanted_component:
            continue
        if wanted_event and str(row.get("event_type", row.get("type", ""))).casefold() != wanted_event:
            continue
        row_epoch = _row_epoch(row)
        if start_epoch is not None and (row_epoch is None or row_epoch < start_epoch):
            continue
        if end_epoch is not None and (row_epoch is None or row_epoch > end_epoch):
            continue
        selected.append(row)
    selected.sort(
        key=lambda item: (_row_epoch(item) or 0, str(item.get("time", item.get("timestamp", "")))),
        reverse=(order != "asc"),
    )
    bounded_page = max(1, int(page or 1))
    bounded_size = max(10, min(100, int(per_page or 50)))
    start = (bounded_page - 1) * bounded_size
    return {
        "items": selected[start:start + bounded_size], "total": len(selected), "page": bounded_page,
        "per_page": bounded_size, "pages": max(1, (len(selected) + bounded_size - 1) // bounded_size),
    }


def _date_boundary(value: Any, *, end: bool) -> float | None:
    candidate = str(value or "")[:10]
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", candidate):
        return None
    try:
        parsed = datetime.strptime(candidate, "%Y-%m-%d").replace(tzinfo=safe_timezone(ROME_TZ))
    except ValueError:
        return None
    if end:
        parsed += timedelta(days=1, microseconds=-1)
    return parsed.timestamp()


def _row_epoch(row: dict[str, Any]) -> float | None:
    for key in ("timestamp_epoch", "time_epoch", "started_epoch"):
        try:
            value = float(row.get(key, 0) or 0)
        except (TypeError, ValueError):
            value = 0
        if value > 0:
            return value
    raw = str(row.get("time", row.get("timestamp", "")) or "").strip()
    if not raw:
        return None
    normalized = raw.replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError:
        for pattern in ("%d/%m/%Y %H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
            try:
                parsed = datetime.strptime(raw[:19], pattern)
                break
            except ValueError:
                parsed = None
        if parsed is None:
            return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=safe_timezone(ROME_TZ))
    return parsed.timestamp()


def system_metrics() -> dict[str, Any]:
    result: dict[str, Any] = {"cpu_percent": None, "memory_percent": None, "disk_percent": None, "uptime_seconds": None}
    try:
        result["uptime_seconds"] = int(float(Path("/proc/uptime").read_text().split()[0]))
        load1 = os.getloadavg()[0]
        result["cpu_percent"] = round(min(100.0, load1 / max(1, os.cpu_count() or 1) * 100.0), 1)
    except (OSError, ValueError):
        pass
    try:
        mem = {}
        for line in Path("/proc/meminfo").read_text().splitlines():
            key, value = line.split(":", 1)
            mem[key] = int(value.strip().split()[0])
        total, available = mem.get("MemTotal", 0), mem.get("MemAvailable", 0)
        if total:
            result["memory_percent"] = round((total - available) / total * 100.0, 1)
    except (OSError, ValueError):
        pass
    try:
        if hasattr(os, "statvfs"):
            disk = os.statvfs("/")
            total = disk.f_blocks * disk.f_frsize
            available = disk.f_bavail * disk.f_frsize
        else:
            import shutil
            disk = shutil.disk_usage(Path.cwd().anchor or Path.cwd())
            total, available = disk.total, disk.free
        if total:
            result["disk_percent"] = round((total - available) / total * 100.0, 1)
    except (OSError, AttributeError):
        pass
    return result


def unit_snapshot(name: str, runner: Callable[[list[str], int], tuple[int, str]]) -> dict[str, Any]:
    safe_name = str(name)
    if not re.fullmatch(r"[A-Za-z0-9@_.-]+\.(?:service|timer)", safe_name):
        return {"name": safe_name, "state": "error", "detail": "Nome unità non valido"}
    code, output = runner([
        "systemctl", "show", safe_name, "--no-pager",
        "--property=LoadState,ActiveState,SubState,UnitFileState,Result,ExecMainStatus,LastTriggerUSec,NextElapseUSecRealtime",
    ], 12)
    props: dict[str, str] = {}
    for line in output.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            props[key] = value
    active = props.get("ActiveState", "unknown")
    result = props.get("Result", "")
    if active == "failed" or result not in {"", "success"}:
        state = "error"
    elif active == "active" and safe_name.endswith(".timer") and not props.get("NextElapseUSecRealtime"):
        state = "delayed"
    elif active == "active":
        state = "operational"
    else:
        state = "disabled" if active in {"inactive", "unknown"} else "error"
    return {"name": safe_name, "state": state, "exit": code, "properties": props, "detail": output[-800:]}


def _safe_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default
