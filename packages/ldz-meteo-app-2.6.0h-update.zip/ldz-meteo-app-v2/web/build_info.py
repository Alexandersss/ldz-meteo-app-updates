"""Immutable package identity loaded from the installed manifest."""
from __future__ import annotations

import json
import logging
import os
import re
import tempfile
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

BUILD_ID_RE = re.compile(r"^(?:[0-9]{8}\.[0-9]{6}|[0-9]{8}\.[0-9]{1,6}\+[0-9a-f]{7,12})$")


class JournalPriorityFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        priority = 3 if record.levelno >= logging.ERROR else 4 if record.levelno >= logging.WARNING else 6
        return f"<{priority}>" + super().format(record)


def configure_service_logging() -> None:
    """Compatibility for engine tests that import both build_info modules."""
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.handlers.clear()
    formatter = JournalPriorityFormatter("%(asctime)s %(levelname)s %(message)s")
    normal = logging.StreamHandler(sys.stdout)
    normal.addFilter(lambda record: record.levelno < logging.WARNING)
    normal.setFormatter(formatter)
    root.addHandler(normal)
    warning = logging.StreamHandler(sys.stderr)
    warning.setLevel(logging.WARNING)
    warning.setFormatter(formatter)
    root.addHandler(warning)


def load_build_info(manifest_path: str | Path | None = None) -> dict[str, Any]:
    path = Path(manifest_path or os.environ.get("LDZ_METEO_MANIFEST", Path(__file__).with_name("manifest.json")))
    value: dict[str, Any] = {}
    try:
        if path.is_file() and not path.is_symlink() and path.stat().st_size <= 1024 * 1024:
            candidate = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(candidate, dict):
                value = candidate
    except (OSError, ValueError, json.JSONDecodeError):
        value = {}
    build_id = str(os.environ.get("LDZ_BUILD_ID") or value.get("build_id") or "development")
    return {
        "version": str(value.get("version") or "2.6.0h")[:64],
        "build_id": build_id if BUILD_ID_RE.fullmatch(build_id) else "development",
        "commit": str(value.get("commit") or "unknown")[:64],
        "built_at": str(value.get("built_at") or "")[:40],
        "manifest_path": str(path),
    }


def write_web_marker(service: str = "web") -> dict[str, Any]:
    info = load_build_info()
    root = Path(os.environ.get("LDZ_METEO_WEB_MARKER_DIR", "/var/lib/ldz-meteo-web/runtime/services"))
    try:
        root.mkdir(parents=True, exist_ok=True)
        value = dict(info, service=service, pid=os.getpid(), started_at=datetime.now(timezone.utc).isoformat(timespec="seconds"))
        fd, temporary = tempfile.mkstemp(prefix=f".{service}.", dir=root)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, sort_keys=True)
            handle.write("\n"); handle.flush(); os.fsync(handle.fileno())
        os.chmod(temporary, 0o600)
        os.replace(temporary, root / f"{service}.json")
    except OSError:
        pass
    return info


def log_service_start(service: str) -> dict[str, Any]:
    """Compatibilita' per processi engine in test con entrambi i path attivi."""
    info = load_build_info()
    logging.info(
        "service_start service=%s version=%s build_id=%s commit=%s pid=%s",
        service, info["version"], info["build_id"], info["commit"], os.getpid(),
    )
    marker_root = Path(os.environ.get("LDZ_METEO_SERVICE_MARKER_DIR", "/var/lib/meteo-alert/runtime/services"))
    try:
        marker_root.mkdir(parents=True, exist_ok=True)
        value = dict(info, service=service, pid=os.getpid(), started_at=datetime.now(timezone.utc).isoformat(timespec="seconds"))
        fd, temporary = tempfile.mkstemp(prefix=f".{service}.", dir=marker_root)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, sort_keys=True)
            handle.write("\n"); handle.flush(); os.fsync(handle.fileno())
        os.chmod(temporary, 0o600)
        os.replace(temporary, marker_root / f"{service}.json")
    except OSError as exc:
        logging.warning("service_marker_failed service=%s error=%s", service, type(exc).__name__)
    return info
