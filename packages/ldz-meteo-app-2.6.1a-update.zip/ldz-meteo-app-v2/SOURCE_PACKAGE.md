# LDZ Meteo App 2.6.1a - Source Package

Sorgente full-stack installabile della revisione stabile 2.6.1a, aggiornabile dalla 2.6.0h tramite LDZ Update Network v2. La release applica una pulizia conservativa e mantiene i canali Stabile/Beta separati, l'updater asincrono e i controlli scientifici shadow-first.

Contiene engine Python, Precision Engine separato, WebGUI Flask/Waitress, template e asset, Leaflet 1.9.4 locale, installer AlmaLinux/RHEL, helper privilegiati, policy archivi condivisa, test meteo/sicurezza e documentazione.

File principali:

- `install.sh`: installazione completa con Python 3.12 e systemd hardening.
- `engine/meteo_alert.py`: acquisizione Radar-DPC, render, notifiche e orchestrazione.
- `engine/precision_engine.py`: track multi-frame, Kalman, optical flow, ensemble nucleo/alone, verifica e calibrazione.
- `engine/verification_engine.py`: ledger nazionale a slot/eventi e metriche complete incluse le mancate previsioni.
- `engine/terrain_lifecycle.py`: terreno, ciclo vitale, Lightning Jump e watch di innesco.
- `engine/adaptive_ai.py`: apprendimento online shadow-first con attivazione protetta.
- `engine/adaptive_ai_trainer.py`: trainer batch separato con split cronologico e output JSON numerico.
- `engine/event_feedback.py`: incidenti, replay compatti, pulsanti Telegram firmati e dataset di verità a terra.
- `engine/telegram_feedback_listener.py`: long polling dedicato, coda atomica, conferma persistente e rimozione dei pulsanti.
- `engine/hail_feedback.py`: calibrazione grandine cronologica shadow-first con attivazione limitata.
- `engine/radar_wss_listener.py`: trigger STOMP sul WebSocket ufficiale Radar-DPC con timer fallback.
- `engine/weather_lab.py`: archivio e verifica shadow, pySTEPS/LINDA e client MeteoHub fixed-origin con limiti di risorse.
- `apply_hotfix.sh`: wrapper per applicazione manuale.
- `scripts/ldz-meteo-apply-hotfix`: updater root con firma e rollback.
- `scripts/ldz-meteo-sign-update`: approvazione locale di un pacchetto.
- `scripts/ldz-meteo-update-check`: controllo tokenless dei feed stable/beta e download vincolato a LDZ Update Network.
- `scripts/build-update-feed`: generazione degli indici pubblici con versione, dimensione e SHA-256 del pacchetto.
- `scripts/ldz-meteo-restore-backup`: restore data-only.
- `scripts/ldz-meteo-backup-manager`: backup atomici, pianificazione e retention verificata.
- `scripts/ldz-meteo-backup-now` / `ldz-meteo-backup-sync`: confine privilegiato esatto per WebGUI e timer.
- `scripts/ldz-meteo-repair-feedback` / `ldz-meteo-repair-update-scheduler`: repair allowlisted e verificabili.
- `scripts/ldz-meteo-watchdog`: controllo esterno dell'heartbeat e avvisi Telegram indipendenti dal motore.
- `web/management.py`: funzioni pure e bounded per backup, template, log, paginazione, metriche e unità systemd.
- `web/security_utils.py`: policy ZIP, hash, firma ed estrazione sicura.
- `tests/test_security.py`: regressioni archive/XSS/auth/CSP/sudoers.
- `tests/test_login_hud.py`: regressioni Master Design, radar scenografico isolato, autofill, responsive e reduced-motion.
- `tests/test_precision.py`: regressioni di tracking, optical flow, traiettorie, prior ICON-2I e Brier Score.
- `tests/test_stable_hail.py`: regressioni Hail Fusion, conferme urgenti e isteresi del rientro.
- `tests/test_scientific_quality.py`: qualità temporale/zona, split/merge, svolte, celle stazionarie, Lightning Jump e semantica grandine.
- `tests/test_lightning_alerts.py`: alert LGT autonomi, ETA live, testo Telegram e classificazione degli esiti.
- `tests/test_adaptive_ai.py`: trainer, dataset limitato e pubblicazione atomica del candidato.
- `tests/test_weather_lab.py`: credenziali dedicate, download MeteoHub filtrati, archivio shadow, metriche e requisiti di leggibilità responsive.
- `tests/test_release_240.py`: callback, ground truth, calibrazione e protocollo WebSocket 2.4.0.
- `tests/test_release_241.py`: selezione release, redirect sicuri, popup/updater, confine privilegiato e regressione `WARNING HTTPError`.
- `tests/test_release_243.py`: coda feedback, immutabilità della prima scelta, conferma persistente e wiring systemd.
- `tests/test_release_250.py`: backup/retention, manutenzione 503, SSRF, updater/snooze/unità univoche, login e wiring installer.
- `tests/test_release_251.py`: filtri, scheduler CET/CEST, restore/rollback, pagine live, canali e Kiosk della 2.5.1.
- `scripts/build-release-package`: rigenera manifest SHA-256 e ZIP preservando i permessi Unix; con `LDZ_PACKAGE_VARIANT=update` produce un payload operativo senza suite `tests/` e senza modificare il manifest del sorgente completo. Workflow, upload locali e vecchi archivi `dist/` restano sempre esclusi.

`manifest.json` usa `schema_version: 2`; `files` contiene lo SHA-256 di ogni payload, escluso il manifest stesso.
