"""Read the engine state without mutating its split SQLite store."""
from __future__ import annotations

import json
import sqlite3
import urllib.parse
from pathlib import Path
from typing import Any


def _read_json(path: Path, maximum: int) -> dict[str, Any]:
    if not path.is_file() or path.is_symlink() or path.stat().st_size > maximum:
        return {}
    value = json.loads(path.read_text(encoding="utf-8"))
    return value if isinstance(value, dict) else {}


def load_engine_state(
    legacy_path: str | Path,
    *,
    include_incidents: bool = False,
    maximum_database_bytes: int = 128 * 1024 * 1024,
) -> dict[str, Any]:
    """Hydrate runtime state with historical namespaces from the v2 store.

    Old installations are read directly from ``state.json``.  Split-state
    installations use ``runtime.json`` plus a strictly read-only SQLite
    connection, so the WebGUI can never alter engine persistence.
    """
    legacy = Path(legacy_path)
    try:
        if legacy.is_file():
            return _read_json(legacy, 64 * 1024 * 1024)
        runtime = _read_json(legacy.parent / "runtime.json", 32 * 1024 * 1024)
    except (OSError, ValueError, TypeError):
        runtime = {}

    database = legacy.parent / "events.sqlite3"
    try:
        if not database.is_file() or database.is_symlink() or database.stat().st_size > maximum_database_bytes:
            return runtime
        uri = "file:" + urllib.parse.quote(str(database), safe="/:\\") + "?mode=ro"
        connection = sqlite3.connect(uri, uri=True, timeout=3.0)
        try:
            connection.execute("PRAGMA query_only=ON")
            for namespace, payload in connection.execute(
                "SELECT namespace, payload_json FROM state_records ORDER BY namespace"
            ):
                if len(payload) > 16 * 1024 * 1024:
                    continue
                value = json.loads(payload)
                if isinstance(value, (dict, list)):
                    runtime[str(namespace)] = value
            if include_incidents:
                feedback = dict(runtime.get("event_feedback") or {})
                incidents: dict[str, Any] = {}
                for event_id, payload in connection.execute(
                    "SELECT event_id, payload_json FROM incidents ORDER BY event_id"
                ):
                    if len(payload) > 1024 * 1024:
                        continue
                    value = json.loads(payload)
                    if isinstance(value, dict):
                        incidents[str(event_id)] = value
                feedback["incidents"] = incidents
                runtime["event_feedback"] = feedback
        finally:
            connection.close()
    except (OSError, ValueError, TypeError, sqlite3.Error):
        # The radar engine must remain independent: a busy/corrupt historical
        # store degrades only the WebGUI snapshot instead of breaking pages.
        return runtime
    return runtime
