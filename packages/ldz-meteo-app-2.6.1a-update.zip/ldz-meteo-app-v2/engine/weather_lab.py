#!/usr/bin/env python3
"""Weather Lab shadow collectors for LDZ Meteo.

This module is deliberately isolated from the operational alert path.  Every
result it produces is labelled ``affects_alerts=False`` and failures are
reported in its own status file without stopping the radar cycle.
"""
from __future__ import annotations

import base64
import fcntl
import hashlib
import importlib.metadata
import json
import math
import os
import re
import signal
import shutil
import stat
import sys
import tempfile
import threading
import time
import zipfile
from datetime import datetime, timedelta, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import requests


METEOHUB_ROOT = "https://meteohub.agenziaitaliameteo.it"
METEOHUB_OPEN_ICON_RUC = f"{METEOHUB_ROOT}/nwp/ICON_2I_RUC/"
SUPPORTED_MODELS = ("WRF_DA_ITA", "ICON-2I-RUC")
PRECIPITATION_SHORT_NAMES = {
    "tp", "tot_prec", "total_precipitation", "prate", "tprate", "rain", "rain_gsp", "rain_con",
}
GRIB_SUFFIXES = {".grib", ".grib1", ".grib2", ".grb", ".grb1", ".grb2"}
MAX_ARCHIVE_MEMBERS = 64
MAX_GRIB_MESSAGES = 12000


class WeatherLabError(RuntimeError):
    pass


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", delete=False, dir=path.parent, encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")
        temporary = Path(handle.name)
    temporary.chmod(0o600)
    temporary.replace(path)


def _read_json(path: Path, default: dict[str, Any] | None = None) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else (default or {})
    except Exception:
        return default or {}


def _append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_APPEND | os.O_CREAT
    if hasattr(os, "O_CLOEXEC"):
        flags |= os.O_CLOEXEC
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    fd = os.open(path, flags, 0o600)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise WeatherLabError("archivio Weather Lab non regolare")
        fcntl.flock(fd, fcntl.LOCK_EX)
        data = (json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)


def _decode_secret(value: str) -> str:
    if not value:
        return ""
    try:
        return base64.b64decode(value.encode("ascii"), validate=True).decode("utf-8")
    except Exception:
        return ""


def load_meteohub_credentials(path: Path) -> tuple[str, str]:
    if not path.is_file() or path.is_symlink():
        return "", ""
    values: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if "=" not in raw or raw.lstrip().startswith("#"):
            continue
        key, value = raw.split("=", 1)
        values[key.strip()] = value.strip()
    return _decode_secret(values.get("METEOHUB_USERNAME_B64", "")), _decode_secret(values.get("METEOHUB_PASSWORD_B64", ""))


class _OpenDataLinkParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.hrefs: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() != "a":
            return
        for key, value in attrs:
            if key.lower() == "href" and isinstance(value, str):
                self.hrefs.append(value)


class MeteoHubOpenDataClient:
    """Fixed-origin downloader for ICON-2I-RUC single-variable open data."""

    def __init__(self, *, timeout: int = 25) -> None:
        self.timeout = max(5, min(60, int(timeout)))
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "LDZMeteoApp/2.6.1a WeatherLab",
            "Accept": "text/html,application/octet-stream",
        })

    @staticmethod
    def _allowed_url(url: str) -> bool:
        return bool(re.fullmatch(
            r"https://meteohub\.agenziaitaliameteo\.it/nwp/ICON_2I_RUC/"
            r"(?:20\d{8}/(?:TOT_PREC/(?:ICON_2I_RUC_20\d{8}_surface-0\.grib)?)?)?",
            url,
        ))

    def _index(self, url: str, label: str) -> list[str]:
        if not self._allowed_url(url) or not url.endswith("/"):
            raise WeatherLabError("Indice open data MeteoHub non consentito")
        response = self.session.get(url, timeout=self.timeout, allow_redirects=False)
        if 300 <= response.status_code < 400:
            raise WeatherLabError(f"{label}: reindirizzamento non consentito")
        response.raise_for_status()
        if len(response.content) > 2 * 1024 * 1024:
            raise WeatherLabError(f"{label}: risposta troppo grande")
        parser = _OpenDataLinkParser()
        parser.feed(response.content.decode("utf-8", errors="replace"))
        return parser.hrefs

    def latest_icon_precipitation(self) -> dict[str, str]:
        runs = sorted(
            href[:-1] for href in self._index(METEOHUB_OPEN_ICON_RUC, "Indice ICON-2I-RUC")
            if re.fullmatch(r"20\d{8}/", href)
        )
        if not runs:
            raise WeatherLabError("MeteoHub non espone run ICON-2I-RUC open data")
        run = runs[-1]
        try:
            run_time = datetime.strptime(run, "%Y%m%d%H").replace(tzinfo=timezone.utc)
        except ValueError as exc:
            raise WeatherLabError("Run ICON-2I-RUC open data non valido") from exc
        now = _utc_now()
        if run_time > now + timedelta(hours=6) or run_time < now - timedelta(days=8):
            raise WeatherLabError("Run ICON-2I-RUC open data fuori dall'intervallo atteso")
        variable_url = f"{METEOHUB_OPEN_ICON_RUC}{run}/TOT_PREC/"
        expected = f"ICON_2I_RUC_{run}_surface-0.grib"
        if expected not in self._index(variable_url, "Indice TOT_PREC ICON-2I-RUC"):
            raise WeatherLabError("GRIB TOT_PREC non disponibile per l'ultimo run ICON-2I-RUC")
        return {
            "run": run,
            "run_utc": run_time.isoformat(),
            "filename": expected,
            "url": variable_url + expected,
        }

    def download(self, url: str, destination: Path, maximum_bytes: int) -> int:
        if not self._allowed_url(url) or not url.endswith(".grib"):
            raise WeatherLabError("URL GRIB open data MeteoHub non consentito")
        response = self.session.get(
            url,
            timeout=max(60, self.timeout),
            allow_redirects=False,
            stream=True,
        )
        if 300 <= response.status_code < 400:
            raise WeatherLabError("Reindirizzamento download open data non consentito")
        response.raise_for_status()
        declared = int(response.headers.get("Content-Length") or 0)
        if declared > maximum_bytes:
            raise WeatherLabError("GRIB open data oltre il limite LDZ configurato")
        destination.parent.mkdir(parents=True, exist_ok=True)
        total = 0
        with tempfile.NamedTemporaryFile("wb", delete=False, dir=destination.parent) as handle:
            temporary = Path(handle.name)
            try:
                for chunk in response.iter_content(1024 * 1024):
                    if not chunk:
                        continue
                    total += len(chunk)
                    if total > maximum_bytes:
                        raise WeatherLabError("Download open data interrotto: limite LDZ superato")
                    handle.write(chunk)
            except Exception:
                handle.close()
                temporary.unlink(missing_ok=True)
                raise
        with temporary.open("rb") as downloaded:
            signature = downloaded.read(4)
        if total < 16 or signature != b"GRIB":
            temporary.unlink(missing_ok=True)
            raise WeatherLabError("Il download TOT_PREC non contiene un GRIB valido")
        temporary.chmod(0o600)
        temporary.replace(destination)
        return total


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _stage_grib_files(package: Path, staging: Path, maximum_bytes: int) -> list[Path]:
    """Return validated GRIB inputs without trusting archive paths or extensions."""
    with package.open("rb") as handle:
        header = handle.read(4)
    if header == b"GRIB":
        if package.stat().st_size > maximum_bytes:
            raise WeatherLabError("GRIB MeteoHub oltre il limite configurato")
        return [package]
    if header[:2] != b"PK":
        raise WeatherLabError("Pacchetto MeteoHub non è ZIP o GRIB")
    staging.mkdir(parents=True, exist_ok=True)
    files: list[Path] = []
    total = 0
    with zipfile.ZipFile(package) as archive:
        members = archive.infolist()
        if len(members) > MAX_ARCHIVE_MEMBERS:
            raise WeatherLabError("Archivio MeteoHub con troppi elementi")
        for index, member in enumerate(members):
            if member.is_dir():
                continue
            raw_name = member.filename.replace("\\", "/")
            parts = Path(raw_name).parts
            mode = (member.external_attr >> 16) & 0o170000
            if (
                not raw_name or "\x00" in raw_name or raw_name.startswith("/")
                or any(part in ("", ".", "..") for part in parts)
                or mode not in (0, stat.S_IFREG)
                or member.flag_bits & 0x1
            ):
                raise WeatherLabError("Elemento ZIP MeteoHub non sicuro")
            total += int(member.file_size)
            if total > maximum_bytes:
                raise WeatherLabError("Archivio MeteoHub espanso oltre il limite configurato")
            if member.compress_size and member.file_size > max(16 * 1024 * 1024, member.compress_size * 100):
                raise WeatherLabError("Archivio MeteoHub con rapporto di compressione anomalo")
            if Path(raw_name).suffix.lower() not in GRIB_SUFFIXES:
                continue
            destination = staging / f"{index:03d}-{Path(raw_name).name}"
            copied = 0
            with archive.open(member) as source, destination.open("xb") as target:
                while True:
                    chunk = source.read(1024 * 1024)
                    if not chunk:
                        break
                    copied += len(chunk)
                    if copied > member.file_size or copied > maximum_bytes:
                        raise WeatherLabError("Elemento GRIB oltre il limite dichiarato")
                    target.write(chunk)
            destination.chmod(0o600)
            with destination.open("rb") as extracted:
                signature = extracted.read(4)
            if signature != b"GRIB":
                destination.unlink(missing_ok=True)
                continue
            files.append(destination)
    if not files:
        raise WeatherLabError("Il pacchetto MeteoHub non contiene GRIB riconoscibili")
    return files


def _codes_get(eccodes: Any, gid: Any, key: str, default: Any = None) -> Any:
    try:
        return eccodes.codes_get(gid, key)
    except Exception:
        return default


def _grib_utc(date_value: Any, time_value: Any) -> datetime | None:
    try:
        date_text = f"{int(date_value):08d}"
        time_text = f"{int(time_value):04d}"
        return datetime.strptime(date_text + time_text, "%Y%m%d%H%M").replace(tzinfo=timezone.utc)
    except (TypeError, ValueError, OverflowError):
        return None


def _step_multiplier_minutes(unit: Any) -> float:
    text = str(unit).strip().lower()
    if text in {"s", "sec", "second", "seconds"}:
        return 1.0 / 60.0
    if text in {"m", "min", "minute", "minutes"}:
        return 1.0
    if text in {"h", "hr", "hour", "hours"}:
        return 60.0
    if text in {"d", "day", "days"}:
        return 1440.0
    try:
        code = int(unit)
    except (TypeError, ValueError):
        code = 1
    return {0: 1.0, 1: 60.0, 2: 1440.0, 10: 180.0, 11: 360.0, 12: 720.0, 13: 1.0 / 60.0}.get(code, 60.0)


def _step_value_minutes(value: Any, unit: Any) -> float:
    if isinstance(value, bool):
        raise ValueError("step GRIB booleano")
    if isinstance(value, (int, float)):
        number = float(value)
        multiplier = _step_multiplier_minutes(unit)
    elif isinstance(value, str):
        match = re.fullmatch(r"\s*(\d+(?:\.\d+)?)\s*([smhdSMHD]?)\s*", value)
        if not match:
            raise ValueError("step GRIB non riconosciuto")
        number = float(match.group(1))
        multiplier = _step_multiplier_minutes(match.group(2) or unit)
    else:
        raise ValueError("step GRIB non numerico")
    result = number * multiplier
    if not math.isfinite(result) or result < 0 or result > 14 * 24 * 60:
        raise ValueError("step GRIB fuori intervallo")
    return result


def _target_coordinates(target: Any) -> tuple[str, float, float]:
    if isinstance(target, dict):
        name, lat, lon = target.get("name"), target.get("lat"), target.get("lon")
    else:
        name, lat, lon = getattr(target, "name", ""), getattr(target, "lat", None), getattr(target, "lon", None)
    return str(name), float(lat), float(lon)


def _haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = math.radians(lat2 - lat1), math.radians(lon2 - lon1)
    value = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * 6371.0088 * math.asin(min(1.0, math.sqrt(value)))


def _precipitation_value(value: float, units: str, short_name: str) -> tuple[str, float] | None:
    normalized = re.sub(r"[\s_*]+", "", units.lower()).replace("**", "").replace("^", "")
    if not math.isfinite(value) or value < -0.01:
        return None
    value = max(0.0, value)
    if normalized in {"m", "metre", "meter"}:
        return "amount_mm", value * 1000.0
    if normalized in {"mm", "kgm-2", "kg/m2", "kgm−2"}:
        return "amount_mm", value
    if normalized in {"kgm-2s-1", "kg/m2/s", "mms-1", "mm/s"}:
        return "rate_mmh", value * 3600.0
    if normalized in {"mmh-1", "mm/h", "mmhr-1"}:
        return "rate_mmh", value
    if short_name in {"prate", "tprate"} and not units:
        return "rate_mmh", value * 3600.0
    return None


def _parse_grib_file(path: Path, targets: Iterable[Any], model: str, maximum_gridpoint_km: float) -> tuple[list[dict[str, Any]], dict[str, int]]:
    try:
        import eccodes
    except Exception as exc:
        raise WeatherLabError("Decoder GRIB ecCodes non disponibile") from exc
    rows: list[dict[str, Any]] = []
    stats = {"messages": 0, "precipitation_messages": 0, "unsupported_units": 0, "outside_targets": 0}
    with path.open("rb") as handle:
        while True:
            gid = eccodes.codes_grib_new_from_file(handle)
            if gid is None:
                break
            stats["messages"] += 1
            if stats["messages"] > MAX_GRIB_MESSAGES:
                eccodes.codes_release(gid)
                raise WeatherLabError("GRIB MeteoHub con troppi messaggi")
            try:
                short_name = str(_codes_get(eccodes, gid, "shortName", "")).strip().lower()
                if short_name not in PRECIPITATION_SHORT_NAMES:
                    continue
                stats["precipitation_messages"] += 1
                edition = int(_codes_get(eccodes, gid, "edition", 0) or 0)
                if edition not in (1, 2):
                    continue
                run = _grib_utc(_codes_get(eccodes, gid, "dataDate"), _codes_get(eccodes, gid, "dataTime"))
                valid = _grib_utc(_codes_get(eccodes, gid, "validityDate"), _codes_get(eccodes, gid, "validityTime"))
                step_units = _codes_get(eccodes, gid, "stepUnits", 1)
                try:
                    start_step = _step_value_minutes(_codes_get(eccodes, gid, "startStep", 0) or 0, step_units)
                    end_step = _step_value_minutes(
                        _codes_get(eccodes, gid, "endStep", _codes_get(eccodes, gid, "forecastTime", 0)) or 0,
                        step_units,
                    )
                except ValueError:
                    continue
                if run is None and valid is not None:
                    run = valid - timedelta(minutes=end_step)
                if run is not None and end_step > 0 and (valid is None or valid <= run):
                    valid = run + timedelta(minutes=end_step)
                if run is None or valid is None or end_step < start_step:
                    continue
                units = str(_codes_get(eccodes, gid, "units", "")).strip()
                step_type = str(_codes_get(eccodes, gid, "stepType", "")).strip().lower()
                for target in targets:
                    name, lat, lon = _target_coordinates(target)
                    nearest = eccodes.codes_grib_find_nearest(gid, lat, lon)[0]
                    point_lat = float(nearest.lat)
                    point_lon = float(nearest.lon)
                    distance = _haversine_km(lat, lon, point_lat, point_lon)
                    if distance > maximum_gridpoint_km:
                        stats["outside_targets"] += 1
                        continue
                    converted = _precipitation_value(float(nearest.value), units, short_name)
                    if converted is None:
                        stats["unsupported_units"] += 1
                        continue
                    quantity, converted_value = converted
                    rows.append({
                        "model": model, "target": name, "short_name": short_name,
                        "run_utc": run.isoformat(), "valid_utc": valid.isoformat(),
                        "run_ms": int(run.timestamp() * 1000), "valid_at_ms": int(valid.timestamp() * 1000),
                        "lead_minutes": int(round((valid - run).total_seconds() / 60.0)),
                        "start_step_minutes": start_step, "end_step_minutes": end_step,
                        "step_type": step_type, "source_units": units, "quantity": quantity,
                        "source_value": converted_value, "grid_lat": round(point_lat, 6),
                        "grid_lon": round(point_lon, 6), "grid_distance_km": round(distance, 3),
                    })
            finally:
                eccodes.codes_release(gid)
    return rows, stats


def _finalize_precipitation_rows(raw_rows: list[dict[str, Any]], event_threshold: float, maximum_lead_minutes: int) -> list[dict[str, Any]]:
    groups: dict[tuple[str, str, str, str], list[dict[str, Any]]] = {}
    for row in raw_rows:
        key = (str(row["model"]), str(row["run_utc"]), str(row["target"]), str(row["short_name"]))
        groups.setdefault(key, []).append(row)
    candidates: list[dict[str, Any]] = []
    for group in groups.values():
        previous: dict[str, Any] | None = None
        for row in sorted(group, key=lambda item: (float(item["end_step_minutes"]), int(item["valid_at_ms"]))):
            lead = int(row["lead_minutes"])
            if lead <= 0 or lead > maximum_lead_minutes:
                previous = row
                continue
            if row["quantity"] == "rate_mmh":
                rate = float(row["source_value"])
                amount = None
                interval = None
            else:
                amount = float(row["source_value"])
                interval = float(row["end_step_minutes"]) - float(row["start_step_minutes"])
                if (
                    previous is not None and float(row["start_step_minutes"]) == 0
                    and float(previous["start_step_minutes"]) == 0
                    and float(previous["end_step_minutes"]) < float(row["end_step_minutes"])
                    and float(previous["source_value"]) <= amount + 0.01
                ):
                    amount -= float(previous["source_value"])
                    interval = float(row["end_step_minutes"]) - float(previous["end_step_minutes"])
                rate = amount / (interval / 60.0) if interval and interval > 0 else 0.0
            previous = row
            if not math.isfinite(rate) or rate < 0 or rate > 500:
                continue
            model_key = "meteohub_icon2i_ruc" if row["model"] == "ICON-2I-RUC" else "meteohub_wrf_da_ita"
            forecast_id = f"{row['run_ms']}:{model_key}:{row['target']}:{row['valid_at_ms']}"
            candidates.append({
                "kind": "forecast", "forecast_id": forecast_id, "model": model_key,
                "model_name": row["model"], "target": row["target"],
                "issued_at_ms": row["run_ms"], "valid_at_ms": row["valid_at_ms"],
                "lead_minutes": lead, "precipitation_rate_mmh": round(rate, 3),
                "precipitation_mm": round(amount, 3) if amount is not None else None,
                "probability_percent": 100.0 if rate >= event_threshold else 0.0,
                "grid_distance_km": row["grid_distance_km"], "grid_lat": row["grid_lat"],
                "grid_lon": row["grid_lon"], "source_variable": row["short_name"],
                "source_units": row["source_units"], "affects_alerts": False,
            })
    priority = {"tp": 0, "tot_prec": 1, "total_precipitation": 1, "prate": 2, "tprate": 2}
    selected: dict[tuple[str, str, int], dict[str, Any]] = {}
    for row in candidates:
        key = (str(row["model"]), str(row["target"]), int(row["valid_at_ms"]))
        current = selected.get(key)
        if current is None or priority.get(str(row["source_variable"]), 9) < priority.get(str(current["source_variable"]), 9):
            selected[key] = row
    return sorted(selected.values(), key=lambda item: (int(item["valid_at_ms"]), str(item["target"]), str(item["model"])))


def _merge_meteohub_forecasts(root: Path, new_rows: list[dict[str, Any]], now_ms: int, retention_hours: int = 48) -> list[dict[str, Any]]:
    path = root / "meteohub" / "forecasts.json"
    stored = _read_json(path, {"rows": []})
    rows = [item for item in stored.get("rows", []) if isinstance(item, dict)]
    merged = {str(item.get("forecast_id")): item for item in rows if item.get("forecast_id")}
    for row in new_rows:
        merged[str(row["forecast_id"])] = row
    cutoff = now_ms - max(12, min(168, retention_hours)) * 3600 * 1000
    kept = [item for item in merged.values() if int(item.get("valid_at_ms", 0) or 0) >= cutoff]
    kept = sorted(kept, key=lambda item: int(item.get("valid_at_ms", 0) or 0))[-5000:]
    _atomic_json(path, {"schema": 1, "rows": kept, "updated_utc": _utc_now().isoformat()})
    return kept


def _process_meteohub_package(package: Path, root: Path, targets: Iterable[Any], model: str, cfg: dict[str, Any], maximum_bytes: int) -> dict[str, Any]:
    if model not in SUPPORTED_MODELS:
        raise WeatherLabError("Modello MeteoHub non supportato")
    maximum_gridpoint_km = max(2.0, min(50.0, float(cfg.get("maximum_gridpoint_km", 15.0) or 15.0)))
    maximum_lead = max(60, min(1440, int(cfg.get("maximum_lead_hours", 3) or 3) * 60))
    threshold = max(0.1, min(20.0, float(cfg.get("event_rain_rate_mmh", 2.0) or 2.0)))
    raw_rows: list[dict[str, Any]] = []
    totals = {"messages": 0, "precipitation_messages": 0, "unsupported_units": 0, "outside_targets": 0}
    with tempfile.TemporaryDirectory(prefix="ldz-meteohub-grib-", dir=str(package.parent)) as temp:
        files = _stage_grib_files(package, Path(temp), maximum_bytes)
        for path in files:
            rows, stats = _parse_grib_file(path, targets, model, maximum_gridpoint_km)
            raw_rows.extend(rows)
            for key in totals:
                totals[key] += int(stats.get(key, 0))
    forecasts = _finalize_precipitation_rows(raw_rows, threshold, maximum_lead)
    if totals["precipitation_messages"] <= 0:
        raise WeatherLabError("GRIB senza precipitazione totale o intensità riconosciuta")
    if not forecasts:
        raise WeatherLabError("GRIB valido ma senza previsioni utilizzabili sui target LDZ")
    return {"forecasts": forecasts, "stats": totals, "sha256": _sha256(package)}


def sync_meteohub(cfg: dict[str, Any], root: Path, previous: dict[str, Any], targets: Iterable[Any] = ()) -> dict[str, Any]:
    source = cfg.get("meteohub", {}) if isinstance(cfg.get("meteohub"), dict) else {}
    result = dict(previous) if isinstance(previous, dict) else {}
    historical_files = [
        path for path in (root / "meteohub" / "inbox").glob("*")
        if path.is_file() and not path.is_symlink()
    ] if (root / "meteohub" / "inbox").is_dir() else []
    previous_artifacts = [item for item in result.get("artifacts", []) if isinstance(item, dict)]
    historical_count = max(
        len(historical_files),
        int(result.get("historical_download_count", 0) or 0),
        sum(1 for item in previous_artifacts if item.get("status") in ("processed", "duplicate", "failed")),
    )
    result.update({
        "enabled": bool(source.get("enabled", False)), "affects_alerts": False,
        "configured": False, "authenticated_now": False, "connected": False,
        "historical_download_count": historical_count,
        "catalog": {"status": "checking", "source": "open_data_fixed_origin", "dataset": "ICON_2I_RUC/TOT_PREC"},
        "scheduling": {"status": "not_required", "mode": "open_data", "requests_created": 0},
    })
    if not result["enabled"]:
        result.update(
            status="disabled", status_label="Disattivato dall'utente",
            configured=False, authenticated_now=False, connected=False,
        )
        return result
    interval = max(15, min(360, int(source.get("sync_minutes", 30) or 30)))
    now = time.time()
    if (
        result.get("source_mode") == "open_data_single_variable"
        and now - float(result.get("last_attempt_epoch", 0) or 0) < interval * 60
    ):
        return result
    result["last_attempt_epoch"] = now
    try:
        client = MeteoHubOpenDataClient()
        latest = client.latest_icon_precipitation()
        artifacts = [item for item in result.get("artifacts", []) if isinstance(item, dict)]
        known_keys = {
            str(item.get("request_key")) for item in artifacts
            if item.get("request_key") and item.get("status") in ("processed", "duplicate")
        }
        known_hashes = {str(item.get("sha256")) for item in artifacts if item.get("sha256") and item.get("status") == "processed"}
        max_bytes = max(32, min(1024, int(source.get("maximum_file_mb", 256) or 256))) * 1024 * 1024
        inbox = root / "meteohub" / "inbox"
        new_forecasts: list[dict[str, Any]] = []
        failed_files = 0
        request_key = f"open-data:ICON_2I_RUC:{latest['run']}:{latest['filename']}"
        if request_key not in known_keys:
            filename = latest["filename"]
            safe_prefix = hashlib.sha256(request_key.encode("utf-8", errors="replace")).hexdigest()[:12]
            destination = inbox / f"{safe_prefix}-{Path(filename).name}"
            client.download(latest["url"], destination, max_bytes)
            package_hash = _sha256(destination)
            artifact: dict[str, Any] = {
                "request_key": request_key, "filename": Path(filename).name, "sha256": package_hash,
                "model": "ICON-2I-RUC", "run": latest["run"],
                "downloaded_utc": _utc_now().isoformat(), "status": "downloaded",
            }
            try:
                if package_hash in known_hashes:
                    artifact.update(status="duplicate", forecasts=0)
                    destination.unlink(missing_ok=True)
                else:
                    processed = _process_meteohub_package(
                        destination, root, targets, "ICON-2I-RUC", source, max_bytes
                    )
                    new_forecasts.extend(processed["forecasts"])
                    artifact.update(status="processed", forecasts=len(processed["forecasts"]), stats=processed["stats"])
                    known_hashes.add(package_hash)
                    destination.unlink(missing_ok=True)
            except Exception as exc:
                failed_files += 1
                artifact.update(status="failed", error=str(exc)[:200])
            artifacts.append(artifact)
            known_keys.add(request_key)
        now_ms = int(time.time() * 1000)
        forecasts = _merge_meteohub_forecasts(root, new_forecasts, now_ms, int(source.get("forecast_retention_hours", 48) or 48))
        active = [
            item for item in forecasts
            if now_ms - 30 * 60000 <= int(item.get("valid_at_ms", 0) or 0) <= now_ms + max(1, int(source.get("maximum_lead_hours", 3) or 3)) * 3600 * 1000
        ][-200:]
        if failed_files:
            status, label = "partial", "Collegato · alcuni GRIB da verificare"
        elif active:
            status, label = "ready", "Dati MeteoHub elaborati"
        else:
            status, label = "waiting_data", "Collegato · in attesa del prossimo run"
        secret_path = Path(os.environ.get("LDZ_METEO_METEOHUB_SECRETS", "/etc/meteo-alert/meteohub.env"))
        username, password = load_meteohub_credentials(secret_path)
        result.update(
            status=status,
            status_label=label,
            connected=True,
            configured=True,
            authenticated_now=False,
            source_mode="open_data_single_variable",
            latest_run=latest["run"],
            account_configured=bool(username and password),
            account_hint=(username[:2] + "…" + username[-2:]) if len(username) > 5 else "",
            matching_requests=1,
            pending_requests=0,
            artifacts=artifacts[-100:],
            downloaded_files=[str(item.get("filename")) for item in artifacts[-100:] if item.get("filename")],
            downloaded_count=sum(1 for item in artifacts if item.get("status") in ("processed", "duplicate", "failed")),
            historical_download_count=max(
                len(historical_files),
                sum(1 for item in artifacts if item.get("status") in ("processed", "duplicate", "failed")),
            ),
            processed_count=sum(1 for item in artifacts if item.get("status") == "processed"),
            failed_count=sum(1 for item in artifacts if item.get("status") == "failed"),
            forecast_count=len(forecasts),
            active_forecasts=active,
            usage={},
            hourly={},
            catalog={"status": "verified", "source": "open_data_fixed_origin", "dataset": "ICON_2I_RUC/TOT_PREC"},
            scheduling={"status": "not_required", "mode": "open_data", "requests_created": 0},
            last_success_utc=_utc_now().isoformat(),
            last_success_at=_utc_now().isoformat(),
            data_freshness="run corrente",
            last_error="",
            error="",
        )
    except Exception as exc:
        result.update(
            status="error", status_label="Collegamento da verificare", connected=False,
            authenticated_now=False, last_error=str(exc)[:240], error=str(exc)[:240],
        )
    return result


def _target_value(field: np.ndarray, ref: dict[str, Any], target: Any, step: int = 1) -> float | None:
    try:
        from rasterio.transform import rowcol
        from rasterio.warp import transform as warp_transform

        lon, lat = float(target.lon), float(target.lat)
        crs = ref.get("crs")
        if crs and str(crs).upper() not in ("EPSG:4326", "OGC:CRS84"):
            xs, ys = warp_transform("EPSG:4326", crs, [lon], [lat])
            x, y = xs[0], ys[0]
        else:
            x, y = lon, lat
        row, col = rowcol(ref["transform"], x, y)
        row, col = int(row) // max(1, step), int(col) // max(1, step)
        if row < 0 or col < 0 or row >= field.shape[-2] or col >= field.shape[-1]:
            return None
        value = float(field[..., row, col])
        return value if math.isfinite(value) else None
    except Exception:
        return None


def _store_frame(
    root: Path, field: np.ndarray, timestamp_ms: int, max_grid: int, *, series: str = "radar-frames", keep: int = 4
) -> tuple[list[Path], int]:
    frames = root / series
    frames.mkdir(parents=True, exist_ok=True)
    step = max(1, int(math.ceil(max(field.shape) / max(64, max_grid))))
    compact = np.nan_to_num(field[::step, ::step].astype("float32"), nan=0.0, posinf=0.0, neginf=0.0)
    destination = frames / f"{int(timestamp_ms)}.npz"
    if not destination.exists():
        with tempfile.NamedTemporaryFile("wb", delete=False, dir=frames) as handle:
            np.savez_compressed(handle, field=compact, step=np.array([step], dtype="int16"))
            temporary = Path(handle.name)
        temporary.chmod(0o600)
        temporary.replace(destination)
    paths = sorted((p for p in frames.glob("*.npz") if p.is_file() and not p.is_symlink()), key=lambda p: int(p.stem))
    bounded_keep = max(3, min(8, int(keep)))
    for old in paths[:-bounded_keep]:
        old.unlink(missing_ok=True)
    paths = paths[-bounded_keep:]
    return paths, step


def _save_verification_field(root: Path, model: str, issued_ms: int, lead: int, field: np.ndarray, step: int, product: str) -> str:
    directory = root / "verification-fields"
    directory.mkdir(parents=True, exist_ok=True)
    destination = directory / f"{model}-{issued_ms}-{lead}.npz"
    with tempfile.NamedTemporaryFile("wb", delete=False, dir=directory) as handle:
        np.savez_compressed(
            handle, field=np.asarray(field, dtype="float32"), step=np.asarray([step], dtype="int16"),
            product=np.asarray([product]),
        )
        temporary = Path(handle.name)
    temporary.chmod(0o600)
    temporary.replace(destination)
    return str(destination)


def _memory_available_mb() -> float | None:
    try:
        for raw in Path("/proc/meminfo").read_text(encoding="ascii").splitlines():
            if raw.startswith("MemAvailable:"):
                return float(raw.split()[1]) / 1024.0
    except (OSError, ValueError, IndexError):
        return None
    return None


def _process_peak_memory_mb() -> float | None:
    try:
        import resource
        value = float(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        if sys.platform == "darwin":
            value /= 1024.0
        return round(value / 1024.0, 1)
    except Exception:
        return None


def _run_with_timeout(callback: Any, seconds: float) -> Any:
    """Timeout reale su Linux; nessun thread concorrente per i challenger."""
    bounded = max(5.0, min(180.0, float(seconds)))
    if not hasattr(signal, "SIGALRM") or threading.current_thread() is not threading.main_thread():
        return callback()
    previous = signal.getsignal(signal.SIGALRM)

    def expired(_signum: int, _frame: Any) -> None:
        raise TimeoutError(f"challenger oltre {bounded:.0f}s")

    signal.signal(signal.SIGALRM, expired)
    signal.setitimer(signal.ITIMER_REAL, bounded)
    try:
        return callback()
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous)


def _resource_gate(cfg: dict[str, Any]) -> dict[str, Any]:
    lab = cfg.get("weather_lab", {}) if isinstance(cfg.get("weather_lab"), dict) else {}
    guard = lab.get("resource_guard", {}) if isinstance(lab.get("resource_guard"), dict) else {}
    minimum_mb = max(256.0, min(1024.0, float(guard.get("minimum_available_memory_mb", 420) or 420)))
    available_mb = _memory_available_mb()
    data_dir = Path(cfg.get("app", {}).get("data_dir", "/var/lib/meteo-alert"))
    block_path = Path(guard.get("optional_jobs_block_file") or (data_dir / "optional-jobs-blocked"))
    disk_blocked = block_path.is_file() and not block_path.is_symlink()
    allowed = not disk_blocked and (available_mb is None or available_mb >= minimum_mb)
    reason = "disk_pressure" if disk_blocked else "ok" if allowed else "memory_pressure"
    return {
        "allowed": allowed,
        "available_memory_mb": None if available_mb is None else round(available_mb, 1),
        "minimum_available_memory_mb": minimum_mb,
        "reason": reason,
        "optional_jobs_blocked": disk_blocked,
    }


def fractions_skill_score(forecast: np.ndarray, observed: np.ndarray, threshold: float, scale: int = 1) -> float | None:
    """FSS deterministico su due campi allineati; None se non c'è alcun evento."""
    left = (np.nan_to_num(np.asarray(forecast, dtype="float64"), nan=0.0) >= float(threshold)).astype("float64")
    right = (np.nan_to_num(np.asarray(observed, dtype="float64"), nan=0.0) >= float(threshold)).astype("float64")
    if left.shape != right.shape or left.ndim != 2:
        raise ValueError("campi FSS non allineati")
    width = max(1, min(101, int(scale)))

    def fraction(field: np.ndarray) -> np.ndarray:
        if width == 1:
            return field
        before = width // 2
        after = width - before - 1
        padded = np.pad(field, ((before, after), (before, after)), mode="constant")
        integral = np.pad(padded.cumsum(0).cumsum(1), ((1, 0), (1, 0)), mode="constant")
        total = integral[width:, width:] - integral[:-width, width:] - integral[width:, :-width] + integral[:-width, :-width]
        return total / float(width * width)

    forecast_fraction, observed_fraction = fraction(left), fraction(right)
    denominator = float(np.mean(forecast_fraction ** 2 + observed_fraction ** 2))
    if denominator <= 0:
        return None
    return max(0.0, min(1.0, 1.0 - float(np.mean((forecast_fraction - observed_fraction) ** 2)) / denominator))


def crps_ensemble(members: Iterable[float], observed: float) -> float | None:
    values = np.asarray([float(item) for item in members if math.isfinite(float(item))], dtype="float64")
    if values.size == 0 or not math.isfinite(float(observed)):
        return None
    first = float(np.mean(np.abs(values - float(observed))))
    second = 0.5 * float(np.mean(np.abs(values[:, None] - values[None, :])))
    return max(0.0, first - second)


def ensemble_rank(members: Iterable[float], observed: float) -> int | None:
    values = sorted(float(item) for item in members if math.isfinite(float(item)))
    if not values or not math.isfinite(float(observed)):
        return None
    return sum(1 for value in values if value < float(observed))


def _relevant_rain_gate(field: np.ndarray, ref: dict[str, Any], targets: Iterable[Any], cfg: dict[str, Any]) -> dict[str, Any]:
    lab = cfg.get("weather_lab", {}) if isinstance(cfg.get("weather_lab"), dict) else {}
    guard = lab.get("resource_guard", {}) if isinstance(lab.get("resource_guard"), dict) else {}
    rain_threshold = max(0.05, min(10.0, float(guard.get("minimum_rain_rate_mmh", 0.2) or 0.2)))
    minimum_fraction = max(0.00001, min(0.05, float(guard.get("minimum_domain_rain_fraction", 0.0005) or 0.0005)))
    radius_pixels = max(2, min(32, int(guard.get("target_window_pixels", 10) or 10)))
    clean = np.nan_to_num(np.asarray(field, dtype="float64"), nan=0.0, posinf=0.0, neginf=0.0)
    fraction = float(np.count_nonzero(clean >= rain_threshold)) / max(1, clean.size)
    relevant_pixels = 0
    relevant_max = 0.0
    try:
        from rasterio.transform import rowcol
        from rasterio.warp import transform as warp_transform
        for target in targets:
            lon, lat = float(target.lon), float(target.lat)
            crs = ref.get("crs")
            if crs and str(crs).upper() not in ("EPSG:4326", "OGC:CRS84"):
                xs, ys = warp_transform("EPSG:4326", crs, [lon], [lat])
                lon, lat = xs[0], ys[0]
            row, col = (int(value) for value in rowcol(ref["transform"], lon, lat))
            window = clean[
                max(0, row - radius_pixels):min(clean.shape[-2], row + radius_pixels + 1),
                max(0, col - radius_pixels):min(clean.shape[-1], col + radius_pixels + 1),
            ]
            if window.size:
                relevant_pixels += int(np.count_nonzero(window >= rain_threshold))
                relevant_max = max(relevant_max, float(np.max(window)))
    except Exception:
        relevant_pixels = 0
    allowed = relevant_pixels > 0 or fraction >= minimum_fraction
    return {
        "allowed": allowed,
        "reason": "ok" if allowed else "insufficient_relevant_rain",
        "domain_rain_fraction": round(fraction, 7),
        "minimum_domain_rain_fraction": minimum_fraction,
        "relevant_rain_pixels": relevant_pixels,
        "relevant_max_mmh": round(relevant_max, 2),
        "threshold_mmh": rain_threshold,
    }


def _run_linda(root: Path, field: np.ndarray, ref: dict[str, Any], targets: Iterable[Any], timestamp_ms: int, cfg: dict[str, Any]) -> dict[str, Any]:
    started = time.monotonic()
    result: dict[str, Any] = {"enabled": True, "mode": "shadow", "affects_alerts": False, "available": False, "process_peak_memory_mb": _process_peak_memory_mb()}
    lab = cfg.get("weather_lab", {}) if isinstance(cfg.get("weather_lab"), dict) else {}
    linda_cfg = lab.get("linda", {}) if isinstance(lab.get("linda"), dict) else {}
    runtime_budget = float((lab.get("resource_guard", {}) or {}).get("maximum_runtime_seconds", 55) or 55)
    if not bool(linda_cfg.get("enabled", True)):
        result.update(enabled=False, status_label="Disattivato")
        return result
    resources = _resource_gate(cfg)
    rain_gate = _relevant_rain_gate(field, ref, targets, cfg)
    result["resource_guard"] = {**resources, **rain_gate}
    if not resources["allowed"]:
        result.update(status="not_run", status_label="Non eseguito · risorse riservate agli avvisi", reason=resources["reason"], duration_seconds=round(time.monotonic() - started, 3))
        return result
    if not rain_gate["allowed"]:
        result.update(status="not_run", status_label="Non eseguito · pioggia rilevante insufficiente", reason="insufficient_relevant_rain", duration_seconds=round(time.monotonic() - started, 3))
        return result
    paths, step = _store_frame(root, field, timestamp_ms, int(linda_cfg.get("max_grid_pixels", 384) or 384))
    if len(paths) < 3:
        result.update(status="collecting", status_label=f"Raccolta frame {len(paths)}/3", frames=len(paths))
        return result
    selected = paths[-3:]
    stamps = [int(path.stem) for path in selected]
    gaps = [(stamps[index] - stamps[index - 1]) / 60000.0 for index in range(1, len(stamps))]
    timestep = float(sum(gaps) / len(gaps))
    if timestep <= 0 or max(gaps) - min(gaps) > max(2.0, timestep * 0.45):
        result.update(status="collecting", status_label="Attesa frame regolari", frames=len(paths))
        return result
    try:
        import pysteps
        from pysteps.motion import get_method as motion_method
        from pysteps.nowcasts.linda import forecast
    except Exception:
        result.update(status="unavailable", status_label="Componente LINDA non disponibile", reason="pysteps_not_installed")
        return result
    arrays = []
    stored_steps = []
    for path in selected:
        with np.load(path, allow_pickle=False) as payload:
            arrays.append(np.asarray(payload["field"], dtype="float64"))
            stored_steps.append(int(payload["step"][0]))
    if len(set(stored_steps)) != 1 or len({array.shape for array in arrays}) != 1:
        result.update(status="collecting", status_label="Griglia radar cambiata")
        return result
    stack = np.stack(arrays)
    leads = [int(item) for item in linda_cfg.get("lead_minutes", lab.get("lead_minutes", [15, 30, 60, 90])) if 5 <= int(item) <= 180]
    if np.count_nonzero(stack[-1] >= 0.2) < 8:
        result.update(status="not_run", status_label="Non eseguito · pioggia rilevante insufficiente", reason="insufficient_relevant_rain", frames=3, duration_seconds=round(time.monotonic() - started, 3))
        return result
    try:
        velocity = motion_method("constant")(stack)
        relative = [lead / timestep for lead in leads]
        members = max(4, min(20, int(linda_cfg.get("ensemble_members", 8) or 8)))
        try:
            output = _run_with_timeout(lambda: forecast(
                stack, velocity, relative, feature_method="domain", add_perturbations=True,
                n_ens_members=members, vel_pert_method=None, num_workers=1,
            ), runtime_budget)
        except TimeoutError:
            raise
        except Exception:
            output = _run_with_timeout(
                lambda: forecast(stack, velocity, relative, feature_method="domain", add_perturbations=False, num_workers=1),
                runtime_budget,
            )
        output = np.asarray(output)
        if output.ndim == 3:
            output = output[np.newaxis, ...]
        threshold = max(0.1, min(20.0, float(linda_cfg.get("event_rain_rate_mmh", 2.0) or 2.0)))
        forecasts: dict[str, Any] = {}
        for target in targets:
            per_lead: dict[str, Any] = {}
            for index, lead in enumerate(leads):
                values = []
                for member in output[:, index, :, :]:
                    value = _target_value(member, ref, target, stored_steps[0])
                    if value is not None:
                        values.append(value)
                if values:
                    per_lead[str(lead)] = {
                        "probability_percent": round(100.0 * sum(value >= threshold for value in values) / len(values), 1),
                        "median_rain_rate_mmh": round(float(np.median(values)), 2),
                        "ensemble_values_mmh": [round(float(value), 3) for value in values[:20]],
                    }
            forecasts[str(target.name)] = per_lead
        result.update(
            status="ready", status_label="Nowcast LINDA pronto", available=True,
            version=importlib.metadata.version("pysteps"), frames=3, timestep_minutes=round(timestep, 1),
            ensemble_members=int(output.shape[0]), forecasts=forecasts, generated_utc=_utc_now().isoformat(), error="",
            duration_seconds=round(time.monotonic() - started, 3),
            process_peak_memory_mb=_process_peak_memory_mb(),
        )
        result["verification_fields"] = [
            {
                "model": "pysteps_linda", "lead_minutes": lead, "product": "SRI",
                "path": _save_verification_field(root, "pysteps_linda", timestamp_ms, lead, np.mean(output[:, index], axis=0), stored_steps[0], "SRI"),
            }
            for index, lead in enumerate(leads)
        ]
    except Exception as exc:
        timed_out = isinstance(exc, TimeoutError)
        result.update(
            status="not_run" if timed_out else "error",
            status_label="Non eseguito · tempo massimo superato" if timed_out else "LINDA in attesa del prossimo ciclo",
            reason="timeout" if timed_out else type(exc).__name__,
            error=type(exc).__name__, duration_seconds=round(time.monotonic() - started, 3),
            process_peak_memory_mb=_process_peak_memory_mb(),
        )
    return result


def _run_anvil(root: Path, field: np.ndarray, ref: dict[str, Any], targets: Iterable[Any], timestamp_ms: int, cfg: dict[str, Any]) -> dict[str, Any]:
    started = time.monotonic()
    result: dict[str, Any] = {"enabled": True, "mode": "shadow", "affects_alerts": False, "available": False, "input_product": "VIL", "process_peak_memory_mb": _process_peak_memory_mb()}
    lab = cfg.get("weather_lab", {}) if isinstance(cfg.get("weather_lab"), dict) else {}
    anvil_cfg = lab.get("anvil", {}) if isinstance(lab.get("anvil"), dict) else {}
    runtime_budget = float((lab.get("resource_guard", {}) or {}).get("maximum_runtime_seconds", 55) or 55)
    if not bool(anvil_cfg.get("enabled", True)):
        result.update(enabled=False, status="disabled", status_label="Disattivato")
        return result
    resources = _resource_gate(cfg)
    result["resource_guard"] = resources
    if not resources["allowed"]:
        result.update(status="not_run", status_label="Non eseguito · risorse riservate agli avvisi", reason=resources["reason"])
        return result
    paths, step = _store_frame(root, field, timestamp_ms, int(anvil_cfg.get("max_grid_pixels", 320) or 320), series="vil-frames", keep=5)
    if len(paths) < 4:
        result.update(status="collecting", status_label=f"Raccolta VIL {len(paths)}/4", frames=len(paths))
        return result
    selected = paths[-4:]
    stamps = [int(path.stem) for path in selected]
    gaps = [(stamps[index] - stamps[index - 1]) / 60000.0 for index in range(1, len(stamps))]
    timestep = float(sum(gaps) / len(gaps))
    if timestep <= 0 or max(gaps) - min(gaps) > max(2.0, timestep * 0.45):
        result.update(status="collecting", status_label="Attesa sequenza VIL regolare", frames=len(paths))
        return result
    try:
        from pysteps.motion import get_method as motion_method
        from pysteps.nowcasts.anvil import forecast as anvil_forecast
        arrays: list[np.ndarray] = []
        stored_steps: list[int] = []
        for path in selected:
            with np.load(path, allow_pickle=False) as payload:
                arrays.append(np.asarray(payload["field"], dtype="float64"))
                stored_steps.append(int(payload["step"][0]))
        if len(set(stored_steps)) != 1 or len({array.shape for array in arrays}) != 1:
            raise WeatherLabError("griglia VIL cambiata")
        stack = np.stack(arrays)
        if np.count_nonzero(stack[-1] > 0) < 8:
            result.update(status="not_run", status_label="Non eseguito · VIL convettivo insufficiente", reason="insufficient_relevant_vil", frames=4)
            return result
        velocity = motion_method("lucaskanade")(stack)
        leads = [int(item) for item in anvil_cfg.get("lead_minutes", [15, 30, 60, 90]) if 5 <= int(item) <= 180]
        relative = [lead / timestep for lead in leads]
        output = np.asarray(_run_with_timeout(
            lambda: anvil_forecast(stack, velocity, relative, ar_order=2, num_workers=1), runtime_budget,
        ))
        forecasts: dict[str, Any] = {}
        for target in targets:
            per_lead: dict[str, Any] = {}
            for index, lead in enumerate(leads):
                value = _target_value(output[index], ref, target, stored_steps[0])
                if value is not None:
                    per_lead[str(lead)] = {
                        "vil_forecast_value": round(max(0.0, value), 2),
                        "units": "input_vil_units", "calibrated": False, "probability": False,
                    }
            forecasts[str(target.name)] = per_lead
        result.update(
            status="ready", status_label="ANVIL VIL pronto · nessun effetto sugli avvisi", available=True,
            frames=4, timestep_minutes=round(timestep, 1), forecasts=forecasts,
            version=importlib.metadata.version("pysteps"), generated_utc=_utc_now().isoformat(),
            duration_seconds=round(time.monotonic() - started, 3),
            process_peak_memory_mb=_process_peak_memory_mb(),
        )
        result["verification_fields"] = [
            {
                "model": "pysteps_anvil", "lead_minutes": lead, "product": "VIL",
                "path": _save_verification_field(root, "pysteps_anvil", timestamp_ms, lead, output[index], stored_steps[0], "VIL"),
            }
            for index, lead in enumerate(leads)
        ]
    except Exception as exc:
        timed_out = isinstance(exc, TimeoutError)
        detail = str(exc).strip()
        reason = "timeout" if timed_out else type(exc).__name__
        if detail and not timed_out:
            reason = f"{reason}: {detail}"[:240]
        result.update(
            status="not_run" if timed_out else "unavailable",
            status_label="Non eseguito · tempo massimo superato" if timed_out else "ANVIL non disponibile",
            reason=reason, duration_seconds=round(time.monotonic() - started, 3),
            process_peak_memory_mb=_process_peak_memory_mb(),
        )
    return result


def _operational_probabilities(forecasts: dict[str, dict[str, Any]], targets: Iterable[Any], leads: list[int]) -> dict[str, dict[str, float]]:
    result: dict[str, dict[str, float]] = {}
    for target in targets:
        candidates = [value for key, value in forecasts.items() if key.endswith("|" + str(target.name)) and isinstance(value, dict)]
        per_lead: dict[str, float] = {}
        for lead in leads:
            probabilities = []
            for item in candidates:
                eta = item.get("eta_minutes")
                eta_low = item.get("eta_low_minutes", eta)
                if eta_low is not None and float(eta_low) <= lead:
                    probabilities.append(float(item.get("impact_probability_percent", 0.0) or 0.0))
            per_lead[str(lead)] = round(max(probabilities, default=0.0), 1)
        result[str(target.name)] = per_lead
    return result


def _metric_rows(raw: Any) -> list[dict[str, Any]]:
    if not isinstance(raw, dict):
        return []
    rows = []
    for key, value in raw.items():
        if not isinstance(value, dict) or "|" not in key:
            continue
        model, lead_text = key.rsplit("|", 1)
        try:
            lead = int(lead_text)
            samples = int(value.get("samples", 0) or 0)
            brier_sum = float(value.get("brier_sum", 0.0) or 0.0)
            correct = int(value.get("correct", 0) or 0)
            positives = int(value.get("positives", 0) or 0)
            negatives = int(value.get("negatives", 0) or 0)
            tp, fp = int(value.get("tp", 0) or 0), int(value.get("fp", 0) or 0)
            fn, tn = int(value.get("fn", 0) or 0), int(value.get("tn", 0) or 0)
            climatology_brier = float(value.get("climatology_brier_sum", 0.0) or 0.0) / samples
            persistence_brier = float(value.get("persistence_brier_sum", 0.0) or 0.0) / samples
        except (TypeError, ValueError):
            continue
        if samples <= 0:
            continue
        brier = brier_sum / samples
        bss_climatology = None if climatology_brier <= 0 else 1.0 - brier / climatology_brier
        bss_persistence = None if persistence_brier <= 0 else 1.0 - brier / persistence_brier
        storms = len(set(str(item) for item in value.get("storm_ids", []) if item))
        reliability_bins = value.get("reliability_bins") if isinstance(value.get("reliability_bins"), dict) else {}
        calibration = []
        for bin_name, bin_value in sorted(reliability_bins.items()):
            if not isinstance(bin_value, dict) or int(bin_value.get("samples", 0) or 0) <= 0:
                continue
            count = int(bin_value["samples"])
            calibration.append({
                "bin": bin_name, "samples": count,
                "mean_forecast_percent": round(100.0 * float(bin_value.get("forecast_sum", 0.0) or 0.0) / count, 1),
                "observed_frequency_percent": round(100.0 * float(bin_value.get("observed_sum", 0.0) or 0.0) / count, 1),
            })
        storm_results = value.get("storm_results") if isinstance(value.get("storm_results"), dict) else {}
        independent_total = len(storm_results)
        independent_correct = sum(bool(item.get("correct")) for item in storm_results.values() if isinstance(item, dict))
        confidence_interval = _wilson_interval(independent_correct, independent_total)
        labels = {
            "ldz_operational": "LDZ Nowcast Fusion",
            "pysteps_linda": "LINDA (ombra)",
            "pysteps_anvil": "ANVIL VIL (ombra)",
            "wrf_da_ita": "WRF_DA_ITA (ombra)",
            "icon_2i_ruc": "ICON-2I-RUC (ombra)",
            "meteohub_icon2i_ruc": "MeteoHub ICON-2I-RUC (ombra)",
            "meteohub_wrf_da_ita": "MeteoHub WRF-DA-ITA (ombra)",
        }
        crps_samples = int(value.get("crps_samples", 0) or 0)
        row = {
            "model": model,
            "model_label": labels.get(model, f"{model} (ombra)"),
            "lead_minutes": lead,
            "samples": samples,
            "positives": positives, "negatives": negatives, "independent_storms": storms,
            "brier": round(brier, 3),
            "bss_climatology": None if bss_climatology is None else round(bss_climatology, 3),
            "bss_persistence": None if bss_persistence is None else round(bss_persistence, 3),
            "accuracy_percent": round(100.0 * correct / samples, 1),
            "precision": None if tp + fp == 0 else round(tp / (tp + fp), 3),
            "recall_pod": None if tp + fn == 0 else round(tp / (tp + fn), 3),
            "false_alarm_ratio": None if tp + fp == 0 else round(fp / (tp + fp), 3),
            "false_negative_rate": None if fn + tp == 0 else round(fn / (fn + tp), 3),
            "sharpness_stddev": round(math.sqrt(max(0.0, float(value.get("probability_sq_sum", 0.0) or 0.0) / samples - (float(value.get("probability_sum", 0.0) or 0.0) / samples) ** 2)), 3),
            "reliability": calibration,
            "crps": None if crps_samples <= 0 else round(float(value.get("crps_sum", 0.0) or 0.0) / crps_samples, 3),
            "crps_samples": crps_samples,
            "rank_histogram": value.get("rank_histogram", {}) if isinstance(value.get("rank_histogram"), dict) else {},
            "independent_event_accuracy_95ci": confidence_interval,
            "confidence_interval_basis": "independent_storm_id",
            "enough_samples": samples >= 20,
            "promotion_sample_ready": samples >= 100 and storms >= 20 and positives >= 20 and negatives >= 20,
            "promotion_eligible": bool(samples >= 100 and storms >= 20 and positives >= 20 and negatives >= 20 and bss_climatology is not None and bss_climatology >= 0.10),
        }
        continuous_samples = int(value.get("continuous_samples", 0) or 0)
        if continuous_samples > 0:
            row.update(
                continuous_samples=continuous_samples,
                mae_mmh=round(float(value.get("absolute_error_sum", 0.0) or 0.0) / continuous_samples, 3),
                rmse_mmh=round(math.sqrt(float(value.get("squared_error_sum", 0.0) or 0.0) / continuous_samples), 3),
                bias_mmh=round(float(value.get("bias_sum", 0.0) or 0.0) / continuous_samples, 3),
            )
        rows.append(row)
    return sorted(rows, key=lambda row: (row["lead_minutes"], row["model"]))


def _wilson_interval(successes: int, total: int, z: float = 1.959963984540054) -> list[float] | None:
    """Wilson 95% interval, used only after grouping correlated forecasts by storm id."""
    if total <= 0:
        return None
    proportion = max(0.0, min(1.0, float(successes) / total))
    denominator = 1.0 + z * z / total
    centre = (proportion + z * z / (2.0 * total)) / denominator
    margin = z * math.sqrt(proportion * (1.0 - proportion) / total + z * z / (4.0 * total * total)) / denominator
    return [round(max(0.0, centre - margin), 3), round(min(1.0, centre + margin), 3)]


def _archive_and_verify(
    root: Path,
    targets: Iterable[Any],
    ref: dict[str, Any],
    arrays: dict[str, np.ndarray],
    timestamp_ms: int,
    operational: dict[str, dict[str, float]],
    linda: dict[str, Any],
    cfg: dict[str, Any],
    meteohub: dict[str, Any] | None = None,
    challengers: dict[str, dict[str, Any]] | None = None,
    field_challengers: Iterable[dict[str, Any]] = (),
) -> dict[str, Any]:
    lab = cfg.get("weather_lab", {}) if isinstance(cfg.get("weather_lab"), dict) else {}
    archive = root / "archive" / f"events-{datetime.fromtimestamp(timestamp_ms / 1000, timezone.utc):%Y%m%d}.jsonl"
    ledger = root / "ledger.json"
    state = _read_json(ledger, {"last_timestamp_ms": 0, "pending": [], "outcomes": 0, "forecasts": 0, "metrics": {}})
    rain = arrays.get("SRI")
    vmi = arrays.get("VMI")
    observed: dict[str, Any] = {}
    for target in targets:
        observed[str(target.name)] = {
            "rain_rate_mmh": _target_value(rain, ref, target) if rain is not None else None,
            "vmi_dbz": _target_value(vmi, ref, target) if vmi is not None else None,
        }
    pending = [item for item in state.get("pending", []) if isinstance(item, dict)]
    field_pending = [item for item in state.get("field_pending", []) if isinstance(item, dict)]
    remaining = []
    rain_threshold = float((lab.get("linda", {}) or {}).get("event_rain_rate_mmh", 2.0) or 2.0)
    for item in pending:
        valid_at = int(item.get("valid_at_ms", 0) or 0)
        if valid_at <= timestamp_ms <= valid_at + 20 * 60000:
            obs = observed.get(str(item.get("target")), {})
            rain_value = obs.get("rain_rate_mmh")
            vmi_value = obs.get("vmi_dbz")
            event = bool(rain_value >= rain_threshold) if rain_value is not None else bool(vmi_value is not None and vmi_value >= 35.0)
            probability = max(0.0, min(1.0, float(item.get("probability_percent", 0.0)) / 100.0))
            outcome = {
                "kind": "outcome", "forecast_id": item.get("forecast_id"), "model": item.get("model"),
                "lead_minutes": item.get("lead_minutes"), "target": item.get("target"),
                "probability_percent": round(probability * 100, 1), "event_observed": event,
                "brier": round((probability - float(event)) ** 2, 6), "observed": obs,
                "verified_at_ms": timestamp_ms,
            }
            predicted_rate = item.get("precipitation_rate_mmh")
            if predicted_rate is not None and rain_value is not None:
                error = float(predicted_rate) - float(rain_value)
                outcome.update(
                    predicted_precipitation_rate_mmh=round(float(predicted_rate), 3),
                    absolute_error_mmh=round(abs(error), 3), squared_error_mmh=round(error * error, 6),
                    bias_mmh=round(error, 3),
                )
            _append_jsonl(archive, outcome)
            state["outcomes"] = int(state.get("outcomes", 0) or 0) + 1
            metrics = state.setdefault("metrics", {})
            metric_key = f"{item.get('model')}|{int(item.get('lead_minutes', 0) or 0)}"
            metric = metrics.setdefault(metric_key, {
                "samples": 0, "brier_sum": 0.0, "correct": 0,
                "positives": 0, "negatives": 0, "tp": 0, "fp": 0, "fn": 0, "tn": 0,
                "climatology_brier_sum": 0.0, "persistence_brier_sum": 0.0,
                "probability_sum": 0.0, "probability_sq_sum": 0.0,
                "reliability_bins": {}, "storm_ids": [],
                "storm_results": {},
            })
            previous_samples = int(metric.get("samples", 0) or 0)
            previous_positive = int(metric.get("positives", 0) or 0)
            climatology_probability = previous_positive / previous_samples if previous_samples else 0.10
            persistence_probability = max(0.0, min(1.0, float(item.get("persistence_probability_percent", 0.0) or 0.0) / 100.0))
            metric["samples"] = int(metric.get("samples", 0) or 0) + 1
            metric["brier_sum"] = round(float(metric.get("brier_sum", 0.0) or 0.0) + (probability - float(event)) ** 2, 6)
            metric["correct"] = int(metric.get("correct", 0) or 0) + int((probability >= 0.5) == event)
            metric["positives"] = previous_positive + int(event)
            metric["negatives"] = int(metric.get("negatives", 0) or 0) + int(not event)
            predicted = probability >= 0.5
            for key, matched in (("tp", predicted and event), ("fp", predicted and not event), ("fn", not predicted and event), ("tn", not predicted and not event)):
                metric[key] = int(metric.get(key, 0) or 0) + int(matched)
            metric["climatology_brier_sum"] = round(float(metric.get("climatology_brier_sum", 0.0) or 0.0) + (climatology_probability - float(event)) ** 2, 6)
            metric["persistence_brier_sum"] = round(float(metric.get("persistence_brier_sum", 0.0) or 0.0) + (persistence_probability - float(event)) ** 2, 6)
            metric["probability_sum"] = round(float(metric.get("probability_sum", 0.0) or 0.0) + probability, 6)
            metric["probability_sq_sum"] = round(float(metric.get("probability_sq_sum", 0.0) or 0.0) + probability * probability, 6)
            bin_name = f"{min(9, int(probability * 10)) * 10:02d}-{min(100, (min(9, int(probability * 10)) + 1) * 10):02d}"
            bins = metric.setdefault("reliability_bins", {})
            bin_state = bins.setdefault(bin_name, {"samples": 0, "forecast_sum": 0.0, "observed_sum": 0})
            bin_state["samples"] = int(bin_state.get("samples", 0) or 0) + 1
            bin_state["forecast_sum"] = round(float(bin_state.get("forecast_sum", 0.0) or 0.0) + probability, 6)
            bin_state["observed_sum"] = int(bin_state.get("observed_sum", 0) or 0) + int(event)
            storm_ids = [str(value) for value in metric.get("storm_ids", []) if value]
            storm_id = str(item.get("storm_id", ""))
            if storm_id and storm_id not in storm_ids:
                storm_ids.append(storm_id)
            metric["storm_ids"] = storm_ids[-500:]
            if storm_id:
                storm_results = metric.setdefault("storm_results", {})
                storm_results[storm_id] = {"correct": bool((probability >= 0.5) == event), "event": event}
                if len(storm_results) > 500:
                    for stale_id in list(storm_results)[:-500]:
                        storm_results.pop(stale_id, None)
            ensemble_values = item.get("ensemble_values_mmh") if isinstance(item.get("ensemble_values_mmh"), list) else []
            rain_observed = observed.get(str(item.get("target")), {}).get("rain_rate_mmh")
            if ensemble_values and rain_observed is not None:
                crps = crps_ensemble(ensemble_values, float(rain_observed))
                rank = ensemble_rank(ensemble_values, float(rain_observed))
                if crps is not None:
                    metric["crps_sum"] = round(float(metric.get("crps_sum", 0.0) or 0.0) + crps, 6)
                    metric["crps_samples"] = int(metric.get("crps_samples", 0) or 0) + 1
                if rank is not None:
                    histogram = metric.setdefault("rank_histogram", {})
                    histogram[str(rank)] = int(histogram.get(str(rank), 0) or 0) + 1
            if predicted_rate is not None and rain_value is not None:
                error = float(predicted_rate) - float(rain_value)
                metric["continuous_samples"] = int(metric.get("continuous_samples", 0) or 0) + 1
                metric["absolute_error_sum"] = round(float(metric.get("absolute_error_sum", 0.0) or 0.0) + abs(error), 6)
                metric["squared_error_sum"] = round(float(metric.get("squared_error_sum", 0.0) or 0.0) + error * error, 6)
                metric["bias_sum"] = round(float(metric.get("bias_sum", 0.0) or 0.0) + error, 6)
        elif timestamp_ms > valid_at + 20 * 60000:
            continue
        else:
            remaining.append(item)
    remaining_fields: list[dict[str, Any]] = []
    field_metrics = state.setdefault("field_metrics", {})
    for item in field_pending:
        valid_at = int(item.get("valid_at_ms", 0) or 0)
        forecast_path = Path(str(item.get("path") or ""))
        if valid_at <= timestamp_ms <= valid_at + 20 * 60000:
            observed_field = arrays.get(str(item.get("product") or ""))
            try:
                if observed_field is None or not forecast_path.is_file() or forecast_path.is_symlink():
                    raise WeatherLabError("campo di verifica non disponibile")
                with np.load(forecast_path, allow_pickle=False) as payload:
                    forecast_field = np.asarray(payload["field"], dtype="float64")
                    field_step = max(1, int(payload["step"][0]))
                aligned_observed = np.asarray(observed_field[::field_step, ::field_step], dtype="float64")
                if aligned_observed.shape != forecast_field.shape:
                    raise WeatherLabError("griglia di verifica cambiata")
                threshold = 2.0 if item.get("product") == "SRI" else 5.0
                scores = {str(scale): fractions_skill_score(forecast_field, aligned_observed, threshold, scale) for scale in (1, 3, 9)}
                scores = {key: value for key, value in scores.items() if value is not None}
                metric_key = f"{item.get('model')}|{int(item.get('lead_minutes', 0) or 0)}"
                metric = field_metrics.setdefault(metric_key, {"samples": 0, "fss_sum": {}})
                metric["samples"] = int(metric.get("samples", 0) or 0) + 1
                for scale, value in scores.items():
                    metric.setdefault("fss_sum", {})[scale] = round(float(metric.get("fss_sum", {}).get(scale, 0.0) or 0.0) + float(value), 6)
                _append_jsonl(archive, {
                    "kind": "field_outcome", "model": item.get("model"), "lead_minutes": item.get("lead_minutes"),
                    "product": item.get("product"), "fss": scores, "verified_at_ms": timestamp_ms,
                })
            except Exception:
                pass
            finally:
                forecast_path.unlink(missing_ok=True)
        elif timestamp_ms <= valid_at + 20 * 60000:
            remaining_fields.append(item)
        else:
            forecast_path.unlink(missing_ok=True)
    if int(state.get("last_timestamp_ms", 0) or 0) != timestamp_ms:
        linda_forecasts = linda.get("forecasts", {}) if isinstance(linda.get("forecasts"), dict) else {}
        leads = [int(item) for item in lab.get("lead_minutes", [15, 30, 60, 90])]
        model_values: list[tuple[str, dict[str, Any]]] = [("ldz_operational", operational)]
        if bool(linda.get("available")):
            model_values.append(("pysteps_linda", linda_forecasts))
        for model, values in (challengers or {}).items():
            if model in {"pysteps_anvil", "wrf_da_ita", "icon_2i_ruc"} and isinstance(values, dict):
                model_values.append((model, values))
        for target in targets:
            name = str(target.name)
            for model, model_forecasts in model_values:
                values = model_forecasts.get(name, {}) if isinstance(model_forecasts, dict) else {}
                model_leads = leads
                if model in {"wrf_da_ita", "icon_2i_ruc"} and isinstance(values, dict):
                    model_leads = sorted({int(value) for value in values if str(value).isdigit() and int(value) in (60, 180, 360)})
                for lead in model_leads:
                    if model != "ldz_operational" and (not isinstance(values, dict) or str(lead) not in values):
                        continue
                    raw = values.get(str(lead), 0.0) if isinstance(values, dict) else 0.0
                    probability = raw.get("probability_percent", 0.0) if isinstance(raw, dict) else raw
                    forecast_id = f"{timestamp_ms}:{model}:{name}:{lead}"
                    row = {
                        "kind": "forecast", "forecast_id": forecast_id, "model": model, "target": name,
                        "lead_minutes": lead, "probability_percent": round(float(probability or 0.0), 1),
                        "issued_at_ms": timestamp_ms, "valid_at_ms": timestamp_ms + lead * 60000,
                        "affects_alerts": False,
                        "source_is_operational": model == "ldz_operational",
                        "persistence_probability_percent": 100.0 if bool(
                            observed.get(name, {}).get("rain_rate_mmh") is not None and
                            observed.get(name, {}).get("rain_rate_mmh") >= rain_threshold
                        ) else 0.0,
                        "storm_id": f"{name}:{datetime.fromtimestamp(timestamp_ms / 1000, timezone.utc):%Y%m%d}",
                        "season": ("winter" if datetime.fromtimestamp(timestamp_ms / 1000, timezone.utc).month in (12, 1, 2) else "spring" if datetime.fromtimestamp(timestamp_ms / 1000, timezone.utc).month in (3, 4, 5) else "summer" if datetime.fromtimestamp(timestamp_ms / 1000, timezone.utc).month in (6, 7, 8) else "autumn"),
                        "severity": "high" if float(probability or 0.0) >= 70 else "medium" if float(probability or 0.0) >= 40 else "low",
                    }
                    if isinstance(raw, dict) and isinstance(raw.get("ensemble_values_mmh"), list):
                        row["ensemble_values_mmh"] = raw["ensemble_values_mmh"][:20]
                    _append_jsonl(archive, row)
                    remaining.append(row)
                    state["forecasts"] = int(state.get("forecasts", 0) or 0) + 1
        seen = [str(item) for item in state.get("seen_external_forecasts", []) if item]
        seen_set = set(seen)
        external = meteohub.get("active_forecasts", []) if isinstance(meteohub, dict) else []
        for raw in external:
            if not isinstance(raw, dict):
                continue
            forecast_id = str(raw.get("forecast_id") or "")
            valid_at = int(raw.get("valid_at_ms", 0) or 0)
            if not forecast_id or forecast_id in seen_set or valid_at < timestamp_ms - 5 * 60000:
                continue
            row = {
                "kind": "forecast", "forecast_id": forecast_id, "model": str(raw.get("model") or "meteohub"),
                "target": str(raw.get("target") or ""), "lead_minutes": int(raw.get("lead_minutes", 0) or 0),
                "probability_percent": round(float(raw.get("probability_percent", 0.0) or 0.0), 1),
                "precipitation_rate_mmh": round(float(raw.get("precipitation_rate_mmh", 0.0) or 0.0), 3),
                "issued_at_ms": int(raw.get("issued_at_ms", 0) or 0), "valid_at_ms": valid_at,
                "grid_distance_km": raw.get("grid_distance_km"), "source_variable": raw.get("source_variable"),
                "affects_alerts": False, "source_is_operational": False,
            }
            _append_jsonl(archive, row)
            remaining.append(row)
            seen.append(forecast_id)
            seen_set.add(forecast_id)
            state["forecasts"] = int(state.get("forecasts", 0) or 0) + 1
        state["seen_external_forecasts"] = seen[-10000:]
        state["last_timestamp_ms"] = timestamp_ms
        for item in field_challengers:
            if not isinstance(item, dict) or item.get("model") not in {"pysteps_linda", "pysteps_anvil"}:
                continue
            lead = int(item.get("lead_minutes", 0) or 0)
            path = Path(str(item.get("path") or ""))
            if lead not in leads or not path.is_file() or path.is_symlink():
                continue
            remaining_fields.append({
                "model": item["model"], "lead_minutes": lead, "product": str(item.get("product") or ""),
                "path": str(path), "issued_at_ms": timestamp_ms, "valid_at_ms": timestamp_ms + lead * 60000,
            })
    state["pending"] = remaining[-3000:]
    state["field_pending"] = remaining_fields[-100:]
    _atomic_json(ledger, state)
    return {
        "observed": observed,
        "forecasts": int(state.get("forecasts", 0)),
        "outcomes": int(state.get("outcomes", 0)),
        "pending": len(state["pending"]),
        "metrics": _metric_rows(state.get("metrics", {})),
        "field_metrics": [
            {
                "model": key.rsplit("|", 1)[0], "lead_minutes": int(key.rsplit("|", 1)[1]),
                "samples": int(value.get("samples", 0) or 0),
                "fss": {scale: round(float(total) / max(1, int(value.get("samples", 0) or 0)), 3) for scale, total in (value.get("fss_sum", {}) or {}).items()},
            }
            for key, value in sorted(field_metrics.items()) if isinstance(value, dict) and "|" in key
        ],
    }


def _cleanup(root: Path, retention_days: int, maximum_mb: int) -> None:
    cutoff = _utc_now() - timedelta(days=max(7, min(365, retention_days)))
    files = [path for path in root.rglob("*") if path.is_file() and not path.is_symlink()]
    for path in files:
        if path.name.startswith("events-") and datetime.fromtimestamp(path.stat().st_mtime, timezone.utc) < cutoff:
            path.unlink(missing_ok=True)
    limit = max(100, min(8192, maximum_mb)) * 1024 * 1024
    protected = {"status.json", "ledger.json", "forecasts.json"}
    files = sorted((path for path in root.rglob("*") if path.is_file() and not path.is_symlink() and path.name not in protected), key=lambda path: path.stat().st_mtime)
    total = sum(path.stat().st_size for path in files)
    for path in files:
        if total <= limit:
            break
        size = path.stat().st_size
        path.unlink(missing_ok=True)
        total -= size


def update_weather_lab(cfg: dict[str, Any], targets: list[Any], ref: dict[str, Any], arrays: dict[str, np.ndarray], precision_forecasts: dict[str, dict[str, Any]], timestamp_ms: int) -> dict[str, Any]:
    lab = cfg.get("weather_lab", {}) if isinstance(cfg.get("weather_lab"), dict) else {}
    enabled = bool(lab.get("enabled", True))
    root = Path(lab.get("data_dir") or (Path(cfg["app"]["data_dir"]) / "weather-lab"))
    status_path = root / "status.json"
    previous = _read_json(status_path)
    status: dict[str, Any] = {
        "enabled": enabled, "mode": "shadow", "affects_alerts": False,
        "status": "collecting" if enabled else "disabled",
        "status_label": "Raccolta dati in corso" if enabled else "Disattivato",
        "updated_utc": _utc_now().isoformat(),
    }
    if not enabled:
        _atomic_json(status_path, status)
        return status
    rain_field = arrays.get("SRI")
    radar_field = rain_field if rain_field is not None else arrays.get("VMI")
    product = "SRI" if rain_field is not None else "VMI"
    if radar_field is None:
        status.update(status="waiting", status_label="Attesa dati radar")
        _atomic_json(status_path, status)
        return status
    if rain_field is None:
        linda = {
            "enabled": bool((lab.get("linda", {}) or {}).get("enabled", True)),
            "mode": "shadow", "affects_alerts": False, "available": False,
            "status": "waiting_sri", "status_label": "Attesa prodotto pioggia SRI",
        }
    else:
        linda = _run_linda(root, rain_field, ref, targets, timestamp_ms, cfg)
    leads = [int(item) for item in lab.get("lead_minutes", [15, 30, 60, 90])]
    operational = _operational_probabilities(precision_forecasts, targets, leads)
    # I challenger sono volutamente sequenziali: prima LINDA, poi ANVIL, infine
    # l'eventuale I/O MeteoHub. Nessun job shadow compete con gli alert.
    vil_field = arrays.get("VIL")
    anvil = _run_anvil(root, vil_field, ref, targets, timestamp_ms, cfg) if vil_field is not None else {
        "enabled": True, "mode": "shadow", "affects_alerts": False, "available": False,
        "status": "waiting_vil", "status_label": "Attesa prodotto VIL",
    }
    meteohub = sync_meteohub(lab, root, previous.get("meteohub", {}), targets)
    challenger_forecasts: dict[str, dict[str, Any]] = {}
    for model, processing in (meteohub.get("model_results", {}) or {}).items():
        if model in {"wrf_da_ita", "icon_2i_ruc"} and isinstance(processing, dict):
            forecasts = processing.get("verification_forecasts")
            if isinstance(forecasts, dict):
                challenger_forecasts[model] = forecasts
    archive = _archive_and_verify(
        root, targets, ref, arrays, timestamp_ms, operational, linda, cfg,
        meteohub=meteohub,
        challengers=challenger_forecasts,
        field_challengers=[*(linda.get("verification_fields", []) or []), *(anvil.get("verification_fields", []) or [])],
    )
    status.update(
        radar={"available": True, "product": product, "timestamp_ms": timestamp_ms},
        linda=linda, anvil=anvil,
        hrd={
            "enabled": True, "mode": "shadow", "affects_alerts": False, "available": False,
            "status": "not_verified", "status_label": "Accesso/formato ufficiale non verificato",
            "reason": "official_api_product_not_listed",
        },
        meteohub=meteohub, archive=archive,
        status="ready", status_label="Weather Lab operativo",
    )
    _cleanup(root, int(lab.get("retention_days", 90) or 90), int(lab.get("maximum_total_mb", 1024) or 1024))
    _atomic_json(status_path, status)
    return status


__all__ = [
    "METEOHUB_ROOT", "MeteoHubOpenDataClient", "WeatherLabError", "load_meteohub_credentials",
    "sync_meteohub", "update_weather_lab",
]
