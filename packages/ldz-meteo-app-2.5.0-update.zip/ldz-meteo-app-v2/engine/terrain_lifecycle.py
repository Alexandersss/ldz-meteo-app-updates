#!/usr/bin/env python3
"""Terrain, lifecycle, lightning-jump and initiation helpers for 2.3.2."""
from __future__ import annotations

import math
from datetime import datetime, timezone
from typing import Any


def clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(value)))


def finite(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except Exception:
        return default


def trend(observations: list[dict[str, Any]], key: str) -> float:
    rows = []
    for row in observations[-8:]:
        value = row.get(key)
        if value is None:
            continue
        rows.append((int(row.get("timestamp_ms", 0) or 0), finite(value)))
    if len(rows) < 2:
        return 0.0
    t0 = rows[-1][0]
    xs = [(timestamp - t0) / 60000.0 for timestamp, _ in rows]
    ys = [value for _, value in rows]
    mean_x = sum(xs) / len(xs)
    mean_y = sum(ys) / len(ys)
    denominator = sum((x - mean_x) ** 2 for x in xs)
    if denominator <= 1e-9:
        return 0.0
    return sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys)) / denominator


def update_lightning_jump(
    track_id: str,
    current_count: int,
    timestamp_ms: int,
    state: dict[str, Any],
    cfg: dict[str, Any],
) -> dict[str, Any]:
    precision = state.setdefault("precision", {})
    histories = precision.setdefault("lightning_history", {})
    history = histories.setdefault(track_id, [])
    if not history or int(history[-1].get("timestamp_ms", 0) or 0) != int(timestamp_ms):
        history.append({"timestamp_ms": int(timestamp_ms), "count": max(0, int(current_count))})
    else:
        history[-1] = {"timestamp_ms": int(timestamp_ms), "count": max(0, int(current_count))}
    del history[:-12]
    maximum_age = max(30, int(cfg.get("lifecycle_engine", {}).get("lightning_history_minutes", 90) or 90))
    histories[track_id] = [
        row for row in history
        if timestamp_ms - int(row.get("timestamp_ms", 0) or 0) <= maximum_age * 60000
    ]
    history = histories[track_id]
    previous = int(history[-2].get("count", 0) or 0) if len(history) >= 2 else current_count
    delta = current_count - previous
    ratio = (current_count + 1.0) / (previous + 1.0)
    minimum_delta = max(2, int(cfg.get("lifecycle_engine", {}).get("lightning_jump_min_delta", 4) or 4))
    jump_score = 100.0 * clamp(0.58 * max(0.0, delta) / max(1.0, minimum_delta * 2.0) + 0.42 * max(0.0, ratio - 1.0) / 2.0)
    return {
        "count": int(current_count),
        "previous_count": int(previous),
        "delta": int(delta),
        "ratio": round(ratio, 3),
        "jump_score": round(jump_score, 1),
        "jump_detected": delta >= minimum_delta and ratio >= 1.5,
        "history_points": len(history),
    }


def assess_lifecycle(
    observations: list[dict[str, Any]],
    lightning: dict[str, Any],
    atmospheric: dict[str, Any],
    terrain: dict[str, Any],
    cfg: dict[str, Any],
) -> dict[str, Any]:
    """Stima euristica e spiegabile della sopravvivenza al lead time."""
    if not bool(cfg.get("lifecycle_engine", {}).get("enabled", True)):
        return {"survival_probability_percent": 100.0, "state": "disabilitato", "components": {}}
    if not observations:
        return {"survival_probability_percent": 50.0, "state": "in acquisizione"}
    current = observations[-1]
    vmi = finite(current.get("max_vmi"))
    poh = finite(current.get("max_poh"))
    vil = finite(current.get("max_vil"))
    etm = finite(current.get("max_etm"))
    srt1 = finite(current.get("max_srt1"))
    ir108 = current.get("min_ir108")
    vmi_trend = trend(observations, "max_vmi")
    area_trend = trend(observations, "area_km2")
    vil_trend = trend(observations, "max_vil")
    etm_trend = trend(observations, "max_etm")
    intensity = clamp((vmi - 25.0) / 35.0)
    vertical = 0.50 * clamp(vil / 55.0) + 0.50 * clamp(etm / 12000.0)
    hail = clamp(poh / 100.0)
    growth = clamp(0.5 + vmi_trend / 3.0 + area_trend / 15.0 + vil_trend / 8.0 + etm_trend / 5000.0)
    electric = clamp(finite(lightning.get("jump_score")) / 100.0)
    cape = clamp(finite(atmospheric.get("cape_jkg")) / 3500.0)
    barrier = clamp(finite(terrain.get("barrier_m")) / 1800.0)
    frames = clamp((len(observations) - 1) / 5.0)
    # Accumulo radar-orario e temperatura della sommita' nuvolosa sono
    # conferme indipendenti, quindi rimangono correttori piccoli e limitati.
    persistence = clamp(srt1 / 45.0)
    cold_cloud = clamp((-finite(ir108, 5.0) - 20.0) / 45.0) if ir108 is not None else 0.0
    raw = (
        0.21 * intensity
        + 0.17 * vertical
        + 0.08 * hail
        + 0.21 * growth
        + 0.10 * electric
        + 0.08 * cape
        + 0.06 * frames
        + 0.05 * persistence
        + 0.04 * cold_cloud
    )
    # L'orografia è soltanto un correttore limitato: mai una regola fisica assoluta.
    terrain_limit = clamp(finite(cfg.get("terrain_engine", {}).get("max_survival_adjustment", 0.12), 0.12), 0.0, 0.15)
    terrain_adjustment = -terrain_limit * barrier if vmi_trend < 0.0 else terrain_limit * 0.35 * barrier
    survival = 100.0 * clamp(raw + terrain_adjustment, 0.05, 0.98)
    if vmi_trend >= 0.7 or area_trend >= 1.8 or bool(lightning.get("jump_detected")):
        state_name = "intensificazione"
    elif vmi_trend <= -0.7 or area_trend <= -1.8:
        state_name = "indebolimento"
    else:
        state_name = "stabile"
    return {
        "survival_probability_percent": round(survival, 1),
        "state": state_name,
        "vmi_trend_dbz_min": round(vmi_trend, 3),
        "area_trend_km2_min": round(area_trend, 3),
        "vil_trend_min": round(vil_trend, 3),
        "etm_trend_m_min": round(etm_trend, 2),
        "terrain_adjustment_percent": round(terrain_adjustment * 100.0, 2),
        "components": {
            "intensity": round(intensity * 100.0, 1),
            "vertical": round(vertical * 100.0, 1),
            "growth": round(growth * 100.0, 1),
            "electric": round(electric * 100.0, 1),
            "environment": round(cape * 100.0, 1),
            "radar_persistence": round(persistence * 100.0, 1),
            "cold_cloud": round(cold_cloud * 100.0, 1),
        },
    }


def terrain_summary(elevations: list[float], cfg: dict[str, Any]) -> dict[str, Any]:
    values = [finite(value, float("nan")) for value in elevations]
    if len(values) < 3 or any(not math.isfinite(value) for value in values):
        return {"available": False}
    start, end = values[0], values[-1]
    peak = max(values)
    valley = min(values)
    barrier = max(0.0, peak - max(start, end))
    ascent = sum(max(0.0, b - a) for a, b in zip(values, values[1:]))
    descent = sum(max(0.0, a - b) for a, b in zip(values, values[1:]))
    return {
        "available": True,
        "source": "Open-Meteo Elevation / Copernicus DEM",
        "samples": len(values),
        "start_m": round(start, 1),
        "target_m": round(end, 1),
        "peak_m": round(peak, 1),
        "valley_m": round(valley, 1),
        "barrier_m": round(barrier, 1),
        "cumulative_ascent_m": round(ascent, 1),
        "cumulative_descent_m": round(descent, 1),
    }


def significant_impact_probability(trajectory_percent: float, survival_percent: float, sensor_score: float, cfg: dict[str, Any]) -> float:
    lcfg = cfg.get("lifecycle_engine", {})
    survival_weight = clamp(finite(lcfg.get("survival_weight", 0.34), 0.34), 0.10, 0.50)
    sensor_weight = clamp(finite(lcfg.get("sensor_confirmation_weight", 0.06), 0.06), 0.0, 0.15)
    trajectory_weight = max(0.35, 1.0 - survival_weight - sensor_weight)
    trajectory = clamp(trajectory_percent / 100.0)
    survival = clamp(survival_percent / 100.0)
    sensor = clamp(sensor_score / 100.0)
    # Media geometrica parziale: una traiettoria alta non basta se la cella decade.
    combined = trajectory_weight * trajectory + survival_weight * (trajectory * survival) + sensor_weight * max(trajectory, sensor)
    return round(100.0 * clamp(combined), 2)


def initiation_watch(
    targets: list[Any],
    atmospheric: dict[str, Any],
    lightning_by_target: dict[str, dict[str, Any]],
    sensor_by_target: dict[str, dict[str, Any]],
    cfg: dict[str, Any],
) -> dict[str, dict[str, Any]]:
    output: dict[str, dict[str, Any]] = {}
    cape = clamp(finite(atmospheric.get("cape_jkg")) / 3500.0)
    cin_value = max(0.0, abs(finite(atmospheric.get("cin_jkg"))))
    inhibition = clamp(cin_value / 250.0)
    spread = clamp(finite(atmospheric.get("steering_spread_kmh")) / 80.0)
    for target in targets:
        name = str(getattr(target, "name", target.get("name") if isinstance(target, dict) else "target"))
        lightning = lightning_by_target.get(name, {})
        sensor = sensor_by_target.get(name, {})
        electric = clamp(finite(lightning.get("count")) / 12.0)
        local = clamp(finite(sensor.get("confirmation_score")) / 100.0)
        score = 100.0 * clamp(0.50 * cape + 0.22 * electric + 0.18 * local + 0.10 * spread - 0.28 * inhibition)
        if score >= 70:
            level = "alto"
        elif score >= 45:
            level = "moderato"
        elif score >= 25:
            level = "basso"
        else:
            level = "minimo"
        output[name] = {
            "score_percent": round(score, 1),
            "level": level,
            "observed_cell": False,
            "advisory_only": True,
            "label": "potenziale innesco, non cella osservata",
        }
    return output


def calibration_segment(direction: str, lead_minutes: float, timestamp_ms: int) -> str:
    try:
        month = datetime.fromtimestamp(timestamp_ms / 1000.0, tz=timezone.utc).month
    except Exception:
        month = 1
    season = "winter" if month in {12, 1, 2} else "spring" if month in {3, 4, 5} else "summer" if month in {6, 7, 8} else "autumn"
    lead_bin = "0-15" if lead_minutes <= 15 else "16-30" if lead_minutes <= 30 else "31-45" if lead_minutes <= 45 else "46+"
    cardinal = str(direction or "ND").upper()[:3]
    return f"{season}|{cardinal}|{lead_bin}"
