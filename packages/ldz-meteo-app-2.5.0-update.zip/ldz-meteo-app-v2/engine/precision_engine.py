#!/usr/bin/env python3
"""LDZ Meteo Stable Impact Precision Engine 2.3.4.

Il modulo mantiene separati tre concetti che nelle versioni precedenti erano
parzialmente sovrapposti:

* traiettoria: dove si sposta geometricamente la cella;
* confidenza: quanto sono coerenti e completi i dati usati;
* pericolosita': intensita', grandine e attivita' elettrica.

Non e' un modello meteorologico ufficiale. Produce un nowcast locale e
probabilistico a brevissimo termine a partire dai prodotti Radar-DPC.
"""
from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import sys
import tempfile
from dataclasses import asdict, is_dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Optional

import numpy as np
from pyproj import Transformer
from scipy.optimize import linear_sum_assignment

COMPAT_MODULE_SOURCE = "native"
try:
    from adaptive_ai import apply_shadow_or_guarded, feature_vector, resolve_and_learn
    from terrain_lifecycle import (
        assess_lifecycle,
        calibration_segment,
        significant_impact_probability,
    )
except ModuleNotFoundError:
    # Il vecchio updater 2.2.9 distribuisce solo meteo_alert.py e
    # precision_engine.py al primo passaggio. I moduli duplicati nella WebGUI,
    # anch'essa root-owned e proveniente dallo ZIP firmato, mantengono il ciclo
    # operativo finché il nuovo updater completa il deploy nativo.
    compatibility_dir = Path(os.environ.get("LDZ_METEO_COMPAT_MODULE_DIR", "/opt/ldz-meteo-web/engine_compat"))
    if not compatibility_dir.is_dir() or compatibility_dir.is_symlink():
        raise
    sys.path.insert(0, str(compatibility_dir))
    from adaptive_ai import apply_shadow_or_guarded, feature_vector, resolve_and_learn
    from terrain_lifecycle import (
        assess_lifecycle,
        calibration_segment,
        significant_impact_probability,
    )
    COMPAT_MODULE_SOURCE = "signed-web-bootstrap"


EARTH_RADIUS_KM = 6371.0088


def clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, value))


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    p1 = math.radians(lat1)
    p2 = math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2.0) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2.0) ** 2
    return 2.0 * EARTH_RADIUS_KM * math.asin(math.sqrt(a))


def lonlat_to_xy_km(lon: float, lat: float, lon0: float, lat0: float) -> tuple[float, float]:
    x = math.radians(lon - lon0) * EARTH_RADIUS_KM * math.cos(math.radians((lat + lat0) / 2.0))
    y = math.radians(lat - lat0) * EARTH_RADIUS_KM
    return x, y


def xy_km_to_lonlat(x: float, y: float, lon0: float, lat0: float) -> tuple[float, float]:
    lat = lat0 + math.degrees(y / EARTH_RADIUS_KM)
    cos_lat = max(0.05, math.cos(math.radians((lat + lat0) / 2.0)))
    lon = lon0 + math.degrees(x / (EARTH_RADIUS_KM * cos_lat))
    return lon, lat


def cardinal_from_vector(east_km_min: float, north_km_min: float) -> tuple[float, str]:
    bearing = (math.degrees(math.atan2(east_km_min, north_km_min)) + 360.0) % 360.0
    labels = ["N", "NE", "E", "SE", "S", "SO", "O", "NO"]
    return bearing, labels[int((bearing + 22.5) // 45) % 8]


def _cell_dict(cell: Any) -> dict[str, Any]:
    if is_dataclass(cell):
        return asdict(cell)
    if isinstance(cell, dict):
        return dict(cell)
    return dict(vars(cell))


def _set_cell_attr(cell: Any, key: str, value: Any) -> None:
    if isinstance(cell, dict):
        cell[key] = value
    else:
        setattr(cell, key, value)


def _observation(cell: Any) -> dict[str, Any]:
    src = _cell_dict(cell)
    keep = (
        "cell_id", "timestamp_ms", "lat", "lon", "area_km2", "radius_km",
        "max_vmi", "mean_vmi", "max_sri", "max_poh", "max_vil", "max_etm", "max_srt1", "min_ir108",
        "risk", "footprint_xy_km", "shape_eccentricity", "shape_orientation_deg",
        "core_area_km2", "core_radius_km", "core_fraction", "core_footprint_xy_km",
        "cappi_profile_dbz", "cappi_available_levels", "cappi_highest_45_km",
        "cappi_highest_50_km", "cappi_highest_55_km", "cappi_quality_percent",
        "cappi_timestamp_ms",
    )
    return {key: src.get(key) for key in keep if key in src}


def _linear_velocity(observations: list[dict[str, Any]]) -> tuple[float, float]:
    """Velocita' recente in km/min usata solo per predire l'associazione."""
    if len(observations) < 2:
        return 0.0, 0.0
    recent = observations[-4:]
    anchor = recent[-1]
    times = np.asarray([(float(o["timestamp_ms"]) - float(anchor["timestamp_ms"])) / 60000.0 for o in recent])
    xs, ys = zip(*(lonlat_to_xy_km(float(o["lon"]), float(o["lat"]), float(anchor["lon"]), float(anchor["lat"])) for o in recent))
    if float(np.ptp(times)) <= 0:
        return 0.0, 0.0
    vx = float(np.polyfit(times, np.asarray(xs), 1)[0])
    vy = float(np.polyfit(times, np.asarray(ys), 1)[0])
    return vx, vy


def update_tracks(cells: list[Any], state: dict[str, Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """Associa le celle ai track con assegnazione globale e memoria multi-frame."""
    pcfg = cfg.get("precision_engine", {})
    tracking = cfg.get("tracking", {})
    precision = state.setdefault("precision", {})
    tracks = precision.setdefault("tracks", {})
    history_frames = max(3, min(12, int(pcfg.get("history_frames", 6) or 6)))
    max_gap = float(tracking.get("max_gap_minutes", 18) or 18)
    max_match = float(tracking.get("max_match_km", 35) or 35)
    now_ms = max([int(getattr(c, "timestamp_ms", 0) or 0) for c in cells], default=0)

    # Elimina track vecchi e limita i dati persistiti.
    for track_id in list(tracks):
        observations = tracks[track_id].get("observations") or []
        if not observations:
            tracks.pop(track_id, None)
            continue
        age_min = (now_ms - int(observations[-1].get("timestamp_ms", 0))) / 60000.0 if now_ms else 0.0
        if age_min > max(90.0, max_gap * 4.0):
            tracks.pop(track_id, None)
        else:
            tracks[track_id]["observations"] = observations[-history_frames:]

    active_ids: list[str] = []
    for track_id, track in tracks.items():
        obs = track.get("observations") or []
        if not obs or not now_ms:
            continue
        gap = (now_ms - int(obs[-1]["timestamp_ms"])) / 60000.0
        if 0 <= gap <= max_gap:
            active_ids.append(track_id)

    assignments: dict[int, str] = {}
    if cells and active_ids:
        costs = np.full((len(cells), len(active_ids)), 99.0, dtype="float64")
        for ci, cell in enumerate(cells):
            cur = _cell_dict(cell)
            for ti, track_id in enumerate(active_ids):
                observations = tracks[track_id]["observations"]
                prev = observations[-1]
                gap = (float(cur["timestamp_ms"]) - float(prev["timestamp_ms"])) / 60000.0
                if gap < 0 or gap > max_gap:
                    continue
                vx, vy = _linear_velocity(observations)
                pred_lon, pred_lat = xy_km_to_lonlat(vx * gap, vy * gap, float(prev["lon"]), float(prev["lat"]))
                distance = haversine_km(float(cur["lat"]), float(cur["lon"]), pred_lat, pred_lon)
                gate = max_match + min(20.0, gap * 1.2)
                if distance > gate:
                    continue
                area_prev = max(0.1, float(prev.get("area_km2") or 0.1))
                area_now = max(0.1, float(cur.get("area_km2") or 0.1))
                area_cost = min(1.0, abs(math.log(area_now / area_prev)) / math.log(4.0))
                vmi_cost = min(1.0, abs(float(cur.get("max_vmi") or 0.0) - float(prev.get("max_vmi") or 0.0)) / 30.0)
                shape_cost = min(1.0, abs(float(cur.get("shape_eccentricity") or 0.0) - float(prev.get("shape_eccentricity") or 0.0)))
                costs[ci, ti] = 0.68 * (distance / max(1.0, gate)) + 0.17 * area_cost + 0.10 * vmi_cost + 0.05 * shape_cost

        rows, cols = linear_sum_assignment(costs)
        for row, col in zip(rows.tolist(), cols.tolist()):
            if costs[row, col] <= float(pcfg.get("association_max_cost", 0.82) or 0.82):
                assignments[row] = active_ids[col]

    counter = int(precision.get("track_counter", 0) or 0)
    assigned_track_ids = set(assignments.values())
    for index, cell in enumerate(cells):
        lifecycle = "continuing"
        parent_track_id: Optional[str] = None
        track_id = assignments.get(index)
        if track_id is None:
            # Se una nuova cella nasce molto vicino a un track gia' assegnato,
            # la annotiamo come split senza riutilizzare lo stesso identificatore.
            cur = _cell_dict(cell)
            nearest_parent = None
            nearest_distance = float("inf")
            for candidate_id in assigned_track_ids:
                prev = (tracks.get(candidate_id, {}).get("observations") or [{}])[-1]
                if "lat" not in prev:
                    continue
                distance = haversine_km(float(cur["lat"]), float(cur["lon"]), float(prev["lat"]), float(prev["lon"]))
                if distance < nearest_distance:
                    nearest_distance, nearest_parent = distance, candidate_id
            if nearest_parent and nearest_distance <= float(pcfg.get("split_distance_km", 16) or 16):
                lifecycle = "split"
                parent_track_id = nearest_parent
            else:
                lifecycle = "new"
            counter += 1
            track_id = f"trk-{counter:07d}"
            tracks[track_id] = {"track_id": track_id, "observations": [], "created_ms": int(_cell_dict(cell)["timestamp_ms"])}

        track = tracks[track_id]
        previous_observations = (track.get("observations") or [])[-history_frames:]
        new_observation = _observation(cell)
        if previous_observations and int(previous_observations[-1].get("timestamp_ms", 0)) == int(new_observation.get("timestamp_ms", 0)):
            previous_observations[-1] = new_observation
            track["observations"] = previous_observations
        else:
            track["observations"] = previous_observations[-(history_frames - 1):] + [new_observation]
        track["updated_ms"] = int(_cell_dict(cell)["timestamp_ms"])
        if parent_track_id:
            track["parent_track_id"] = parent_track_id
        _set_cell_attr(cell, "track_id", track_id)
        _set_cell_attr(cell, "track_frames", len(track["observations"]))
        _set_cell_attr(cell, "lifecycle", lifecycle)

    # Merge: una cella assegnata che ingloba due vecchi track vicini.
    for cell in cells:
        cur = _cell_dict(cell)
        nearby = []
        for track_id in active_ids:
            prev = (tracks.get(track_id, {}).get("observations") or [{}])[-1]
            if "lat" not in prev:
                continue
            if haversine_km(float(cur["lat"]), float(cur["lon"]), float(prev["lat"]), float(prev["lon"])) <= float(pcfg.get("merge_distance_km", 14) or 14):
                nearby.append(track_id)
        if len(nearby) >= 2:
            _set_cell_attr(cell, "lifecycle", "merge")
            tracks[str(cur.get("track_id") or getattr(cell, "track_id", ""))]["merged_from"] = nearby[:4]

    precision["track_counter"] = counter
    precision["active_tracks"] = len(cells)
    precision["retained_tracks"] = len(tracks)
    return precision


def _kalman_motion(observations: list[dict[str, Any]], lon0: float, lat0: float, pcfg: dict[str, Any]) -> dict[str, Any]:
    """Filtro di Kalman a velocita' costante in coordinate locali km/min."""
    obs = sorted(observations, key=lambda row: int(row["timestamp_ms"]))
    points = [lonlat_to_xy_km(float(o["lon"]), float(o["lat"]), lon0, lat0) for o in obs]
    measurement_sigma = max(0.2, float(pcfg.get("measurement_noise_km", 1.2) or 1.2))
    accel_sigma = max(0.002, float(pcfg.get("acceleration_noise_km_min2", 0.018) or 0.018))
    if len(obs) >= 2:
        dt0 = max(0.1, (int(obs[1]["timestamp_ms"]) - int(obs[0]["timestamp_ms"])) / 60000.0)
        vx0 = (points[1][0] - points[0][0]) / dt0
        vy0 = (points[1][1] - points[0][1]) / dt0
    else:
        vx0 = vy0 = 0.0
    x = np.asarray([points[0][0], points[0][1], vx0, vy0], dtype="float64")
    p = np.diag([measurement_sigma ** 2, measurement_sigma ** 2, 0.08, 0.08])
    h = np.asarray([[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0]])
    r = np.eye(2) * measurement_sigma ** 2
    residuals: list[float] = []
    for index in range(1, len(obs)):
        dt = max(0.1, (int(obs[index]["timestamp_ms"]) - int(obs[index - 1]["timestamp_ms"])) / 60000.0)
        f = np.asarray([[1, 0, dt, 0], [0, 1, 0, dt], [0, 0, 1, 0], [0, 0, 0, 1]], dtype="float64")
        g = np.asarray([[0.5 * dt * dt], [0.5 * dt * dt], [dt], [dt]], dtype="float64")
        q = (g @ g.T) * accel_sigma ** 2
        x = f @ x
        p = f @ p @ f.T + q
        z = np.asarray(points[index], dtype="float64")
        innovation = z - h @ x
        residuals.append(float(np.linalg.norm(innovation)))
        s = h @ p @ h.T + r
        k = p @ h.T @ np.linalg.inv(s)
        x = x + k @ innovation
        p = (np.eye(4) - k @ h) @ p
    return {
        "state": x,
        "covariance": p,
        "residual_km": float(np.median(residuals)) if residuals else measurement_sigma,
    }


def _trend(observations: list[dict[str, Any]], key: str) -> float:
    rows = [(int(o["timestamp_ms"]), o.get(key)) for o in observations if o.get(key) is not None]
    if len(rows) < 2:
        return 0.0
    anchor = rows[-1][0]
    t = np.asarray([(timestamp - anchor) / 60000.0 for timestamp, _ in rows[-6:]], dtype="float64")
    values = np.asarray([float(value) for _, value in rows[-6:]], dtype="float64")
    if float(np.ptp(t)) <= 0:
        return 0.0
    return float(np.polyfit(t, values, 1)[0])


def estimate_motion(cell: Any, target: Any, state: dict[str, Any], cfg: dict[str, Any], optical_flow: Optional[dict[str, Any]] = None, atmospheric: Optional[dict[str, Any]] = None) -> Optional[dict[str, Any]]:
    pcfg = cfg.get("precision_engine", {})
    precision = state.get("precision", {})
    track_id = str(getattr(cell, "track_id", "") or _cell_dict(cell).get("track_id") or "")
    observations = ((precision.get("tracks") or {}).get(track_id, {}).get("observations") or [])[-12:]
    if len(observations) < 2:
        return None
    target_lon = float(getattr(target, "lon", target.get("lon") if isinstance(target, dict) else 0.0))
    target_lat = float(getattr(target, "lat", target.get("lat") if isinstance(target, dict) else 0.0))
    kalman = _kalman_motion(observations, target_lon, target_lat, pcfg)
    x = kalman["state"]
    covariance = kalman["covariance"]
    track_vx, track_vy = float(x[2]), float(x[3])

    flow_quality = clamp(float((optical_flow or {}).get("quality", 0.0) or 0.0))
    flow_vx = float((optical_flow or {}).get("east_kmh", 0.0) or 0.0) / 60.0
    flow_vy = float((optical_flow or {}).get("north_kmh", 0.0) or 0.0) / 60.0
    flow_weight = clamp(float(pcfg.get("optical_flow_weight", 0.30) or 0.30) * flow_quality, 0.0, 0.45)
    disagreement_kmh = math.hypot((flow_vx - track_vx) * 60.0, (flow_vy - track_vy) * 60.0)
    if disagreement_kmh > float(pcfg.get("max_flow_disagreement_kmh", 55) or 55):
        flow_weight *= 0.20
    vx = (1.0 - flow_weight) * track_vx + flow_weight * flow_vx
    vy = (1.0 - flow_weight) * track_vy + flow_weight * flow_vy
    atmospheric = atmospheric or {}
    nwp_available = bool(atmospheric.get("available"))
    nwp_vx = float(atmospheric.get("steering_east_kmh", 0.0) or 0.0) / 60.0
    nwp_vy = float(atmospheric.get("steering_north_kmh", 0.0) or 0.0) / 60.0
    nwp_disagreement_kmh = math.hypot((nwp_vx - vx) * 60.0, (nwp_vy - vy) * 60.0) if nwp_available else 0.0
    # Il modello atmosferico e' solo un prior debole: il radar osservato resta
    # dominante e il peso diminuisce man mano che il track accumula frame.
    nwp_weight = 0.0
    if nwp_available and nwp_disagreement_kmh <= float(pcfg.get("max_nwp_disagreement_kmh", 75) or 75):
        base_nwp_weight = clamp(float(pcfg.get("nwp_steering_weight", 0.10) or 0.10), 0.0, 0.20)
        consensus_quality = clamp(float(atmospheric.get("consensus_quality_percent", 100.0) or 0.0) / 100.0)
        nwp_weight = base_nwp_weight * consensus_quality * clamp(1.15 - len(observations) / 8.0, 0.35, 1.0)
        vx = (1.0 - nwp_weight) * vx + nwp_weight * nwp_vx
        vy = (1.0 - nwp_weight) * vy + nwp_weight * nwp_vy
    speed_kmh = math.hypot(vx, vy) * 60.0
    bearing, cardinal = cardinal_from_vector(vx, vy)

    area_trend = _trend(observations, "area_km2")
    vmi_trend = _trend(observations, "max_vmi")
    radius_trend = _trend(observations, "radius_km")
    if vmi_trend >= 0.6 or area_trend >= 1.5:
        growth_state = "intensificazione"
    elif vmi_trend <= -0.6 or area_trend <= -1.5:
        growth_state = "indebolimento"
    else:
        growth_state = "stabile"

    frame_score = clamp((len(observations) - 1) / max(1.0, float(pcfg.get("history_frames", 6)) - 1.0))
    residual_score = clamp(1.0 - kalman["residual_km"] / max(1.0, float(pcfg.get("poor_track_residual_km", 6.0) or 6.0)))
    flow_spread = float((optical_flow or {}).get("spread_kmh", 0.0) or 0.0)
    flow_agreement = clamp(1.0 - max(disagreement_kmh, flow_spread) / max(10.0, float(pcfg.get("max_flow_disagreement_kmh", 55) or 55))) if flow_quality else 0.45
    motion_confidence = 100.0 * clamp(0.52 * frame_score + 0.30 * residual_score + 0.18 * flow_agreement)
    return {
        "track_id": track_id,
        "track_frames": len(observations),
        "vx_km_min": vx,
        "vy_km_min": vy,
        "track_vx_km_min": track_vx,
        "track_vy_km_min": track_vy,
        "speed_kmh": speed_kmh,
        "bearing_deg": bearing,
        "direction_cardinal": cardinal,
        "covariance": covariance,
        "residual_km": kalman["residual_km"],
        "motion_confidence_percent": motion_confidence,
        "flow_quality_percent": flow_quality * 100.0,
        "flow_weight": flow_weight,
        "flow_disagreement_kmh": disagreement_kmh,
        "flow_multiscale_spread_kmh": flow_spread,
        "flow_deformation_score_percent": float((optical_flow or {}).get("deformation_score_percent", 0.0) or 0.0),
        "nwp_source": atmospheric.get("source") if nwp_available else None,
        "nwp_weight": nwp_weight,
        "nwp_disagreement_kmh": nwp_disagreement_kmh,
        "nwp_consensus_quality_percent": atmospheric.get("consensus_quality_percent") if nwp_available else None,
        "nwp_steering_spread_kmh": atmospheric.get("steering_spread_kmh") if nwp_available else None,
        "cape_jkg": atmospheric.get("cape_jkg") if nwp_available else None,
        "freezing_level_m": atmospheric.get("freezing_level_m") if nwp_available else None,
        "area_trend_km2_min": area_trend,
        "vmi_trend_dbz_min": vmi_trend,
        "radius_trend_km_min": radius_trend,
        "growth_state": growth_state,
    }


def _point_in_polygon(x: float, y: float, polygon: np.ndarray) -> bool:
    inside = False
    j = len(polygon) - 1
    for i in range(len(polygon)):
        xi, yi = polygon[i]
        xj, yj = polygon[j]
        if ((yi > y) != (yj > y)) and x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi:
            inside = not inside
        j = i
    return inside


def _polygon_distance(x: float, y: float, polygon: np.ndarray) -> float:
    if len(polygon) < 3:
        return float("inf")
    if _point_in_polygon(x, y, polygon):
        return 0.0
    best = float("inf")
    for i in range(len(polygon)):
        ax, ay = polygon[i]
        bx, by = polygon[(i + 1) % len(polygon)]
        dx, dy = bx - ax, by - ay
        denom = dx * dx + dy * dy
        t = 0.0 if denom <= 1e-12 else clamp(((x - ax) * dx + (y - ay) * dy) / denom)
        px, py = ax + t * dx, ay + t * dy
        best = min(best, math.hypot(x - px, y - py))
    return best


def _footprint(cell: Any) -> np.ndarray:
    raw = _cell_dict(cell).get("footprint_xy_km") or []
    if isinstance(raw, list) and len(raw) >= 3:
        try:
            polygon = np.asarray(raw, dtype="float64")
            if polygon.ndim == 2 and polygon.shape[1] == 2 and np.all(np.isfinite(polygon)):
                return polygon
        except Exception:
            pass
    radius = max(1.0, float(_cell_dict(cell).get("radius_km") or 1.0))
    angles = np.linspace(0.0, 2.0 * math.pi, 24, endpoint=False)
    return np.column_stack([np.cos(angles) * radius, np.sin(angles) * radius])


def _core_footprint(cell: Any) -> tuple[np.ndarray, bool]:
    """Restituisce il nucleo >= soglia e indica se è realmente osservato.

    Per vecchi stati o fixture senza il nuovo poligono usa un nucleo prudente
    ricavato dalla forma esterna. Il fallback serve solo al nowcast e non può
    attivare l'eccezione di impatto già osservato.
    """
    data = _cell_dict(cell)
    raw = data.get("core_footprint_xy_km") or []
    if isinstance(raw, list) and len(raw) >= 3:
        try:
            polygon = np.asarray(raw, dtype="float64")
            if polygon.ndim == 2 and polygon.shape[1] == 2 and np.all(np.isfinite(polygon)):
                return polygon, True
        except Exception:
            pass
    body = _footprint(cell)
    max_vmi = float(data.get("max_vmi") or 0.0)
    scale = 0.72 if max_vmi >= 55.0 else 0.58
    return body * scale, False


def empirical_calibration(
    raw_percent: float,
    target_name: str,
    state: dict[str, Any],
    cfg: dict[str, Any],
    direction: str = "ND",
    lead_minutes: float = 0.0,
    timestamp_ms: int = 0,
) -> tuple[float, bool, str]:
    cal = ((state.get("precision") or {}).get("calibration") or {}).get("targets", {}).get(target_name, {})
    total = int(cal.get("resolved", 0) or 0)
    minimum = int(cfg.get("precision_engine", {}).get("calibration_min_samples", 30) or 30)
    segment = calibration_segment(direction, lead_minutes, timestamp_ms)
    if total < minimum:
        return raw_percent, False, segment
    # Prima usa il comportamento locale stagione/direzione/lead; se il campione
    # è piccolo ricade sulla calibrazione generale del target.
    segmented = (cal.get("segments") or {}).get(segment) or {}
    bins = segmented.get("bins") if int(segmented.get("resolved", 0) or 0) >= 12 else cal.get("bins")
    bins = bins or {}
    key = str(min(9, max(0, int(raw_percent // 10))))
    bucket = bins.get(key) or {}
    count = int(bucket.get("count", 0) or 0)
    if count < 8:
        return raw_percent, False, segment
    hits = int(bucket.get("hits", 0) or 0)
    prior_strength = 10.0
    posterior = (hits + prior_strength * raw_percent / 100.0) / (count + prior_strength)
    # Limitiamo la correzione per evitare salti dovuti a campioni locali piccoli.
    calibrated = raw_percent + clamp(posterior * 100.0 - raw_percent, -15.0, 15.0)
    return clamp(calibrated, 0.0, 100.0), True, segment


def ensemble_forecast(
    cell: Any,
    target: Any,
    motion: dict[str, Any],
    state: dict[str, Any],
    cfg: dict[str, Any],
    terrain: Optional[dict[str, Any]] = None,
    lightning: Optional[dict[str, Any]] = None,
    atmospheric: Optional[dict[str, Any]] = None,
    sensor: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    pcfg = cfg.get("precision_engine", {})
    tracking = cfg.get("tracking", {})
    members = max(16, min(256, int(pcfg.get("ensemble_members", 72) or 72)))
    lead_minutes = max(5, min(90, int(tracking.get("prealert_minutes", 20) or 20)))
    step_minutes = max(0.5, min(2.0, float(pcfg.get("ensemble_step_minutes", 1.0) or 1.0)))
    target_name = str(getattr(target, "name", target.get("name") if isinstance(target, dict) else "target"))
    target_lon = float(getattr(target, "lon", target.get("lon") if isinstance(target, dict) else 0.0))
    target_lat = float(getattr(target, "lat", target.get("lat") if isinstance(target, dict) else 0.0))
    target_radius = float(getattr(target, "radius_km", target.get("radius_km") if isinstance(target, dict) else 0.0))
    cell_data = _cell_dict(cell)
    cur_x, cur_y = lonlat_to_xy_km(float(cell_data["lon"]), float(cell_data["lat"]), target_lon, target_lat)
    body_polygon = _footprint(cell)
    polygon, core_observed = _core_footprint(cell)
    body_distance = _polygon_distance(-cur_x, -cur_y, body_polygon)
    current_distance = _polygon_distance(-cur_x, -cur_y, polygon)
    observed_core_impact = core_observed and current_distance <= target_radius
    fringe_inside = body_distance <= target_radius and not observed_core_impact
    if observed_core_impact:
        return {
            "eta_minutes": 0.0,
            "eta_low_minutes": 0.0,
            "eta_high_minutes": 0.0,
            "speed_kmh": float(motion["speed_kmh"]),
            "closing_kmh": float(motion["speed_kmh"]),
            "distance_now_km": haversine_km(float(cell_data["lat"]), float(cell_data["lon"]), target_lat, target_lon),
            "closest_approach_km": current_distance,
            "min_track_distance_km": current_distance,
            "impact_probability_percent": 97.0,
            "raw_probability_percent": 97.0,
            "trajectory_probability_percent": 97.0,
            "impact_confidence_percent": max(70.0, float(motion["motion_confidence_percent"])),
            "exact_intersection": 1.0,
            "ensemble_members": members,
            "significant_impact_probability_percent": 97.0,
            "survival_probability_percent": 100.0,
            "model": "stable-impact-ensemble-2.4.0",
            "mode": "observed_core",
            "observed_core_impact": True,
            "fringe_inside": False,
            **{key: value for key, value in motion.items() if key != "covariance"},
        }

    seed_material = f"{motion['track_id']}:{cell_data['timestamp_ms']}:{target_name}".encode("utf-8")
    seed = int.from_bytes(hashlib.sha256(seed_material).digest()[:8], "big")
    rng = np.random.default_rng(seed)
    covariance = np.asarray(motion["covariance"], dtype="float64")
    velocity_cov = covariance[2:4, 2:4]
    base_sigma_km_min = max(0.01, float(pcfg.get("ensemble_velocity_sigma_kmh", 10.0) or 10.0) / 60.0)
    velocity_cov = velocity_cov + np.eye(2) * base_sigma_km_min ** 2
    try:
        velocities = rng.multivariate_normal(
            [float(motion["vx_km_min"]), float(motion["vy_km_min"])], velocity_cov, size=members, check_valid="ignore"
        )
    except Exception:
        velocities = np.column_stack([
            rng.normal(float(motion["vx_km_min"]), base_sigma_km_min, members),
            rng.normal(float(motion["vy_km_min"]), base_sigma_km_min, members),
        ])
    growth_mean = clamp(float(motion.get("radius_trend_km_min", 0.0) or 0.0), -0.25, 0.25)
    growth = rng.normal(growth_mean, float(pcfg.get("ensemble_growth_sigma_km_min", 0.045) or 0.045), members)
    times = np.arange(0.0, lead_minutes + 0.001, step_minutes)
    hit_etas: list[float] = []
    closest_values: list[float] = []
    for index in range(members):
        best_distance = float("inf")
        hit_eta: Optional[float] = None
        for minute in times:
            scale = clamp(1.0 + (growth[index] * minute) / max(1.0, float(cell_data.get("radius_km") or 1.0)), 0.45, 1.85)
            moved_polygon = polygon * scale
            center_x = cur_x + velocities[index, 0] * minute
            center_y = cur_y + velocities[index, 1] * minute
            distance = _polygon_distance(-center_x, -center_y, moved_polygon)
            best_distance = min(best_distance, distance)
            if hit_eta is None and distance <= target_radius:
                hit_eta = float(minute)
        closest_values.append(best_distance)
        if hit_eta is not None:
            hit_etas.append(hit_eta)

    # Beta(1,1) evita 0/100 artificiali con un ensemble finito.
    raw_probability = 100.0 * (len(hit_etas) + 1.0) / (members + 2.0)
    if hit_etas:
        eta_low, eta_med, eta_high = np.percentile(np.asarray(hit_etas), [20, 50, 80]).tolist()
    else:
        eta_low = eta_med = eta_high = float(times[-1])
    calibrated_probability, calibrated, calibration_group = empirical_calibration(
        raw_probability,
        target_name,
        state,
        cfg,
        str(motion.get("direction_cardinal", "ND")),
        float(eta_med),
        int(cell_data.get("timestamp_ms", 0) or 0),
    )
    closest = float(np.median(closest_values)) if closest_values else float("inf")

    vx, vy = float(motion["vx_km_min"]), float(motion["vy_km_min"])
    speed2 = vx * vx + vy * vy
    closing_kmh = 0.0 if speed2 <= 1e-9 else max(0.0, -(cur_x * vx + cur_y * vy) / max(0.1, math.hypot(cur_x, cur_y)) * 60.0)
    path_points = []
    for minute in range(0, lead_minutes + 1, 5):
        lon, lat = xy_km_to_lonlat(cur_x + vx * minute, cur_y + vy * minute, target_lon, target_lat)
        path_points.append({"minute": minute, "lon": round(lon, 6), "lat": round(lat, 6)})

    end_positions = np.column_stack([cur_x + velocities[:, 0] * lead_minutes, cur_y + velocities[:, 1] * lead_minutes])
    end_spread = np.linalg.norm(end_positions - np.median(end_positions, axis=0), axis=1)
    uncertainty_km = float(np.percentile(end_spread, 80)) if end_spread.size else 0.0
    confidence = float(motion["motion_confidence_percent"])
    if int(motion["track_frames"]) < 3:
        confidence = min(confidence, 58.0)
    observations = ((((state.get("precision") or {}).get("tracks") or {}).get(str(motion.get("track_id", "")), {}) or {}).get("observations") or [])[-12:]
    terrain = terrain or {"available": False}
    lightning = lightning or {}
    atmospheric = atmospheric or {}
    sensor = sensor or {}
    lifecycle = assess_lifecycle(observations, lightning, atmospheric, terrain, cfg)
    significant_probability = significant_impact_probability(
        calibrated_probability,
        float(lifecycle.get("survival_probability_percent", 50.0)),
        float(sensor.get("confirmation_score", 0.0) or 0.0),
        cfg,
    )
    base_forecast = {
        "eta_minutes": float(eta_med),
        "eta_low_minutes": float(eta_low),
        "eta_high_minutes": float(eta_high),
        "speed_kmh": float(motion["speed_kmh"]),
        "closing_kmh": closing_kmh,
        "distance_now_km": haversine_km(float(cell_data["lat"]), float(cell_data["lon"]), target_lat, target_lon),
        "closest_approach_km": closest,
        "min_track_distance_km": closest,
        "trajectory_uncertainty_km": uncertainty_km,
        "impact_probability_percent": significant_probability,
        "significant_impact_probability_percent": significant_probability,
        "raw_probability_percent": raw_probability,
        "trajectory_probability_percent": calibrated_probability,
        "impact_confidence_percent": confidence,
        "exact_intersection": 1.0 if raw_probability >= 50.0 else 0.0,
        "ensemble_members": members,
        "calibrated": calibrated,
        "calibration_group": calibration_group,
        "model": "stable-impact-ensemble-2.4.0",
        "path_points": path_points,
        "mode": "fringe_inside" if fringe_inside else "approaching",
        "observed_core_impact": False,
        "fringe_inside": fringe_inside,
        "lifecycle": lifecycle,
        "survival_probability_percent": float(lifecycle.get("survival_probability_percent", 50.0)),
        "terrain": terrain,
        "lightning_jump": lightning,
        "sensor_confirmation": sensor,
        **{key: value for key, value in motion.items() if key != "covariance"},
    }
    features = feature_vector(cell_data, base_forecast, lifecycle, terrain, lightning, atmospheric, sensor)
    ai = apply_shadow_or_guarded(significant_probability, features, state, cfg)
    base_forecast["adaptive_ai"] = ai
    base_forecast["ai_features"] = features
    base_forecast["impact_probability_percent"] = float(ai["blended_probability_percent"])
    base_forecast["significant_impact_probability_percent"] = float(ai["blended_probability_percent"])
    return base_forecast


def build_precision_forecasts(
    cells: list[Any],
    targets: list[Any],
    state: dict[str, Any],
    cfg: dict[str, Any],
    optical_flows: Optional[dict[str, dict[str, Any]]] = None,
    atmospheric_context: Optional[dict[str, Any]] = None,
    terrain_context: Optional[dict[str, dict[str, Any]]] = None,
    lightning_by_cell: Optional[dict[str, dict[str, Any]]] = None,
    sensor_by_target: Optional[dict[str, dict[str, Any]]] = None,
) -> dict[str, dict[str, Any]]:
    forecasts: dict[str, dict[str, Any]] = {}
    optical_flows = optical_flows or {}
    terrain_context = terrain_context or {}
    lightning_by_cell = lightning_by_cell or {}
    sensor_by_target = sensor_by_target or {}
    atmospheric_context = atmospheric_context or {}
    atmospheric_by_target = atmospheric_context.get("by_target") if isinstance(atmospheric_context.get("by_target"), dict) else {}
    min_speed = float(cfg.get("tracking", {}).get("min_speed_kmh", 8) or 8)
    max_speed = float(cfg.get("tracking", {}).get("max_speed_kmh", 130) or 130)
    for cell in cells:
        cell_id = str(getattr(cell, "cell_id", _cell_dict(cell).get("cell_id")))
        for target in targets:
            target_name = str(getattr(target, "name", target.get("name") if isinstance(target, dict) else "target"))
            target_atmospheric = atmospheric_by_target.get(target_name) or atmospheric_context
            motion = estimate_motion(cell, target, state, cfg, optical_flows.get(cell_id), target_atmospheric)
            if motion is None:
                continue
            if not (min_speed <= float(motion["speed_kmh"]) <= max_speed):
                continue
            key = f"{cell_id}|{target_name}"
            info = ensemble_forecast(
                cell,
                target,
                motion,
                state,
                cfg,
                terrain=terrain_context.get(key),
                lightning=lightning_by_cell.get(cell_id),
                atmospheric=target_atmospheric,
                sensor=sensor_by_target.get(target_name),
            )
            forecasts[key] = info
    return forecasts


def best_forecasts_by_target(cells: list[Any], targets: list[Any], forecasts: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
    cell_map = {str(getattr(c, "cell_id", _cell_dict(c).get("cell_id"))): c for c in cells}
    result: dict[str, dict[str, Any]] = {}
    for target in targets:
        target_name = str(getattr(target, "name", target.get("name") if isinstance(target, dict) else "target"))
        rows = []
        for key, info in forecasts.items():
            cell_id, _, name = key.partition("|")
            if name == target_name and cell_id in cell_map:
                rows.append((float(info.get("impact_probability_percent", 0.0)), -float(info.get("eta_minutes", 999.0)), cell_id, info))
        if rows:
            _, _, cell_id, info = max(rows)
            result[target_name] = {"cell_id": cell_id, "cell": _cell_dict(cell_map[cell_id]), "forecast": info}
    return result


def _target_hit(target: Any, cells: list[Any], strong_vmi: float) -> bool:
    target_lat = float(getattr(target, "lat", target.get("lat") if isinstance(target, dict) else 0.0))
    target_lon = float(getattr(target, "lon", target.get("lon") if isinstance(target, dict) else 0.0))
    target_radius = float(getattr(target, "radius_km", target.get("radius_km") if isinstance(target, dict) else 0.0))
    for cell in cells:
        data = _cell_dict(cell)
        if float(data.get("max_vmi") or 0.0) < strong_vmi:
            continue
        cx, cy = lonlat_to_xy_km(target_lon, target_lat, float(data["lon"]), float(data["lat"]))
        if _polygon_distance(cx, cy, _footprint(cell)) <= target_radius:
            return True
    return False


def _append_jsonl(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")


def update_verification(state: dict[str, Any], cells: list[Any], targets: list[Any], forecasts: dict[str, dict[str, Any]], timestamp_ms: int, cfg: dict[str, Any]) -> None:
    """Risoluzione automatica hit/miss e Brier Score locale, senza dati esterni."""
    pcfg = cfg.get("precision_engine", {})
    if not bool(pcfg.get("verification_enabled", True)):
        return
    precision = state.setdefault("precision", {})
    pending = precision.setdefault("pending_forecasts", [])
    calibration = precision.setdefault("calibration", {"targets": {}})
    targets_stats = calibration.setdefault("targets", {})
    target_map = {str(getattr(t, "name", t.get("name") if isinstance(t, dict) else "target")): t for t in targets}
    strong_vmi = float(cfg.get("tracking", {}).get("strong_alert_vmi_dbz", cfg.get("thresholds", {}).get("vmi_strong_dbz", 45)) or 45)
    observed = {name: _target_hit(target, cells, strong_vmi) for name, target in target_map.items()}
    verification_file = Path(cfg.get("app", {}).get("verification_file", str(Path(cfg["app"]["data_dir"]) / "precision" / "forecast-verification.jsonl")))

    kept = []
    for row in pending:
        target_name = str(row.get("target"))
        hit = bool(row.get("hit", False)) or (bool(observed.get(target_name)) and int(row.get("created_ms", 0)) <= timestamp_ms <= int(row.get("due_ms", 0)))
        due = timestamp_ms >= int(row.get("due_ms", 0))
        if not hit and not due:
            kept.append(row)
            continue
        outcome = 1 if hit else 0
        probability = clamp(float(row.get("probability_percent", 0.0)) / 100.0)
        brier = (probability - outcome) ** 2
        stats = targets_stats.setdefault(target_name, {"resolved": 0, "hits": 0, "brier_sum": 0.0, "bins": {}})
        stats["resolved"] = int(stats.get("resolved", 0)) + 1
        stats["hits"] = int(stats.get("hits", 0)) + outcome
        stats["brier_sum"] = float(stats.get("brier_sum", 0.0)) + brier
        stats["brier_score"] = float(stats["brier_sum"]) / int(stats["resolved"])
        key = str(min(9, max(0, int(float(row.get("probability_percent", 0.0)) // 10))))
        bucket = stats.setdefault("bins", {}).setdefault(key, {"count": 0, "hits": 0})
        bucket["count"] = int(bucket.get("count", 0)) + 1
        bucket["hits"] = int(bucket.get("hits", 0)) + outcome
        segment_key = str(row.get("calibration_group") or calibration_segment(
            str(row.get("direction_cardinal", "ND")),
            float(row.get("eta_minutes", 0.0) or 0.0),
            int(row.get("created_ms", timestamp_ms) or timestamp_ms),
        ))
        segment = stats.setdefault("segments", {}).setdefault(segment_key, {"resolved": 0, "hits": 0, "brier_sum": 0.0, "bins": {}})
        segment["resolved"] = int(segment.get("resolved", 0) or 0) + 1
        segment["hits"] = int(segment.get("hits", 0) or 0) + outcome
        segment["brier_sum"] = float(segment.get("brier_sum", 0.0) or 0.0) + brier
        segment["brier_score"] = float(segment["brier_sum"]) / int(segment["resolved"])
        segment_bucket = segment.setdefault("bins", {}).setdefault(key, {"count": 0, "hits": 0})
        segment_bucket["count"] = int(segment_bucket.get("count", 0) or 0) + 1
        segment_bucket["hits"] = int(segment_bucket.get("hits", 0) or 0) + outcome
        ai_result = resolve_and_learn(row, outcome, state, cfg, timestamp_ms)
        resolved = dict(row)
        resolved.update({"resolved_ms": timestamp_ms, "outcome": outcome, "brier": round(brier, 6), "adaptive_ai_result": ai_result})
        try:
            _append_jsonl(verification_file, resolved)
        except Exception as exc:
            logging.warning("impossibile scrivere verifica precisione: %s", exc)
    precision["pending_forecasts"] = kept[-500:]

    best = best_forecasts_by_target(cells, targets, forecasts)
    lead_minutes = int(cfg.get("tracking", {}).get("prealert_minutes", 20) or 20) + int(pcfg.get("verification_grace_minutes", 10) or 10)
    existing = {
        (str(row.get("target")), str(row.get("track_id")))
        for row in precision["pending_forecasts"]
    }
    minimum = float(pcfg.get("verification_min_probability_percent", 15) or 15)
    for target_name, item in best.items():
        info = item["forecast"]
        probability = float(info.get("impact_probability_percent", 0.0))
        track_id = str(info.get("track_id") or item["cell_id"])
        if probability < minimum or info.get("mode") in {"inside", "observed_core"} or (target_name, track_id) in existing:
            continue
        horizon_minutes = max(
            5.0,
            min(float(lead_minutes), float(info.get("eta_high_minutes", info.get("eta_minutes", lead_minutes)) or lead_minutes) + float(pcfg.get("verification_grace_minutes", 10) or 10)),
        )
        precision["pending_forecasts"].append({
            "model": str(info.get("model", "stable-impact-ensemble-2.4.0")),
            "target": target_name,
            "cell_id": item["cell_id"],
            "track_id": track_id,
            "created_ms": timestamp_ms,
            "due_ms": timestamp_ms + int(horizon_minutes * 60000),
            "probability_percent": round(probability, 2),
            "raw_probability_percent": round(float(info.get("raw_probability_percent", probability)), 2),
            "eta_minutes": round(float(info.get("eta_minutes", 0.0)), 2),
            "track_frames": int(info.get("track_frames", 0) or 0),
            "confidence_percent": round(float(info.get("impact_confidence_percent", 0.0)), 2),
            "survival_probability_percent": round(float(info.get("survival_probability_percent", 50.0) or 50.0), 2),
            "direction_cardinal": str(info.get("direction_cardinal", "ND")),
            "calibration_group": str(info.get("calibration_group", "")),
            "ai_features": list(info.get("ai_features") or []),
            "ai_shadow_probability_percent": round(float((info.get("adaptive_ai") or {}).get("probability_percent", 50.0) or 50.0), 2),
            "ai_status": str((info.get("adaptive_ai") or {}).get("status", "collection")),
        })

    resolved_total = sum(int(row.get("resolved", 0) or 0) for row in targets_stats.values())
    brier_sum = sum(float(row.get("brier_sum", 0.0) or 0.0) for row in targets_stats.values())
    calibration["resolved"] = resolved_total
    calibration["brier_score"] = (brier_sum / resolved_total) if resolved_total else None
    calibration["updated_ms"] = timestamp_ms
    precision["last_forecasts"] = best


def _phase_correlation_shift(previous: np.ndarray, current: np.ndarray) -> tuple[float, float, float]:
    """Ritorna movimento prev→current in pixel (row, col) e qualita' 0..1."""
    if previous.shape != current.shape or previous.ndim != 2 or min(previous.shape) < 16:
        return 0.0, 0.0, 0.0
    a = np.asarray(previous, dtype="float64")
    b = np.asarray(current, dtype="float64")
    finite = np.isfinite(a) & np.isfinite(b)
    if int(finite.sum()) < 128:
        return 0.0, 0.0, 0.0
    a = np.where(finite, np.clip(a, 15.0, 75.0), 15.0)
    b = np.where(finite, np.clip(b, 15.0, 75.0), 15.0)
    a -= float(np.mean(a))
    b -= float(np.mean(b))
    window = np.outer(np.hanning(a.shape[0]), np.hanning(a.shape[1]))
    a *= window
    b *= window
    fa = np.fft.fft2(a)
    fb = np.fft.fft2(b)
    cross = fa * np.conj(fb)
    magnitude = np.abs(cross)
    cross /= np.where(magnitude > 1e-12, magnitude, 1.0)
    corr = np.abs(np.fft.ifft2(cross))
    peak_index = np.unravel_index(int(np.argmax(corr)), corr.shape)
    align_shift = np.asarray(peak_index, dtype="float64")
    for dim, size in enumerate(corr.shape):
        if align_shift[dim] > size / 2:
            align_shift[dim] -= size
    peak = float(corr[peak_index])
    flat = corr.ravel()
    baseline = float(np.percentile(flat, 99.0)) if flat.size else peak
    quality = clamp((peak - baseline) / max(1e-6, peak) * 4.0)
    # align_shift e' la traslazione current→previous; il moto osservato ha segno opposto.
    return float(-align_shift[0]), float(-align_shift[1]), quality


def load_radar_cache(path: Path, ref: dict[str, Any], timestamp_ms: int, cfg: dict[str, Any]) -> Optional[dict[str, Any]]:
    if not path.is_file() or path.stat().st_size > 200 * 1024 * 1024:
        return None
    try:
        with np.load(path, allow_pickle=False) as data:
            array = np.asarray(data["vmi"], dtype="float32")
            old_timestamp = int(np.asarray(data["timestamp_ms"]).item())
            shape = tuple(int(v) for v in np.asarray(data["shape"]).tolist())
            transform = tuple(float(v) for v in np.asarray(data["transform"]).tolist())
            crs = str(np.asarray(data["crs"]).item())
        expected_transform = tuple(float(v) for v in tuple(ref["transform"])[:6])
        if array.shape != tuple(ref["array"].shape) or shape != array.shape or transform != expected_transform or crs != str(ref["crs"]):
            return None
        gap = (timestamp_ms - old_timestamp) / 60000.0
        max_gap = float(cfg.get("tracking", {}).get("max_gap_minutes", 18) or 18)
        if gap <= 0 or gap > max_gap:
            return None
        return {"vmi": array, "timestamp_ms": old_timestamp, "gap_minutes": gap}
    except Exception as exc:
        logging.warning("cache optical-flow ignorata: %s", exc)
        return None


def save_radar_cache(path: Path, ref: dict[str, Any], timestamp_ms: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    array = np.asarray(ref["array"], dtype="float32")
    if array.size > 100_000_000:
        return
    with tempfile.NamedTemporaryFile(delete=False, dir=str(path.parent), suffix=".npz") as handle:
        temporary = Path(handle.name)
    try:
        np.savez_compressed(
            temporary,
            vmi=array,
            timestamp_ms=np.asarray(timestamp_ms, dtype="int64"),
            shape=np.asarray(array.shape, dtype="int64"),
            transform=np.asarray(tuple(ref["transform"])[:6], dtype="float64"),
            crs=np.asarray(str(ref["crs"])),
        )
        temporary.replace(path)
        path.chmod(0o600)
    finally:
        temporary.unlink(missing_ok=True)


def estimate_optical_flows(cells: list[Any], current_vmi: np.ndarray, previous_cache: Optional[dict[str, Any]], ref: dict[str, Any], cfg: dict[str, Any]) -> dict[str, dict[str, Any]]:
    if previous_cache is None:
        return {}
    previous = np.asarray(previous_cache["vmi"], dtype="float32")
    gap_minutes = float(previous_cache["gap_minutes"])
    transformer = Transformer.from_crs(ref["crs"], "EPSG:4326", always_xy=True)
    results: dict[str, dict[str, Any]] = {}
    max_shift = max(8, min(80, int(cfg.get("precision_engine", {}).get("optical_flow_patch_padding_pixels", 36) or 36)))
    scale_factors = cfg.get("precision_engine", {}).get("optical_flow_scale_factors", [0.55, 1.0, 1.55])
    if not isinstance(scale_factors, list):
        scale_factors = [0.55, 1.0, 1.55]
    paddings = sorted({max(8, min(96, int(max_shift * float(scale)))) for scale in scale_factors[:5]})
    for cell in cells:
        data = _cell_dict(cell)
        bbox = data.get("pixel_bbox") or []
        if not isinstance(bbox, list) or len(bbox) != 4:
            continue
        base_r0, base_r1, base_c0, base_c1 = [int(v) for v in bbox]
        row = float(data.get("centroid_row") or (base_r0 + base_r1) / 2.0)
        col = float(data.get("centroid_col") or (base_c0 + base_c1) / 2.0)
        vectors: list[dict[str, float]] = []
        for padding in paddings:
            r0 = max(0, base_r0 - padding); r1 = min(current_vmi.shape[0], base_r1 + padding + 1)
            c0 = max(0, base_c0 - padding); c1 = min(current_vmi.shape[1], base_c1 + padding + 1)
            if r1 - r0 < 16 or c1 - c0 < 16:
                continue
            drow, dcol, quality = _phase_correlation_shift(previous[r0:r1, c0:c1], current_vmi[r0:r1, c0:c1])
            if quality <= 0.03 or math.hypot(drow, dcol) > max(8, padding):
                continue
            cur_x, cur_y = ref["transform"] * (col, row)
            prev_x, prev_y = ref["transform"] * (col - dcol, row - drow)
            cur_lon, cur_lat = transformer.transform(cur_x, cur_y)
            prev_lon, prev_lat = transformer.transform(prev_x, prev_y)
            east, north = lonlat_to_xy_km(float(cur_lon), float(cur_lat), float(prev_lon), float(prev_lat))
            vectors.append({
                "east_kmh": east / gap_minutes * 60.0,
                "north_kmh": north / gap_minutes * 60.0,
                "quality": quality,
                "row_shift_pixels": drow,
                "col_shift_pixels": dcol,
                "padding_pixels": float(padding),
            })
        if not vectors:
            continue
        weights = np.asarray([max(0.02, row["quality"]) for row in vectors], dtype="float64")
        weights /= float(np.sum(weights))
        east_values = np.asarray([row["east_kmh"] for row in vectors], dtype="float64")
        north_values = np.asarray([row["north_kmh"] for row in vectors], dtype="float64")
        east = float(np.sum(east_values * weights))
        north = float(np.sum(north_values * weights))
        spread = float(np.sqrt(np.sum(weights * ((east_values - east) ** 2 + (north_values - north) ** 2))))
        quality = clamp(float(np.sum(np.asarray([row["quality"] for row in vectors]) * weights)) * clamp(len(vectors) / max(1.0, len(paddings))))
        representative = vectors[int(np.argmax(weights))]
        results[str(data["cell_id"])] = {
            "east_kmh": east,
            "north_kmh": north,
            "quality": quality,
            "row_shift_pixels": representative["row_shift_pixels"],
            "col_shift_pixels": representative["col_shift_pixels"],
            "gap_minutes": gap_minutes,
            "scale_count": len(vectors),
            "spread_kmh": round(spread, 2),
            "deformation_score_percent": round(100.0 * clamp(spread / 45.0), 1),
            "scales": vectors,
        }
    return results
