from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path


ENGINE = Path(__file__).resolve().parents[1] / "engine"
sys.path.insert(0, str(ENGINE))

import adaptive_ai as ai  # noqa: E402
import adaptive_ai_trainer as trainer  # noqa: E402


class AdaptiveAITests(unittest.TestCase):
    def test_batch_trainer_uses_chronological_holdout_and_safe_json(self) -> None:
        rows = []
        for index in range(120):
            outcome = 1 if index % 2 else 0
            features = [float(outcome)] + [0.5] * (len(ai.FEATURE_NAMES) - 1)
            rows.append({"features": features, "outcome": outcome, "baseline_probability": 0.5})
        result = trainer.train(rows, {"adaptive_ai": {"shadow_warmup_events": 25, "batch_epochs": 160}})
        self.assertTrue(result["ready"])
        self.assertEqual(result["trained_events"], 84)
        self.assertEqual(result["validation_events"], 36)
        self.assertLess(result["candidate_brier"], result["baseline_brier"])
        self.assertEqual(result["feature_names"], list(ai.FEATURE_NAMES))

    def test_dataset_loader_rejects_invalid_or_unbounded_features(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "events.jsonl"
            valid = {"features": [0.25] * len(ai.FEATURE_NAMES), "outcome": 1, "baseline_probability": 70}
            invalid = {"features": [99.0] * len(ai.FEATURE_NAMES), "outcome": 0}
            path.write_text(json.dumps(valid) + "\n" + json.dumps(invalid) + "\n", encoding="utf-8")
            rows = trainer.load_rows(path)
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["outcome"], 1)

    def test_candidate_json_write_is_atomic_and_private(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "candidate.json"
            trainer.atomic_json(path, {"ready": True, "weights": [0.0] * len(ai.FEATURE_NAMES)})
            self.assertTrue(json.loads(path.read_text(encoding="utf-8"))["ready"])
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)


if __name__ == "__main__":
    unittest.main(verbosity=2)
