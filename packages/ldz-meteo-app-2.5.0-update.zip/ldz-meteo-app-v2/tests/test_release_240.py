from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / "engine"
sys.path.insert(0, str(ENGINE))

import hail_feedback as hf  # noqa: E402


def load_event_feedback():
    rasterio = types.ModuleType("rasterio")
    rasterio.transform = types.SimpleNamespace(rowcol=lambda *_args, **_kwargs: (0, 0))
    previous = sys.modules.get("rasterio")
    sys.modules["rasterio"] = rasterio
    try:
        spec = importlib.util.spec_from_file_location("event_feedback_release_240", ENGINE / "event_feedback.py")
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)
        return module
    finally:
        if previous is None:
            sys.modules.pop("rasterio", None)
        else:
            sys.modules["rasterio"] = previous


def load_wss_listener():
    websocket = types.ModuleType("websocket")
    websocket.create_connection = lambda *_args, **_kwargs: None
    previous = sys.modules.get("websocket")
    sys.modules["websocket"] = websocket
    try:
        spec = importlib.util.spec_from_file_location("radar_wss_release_240", ENGINE / "radar_wss_listener.py")
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)
        return module
    finally:
        if previous is None:
            sys.modules.pop("websocket", None)
        else:
            sys.modules["websocket"] = previous


ef = load_event_feedback()
wss = load_wss_listener()


class GroundTruthTests(unittest.TestCase):
    def sample_event(self) -> dict:
        return {
            "event_id": "evt240safe01",
            "target": "Pescara",
            "status": "closed",
            "started_ms": 2_000_000_000_000,
            "feedback_status": "asked",
            "peak": {
                "impact_probability_percent": 72,
                "hail_probability_percent": 45,
                "vmi": 52,
                "sri": 35,
                "poh": 40,
                "vil": 38,
                "etm": 11000,
                "lightning_count": 12,
                "hail_data_quality_percent": 82,
                "hail_persistence_frames": 3,
                "cappi_vertical": {"score_percent": 55, "height_45_above_freezing_km": 3.2},
            },
        }

    def test_signed_callback_accepts_only_configured_chat_and_writes_ground_truth(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            token = "123456:abcdefghijklmnopqrstuvwxyz_SAFE"
            chat_id = "12345678"
            event = self.sample_event()
            state = {"event_feedback": {"incidents": {event["event_id"]: event}}}
            cfg = {"app": {"data_dir": temp}, "hail_feedback_calibration": {}}
            code = ef.OPTION_CODES_REVERSE["small_hail"]
            signature = ef.feedback_signature(token, event["event_id"], code)
            update = {
                "callback_query": {
                    "id": "callback-1",
                    "data": f"fb:{event['event_id']}:{code}:{signature}",
                    "message": {"chat": {"id": int(chat_id)}},
                }
            }
            accepted = ef.handle_feedback_updates([update], state, cfg, token, chat_id, now_ms=2_000_000_100_000)
            self.assertTrue(accepted[0]["ok"])
            self.assertEqual(event["feedback_status"], "received")
            rows = (Path(temp) / "feedback" / "ground-truth.jsonl").read_text().splitlines()
            self.assertEqual(len(rows), 1)
            self.assertEqual(json.loads(rows[0])["hail_outcome"], 1)

            event2 = self.sample_event()
            event2["event_id"] = "evt240safe02"
            state["event_feedback"]["incidents"][event2["event_id"]] = event2
            bad = {"callback_query": {"id": "callback-2", "data": "fb:evt240safe02:h:wrong", "message": {"chat": {"id": 999}}}}
            rejected = ef.handle_feedback_updates([bad], state, cfg, token, chat_id)
            self.assertFalse(rejected[0]["ok"])

    def test_not_on_site_is_saved_as_ignored_not_ground_truth(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            token, chat_id = "token-safe", "42"
            event = self.sample_event()
            state = {"event_feedback": {"incidents": {event["event_id"]: event}}}
            code = ef.OPTION_CODES_REVERSE["not_there"]
            signature = ef.feedback_signature(token, event["event_id"], code)
            update = {"callback_query": {"id": "cb", "data": f"fb:{event['event_id']}:{code}:{signature}", "message": {"chat": {"id": 42}}}}
            ef.handle_feedback_updates([update], state, {"app": {"data_dir": temp}}, token, chat_id)
            self.assertEqual(event["feedback_status"], "ignored_not_on_site")
            self.assertFalse((Path(temp) / "feedback" / "ground-truth.jsonl").exists())

    def test_incident_closes_and_schedules_one_feedback_prompt(self) -> None:
        state: dict = {}
        target = {"name": "Pescara"}
        cell = {"cell_id": "c1", "max_vmi": 48, "max_sri": 25, "max_poh": 30, "max_vil": 20, "max_etm": 9000}
        forecast = {"c1|Pescara": {"cell_id": "c1", "impact_probability_percent": 70, "hail_probability_percent": 20}}
        cfg = {"tracking": {"min_alert_probability_percent": 60}, "event_feedback": {"enabled": True, "prompt_delay_minutes": 25}}
        ef.update_incidents(state, [target], [cell], forecast, {"Pescara": {}}, [{"target": "Pescara", "mode": "alert"}], 1_000_000, cfg, {"status": "aligned"})
        ef.update_incidents(state, [target], [cell], forecast, {"Pescara": {}}, [{"target": "Pescara", "mode": "clear"}], 1_300_000, cfg, {"status": "aligned"})
        event = next(iter(state["event_feedback"]["incidents"].values()))
        self.assertEqual(event["status"], "closed")
        self.assertEqual(event["feedback_status"], "pending")
        self.assertEqual(len(ef.pending_feedback_prompts(state, event["feedback_due_ms"])), 1)


class HailCalibrationTests(unittest.TestCase):
    def test_candidate_uses_chronological_validation_and_bounded_influence(self) -> None:
        rows = []
        for index in range(100):
            outcome = 1 if index % 2 else 0
            features = [0.9 if outcome else 0.1] * len(hf.FEATURE_NAMES)
            rows.append({"features": features, "outcome": outcome, "baseline": 0.5, "event_id": f"e{index}", "observed_ms": index})
        cfg = {"hail_feedback_calibration": {"minimum_events": 40, "minimum_validation_events": 12, "minimum_brier_improvement_percent": 1}}
        candidate = hf.train_candidate(rows, cfg)
        self.assertTrue(candidate["eligible"])
        self.assertEqual(candidate["trained_events"], 70)
        self.assertEqual(candidate["validation_events"], 30)
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "candidate.json"
            hf.atomic_json(path, candidate)
            apply_cfg = {
                "app": {"data_dir": temp},
                "hail_feedback_calibration": {
                    "candidate_model_file": str(path), "enabled": True, "auto_activate": True,
                    "guarded_influence": 0.18, "maximum_probability_delta_percent": 10,
                },
            }
            applied = hf.apply_candidate(50, [0.9] * len(hf.FEATURE_NAMES), apply_cfg)
            self.assertTrue(applied["applied"])
            self.assertLessEqual(abs(applied["probability_percent"] - 50), 1.8 + 1e-9)


class WebSocketProtocolTests(unittest.TestCase):
    def test_official_stomp_message_is_parsed(self) -> None:
        frame = (
            "MESSAGE\nsubscription:sub-0\ndestination:/topic/product\ncontent-type:application/json\n\n"
            '{"productType":"VMI","time":1556116200000,"period":"PT5M"}\x00'
        )
        product = wss.message_product(frame)
        self.assertEqual(product["productType"], "VMI")
        self.assertEqual(product["time"], 1556116200000)


if __name__ == "__main__":
    unittest.main(verbosity=2)
