from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / "engine"
sys.path.insert(0, str(ENGINE))


def load_event_feedback():
    rasterio = types.ModuleType("rasterio")
    rasterio.transform = types.SimpleNamespace(rowcol=lambda *_args, **_kwargs: (0, 0))
    previous = sys.modules.get("rasterio")
    sys.modules["rasterio"] = rasterio
    try:
        spec = importlib.util.spec_from_file_location("event_feedback_release_243", ENGINE / "event_feedback.py")
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)
        return module
    finally:
        if previous is None:
            sys.modules.pop("rasterio", None)
        else:
            sys.modules["rasterio"] = previous


ef = load_event_feedback()


def sample_event() -> dict:
    return {
        "event_id": "evt243safe01",
        "target": "Pescasseroli",
        "status": "closed",
        "feedback_status": "asked",
        "started_ms": 2_000_000_000_000,
        "peak": {"impact_probability_percent": 60, "hail_probability_percent": 10},
    }


def signed_update(token: str, chat_id: str, option: str, update_id: int = 91) -> dict:
    code = ef.OPTION_CODES_REVERSE[option]
    signature = ef.feedback_signature(token, "evt243safe01", code)
    return {
        "update_id": update_id,
        "callback_query": {
            "id": f"callback-{update_id}",
            "data": f"fb:evt243safe01:{code}:{signature}",
            "message": {"message_id": 777, "chat": {"id": int(chat_id)}},
        },
    }


class ImmediateFeedbackTests(unittest.TestCase):
    def test_callback_is_durably_queued_then_drained(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            token, chat_id = "safe-token", "42"
            event = sample_event()
            state = {"event_feedback": {"incidents": {event["event_id"]: event}}}
            cfg = {"app": {"data_dir": temp}}
            update = signed_update(token, chat_id, "not_there")
            validated = ef.validate_feedback_update(update, state, token, chat_id)
            self.assertTrue(validated["ok"])
            self.assertEqual(validated["message_id"], 777)
            self.assertEqual(validated["clean_label"], "Non ero sul posto")
            self.assertTrue(ef.queue_feedback_update(update, cfg))
            self.assertTrue(ef.feedback_event_is_queued(cfg, event["event_id"]))
            results = ef.drain_feedback_inbox(state, cfg, token, chat_id, now_ms=2_000_000_100_000)
            self.assertTrue(results[0]["ok"])
            self.assertEqual(event["feedback_status"], "ignored_not_on_site")
            self.assertFalse(ef.feedback_event_is_queued(cfg, event["event_id"]))

    def test_first_feedback_is_terminal_and_cannot_be_overwritten(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            token, chat_id = "safe-token", "42"
            event = sample_event()
            state = {"event_feedback": {"incidents": {event["event_id"]: event}}}
            cfg = {"app": {"data_dir": temp}}
            first = ef.handle_feedback_updates([signed_update(token, chat_id, "not_there")], state, cfg, token, chat_id)
            second = ef.handle_feedback_updates([signed_update(token, chat_id, "damaging_hail", 92)], state, cfg, token, chat_id)
            self.assertFalse(first[0]["duplicate"])
            self.assertTrue(second[0]["duplicate"])
            self.assertEqual(event["feedback"]["option"], "not_there")
            self.assertFalse((Path(temp) / "feedback" / "ground-truth.jsonl").exists())

    def test_listener_builds_persistent_confirmation_and_removes_buttons(self) -> None:
        requests_stub = types.ModuleType("requests")
        previous_requests = sys.modules.get("requests")
        previous_feedback = sys.modules.get("event_feedback")
        sys.modules["requests"] = requests_stub
        sys.modules["event_feedback"] = ef
        try:
            spec = importlib.util.spec_from_file_location("telegram_feedback_listener_test", ENGINE / "telegram_feedback_listener.py")
            listener = importlib.util.module_from_spec(spec)
            assert spec.loader is not None
            spec.loader.exec_module(listener)
        finally:
            if previous_requests is None:
                sys.modules.pop("requests", None)
            else:
                sys.modules["requests"] = previous_requests
            if previous_feedback is None:
                sys.modules.pop("event_feedback", None)
            else:
                sys.modules["event_feedback"] = previous_feedback

        calls: list[tuple[str, dict]] = []
        job = listener.ui_job({
            "callback_id": "cb", "chat_id": "42", "message_id": 777,
            "event_id": "evt243safe01", "clean_label": "Non ero sul posto",
        })
        state = {"pending_ui": [job]}

        def fake_call(_token, method, payload, timeout=(5, 20)):
            calls.append((method, payload))
            return True, {"ok": True}

        with patch.object(listener, "telegram_call", side_effect=fake_call):
            listener.process_ui_jobs("token", state)
        self.assertEqual(state["pending_ui"], [])
        self.assertEqual([method for method, _ in calls], ["answerCallbackQuery", "editMessageReplyMarkup", "sendMessage"])
        self.assertEqual(calls[1][1]["reply_markup"], {"inline_keyboard": []})
        self.assertEqual(calls[2][1]["text"], "✅ Feedback registrato: Non ero sul posto")

    def test_hotfix_installs_and_monitors_dedicated_listener(self) -> None:
        installer = (ROOT / "install.sh").read_text(encoding="utf-8")
        updater = (ROOT / "scripts/ldz-meteo-apply-hotfix").read_text(encoding="utf-8")
        web = (ROOT / "web/app.py").read_text(encoding="utf-8")
        policy = (ROOT / "web/security_utils.py").read_text(encoding="utf-8")
        engine = (ROOT / "engine/meteo_alert.py").read_text(encoding="utf-8")
        listener = (ROOT / "engine/telegram_feedback_listener.py").read_text(encoding="utf-8")
        for source in (installer, updater, web):
            self.assertIn("meteo-alert-telegram-feedback.service", source)
        self.assertIn("engine/telegram_feedback_listener.py", policy)
        self.assertIn('APP_VERSION = "2.5.0"', web)
        self.assertNotIn("/getUpdates", engine)
        self.assertIn("/getUpdates", listener)
        self.assertIn("FEEDBACK_SERVICE_PREEXISTED", updater)
        self.assertIn("disable --now meteo-alert-telegram-feedback.service", updater)


if __name__ == "__main__":
    unittest.main(verbosity=2)
