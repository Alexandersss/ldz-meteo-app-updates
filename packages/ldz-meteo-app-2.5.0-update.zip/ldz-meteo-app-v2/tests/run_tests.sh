#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
export MPLCONFIGDIR="${MPLCONFIGDIR:-/tmp/ldz-matplotlib-test}"
cd "$ROOT"
python3 -m unittest discover -s tests -p 'test_*.py' -v
