from __future__ import annotations

import importlib.util
import tempfile
import unittest
from dataclasses import dataclass, field
from pathlib import Path


ENGINE_READY = all(importlib.util.find_spec(name) for name in ("numpy", "scipy", "pyproj"))


@unittest.skipUnless(ENGINE_READY, "Dipendenze scientifiche motore non installate")
class PrecisionEngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        import sys

        engine = Path(__file__).resolve().parents[1] / "engine"
        sys.path.insert(0, str(engine))
        global np, pe, ve
        import numpy as np_module
        import precision_engine as precision_module
        import verification_engine as verification_module

        np = np_module
        pe = precision_module
        ve = verification_module

    @dataclass
    class Target:
        name: str
        lat: float
        lon: float
        radius_km: float

    @dataclass
    class Cell:
        cell_id: str
        timestamp_ms: int
        lat: float
        lon: float
        area_km2: float = 28.0
        radius_km: float = 3.0
        max_vmi: float = 52.0
        mean_vmi: float = 48.0
        max_sri: float | None = 24.0
        max_poh: float | None = 35.0
        max_vil: float | None = 30.0
        max_etm: float | None = 8200.0
        risk: str = "MEDIUM"
        footprint_xy_km: list[list[float]] = field(default_factory=lambda: [[-3, -2], [3, -2], [3, 2], [-3, 2]])
        shape_eccentricity: float = 0.55
        shape_orientation_deg: float = 90.0
        track_id: str = ""
        track_frames: int = 1
        lifecycle: str = "new"
        core_area_km2: float = 0.0
        core_radius_km: float = 0.0
        core_fraction: float = 0.0
        core_footprint_xy_km: list[list[float]] = field(default_factory=list)

    def config(self, data_dir: str = "/tmp") -> dict:
        return {
            "app": {"data_dir": data_dir},
            "thresholds": {"vmi_strong_dbz": 45},
            "tracking": {
                "max_gap_minutes": 18,
                "max_match_km": 35,
                "prealert_minutes": 20,
                "min_speed_kmh": 2,
                "max_speed_kmh": 130,
                "strong_alert_vmi_dbz": 45,
            },
            "precision_engine": {
                "enabled": True,
                "history_frames": 6,
                "ensemble_members": 96,
                "ensemble_velocity_sigma_kmh": 4,
                "measurement_noise_km": 0.5,
                "verification_enabled": True,
                "verification_grace_minutes": 5,
                "verification_min_probability_percent": 15,
            },
        }

    def test_multiframe_track_identity_and_forecast(self) -> None:
        state: dict = {}
        cfg = self.config()
        target = self.Target("Pescara", 42.46, 14.216, 3.0)
        cells = None
        for index, lon in enumerate((14.02, 14.06, 14.10, 14.14)):
            cells = [self.Cell(f"c{index}", 1_000_000 + index * 300_000, 42.46, lon)]
            pe.update_tracks(cells, state, cfg)
        assert cells is not None
        self.assertEqual(cells[0].track_id, "trk-0000001")
        self.assertEqual(cells[0].track_frames, 4)
        forecasts = pe.build_precision_forecasts(cells, [target], state, cfg, {})
        forecast = forecasts[f"{cells[0].cell_id}|Pescara"]
        self.assertEqual(forecast["model"], "stable-impact-ensemble-2.4.0")
        self.assertGreater(forecast["impact_probability_percent"], 55)
        self.assertIn("survival_probability_percent", forecast)
        self.assertEqual(forecast["adaptive_ai"]["status"], "collection")
        self.assertFalse(forecast["adaptive_ai"]["applied"])
        self.assertLessEqual(forecast["eta_low_minutes"], forecast["eta_high_minutes"])
        self.assertEqual(forecast["direction_cardinal"], "E")

    def test_observed_core_is_high_but_never_artificially_100_percent(self) -> None:
        state: dict = {}
        cfg = self.config()
        target = self.Target("Target", 42.46, 14.216, 3.0)
        cells = None
        for index, lon in enumerate((14.16, 14.19, 14.216)):
            cells = [self.Cell(f"core-{index}", 1_500_000 + index * 300_000, 42.46, lon, max_vmi=60.0)]
            cells[0].core_footprint_xy_km = [[-2, -2], [2, -2], [2, 2], [-2, 2]]
            cells[0].core_area_km2 = 16.0
            cells[0].core_fraction = 0.55
            pe.update_tracks(cells, state, cfg)
        assert cells is not None
        forecast = pe.build_precision_forecasts(cells, [target], state, cfg, {})
        info = forecast[f"{cells[0].cell_id}|Target"]
        self.assertEqual(info["mode"], "observed_core")
        self.assertTrue(info["observed_core_impact"])
        self.assertEqual(info["impact_probability_percent"], 97.0)
        self.assertLess(info["impact_probability_percent"], 100.0)

    def test_crossing_path_beats_perpendicular_path(self) -> None:
        cfg = self.config()
        target = self.Target("Target", 42.46, 14.216, 3.0)

        crossing_state: dict = {}
        perpendicular_state: dict = {}
        crossing = perpendicular = None
        for index in range(4):
            crossing = [self.Cell(f"e{index}", 2_000_000 + index * 300_000, 42.46, 14.02 + 0.04 * index)]
            perpendicular = [self.Cell(f"n{index}", 2_000_000 + index * 300_000, 42.20 + 0.03 * index, 14.14)]
            pe.update_tracks(crossing, crossing_state, cfg)
            pe.update_tracks(perpendicular, perpendicular_state, cfg)
        cross = pe.build_precision_forecasts(crossing, [target], crossing_state, cfg, {})
        north = pe.build_precision_forecasts(perpendicular, [target], perpendicular_state, cfg, {})
        cross_probability = next(iter(cross.values()))["impact_probability_percent"]
        north_probability = next(iter(north.values()))["impact_probability_percent"]
        self.assertGreater(cross_probability, north_probability + 25)

    def test_phase_correlation_recovers_translation(self) -> None:
        previous = np.zeros((80, 80), dtype="float32")
        previous[22:34, 25:39] = 45
        current = np.zeros_like(previous)
        current[26:38, 31:45] = 45
        row, col, quality = pe._phase_correlation_shift(previous, current)
        self.assertAlmostEqual(row, 4.0, delta=0.5)
        self.assertAlmostEqual(col, 6.0, delta=0.5)
        self.assertGreater(quality, 0.5)

    def test_duplicate_radar_frame_does_not_create_fake_track(self) -> None:
        state: dict = {}
        cfg = self.config()
        first = [self.Cell("same-a", 5_000_000, 42.46, 14.10)]
        pe.update_tracks(first, state, cfg)
        second = [self.Cell("same-b", 5_000_000, 42.46, 14.10)]
        pe.update_tracks(second, state, cfg)
        self.assertEqual(first[0].track_id, second[0].track_id)
        self.assertEqual(second[0].track_frames, 1)

    def test_complete_verification_counts_missed_event_without_forecast(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            cfg = self.config(temp)
            cfg["verification_engine"] = {"enabled": True, "episode_open_hits": 2, "minimum_slots": 4}
            target = self.Target("Pescara", 42.46, 14.216, 3.0)
            state: dict = {}
            cell = self.Cell("storm", 10_000_000, 42.46, 14.216)
            ve.update_complete_verification(state, [target], [cell], {}, 10_000_000, cfg)
            result = ve.update_complete_verification(state, [target], [cell], {}, 10_300_000, cfg)
            self.assertEqual(result["overall"]["events"]["fn"], 1)
            self.assertEqual(result["overall"]["slots"]["fn"], 2)

    def test_complete_verification_matches_early_forecast_to_event(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            cfg = self.config(temp)
            cfg["tracking"]["min_alert_probability_percent"] = 60
            cfg["verification_engine"] = {"enabled": True, "episode_open_hits": 2, "event_match_minutes": 20}
            target = self.Target("Pescara", 42.46, 14.216, 3.0)
            forecast = {"cell|Pescara": {"impact_probability_percent": 82, "eta_minutes": 10, "track_id": "trk-1"}}
            state: dict = {}
            ve.update_complete_verification(state, [target], [], forecast, 20_000_000, cfg)
            cell = self.Cell("storm", 20_300_000, 42.46, 14.216)
            ve.update_complete_verification(state, [target], [cell], {}, 20_300_000, cfg)
            result = ve.update_complete_verification(state, [target], [cell], {}, 20_600_000, cfg)
            self.assertEqual(result["overall"]["events"]["tp"], 1)
            self.assertEqual(result["overall"]["events"]["fn"], 0)

    def test_lifecycle_distinguishes_growth_from_decay(self) -> None:
        import terrain_lifecycle as tl

        base = 10_000_000
        growing = [
            {"timestamp_ms": base + index * 300_000, "max_vmi": 42 + index * 3, "area_km2": 15 + index * 5, "max_vil": 20 + index * 3, "max_etm": 6500 + index * 600, "max_poh": 20}
            for index in range(4)
        ]
        decaying = [
            {"timestamp_ms": base + index * 300_000, "max_vmi": 56 - index * 5, "area_km2": 35 - index * 7, "max_vil": 35 - index * 6, "max_etm": 9500 - index * 1000, "max_poh": 20}
            for index in range(4)
        ]
        cfg = {"lifecycle_engine": {"enabled": True}, "terrain_engine": {"max_survival_adjustment": 0.12}}
        growth = tl.assess_lifecycle(growing, {"jump_score": 70, "jump_detected": True}, {"cape_jkg": 2200}, {"barrier_m": 200}, cfg)
        decay = tl.assess_lifecycle(decaying, {"jump_score": 0}, {"cape_jkg": 600}, {"barrier_m": 900}, cfg)
        self.assertEqual(growth["state"], "intensificazione")
        self.assertEqual(decay["state"], "indebolimento")
        self.assertGreater(growth["survival_probability_percent"], decay["survival_probability_percent"] + 20)

    def test_adaptive_ai_cannot_influence_forecast_during_collection(self) -> None:
        import adaptive_ai as ai

        state: dict = {}
        cfg = {"adaptive_ai": {"enabled": True, "auto_activate": True, "activation_min_events": 80}}
        features = [0.5] * len(ai.FEATURE_NAMES)
        result = ai.apply_shadow_or_guarded(73.0, features, state, cfg)
        self.assertEqual(result["status"], "collection")
        self.assertFalse(result["applied"])
        self.assertEqual(result["blended_probability_percent"], 73.0)
        self.assertNotIn("pickle", str(state).lower())
        self.assertEqual(state["precision"]["adaptive_ai"]["model"]["updates"], 0)

    def test_new_batch_candidate_is_forced_back_to_shadow(self) -> None:
        import json
        import adaptive_ai as ai

        with tempfile.TemporaryDirectory() as temp:
            candidate = Path(temp) / "candidate.json"
            candidate.write_text(json.dumps({
                "ready": True,
                "schema": 1,
                "feature_names": list(ai.FEATURE_NAMES),
                "weights": [0.1] * len(ai.FEATURE_NAMES),
                "bias": -0.2,
                "generated_utc": "2026-07-19T10:00:00+00:00",
            }), encoding="utf-8")
            state = {"precision": {"adaptive_ai": {
                "status": "active_guarded", "influence": 0.2,
                "model": {"weights": [0.0] * len(ai.FEATURE_NAMES), "bias": 0.0, "updates": 120},
            }}}
            cfg = {"app": {"data_dir": temp}, "adaptive_ai": {"candidate_model_file": str(candidate)}}
            result = ai.load_batch_candidate(state, cfg)
            self.assertTrue(result["loaded"])
            ai_state = state["precision"]["adaptive_ai"]
            self.assertEqual(ai_state["status"], "shadow")
            self.assertEqual(ai_state["influence"], 0.0)
            self.assertEqual(ai_state["candidate_loaded_at_update"], 120)

    def test_icon2i_is_a_weak_prior_not_a_radar_replacement(self) -> None:
        state: dict = {}
        cfg = self.config()
        target = self.Target("Target", 42.46, 14.30, 3.0)
        cells = None
        for index, lon in enumerate((14.02, 14.06, 14.10, 14.14)):
            cells = [self.Cell(f"p{index}", 7_000_000 + index * 300_000, 42.46, lon)]
            pe.update_tracks(cells, state, cfg)
        context = {
            "available": True,
            "source": "ItaliaMeteo-ARPAE ICON-2I via Open-Meteo",
            "steering_east_kmh": 0.0,
            "steering_north_kmh": 20.0,
            "cape_jkg": 1400,
        }
        forecasts = pe.build_precision_forecasts(cells, [target], state, cfg, {}, context)
        forecast = next(iter(forecasts.values()))
        self.assertGreater(forecast["nwp_weight"], 0)
        self.assertLessEqual(forecast["nwp_weight"], 0.10)
        self.assertIn(forecast["direction_cardinal"], ("E", "NE"))

    def test_verification_resolves_miss_and_brier_score(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            cfg = self.config(temp)
            target = self.Target("Target", 42.46, 14.216, 3.0)
            state = {
                "precision": {
                    "pending_forecasts": [{
                        "target": "Target", "track_id": "trk-1", "cell_id": "c1",
                        "created_ms": 1_000_000, "due_ms": 1_300_000,
                        "probability_percent": 80.0, "eta_minutes": 5,
                    }]
                }
            }
            pe.update_verification(state, [], [target], {}, 1_600_000, cfg)
            stats = state["precision"]["calibration"]["targets"]["Target"]
            self.assertEqual(stats["resolved"], 1)
            self.assertEqual(stats["hits"], 0)
            self.assertAlmostEqual(stats["brier_score"], 0.64, places=4)
            self.assertTrue((Path(temp) / "precision" / "forecast-verification.jsonl").is_file())


if __name__ == "__main__":
    unittest.main(verbosity=2)
