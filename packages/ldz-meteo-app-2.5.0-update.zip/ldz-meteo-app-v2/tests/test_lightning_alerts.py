from __future__ import annotations

import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

from tests.test_alert_messages import load_message_module


class LightningAlertTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.ma = load_message_module()

    def cfg(self, log_dir: str) -> dict:
        return {
            "app": {"log_dir": log_dir, "max_frame_age_minutes": 30},
            "lightning": {
                "enabled": True,
                "source": "radar_dpc_lgt",
                "radius_km": 20,
                "window_minutes": 15,
                "notify_on_lightning": True,
                "notify_lightning_clear": True,
                "alert_min_strikes": 2,
                "alert_high_count": 8,
                "alert_urgent_radius_km": 8,
                "alert_cooldown_minutes": 20,
                "alert_escalation_delta": 5,
                "alert_clear_windows": 2,
            },
            "tracking": {"expired_eta_grace_minutes": 2},
            "quiet_hours": {"enabled": False},
        }

    def target(self):
        return self.ma.Target("Pescara", 42.46, 14.21, 3.0)

    def strikes(self, timestamp_ms: int):
        return [
            self.ma.LightningStrike(42.47, 14.20, timestamp_ms),
            self.ma.LightningStrike(42.50, 14.23, timestamp_ms),
            self.ma.LightningStrike(42.80, 14.60, timestamp_ms),
        ]

    def test_dedicated_lightning_alert_is_sent_once_per_slot(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            cfg = self.cfg(temp)
            state: dict = {}
            timestamp_ms = 2_000_000_000_000
            meta = {
                "available": True,
                "fresh": True,
                "latest_timestamp_ms": timestamp_ms,
                "window_minutes": 15,
            }
            with patch.object(self.ma, "send_telegram", return_value=True) as send:
                first = self.ma.evaluate_lightning_alerts(
                    self.strikes(timestamp_ms), meta, state, [self.target()], cfg, dry_run=False,
                )
                second = self.ma.evaluate_lightning_alerts(
                    self.strikes(timestamp_ms), meta, state, [self.target()], cfg, dry_run=False,
                )
            self.assertEqual(len(first), 1)
            self.assertEqual(second, [])
            self.assertEqual(send.call_count, 1)
            message = send.call_args.args[0]
            self.assertIn("FULMINI VICINO ALLA ZONA", message)
            self.assertIn("Cosa significa", message)
            self.assertIn("Indicazioni pratiche", message)
            self.assertTrue((Path(temp) / "alerts.log").is_file())

    def test_lgt_uses_ten_minute_cadence_and_real_publish_age(self) -> None:
        class Response:
            def __init__(self, status_code: int, content: bytes = b""):
                self.status_code = status_code
                self.content = content

            def raise_for_status(self):
                if self.status_code >= 400:
                    raise RuntimeError(self.status_code)

        class Session:
            def __init__(self, available: set[int]):
                self.available = available

            def get(self, url, **_kwargs):
                timestamp = int(url.rsplit("_", 1)[1].split(".", 1)[0])
                return Response(200, bytes([2, 0, 0])) if timestamp in self.available else Response(404)

        with tempfile.TemporaryDirectory() as temp:
            grid = 2_000_000_000_000 // 300_000 * 300_000
            now_ms = grid + 3 * 60_000
            latest = grid - 10 * 60_000
            cfg = self.cfg(temp)
            cfg["app"]["data_dir"] = temp
            cfg["radar"] = {"request_timeout_seconds": 2, "user_agent": "test", "referer": "https://radar.protezionecivile.it/"}
            cfg["lightning"].update({
                "window_minutes": 20, "official_cadence_minutes": 10,
                "dpc_lgt_max_age_minutes": 15, "dpc_lgt_max_lookback_minutes": 30,
            })
            fixed_now = datetime.fromtimestamp(now_ms / 1000, tz=timezone.utc)
            with (
                patch.object(self.ma, "utc_now", return_value=fixed_now),
                patch.object(self.ma, "validate_outbound_url", return_value="ok"),
            ):
                _strikes, meta = self.ma.fetch_dpc_lgt_window(
                    Session({latest, latest - 10 * 60_000}), grid, cfg,
                )
            self.assertEqual(meta["timestamps"], [latest, latest - 10 * 60_000])
            self.assertEqual(meta["official_cadence_minutes"], 10)
            self.assertAlmostEqual(meta["age_minutes"], 13.0)
            self.assertTrue(meta["fresh"])
            cfg["lightning"]["dpc_lgt_max_age_minutes"] = 10
            with (
                patch.object(self.ma, "utc_now", return_value=fixed_now),
                patch.object(self.ma, "validate_outbound_url", return_value="ok"),
            ):
                _strikes, stale = self.ma.fetch_dpc_lgt_window(Session(set()), grid, cfg)
            self.assertFalse(stale["fresh"])
            self.assertTrue(stale["stale"])

    def test_lightning_alert_is_not_duplicated_when_weather_alert_already_covers_target(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            cfg = self.cfg(temp)
            state: dict = {}
            timestamp_ms = 2_000_000_000_000
            meta = {"available": True, "fresh": True, "latest_timestamp_ms": timestamp_ms, "window_minutes": 15}
            with patch.object(self.ma, "send_telegram", return_value=True) as send:
                result = self.ma.evaluate_lightning_alerts(
                    self.strikes(timestamp_ms),
                    meta,
                    state,
                    [self.target()],
                    cfg,
                    dry_run=False,
                    covered_targets={"Pescara"},
                )
            self.assertEqual(result, [])
            send.assert_not_called()
            self.assertTrue(state["lightning_alerts"]["Pescara"]["active"])
            self.assertFalse(state["lightning_alerts"]["Pescara"].get("notified", False))

            clear_meta = {**meta, "latest_timestamp_ms": timestamp_ms + 5 * 60_000}
            clear_meta_2 = {**meta, "latest_timestamp_ms": timestamp_ms + 10 * 60_000}
            with patch.object(self.ma, "send_telegram", return_value=True) as clear_send:
                self.ma.evaluate_lightning_alerts([], clear_meta, state, [self.target()], cfg, dry_run=False)
                cleared = self.ma.evaluate_lightning_alerts([], clear_meta_2, state, [self.target()], cfg, dry_run=False)
            self.assertEqual(cleared, [])
            clear_send.assert_not_called()

    def test_eta_is_reduced_by_real_frame_age_and_expired_window_is_flagged(self) -> None:
        now_ms = 2_000_000_000_000
        frame_ms = now_ms - 7 * 60_000
        cfg = self.cfg("/tmp")
        info = self.ma.adjust_eta_for_data_age(
            {"eta_minutes": 10.0, "eta_low_minutes": 8.0, "eta_high_minutes": 14.0},
            frame_ms,
            cfg,
            now_ms=now_ms,
        )
        self.assertAlmostEqual(info["eta_minutes"], 3.0)
        self.assertAlmostEqual(info["eta_low_minutes"], 1.0)
        self.assertAlmostEqual(info["eta_high_minutes"], 7.0)
        self.assertFalse(info["eta_window_expired"])

        expired = self.ma.adjust_eta_for_data_age(
            {"eta_minutes": 2.0, "eta_low_minutes": 1.0, "eta_high_minutes": 2.0},
            frame_ms,
            cfg,
            now_ms=now_ms,
        )
        self.assertTrue(expired["eta_window_expired"])

    def test_uniform_weather_copy_removes_ambiguous_labels(self) -> None:
        cell = self.ma.Cell(
            cell_id="cell", timestamp_ms=int(datetime.now(timezone.utc).timestamp() * 1000),
            lat=42.47, lon=14.10, area_km2=80.0, radius_km=5.0, pixels=120,
            max_vmi=50.5, mean_vmi=45.0, max_sri=33.3, max_poh=0.0,
            max_vil=13.0, max_etm=7100.0, risk="HIGH", risk_reasons=[],
            nearest_target="Pescara", nearest_distance_km=12.0,
            footprint_xy_km=[], pixel_bbox=[0, 0, 10, 10], centroid_row=5.0,
            centroid_col=5.0, shape_eccentricity=0.4, shape_orientation_deg=90.0,
            track_id="track", track_frames=2, lifecycle="stable",
        )
        eta = {
            "eta_minutes": 3.0,
            "eta_low_minutes": 1.0,
            "eta_high_minutes": 5.0,
            "impact_probability_percent": 77.0,
            "impact_confidence_percent": 60.0,
            "motion_confidence_percent": 55.0,
            "speed_kmh": 36.0,
            "direction_cardinal": "SE",
            "multisignal": {
                "trajectory_probability_percent": 77.0,
                "hail_probability_percent": 8.0,
                "hail_confidence_percent": 8.0,
                "hail_data_quality_percent": 90.0,
                "severe_hail_potential_percent": 4.0,
                "hail_persistence_frames": 1,
                "hail_level": "BASSO",
            },
        }
        cfg = {
            "thresholds": {
                "poh_medium_percent": 40,
                "poh_high_percent": 60,
                "vil_hail_threshold": 35,
            }
        }
        message = self.ma.build_alert_message(self.target(), cell, eta, cfg)
        self.assertIn("TEMPORALE CON PIOGGIA INTENSA", message)
        self.assertIn("Cosa sta rilevando il sistema", message)
        self.assertIn("segnale debole visto in una sola scansione", message)
        self.assertIn("Stabilità previsione", message)
        self.assertNotIn("Perché ricevi questo avviso", message)
        self.assertNotIn("da confermare", message)
        self.assertNotIn("Affidabilità della stima", message)
        self.assertLessEqual(len(message), 1024)

    def test_clear_message_uses_the_alert_really_sent_and_classifies_the_outcome(self) -> None:
        previous = {
            "notified_probability_percent": 72.0,
            "notified_eta_minutes": 10.0,
            "last_probability_percent": 18.0,
            "last_eta_minutes": 25.0,
            "ever_observed_core": False,
            "ever_fringe_inside": False,
        }
        deviated = self.ma.build_clear_message(
            self.target(),
            previous,
            {},
            {"distance_km": 16.3, "probability": 1.0},
        )
        self.assertIn("TRAIETTORIA DEVIATA", deviated)
        self.assertIn("72% · arrivo 10 min", deviated)
        self.assertNotIn("18% · arrivo 25 min", deviated)

        marginal = self.ma.build_clear_message(
            self.target(),
            {**previous, "ever_fringe_inside": True},
            {},
        )
        self.assertIn("PASSAGGIO MARGINALE CONCLUSO", marginal)

        passed = self.ma.build_clear_message(
            self.target(),
            {**previous, "ever_observed_core": True},
            {},
        )
        self.assertIn("FENOMENO TRANSITATO", passed)


if __name__ == "__main__":
    unittest.main(verbosity=2)
