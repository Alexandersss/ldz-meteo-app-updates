from __future__ import annotations

import base64
import re
import unittest
from io import BytesIO
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
TEMPLATE = ROOT / "web/templates/login.html"
CSS = ROOT / "web/static/login-hud.css"
JS = ROOT / "web/static/login-hud.js"
APP = ROOT / "web/app.py"
ORBIT = ROOT / "web/static/login-orbit.svg"


class MasterDesignLoginTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.template = TEMPLATE.read_text(encoding="utf-8")
        cls.css = CSS.read_text(encoding="utf-8")
        cls.js = JS.read_text(encoding="utf-8")
        cls.app = APP.read_text(encoding="utf-8")

    def test_login_keeps_security_and_auth_contract(self) -> None:
        for token in (
            "{{ csrf_field()|safe }}",
            'name="username"',
            'name="password"',
            'name="remember_me"',
            'autocomplete="username"',
            'autocomplete="current-password"',
        ):
            self.assertIn(token, self.template)
        for token in (
            "login_is_limited(rate_key)",
            "check_password_hash(password_hash, password)",
            "make_remember_token(username)",
            "validate_csrf_token()",
            "origin_is_allowed()",
            "session.clear()",
        ):
            self.assertIn(token, self.app)

    def test_master_composition_and_copy_are_locked(self) -> None:
        for token in (
            'class="login-left-column"',
            'class="login-radar-zone"',
            'class="login-radar-panel"',
            'class="login-radar-side"',
            'class="login-auth-panel"',
            'class="login-status-strip"',
            'class="login-feature-grid"',
            "Il tuo centro<br>meteo <span>privato.</span>",
            "RADAR LIVE",
            "TARGET SMART",
            "ALERT TELEGRAM",
            "FULMINI &amp; GRANDINE",
            "ACCESSO AMMINISTRATORE",
        ):
            self.assertIn(token.upper(), self.template.upper())
        self.assertIn("grid-template-columns: 35.3% 36% 28.7%", self.css)
        self.assertIn("aspect-ratio: 16 / 9", self.css)

    def test_master_image_is_not_used_as_background(self) -> None:
        combined = (self.template + self.css).lower()
        for forbidden in ("ok.png", "concept.png", "mockup", "screenshot", "approved-login"):
            self.assertNotIn(forbidden, combined)
        self.assertIn('url("login-orbit.svg")', self.css)

    def test_orbital_asset_is_local_bounded_and_usable(self) -> None:
        self.assertTrue(ORBIT.is_file())
        self.assertGreater(ORBIT.stat().st_size, 20_000)
        self.assertLess(ORBIT.stat().st_size, 100_000)
        source = ORBIT.read_text(encoding="utf-8")
        self.assertIn("<svg", source)
        encoded = re.search(r"data:image/webp;base64,([^\"]+)", source)
        self.assertIsNotNone(encoded)
        with Image.open(BytesIO(base64.b64decode(encoded.group(1)))) as image:
            self.assertGreaterEqual(image.width, 1400)
            self.assertGreaterEqual(image.height, 780)
            self.assertAlmostEqual(image.width / image.height, 16 / 9, delta=0.03)

    def test_radar_is_scenic_and_operationally_isolated(self) -> None:
        for token in (
            'class="scenic-radar"',
            'class="radar-geography"',
            'class="storm-system"',
            'class="radar-rings-svg"',
            'class="radar-sweep-svg"',
            "RIFLETTIVITÀ",
            "000°",
            "090°",
            "180°",
            "270°",
        ):
            self.assertIn(token, self.template)
        combined = self.template + self.js
        for forbidden in (
            "/meteo-map.jpg",
            "/meteo.jpg",
            "/radar-image",
            "/targets",
            "/diagnostics",
            "data-primary-src",
            "data-fallback-src",
            "fetch(",
            "XMLHttpRequest",
        ):
            self.assertNotIn(forbidden, combined)

    def test_public_scene_does_not_expose_real_counts_or_names(self) -> None:
        lowered = self.template.lower()
        for place in ("pescara", "pescasseroli", "san vito chietino", "sambuceto", "san giovanni teatino"):
            self.assertNotIn(place, lowered)
        self.assertNotRegex(self.template.upper(), r">\s*[1-9][0-9]*\s+(?:TARGET|CELLE)\s+ATTIV")

    def test_browser_autofill_stays_dark(self) -> None:
        for token in (
            "input:-webkit-autofill",
            "input:-moz-autofill",
            "-webkit-text-fill-color:#f3fbff !important",
            "0 0 0 1000px #03111b inset",
            "input:autofill",
        ):
            self.assertIn(token, self.css)

    def test_motion_and_reduced_motion_are_both_supported(self) -> None:
        for token in (
            "radar-sweep-spin",
            "storm-pulse",
            "meter-jump",
            "wave-run",
            "status-flicker",
            "prefers-reduced-motion: reduce",
        ):
            self.assertIn(token, self.css)

    def test_assets_are_local_and_csp_friendly(self) -> None:
        self.assertIn("login-hud.css", self.template)
        self.assertIn("login-hud.js", self.template)
        self.assertNotIn("fonts.googleapis.com", self.template)
        self.assertNotIn("cdnjs", self.template)
        self.assertNotIn("unpkg.com", self.template)
        self.assertNotIn("https://", self.css)
        self.assertNotIn("@import", self.css)
        self.assertNotRegex(self.template, r"<script(?![^>]*\bsrc=)[^>]*>")

    def test_mobile_puts_authentication_first(self) -> None:
        for token in (
            "@media (max-aspect-ratio: 4/3), (max-width: 900px)",
            ".login-auth-panel { order:1",
            ".login-left-column { order:2",
            ".login-radar-zone { order:3",
            "@media (max-width: 520px)",
            "min-height:calc(100vh - 58px)",
        ):
            self.assertIn(token, self.css)
        for token in (
            'class="mobile-auth-brand"',
            'aria-label="Accesso LDZ Meteo App"',
            'aria-live="polite"',
            'for="loginUsername"',
            'for="loginPassword"',
            'aria-pressed="false"',
        ):
            self.assertIn(token, self.template)

    def test_password_visibility_is_functional_without_unsafe_dom_writes(self) -> None:
        self.assertIn("passwordInput.type = show ? 'text' : 'password'", self.js)
        self.assertIn("aria-pressed", self.js)
        self.assertNotIn("innerHTML", self.js)
        self.assertNotIn("document.write", self.js)


if __name__ == "__main__":
    unittest.main(verbosity=2)
