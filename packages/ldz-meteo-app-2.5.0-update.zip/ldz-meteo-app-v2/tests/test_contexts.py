from __future__ import annotations

import importlib.util
import json
import os
import sys
import tempfile
import unittest
from datetime import timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


CONTEXT_READY = all(importlib.util.find_spec(name) for name in ("requests", "rasterio", "matplotlib", "pyproj", "scipy"))
os.environ.setdefault("MPLCONFIGDIR", "/tmp/ldz-meteo-test-matplotlib")


@unittest.skipUnless(CONTEXT_READY, "Dipendenze complete engine non installate")
class ContextIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        engine = Path(__file__).resolve().parents[1] / "engine"
        sys.path.insert(0, str(engine))
        global ma
        import meteo_alert as module
        ma = module

    class Response:
        def __init__(self, payload: dict) -> None:
            self._payload = payload
            self.content = json.dumps(payload).encode()

        def raise_for_status(self) -> None:
            return None

        def json(self) -> dict:
            return self._payload

    def test_detected_cell_builds_cappi_vertical_profile(self) -> None:
        import numpy as np
        from rasterio.crs import CRS
        from rasterio.transform import from_origin

        vmi = np.full((12, 12), np.nan, dtype="float32")
        vmi[3:9, 3:9] = 56.0
        products = {"VMI": vmi}
        for level in range(1, 11):
            layer = np.full((12, 12), np.nan, dtype="float32")
            layer[3:9, 3:9] = 52.0 if level <= 7 else 32.0
            products[f"CAPPI_{level}"] = layer
        cfg = {
            "thresholds": {
                "vmi_strong_dbz": 45,
                "vmi_core_dbz": 55,
                "vmi_hail_dbz": 55,
                "poh_medium_percent": 40,
                "poh_high_percent": 60,
                "vil_hail_threshold": 35,
                "etm_hail_threshold_m": 9000,
            },
            "tracking": {"min_component_pixels": 8, "max_search_km": 110},
            "precision_engine": {"max_footprint_vertices": 48},
            "vertical_profile": {
                "enabled": True,
                "products": [f"CAPPI_{level}" for level in range(1, 11)],
                "cell_percentile": 95,
            },
        }
        ref = {
            "array": vmi,
            "transform": from_origin(14.0, 43.0, 0.01, 0.01),
            "crs": CRS.from_epsg(4326),
            "width": 12,
            "height": 12,
            "bounds": (14.0, 42.88, 14.12, 43.0),
            "cappi_timestamp_ms": 2_000_000_000,
        }
        cells = ma.detect_cells(
            ref,
            products,
            2_000_000_000,
            [ma.Target("Test", 42.94, 14.06, 3.0)],
            cfg,
        )
        self.assertEqual(len(cells), 1)
        self.assertEqual(cells[0].cappi_available_levels, 10)
        self.assertEqual(cells[0].cappi_highest_45_km, 7.0)
        self.assertEqual(cells[0].cappi_highest_50_km, 7.0)
        self.assertIsNone(cells[0].cappi_highest_55_km)
        self.assertEqual(cells[0].cappi_quality_percent, 100.0)

    def test_multi_model_context_uses_consensus_and_reports_spread(self) -> None:
        now = ma.utc_now().astimezone(timezone.utc).replace(minute=0, second=0, microsecond=0)
        directions = iter((240.0, 260.0, 280.0))

        class Session:
            def get(self, *args, **kwargs):
                direction = next(directions)
                payload = {"hourly": {
                    "time": [now.isoformat()],
                    "wind_speed_700hPa": [45.0], "wind_direction_700hPa": [direction],
                    "wind_speed_500hPa": [65.0], "wind_direction_500hPa": [direction + 5.0],
                    "cape": [1800.0], "convective_inhibition": [-25.0], "freezing_level_height": [3900.0],
                }}
                return ContextIntegrationTests.Response(payload)

        with tempfile.TemporaryDirectory() as temp, patch.object(ma, "validate_outbound_url", return_value=None):
            cfg = {"app": {"data_dir": temp}, "atmospheric_context": {
                "enabled": True,
                "models": ["italia_meteo_arpae_icon_2i", "icon_seamless", "ecmwf_ifs025"],
                "api_url": "https://api.open-meteo.com/v1/forecast",
            }}
            context = ma.fetch_atmospheric_context(Session(), [ma.Target("Pescara", 42.46, 14.21, 3.0)], cfg)
            self.assertTrue(context["available"])
            self.assertEqual(len(context["models_available"]), 3)
            self.assertGreater(context["steering_spread_kmh"], 0.0)
            self.assertLessEqual(context["consensus_quality_percent"], 100.0)

    def test_national_context_assigns_distant_targets_to_local_clusters(self) -> None:
        targets = [
            ma.Target("Pescara", 42.46, 14.21, 3.0),
            ma.Target("Roma", 41.90, 12.50, 3.0),
            ma.Target("Milano", 45.46, 9.19, 3.0),
            ma.Target("Palermo", 38.12, 13.36, 3.0),
        ]

        def fake_context(_session, cluster, _cfg, cache_key="italy"):
            return {
                "available": True, "models_available": ["icon_seamless", "gfs_seamless"],
                "steering_spread_kmh": 8.0, "consensus_quality_percent": 90.0,
                "cape_jkg": 900.0, "cache_key": cache_key,
            }

        cfg = {"atmospheric_context": {"enabled": True, "cluster_radius_km": 180, "max_clusters": 8}}
        with patch.object(ma, "fetch_atmospheric_context", side_effect=fake_context):
            result = ma.fetch_national_atmospheric_context(SimpleNamespace(), targets, cfg)
        self.assertTrue(result["available"])
        self.assertGreaterEqual(result["cluster_count"], 3)
        self.assertEqual(set(result["by_target"]), {target.name for target in targets})
        self.assertNotEqual(result["by_target"]["Milano"]["cluster_id"], result["by_target"]["Palermo"]["cluster_id"])

    def test_terrain_profile_is_bounded_and_cached(self) -> None:
        class Session:
            def get(self, url, params, **kwargs):
                count = len(params["latitude"].split(","))
                return ContextIntegrationTests.Response({"elevation": [100.0 + 40.0 * (index % 4) for index in range(count)]})

        with tempfile.TemporaryDirectory() as temp, patch.object(ma, "validate_outbound_url", return_value=None):
            cfg = {"app": {"data_dir": temp}, "terrain_engine": {"enabled": True, "profile_samples": 7}}
            cell = SimpleNamespace(cell_id="cell-1", lat=42.30, lon=13.90)
            target = ma.Target("Target", 42.46, 14.21, 3.0)
            profiles = ma.fetch_terrain_profiles(Session(), [cell], [target], cfg)
            self.assertTrue(profiles["cell-1|Target"]["available"])
            self.assertEqual(profiles["cell-1|Target"]["samples"], 7)
            self.assertTrue((Path(temp) / "terrain/elevation-cache.json").is_file())

    def test_invalid_sensor_row_does_not_discard_valid_target_row(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            snapshot = Path(temp) / "sensors.json"
            snapshot.write_text(json.dumps([
                {"target": "Pescara", "observed_ms": "not-a-number", "rain_rate_mmh": 999},
                {"target": "Pescara", "rain_rate_mmh": 12, "wind_gust_kmh": 55, "pressure_tendency_hpa_h": -2},
            ]), encoding="utf-8")
            cfg = {"app": {"data_dir": temp}, "local_sensors": {"enabled": True, "snapshot_file": str(snapshot)}}
            context = ma.fetch_local_sensor_context(SimpleNamespace(), [ma.Target("Pescara", 42.46, 14.21, 3.0)], cfg)
            self.assertIn("Pescara", context)
            self.assertGreater(context["Pescara"]["confirmation_score"], 0.0)
            self.assertLessEqual(context["Pescara"]["rain_rate_mmh"], 500.0)

    def test_lightning_jump_ignores_strikes_outside_recent_window(self) -> None:
        timestamp = 2_000_000_000_000
        strikes = [
            ma.LightningStrike(42.46, 14.21, timestamp - 10 * 60000),
            ma.LightningStrike(42.46, 14.21, timestamp - 40 * 60000),
        ]
        cell = SimpleNamespace(cell_id="cell-1", track_id="track-1", lat=42.46, lon=14.21)
        cfg = {"lifecycle_engine": {"lightning_cell_radius_km": 30, "lightning_jump_window_minutes": 15}}
        context = ma.lightning_context_by_cell(strikes, [cell], {}, timestamp, cfg)
        self.assertEqual(context["cell-1"]["count"], 1)
        self.assertEqual(context["cell-1"]["window_minutes"], 15)

    def test_alert_caption_is_human_readable_and_telegram_safe(self) -> None:
        cell = ma.Cell(
            cell_id="cell-human", timestamp_ms=2_000_000_000_000,
            lat=42.47, lon=13.31, area_km2=80.0, radius_km=5.0, pixels=120,
            max_vmi=48.5, mean_vmi=42.0, max_sri=23.3, max_poh=0.0,
            max_vil=18.0, max_etm=10940.0, risk="HIGH", risk_reasons=[],
            nearest_target="Capitignano", nearest_distance_km=15.0,
            footprint_xy_km=[], pixel_bbox=[0, 0, 10, 10], centroid_row=5.0,
            centroid_col=5.0, shape_eccentricity=0.4, shape_orientation_deg=60.0,
            track_id="track-human", track_frames=6, lifecycle="stable",
        )
        eta = {
            "eta_minutes": 10.0, "eta_low_minutes": 9.0, "eta_high_minutes": 12.0,
            "impact_probability_percent": 85.0, "impact_confidence_percent": 78.0,
            "motion_confidence_percent": 97.0, "speed_kmh": 86.0,
            "direction_cardinal": "NE", "model": "precision-ensemble-2.3",
            "lightning_source": "radar_dpc_lgt", "lightning_count": 3,
            "lightning_radius_km": 20.0, "lightning_nearest_km": 8.4,
            "multisignal": {
                "trajectory_probability_percent": 85.0,
                "hail_confidence_percent": 11.0,
                "hail_factors": ["POH probabilità grandine 0%"],
            },
        }
        cfg = {"thresholds": {
            "poh_medium_percent": 40, "poh_high_percent": 60,
            "vil_hail_threshold": 35, "etm_hail_threshold_m": 9000,
        }}
        message = ma.build_alert_message(ma.Target("Capitignano", 42.52, 13.30, 3.0), cell, eta, cfg)
        for expected in (
            "TEMPORALE CON PIOGGIA INTENSA IN ARRIVO", "Arrivo stimato",
            "Possibilità che raggiunga la zona", "Indicazioni pratiche",
            "Cosa sta rilevando il sistema", "Nucleo", "Grandine",
            "Movimento", "Stabilità previsione",
        ):
            self.assertIn(expected, message)
        self.assertNotIn("Perché ricevi questo avviso", message)
        self.assertNotIn("Affidabilità della stima", message)
        self.assertNotIn("Ensemble traiettorie", message)
        self.assertNotIn("Precision Engine", message)
        self.assertNotIn("senza panico", message)
        self.assertLessEqual(len(message), 1000)
        self.assertEqual(message.count("<b>"), message.count("</b>"))
        self.assertEqual(message.count("<i>"), message.count("</i>"))

    def test_threat_updates_report_change_without_engine_jargon(self) -> None:
        cell = SimpleNamespace(max_vmi=52.0, track_frames=8)
        eta = {
            "impact_probability_percent": 84.0, "impact_confidence_percent": 76.0,
            "eta_minutes": 7.0, "eta_low_minutes": 6.0, "eta_high_minutes": 9.0,
        }
        message = ma.build_threat_update_message(
            ma.Target("Pescara", 42.46, 14.21, 3.0),
            {"last_probability_percent": 64.0}, cell, eta, "escalation",
        )
        self.assertIn("RISCHIO AUMENTATO", message)
        self.assertIn("64% → 84%", message)
        self.assertNotIn("track", message.lower())
        self.assertNotIn("VMI", message)

    def test_public_radar_panel_renders_with_adaptive_ai_row(self) -> None:
        import numpy as np
        from rasterio.transform import from_bounds

        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "meteo.jpg"
            vmi = np.zeros((80, 80), dtype="float32")
            vmi[30:44, 35:52] = 52.0
            ref = {
                "array": vmi,
                "transform": from_bounds(13.7, 42.0, 14.7, 42.8, 80, 80),
                "crs": "EPSG:4326", "width": 80, "height": 80,
                "timestamp_ms": 2_000_000_000_000,
            }
            cfg = {
                "app": {"data_dir": temp},
                "public_image": {"enabled": True, "output_file": str(output), "width_px": 1280, "height_px": 720, "zoom_padding_deg": 0.25},
                "basemap": {"enabled": False},
                "publish": {"method": "local", "local_path": str(output)},
                "thresholds": {"poh_medium_percent": 40, "poh_high_percent": 60, "vmi_hail_dbz": 55},
                "tracking": {"min_alert_probability_percent": 60, "prealert_minutes": 20, "check_interval_minutes": 5},
            }
            result = ma.generate_public_image(
                ref, {"VMI": vmi}, [], [ma.Target("Pescara", 42.46, 14.21, 3.0)], cfg,
                state={"precision": {"adaptive_ai": {"status": "shadow", "influence": 0.0}}},
            )
            self.assertEqual(result, output)
            self.assertGreater(output.stat().st_size, 50_000)
            self.assertEqual(output.read_bytes()[:2], b"\xff\xd8")
            map_view = output.with_name("meteo-map.jpg")
            details_view = output.with_name("meteo-details.jpg")
            self.assertTrue(map_view.is_file())
            self.assertTrue(details_view.is_file())
            from PIL import Image
            with Image.open(output) as full, Image.open(map_view) as map_image, Image.open(details_view) as details_image:
                self.assertLess(map_image.width, full.width)
                self.assertLess(details_image.width, map_image.width)


if __name__ == "__main__":
    unittest.main(verbosity=2)
