from __future__ import annotations

import importlib.util
from datetime import datetime
from importlib.machinery import SourceFileLoader
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load_checker():
    path = ROOT / "scripts/ldz-meteo-update-check"
    spec = importlib.util.spec_from_loader("ldz_meteo_update_check_246", SourceFileLoader("ldz_meteo_update_check_246", str(path)))
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


checker = load_checker()


class UpdateCockpitTests(unittest.TestCase):
    def test_popup_and_progress_are_global_and_interactive(self) -> None:
        base = (ROOT / "web/templates/base.html").read_text(encoding="utf-8")
        page = (ROOT / "web/templates/update.html").read_text(encoding="utf-8")
        css = (ROOT / "web/static/app.css").read_text(encoding="utf-8")
        self.assertNotIn("request.endpoint != 'update_page'", base)
        self.assertIn('data-update-action="download"', base)
        self.assertIn('id="update-operation-v244"', base)
        self.assertIn('class="update-progress-v244"', base)
        self.assertIn('data-update-action="check"', page)
        self.assertIn('data-update-action="install"', page)
        self.assertIn("update-operation-v244", css)
        self.assertIn("::-webkit-progress-value", css)
        self.assertNotIn("innerHTML", base)

    def test_schedule_has_real_hour_day_and_week_controls(self) -> None:
        page = (ROOT / "web/templates/update.html").read_text(encoding="utf-8")
        for token in ('name="schedule_minute"', 'name="schedule_time"', 'name="schedule_weekday"', "data-next-update-check"):
            self.assertIn(token, page)
        self.assertIn("Salva e controlla", page)

    def test_hourly_schedule_fires_only_after_selected_minute(self) -> None:
        settings = checker.default_settings()
        settings.update(schedule="hourly", schedule_minute=15)
        before = datetime.now().astimezone().replace(hour=10, minute=14, second=30, microsecond=0)
        after = before.replace(minute=15, second=5)
        previous_due = checker.previous_scheduled_epoch(settings, before.timestamp())
        current_due = checker.previous_scheduled_epoch(settings, after.timestamp())
        self.assertLess(previous_due, current_due)
        self.assertFalse(checker.scheduled_due(settings, {"last_checked_epoch": previous_due + 1}, before.timestamp()))
        self.assertTrue(checker.scheduled_due(settings, {"last_checked_epoch": previous_due + 1}, after.timestamp()))
        settings["schedule_activated_epoch"] = after.timestamp()
        self.assertTrue(checker.scheduled_due(settings, {"last_checked_epoch": 0}, after.timestamp()))

    def test_install_runs_in_transient_service_and_reports_real_phases(self) -> None:
        helper = (ROOT / "scripts/ldz-meteo-approve-update").read_text(encoding="utf-8")
        updater = (ROOT / "scripts/ldz-meteo-apply-hotfix").read_text(encoding="utf-8")
        self.assertIn('UNIT_BASE="ldz-meteo-update-web-${JOB_ID}"', helper)
        self.assertNotIn("--wait", helper)
        for phase in ("Pacchetto verificato", "Dipendenze isolate", "Backup di sicurezza", "Installazione file", "Controllo servizi", "Riavvio WebGUI"):
            self.assertIn(phase, updater)
        self.assertIn("installazione non confermata", updater)
        self.assertIn("update-progress.json", helper)
        self.assertIn("update-progress.json", updater)

    def test_minute_timer_drives_precise_schedule_without_auto_install(self) -> None:
        installer = (ROOT / "install.sh").read_text(encoding="utf-8")
        updater = (ROOT / "scripts/ldz-meteo-apply-hotfix").read_text(encoding="utf-8")
        for source in (installer, updater):
            self.assertIn("OnCalendar=*-*-* *:*:00", source)
            self.assertIn("Persistent=true", source)
        checker_source = (ROOT / "scripts/ldz-meteo-update-check").read_text(encoding="utf-8")
        self.assertNotIn("ldz-meteo-approve-update", checker_source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
