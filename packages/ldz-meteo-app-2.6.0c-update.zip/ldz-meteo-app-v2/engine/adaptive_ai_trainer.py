#!/usr/bin/env python3
"""Batch trainer isolato per Adaptive Forecast AI e grandine 2.4.0.

Legge esclusivamente JSONL numerico, usa una divisione cronologica e pubblica
un candidato JSON atomico. Il motore operativo decide separatamente se usarlo
in shadow/guarded mode; questo processo non invia alert.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import yaml

from adaptive_ai import FEATURE_NAMES
from hail_feedback import train_feedback_file


def sigmoid(values: np.ndarray) -> np.ndarray:
    values = np.clip(values, -30.0, 30.0)
    return 1.0 / (1.0 + np.exp(-values))


def load_rows(path: Path, maximum: int = 5000) -> list[dict[str, Any]]:
    if not path.is_file() or path.is_symlink() or path.stat().st_size > 200 * 1024 * 1024:
        return []
    rows = []
    with path.open(encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if len(line) > 64 * 1024:
                continue
            try:
                row = json.loads(line)
                features = row.get("features")
                outcome = int(row.get("outcome"))
                if not isinstance(features, list) or len(features) != len(FEATURE_NAMES) or outcome not in {0, 1}:
                    continue
                vector = [float(value) for value in features]
                if all(math.isfinite(value) and 0.0 <= value <= 1.0 for value in vector):
                    rows.append({"features": vector, "outcome": outcome, "baseline_probability": float(row.get("baseline_probability", 50.0)) / 100.0})
            except Exception:
                continue
    return rows[-maximum:]


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, dir=str(path.parent)) as handle:
        json.dump(payload, handle, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
        handle.write("\n")
        handle.flush(); os.fsync(handle.fileno())
        temporary = Path(handle.name)
    temporary.replace(path)
    path.chmod(0o600)


def train(rows: list[dict[str, Any]], cfg: dict[str, Any]) -> dict[str, Any]:
    acfg = cfg.get("adaptive_ai", {})
    minimum = max(30, int(acfg.get("shadow_warmup_events", 25) or 25))
    if len(rows) < minimum:
        return {"ready": False, "reason": "insufficient_events", "events": len(rows), "required": minimum}
    split = max(20, min(len(rows) - 10, int(len(rows) * 0.70)))
    train_rows, validation_rows = rows[:split], rows[split:]
    x = np.asarray([row["features"] for row in train_rows], dtype="float64")
    y = np.asarray([row["outcome"] for row in train_rows], dtype="float64")
    weights = np.zeros(x.shape[1], dtype="float64")
    bias = 0.0
    learning_rate = max(0.005, min(0.20, float(acfg.get("batch_learning_rate", 0.08) or 0.08)))
    l2 = max(0.0, min(0.05, float(acfg.get("l2_regularization", 0.002) or 0.002)))
    epochs = max(20, min(500, int(acfg.get("batch_epochs", 120) or 120)))
    for epoch in range(epochs):
        prediction = sigmoid(x @ weights + bias)
        error = prediction - y
        weights -= learning_rate / math.sqrt(1.0 + epoch / 30.0) * ((x.T @ error) / len(x) + l2 * weights)
        bias -= learning_rate / math.sqrt(1.0 + epoch / 30.0) * float(np.mean(error))
    vx = np.asarray([row["features"] for row in validation_rows], dtype="float64")
    vy = np.asarray([row["outcome"] for row in validation_rows], dtype="float64")
    baseline = np.asarray([row["baseline_probability"] for row in validation_rows], dtype="float64")
    candidate = sigmoid(vx @ weights + bias)
    baseline_brier = float(np.mean((baseline - vy) ** 2))
    candidate_brier = float(np.mean((candidate - vy) ** 2))
    improvement = 0.0 if baseline_brier <= 1e-12 else 100.0 * (baseline_brier - candidate_brier) / baseline_brier
    return {
        "ready": True,
        "schema": 1,
        "feature_names": list(FEATURE_NAMES),
        "weights": [round(float(value), 10) for value in weights],
        "bias": round(float(bias), 10),
        "trained_events": len(train_rows),
        "validation_events": len(validation_rows),
        "positive_events": int(sum(row["outcome"] for row in rows)),
        "negative_events": int(len(rows) - sum(row["outcome"] for row in rows)),
        "baseline_brier": round(baseline_brier, 6),
        "candidate_brier": round(candidate_brier, 6),
        "improvement_percent": round(improvement, 2),
        "generated_utc": datetime.now(timezone.utc).isoformat(),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="/etc/meteo-alert/config.yml")
    args = parser.parse_args()
    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8")) or {}
    acfg = cfg.get("adaptive_ai", {})
    data_dir = Path(cfg.get("app", {}).get("data_dir", "/var/lib/meteo-alert"))
    dataset = Path(acfg.get("dataset_file", str(data_dir / "adaptive-ai" / "events.jsonl")))
    candidate = Path(acfg.get("candidate_model_file", str(data_dir / "adaptive-ai" / "candidate-model.json")))
    report = Path(acfg.get("training_report_file", str(data_dir / "adaptive-ai" / "training-report.json")))
    result = train(load_rows(dataset, max(100, min(10000, int(acfg.get("batch_max_events", 5000) or 5000)))), cfg)
    atomic_json(report, result)
    if result.get("ready"):
        atomic_json(candidate, result)
    hail_result = train_feedback_file(cfg)
    print(json.dumps({
        "ok": True,
        "ready": bool(result.get("ready")),
        "events": result.get("events", result.get("trained_events", 0)),
        "hail_feedback_ready": bool(hail_result.get("ready")),
        "hail_feedback_eligible": bool(hail_result.get("eligible")),
        "hail_feedback_events": hail_result.get("events", hail_result.get("trained_events", 0)),
    }))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
