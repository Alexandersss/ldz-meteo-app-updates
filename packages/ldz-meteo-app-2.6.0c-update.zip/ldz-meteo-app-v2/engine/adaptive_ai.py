#!/usr/bin/env python3
"""Adaptive Forecast AI 2.3.0.

Modello online intenzionalmente prudente: apprende in shadow mode, viene
valutato in ordine cronologico prima dell'aggiornamento dei pesi e non può
influenzare il nowcast finché non supera soglie minime di numerosità,
calibrazione e sicurezza.  Pesi e dataset sono solo JSON/numeri: nessun pickle.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any


FEATURE_NAMES = (
    "trajectory_probability",
    "motion_confidence",
    "vmi_intensity",
    "cell_area",
    "poh",
    "vil",
    "etm",
    "vmi_trend",
    "area_trend",
    "storm_speed",
    "terrain_barrier",
    "nwp_spread",
    "lightning_jump",
    "cape",
    "sensor_confirmation",
    "lifecycle_survival",
)


def clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(value)))


def _finite(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except Exception:
        return default


def _sigmoid(value: float) -> float:
    value = max(-30.0, min(30.0, value))
    return 1.0 / (1.0 + math.exp(-value))


def feature_vector(
    cell: dict[str, Any],
    forecast: dict[str, Any],
    lifecycle: dict[str, Any],
    terrain: dict[str, Any],
    lightning: dict[str, Any],
    atmospheric: dict[str, Any],
    sensor: dict[str, Any],
) -> list[float]:
    """Crea feature normalizzate e limitate, stabili tra release."""
    area = max(0.0, _finite(cell.get("area_km2")))
    etm = _finite(cell.get("max_etm"))
    vector = [
        clamp(_finite(forecast.get("trajectory_probability_percent")) / 100.0),
        clamp(_finite(forecast.get("impact_confidence_percent")) / 100.0),
        clamp((_finite(cell.get("max_vmi")) - 15.0) / 55.0),
        clamp(math.log1p(area) / math.log(301.0)),
        clamp(_finite(cell.get("max_poh")) / 100.0),
        clamp(_finite(cell.get("max_vil")) / 80.0),
        clamp(etm / 16000.0),
        clamp(0.5 + _finite(forecast.get("vmi_trend_dbz_min")) / 4.0),
        clamp(0.5 + _finite(forecast.get("area_trend_km2_min")) / 12.0),
        clamp(_finite(forecast.get("speed_kmh")) / 140.0),
        clamp(_finite(terrain.get("barrier_m")) / 1800.0),
        clamp(_finite(atmospheric.get("steering_spread_kmh")) / 80.0),
        clamp(_finite(lightning.get("jump_score")) / 100.0),
        clamp(_finite(atmospheric.get("cape_jkg")) / 4000.0),
        clamp(_finite(sensor.get("confirmation_score")) / 100.0),
        clamp(_finite(lifecycle.get("survival_probability_percent"), 50.0) / 100.0),
    ]
    return [round(value, 7) for value in vector]


def _ai_state(state: dict[str, Any]) -> dict[str, Any]:
    precision = state.setdefault("precision", {})
    ai = precision.setdefault("adaptive_ai", {})
    model = ai.setdefault("model", {})
    weights = model.get("weights")
    if not isinstance(weights, list) or len(weights) != len(FEATURE_NAMES):
        model["weights"] = [0.0] * len(FEATURE_NAMES)
        model["bias"] = 0.0
        model["updates"] = 0
    ai.setdefault("status", "collection")
    ai.setdefault("influence", 0.0)
    ai.setdefault("events", [])
    ai.setdefault("storms", [])
    ai.setdefault("activation_streak", 0)
    return ai


def load_batch_candidate(state: dict[str, Any], cfg: dict[str, Any]) -> dict[str, Any]:
    """Promuove atomicamente nel solo shadow model un candidato JSON validato."""
    ai = _ai_state(state)
    acfg = cfg.get("adaptive_ai", {})
    path = Path(acfg.get("candidate_model_file", str(Path(cfg["app"]["data_dir"]) / "adaptive-ai" / "candidate-model.json")))
    try:
        if not path.is_file() or path.is_symlink() or path.stat().st_size > 1024 * 1024:
            return {"loaded": False}
        payload = json.loads(path.read_text(encoding="utf-8"))
        weights = payload.get("weights")
        if payload.get("ready") is not True or payload.get("schema") != 1 or payload.get("feature_names") != list(FEATURE_NAMES):
            return {"loaded": False, "reason": "schema"}
        if not isinstance(weights, list) or len(weights) != len(FEATURE_NAMES):
            return {"loaded": False, "reason": "weights"}
        weights = [float(value) for value in weights]
        bias = float(payload.get("bias"))
        if not all(math.isfinite(value) and abs(value) <= 100 for value in weights + [bias]):
            return {"loaded": False, "reason": "numeric_bounds"}
        generation = str(payload.get("generated_utc", "")).strip()
        if not generation or len(generation) > 64:
            return {"loaded": False, "reason": "generation"}
        if generation == str(ai.get("batch_generation", "")):
            return {"loaded": False, "reason": "already_loaded"}
        ai["model"].update({"weights": weights, "bias": bias, "batch_metrics": {
            "trained_events": int(payload.get("trained_events", 0) or 0),
            "validation_events": int(payload.get("validation_events", 0) or 0),
            "baseline_brier": payload.get("baseline_brier"),
            "candidate_brier": payload.get("candidate_brier"),
            "improvement_percent": payload.get("improvement_percent"),
        }})
        ai["batch_generation"] = generation
        # Un nuovo candidato non eredita mai l'autorizzazione operativa del
        # modello precedente: riparte in shadow e viene rivalutato solo su
        # eventi temporalmente successivi al caricamento.
        ai["candidate_loaded_at_update"] = int(ai["model"].get("updates", 0) or 0)
        ai["status"] = "shadow"
        ai["influence"] = 0.0
        ai["activation_streak"] = 0
        return {"loaded": True, "generation": generation}
    except Exception:
        return {"loaded": False, "reason": "invalid_candidate"}


def predict(features: list[float], state: dict[str, Any], cfg: dict[str, Any]) -> dict[str, Any]:
    ai = _ai_state(state)
    if not bool(cfg.get("adaptive_ai", {}).get("enabled", True)):
        ai["status"] = "disabled"
        ai["influence"] = 0.0
        return {"probability_percent": 50.0, "status": "disabled", "influence": 0.0, "trained_events": int(ai["model"].get("updates", 0) or 0), "feature_schema": 1}
    model = ai["model"]
    score = _finite(model.get("bias"))
    score += sum(_finite(weight) * _finite(value) for weight, value in zip(model["weights"], features))
    probability = 100.0 * _sigmoid(score)
    updates = int(model.get("updates", 0) or 0)
    return {
        "probability_percent": round(probability, 2),
        "status": str(ai.get("status", "collection")),
        "influence": clamp(_finite(ai.get("influence"))),
        "trained_events": updates,
        "feature_schema": 1,
    }


def apply_shadow_or_guarded(
    base_probability: float,
    features: list[float],
    state: dict[str, Any],
    cfg: dict[str, Any],
) -> dict[str, Any]:
    result = predict(features, state, cfg)
    acfg = cfg.get("adaptive_ai", {})
    influence = result["influence"] if result["status"] == "active_guarded" else 0.0
    influence = min(clamp(_finite(acfg.get("max_influence", 0.30), 0.30)), influence)
    maximum_delta = max(2.0, min(25.0, _finite(acfg.get("max_probability_delta_percent", 18.0), 18.0)))
    ai_probability = _finite(result["probability_percent"], base_probability)
    delta = max(-maximum_delta, min(maximum_delta, ai_probability - base_probability))
    blended = max(0.0, min(100.0, base_probability + influence * delta))
    result.update({
        "base_probability_percent": round(base_probability, 2),
        "blended_probability_percent": round(blended, 2),
        "applied": influence > 0.0,
    })
    return result


def _append_dataset(path: Path, row: dict[str, Any], max_mb: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise OSError("dataset symlink non consentito")
    limit = max(5, min(200, int(max_mb))) * 1024 * 1024
    if path.is_file() and path.stat().st_size > limit:
        rotated = path.with_suffix(path.suffix + ".1")
        rotated.unlink(missing_ok=True)
        path.replace(rotated)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")


def _metrics(events: list[dict[str, Any]]) -> dict[str, Any]:
    if not events:
        return {"evaluated": 0, "baseline_brier": None, "ai_brier": None, "improvement_percent": None}
    baseline = sum(_finite(row.get("baseline_brier")) for row in events) / len(events)
    ai_brier = sum(_finite(row.get("ai_brier")) for row in events) / len(events)
    improvement = 0.0 if baseline <= 1e-9 else 100.0 * (baseline - ai_brier) / baseline
    positives = [row for row in events if int(row.get("outcome", 0) or 0) == 1]
    false_negative = sum(1 for row in positives if _finite(row.get("ai_probability")) < 50.0)
    return {
        "evaluated": len(events),
        "baseline_brier": round(baseline, 6),
        "ai_brier": round(ai_brier, 6),
        "improvement_percent": round(improvement, 2),
        "positive_events": len(positives),
        "negative_events": len(events) - len(positives),
        "ai_false_negative_rate": round(false_negative / len(positives), 4) if positives else None,
    }


def resolve_and_learn(
    pending: dict[str, Any],
    outcome: int,
    state: dict[str, Any],
    cfg: dict[str, Any],
    resolved_ms: int,
) -> dict[str, Any]:
    """Valuta la previsione shadow prima di aggiornare il modello."""
    ai = _ai_state(state)
    acfg = cfg.get("adaptive_ai", {})
    if not bool(acfg.get("enabled", True)):
        ai["status"] = "disabled"
        ai["influence"] = 0.0
        return {"recorded": False, "status": "disabled"}
    features = pending.get("ai_features")
    if not isinstance(features, list) or len(features) != len(FEATURE_NAMES):
        return {"recorded": False}
    features = [clamp(_finite(value)) for value in features]
    shadow = _finite(pending.get("ai_shadow_probability_percent"), 50.0) / 100.0
    baseline = clamp(_finite(pending.get("probability_percent")) / 100.0)
    outcome = 1 if outcome else 0
    storm_key = f"{pending.get('track_id', '')}|{pending.get('target', '')}"
    storms = ai.setdefault("storms", [])
    if storm_key and storm_key not in storms:
        storms.append(storm_key)
        del storms[:-1000]

    model = ai["model"]
    updates_before = int(model.get("updates", 0) or 0)
    warmup = max(10, int(acfg.get("shadow_warmup_events", 25) or 25))
    if updates_before >= warmup:
        event = {
            "resolved_ms": int(resolved_ms),
            "storm_key": storm_key,
            "target": str(pending.get("target", ""))[:100],
            "outcome": outcome,
            "baseline_probability": round(baseline * 100.0, 2),
            "ai_probability": round(shadow * 100.0, 2),
            "baseline_brier": round((baseline - outcome) ** 2, 6),
            "ai_brier": round((shadow - outcome) ** 2, 6),
        }
        events = ai.setdefault("events", [])
        events.append(event)
        del events[:-500]
    else:
        event = {"resolved_ms": int(resolved_ms), "storm_key": storm_key, "outcome": outcome, "warmup": True}

    # Online logistic regression con decadimento L2 e learning-rate decrescente.
    prediction = shadow
    error = prediction - outcome
    rate = max(0.005, min(0.20, _finite(acfg.get("learning_rate", 0.055), 0.055))) / math.sqrt(1.0 + updates_before / 40.0)
    l2 = max(0.0, min(0.05, _finite(acfg.get("l2_regularization", 0.002), 0.002)))
    weights = [_finite(value) for value in model["weights"]]
    model["weights"] = [
        round((weight * (1.0 - rate * l2)) - rate * error * value, 10)
        for weight, value in zip(weights, features)
    ]
    model["bias"] = round(_finite(model.get("bias")) - rate * error, 10)
    model["updates"] = updates_before + 1
    model["feature_names"] = list(FEATURE_NAMES)
    model["schema"] = 1

    window = max(25, min(250, int(acfg.get("evaluation_window_events", 120) or 120)))
    metrics = _metrics(ai.get("events", [])[-window:])
    ai["metrics"] = metrics
    positives = sum(1 for row in ai.get("events", []) if int(row.get("outcome", 0) or 0) == 1)
    negatives = len(ai.get("events", [])) - positives
    min_events = max(30, int(acfg.get("activation_min_events", 80) or 80))
    min_unique_storms = max(5, int(acfg.get("activation_min_unique_storms", 12) or 12))
    min_positive = max(5, int(acfg.get("activation_min_positive", 20) or 20))
    min_negative = max(5, int(acfg.get("activation_min_negative", 20) or 20))
    min_improvement = max(1.0, _finite(acfg.get("activation_min_brier_improvement_percent", 10.0), 10.0))
    candidate_guard_events = max(10, int(acfg.get("candidate_guard_events", 25) or 25))
    candidate_loaded_at = int(ai.get("candidate_loaded_at_update", 0) or 0)
    candidate_guard_ready = updates_before + 1 - candidate_loaded_at >= candidate_guard_events
    eligible = (
        updates_before + 1 >= min_events
        and len(storms) >= min_unique_storms
        and int(metrics.get("evaluated", 0) or 0) >= min_events - warmup
        and positives >= min_positive
        and negatives >= min_negative
        and _finite(metrics.get("improvement_percent"), -999.0) >= min_improvement
        and (metrics.get("ai_false_negative_rate") is None or _finite(metrics.get("ai_false_negative_rate")) <= _finite(acfg.get("max_false_negative_rate", 0.35), 0.35))
        and candidate_guard_ready
    )

    previous_status = str(ai.get("status", "collection"))
    if updates_before + 1 < warmup:
        status = "collection"
    elif eligible:
        ai["activation_streak"] = int(ai.get("activation_streak", 0) or 0) + 1
        required_streak = max(2, int(acfg.get("activation_required_streak", 3) or 3))
        status = "active_guarded" if bool(acfg.get("auto_activate", True)) and ai["activation_streak"] >= required_streak else "eligible"
    else:
        ai["activation_streak"] = 0
        status = "shadow"

    # Circuit breaker: una AI già attiva torna shadow se perde il vantaggio.
    if previous_status == "active_guarded" and int(metrics.get("evaluated", 0) or 0) >= 25:
        baseline_brier = _finite(metrics.get("baseline_brier"), 1.0)
        ai_brier = _finite(metrics.get("ai_brier"), 1.0)
        if ai_brier > baseline_brier * _finite(acfg.get("suspend_brier_ratio", 1.05), 1.05):
            status = "suspended"
            ai["suspended_reason"] = "brier_degradation"

    ai["status"] = status
    ai["influence"] = clamp(_finite(acfg.get("guarded_influence", 0.20), 0.20)) if status == "active_guarded" else 0.0
    ai["unique_storms"] = len(storms)
    ai["positive_events"] = positives
    ai["negative_events"] = negatives
    ai["last_resolved_ms"] = int(resolved_ms)
    ai["requirements"] = {
        "min_events": min_events,
        "min_unique_storms": min_unique_storms,
        "min_positive": min_positive,
        "min_negative": min_negative,
        "min_brier_improvement_percent": min_improvement,
        "candidate_guard_events": candidate_guard_events,
    }

    dataset_path = Path(acfg.get("dataset_file", str(Path(cfg["app"]["data_dir"]) / "adaptive-ai" / "events.jsonl")))
    dataset_row = dict(event)
    dataset_row.update({
        "feature_schema": 1,
        "features": features,
        "feature_names": list(FEATURE_NAMES),
        "model_updates_before": updates_before,
    })
    try:
        _append_dataset(dataset_path, dataset_row, int(acfg.get("max_dataset_mb", 50) or 50))
    except Exception:
        # Il dataset esterno è diagnostico: lo stato online rimane utilizzabile.
        pass
    return {"recorded": True, "status": status, "metrics": metrics}
