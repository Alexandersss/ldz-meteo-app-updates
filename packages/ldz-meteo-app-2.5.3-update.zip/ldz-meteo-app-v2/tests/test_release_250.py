from __future__ import annotations

import hashlib
import importlib
import importlib.util
import json
import os
import sys
import tempfile
import time
import unittest
import zipfile
from datetime import datetime
from importlib.machinery import SourceFileLoader
from pathlib import Path
from zoneinfo import ZoneInfo


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "web"))

from management import (  # noqa: E402
    filter_paginate,
    inspect_backup,
    normalize_backup_settings,
    redact_log_line,
    retention_victims,
    validate_template,
)


def load_checker():
    path = ROOT / "scripts/ldz-meteo-update-check"
    spec = importlib.util.spec_from_loader("ldz_meteo_update_check_250", SourceFileLoader("ldz_meteo_update_check_250", str(path)))
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


checker = load_checker()


class ManagementHelpersTests(unittest.TestCase):
    def test_backup_settings_are_bounded_and_use_rome(self) -> None:
        cfg = normalize_backup_settings({
            "enabled": True, "frequency": "invalid", "schedule_time": "99:70",
            "weekday": 99, "custom_days": 0, "retention_count": 9999,
            "retention_days": -1, "max_space_mb": -50, "timezone": "UTC",
        })
        self.assertEqual(cfg["frequency"], "daily")
        self.assertEqual(cfg["schedule_time"], "02:30")
        self.assertEqual(cfg["weekday"], 6)
        self.assertEqual(cfg["timezone"], "Europe/Rome")
        self.assertEqual(cfg["retention_count"], 500)
        self.assertEqual(cfg["max_space_mb"], 0)

    def test_retention_combines_count_and_space(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            paths = []
            now = time.time()
            for index in range(5):
                path = root / f"backup-{index}.zip"
                path.write_bytes(b"x" * 1024)
                os.utime(path, (now - index * 60, now - index * 60))
                paths.append(path)
            victims = retention_victims(paths, {"retention_mode": "count", "retention_count": 2})
            self.assertEqual({p.name for p in victims}, {"backup-2.zip", "backup-3.zip", "backup-4.zip"})

    def test_backup_inventory_verifies_allowlist_and_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            archive_path = Path(temporary) / "ldz-meteo-backup-test.zip"
            config = b"app: {}\n"
            manifest = {
                "type": "configuration-backup", "schema_version": 2, "version": "2.5.0",
                "files": {"etc/meteo-alert/config.yml": hashlib.sha256(config).hexdigest()},
            }
            with zipfile.ZipFile(archive_path, "w") as archive:
                archive.writestr("etc/meteo-alert/config.yml", config)
                archive.writestr("manifest.json", json.dumps(manifest))
            self.assertTrue(inspect_backup(archive_path)["ok"])
            manifest["files"]["etc/meteo-alert/config.yml"] = "0" * 64
            with zipfile.ZipFile(archive_path, "w") as archive:
                archive.writestr("etc/meteo-alert/config.yml", config)
                archive.writestr("manifest.json", json.dumps(manifest))
            self.assertFalse(inspect_backup(archive_path)["ok"])

    def test_templates_logs_and_pagination_are_safe(self) -> None:
        self.assertEqual(validate_template("Alert {target}: {eta}")[0], True)
        self.assertEqual(validate_template("Alert {unknown}")[0], False)
        redacted = redact_log_line("Authorization: Bearer abc password=hunter2 123456789:abcdefghijklmnopqrstuvwxyz")
        self.assertNotIn("hunter2", redacted)
        self.assertNotIn("abcdefghijklmnopqrstuvwxyz", redacted)
        data = filter_paginate(
            [{"time": f"2026-08-{day:02d}", "level": "INFO", "message": f"target {day}"} for day in range(1, 21)],
            query="target", level="INFO", page=2, per_page=10,
        )
        self.assertEqual(data["total"], 20)
        self.assertEqual(len(data["items"]), 10)


class Updater250Tests(unittest.TestCase):
    def test_schedule_is_rome_aware_and_activation_is_not_a_fake_check(self) -> None:
        now = datetime(2026, 8, 9, 16, 52, 5, tzinfo=ZoneInfo("Europe/Rome"))
        settings = checker.default_settings()
        settings.update(schedule="daily", schedule_time="16:52", schedule_activated_epoch=now.timestamp())
        self.assertTrue(checker.scheduled_due(settings, {"last_checked_epoch": 0}, now.timestamp()))
        self.assertFalse(checker.scheduled_due(settings, {"last_checked_epoch": now.timestamp()}, now.timestamp()))
        self.assertGreater(checker.next_scheduled_epoch(settings, now.timestamp()), now.timestamp())

    def test_singleflight_progress_snooze_and_unique_unit_are_present(self) -> None:
        checker_source = (ROOT / "scripts/ldz-meteo-update-check").read_text(encoding="utf-8")
        helper = (ROOT / "scripts/ldz-meteo-approve-update").read_text(encoding="utf-8")
        base = (ROOT / "web/templates/base.html").read_text(encoding="utf-8")
        self.assertIn("LOCK_EX | fcntl.LOCK_NB", checker_source)
        self.assertIn('UNIT_BASE="ldz-meteo-update-web-${JOB_ID}"', helper)
        self.assertIn("ldz-meteo-update-web-*.service", helper)
        for value in ('value="1h"', 'value="6h"', 'value="24h"'):
            self.assertIn(value, base)
        self.assertIn("data-operation-retry", base)
        self.assertIn("data-operation-details", base)
        self.assertIn("ldz-update-completion-", base)
        self.assertIn("window.localStorage.getItem(completionKey)", base)
        self.assertIn("progress.status === 'error'", base)
        self.assertIn("progress.status === 'completed'", base)
        css = (ROOT / "web/static/app.css").read_text(encoding="utf-8")
        self.assertIn("grid-template-columns:auto auto minmax(210px,1fr) auto", css)
        self.assertIn(".update-operation-actions-v244 [hidden]", css)


class ManagementWebTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        if importlib.util.find_spec("flask") is None:
            raise unittest.SkipTest("Flask non installato")
        from werkzeug.security import generate_password_hash

        cls.temp = tempfile.TemporaryDirectory()
        root = Path(cls.temp.name)
        cls.config = root / "config.yml"
        cls.config.write_text(
            "app: {}\ntargets: []\nmaintenance:\n  enabled: true\n  status: Aggiornamento programmato\n  message: Torniamo presto.\n",
            encoding="utf-8",
        )
        secrets = root / "secrets.env"
        secrets.write_text("", encoding="utf-8")
        env = root / "web.env"
        env.write_text("\n".join([
            'LDZ_METEO_WEB_USERNAME="admin"',
            f'LDZ_METEO_WEB_PASSWORD_HASH="{generate_password_hash("test-password")}"',
            f'LDZ_METEO_WEB_SECRET_KEY="{"a" * 64}"',
            f'LDZ_METEO_CONFIG="{cls.config}"', f'LDZ_METEO_SECRETS="{secrets}"',
            f'LDZ_METEO_UPDATE_STATE="{root / "update-state.json"}"',
            f'LDZ_METEO_UPDATE_SETTINGS="{root / "update-settings.json"}"',
            f'LDZ_METEO_UPDATE_PROGRESS="{root / "update-progress.json"}"',
            f'LDZ_METEO_BACKUP_EXPORT_DIR="{root / "exports"}"',
            f'LDZ_METEO_BACKUP_SETTINGS="{root / "backup-settings.json"}"',
            f'LDZ_METEO_BACKUP_STATE="{root / "backup-state.json"}"',
            f'LDZ_METEO_BACKUP_JOBS="{root / "backup-jobs.jsonl"}"',
            f'LDZ_METEO_BACKUP_PROGRESS="{root / "backup-progress.json"}"',
            f'LDZ_METEO_RESTORE_UPLOAD_DIR="{root / "uploads"}"',
            f'LDZ_METEO_UPDATE_UPLOAD_DIR="{root / "updates"}"',
        ]) + "\n", encoding="utf-8")
        os.environ["LDZ_METEO_WEB_ENV"] = str(env)
        sys.modules.pop("app", None)
        cls.web = importlib.import_module("app")

    @classmethod
    def tearDownClass(cls) -> None:
        cls.temp.cleanup()

    @staticmethod
    def csrf(response) -> str:
        import re
        match = re.search(rb'name="_csrf_token" value="([^"]+)"', response.data)
        assert match
        return match.group(1).decode()

    def test_maintenance_gate_blocks_visitors_but_not_login_or_admin(self) -> None:
        client = self.web.app.test_client()
        public = client.get("/")
        self.assertEqual(public.status_code, 503)
        self.assertIn(b"Torniamo presto", public.data)
        api = client.get("/api/system-status", headers={"Accept": "application/json"})
        self.assertEqual(api.status_code, 503)
        self.assertTrue(api.get_json()["maintenance"])
        login_page = client.get("/login")
        self.assertEqual(login_page.status_code, 200)
        token = self.csrf(login_page)
        self.assertEqual(client.post("/login", data={"_csrf_token": token, "username": "admin", "password": "test-password"}).status_code, 302)
        admin = client.get("/")
        self.assertEqual(admin.status_code, 200)
        self.assertIn(b"Modalit\xc3\xa0 manutenzione attiva", admin.data)

    def test_webhook_ssrf_and_stale_progress_are_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "locale|privata|riservata"):
            self.web.validate_public_webhook("https://127.0.0.1/hook")
        self.web.UPDATE_PROGRESS_FILE.write_text(json.dumps({
            "status": "running", "updated_epoch": int(time.time()) - 3600,
            "message": "vecchio", "percent": 50,
        }), encoding="utf-8")
        self.assertEqual(self.web.update_progress()["status"], "idle")

    def test_login_uses_real_italy_asset_and_clean_stream_animations(self) -> None:
        html = (ROOT / "web/templates/login.html").read_text(encoding="utf-8")
        css = (ROOT / "web/static/login-hud.css").read_text(encoding="utf-8")
        image = ROOT / "web/static/login-italy-radar.jpg"
        self.assertTrue(image.is_file())
        self.assertGreater(image.stat().st_size, 100_000)
        self.assertIn("scenic-radar-map-v250", html)
        self.assertIn("connection-signal-v250", html)
        self.assertIn("data-stream-v250", html)
        self.assertIn(".scenic-radar { display:none; }", css)


class InstallerIntegration250Tests(unittest.TestCase):
    def test_installer_and_hotfix_ship_backup_and_repair_units(self) -> None:
        installer = (ROOT / "install.sh").read_text(encoding="utf-8")
        hotfix = (ROOT / "scripts/ldz-meteo-apply-hotfix").read_text(encoding="utf-8")
        for source in (installer, hotfix):
            for token in (
                "ldz-meteo-backup-manager", "ldz-meteo-backup.timer",
                "ldz-meteo-repair-feedback", "ldz-meteo-repair-update-scheduler",
            ):
                self.assertIn(token, source)
            self.assertIn("OnCalendar=*-*-* *:*:00", source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
