from __future__ import annotations

import hashlib
import importlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
import zipfile
from datetime import datetime
from importlib.machinery import SourceFileLoader
from pathlib import Path
from unittest import mock
from zoneinfo import ZoneInfo


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "web"))

from management import filter_paginate  # noqa: E402


def load_checker():
    path = ROOT / "scripts/ldz-meteo-update-check"
    spec = importlib.util.spec_from_loader("ldz_meteo_update_check_251", SourceFileLoader("ldz_meteo_update_check_251", str(path)))
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


checker = load_checker()


class CompletionHelpersTests(unittest.TestCase):
    def test_filters_cover_date_range_and_event_type(self) -> None:
        rome = ZoneInfo("Europe/Rome")
        rows = [
            {"time": "2026-08-08T20:00:00+02:00", "event_type": "weather_alert", "target": "Pescara"},
            {"time": "2026-08-09T20:00:00+02:00", "event_type": "lightning_alert", "target": "Pescara"},
            {"time": "2026-08-10T20:00:00+02:00", "event_type": "lightning_alert", "target": "Pescara"},
        ]
        selected = filter_paginate(
            rows, event_type="lightning_alert", start_date="2026-08-09", end_date="2026-08-09"
        )
        self.assertEqual(selected["total"], 1)
        self.assertEqual(selected["items"][0]["time"], datetime(2026, 8, 9, 20, tzinfo=rome).isoformat())

    def test_model_identifier_has_no_old_release_suffix(self) -> None:
        for relative in ("engine/meteo_alert.py", "engine/precision_engine.py", "install.sh", "web/templates/settings.html"):
            source = (ROOT / relative).read_text(encoding="utf-8")
            self.assertNotIn("stable-impact-ensemble-2.4.0", source, relative)
        self.assertIn('"model": "stable-impact-ensemble"', (ROOT / "engine/precision_engine.py").read_text(encoding="utf-8"))

    def test_management_pages_have_real_controls_not_decorative_labels(self) -> None:
        backup = (ROOT / "web/templates/backup.html").read_text(encoding="utf-8")
        history = (ROOT / "web/templates/history.html").read_text(encoding="utf-8")
        events = (ROOT / "web/templates/events_feedback.html").read_text(encoding="utf-8")
        logs = (ROOT / "web/templates/logs.html").read_text(encoding="utf-8")
        templates = (ROOT / "web/templates/templates_page.html").read_text(encoding="utf-8")
        kiosk = (ROOT / "web/templates/kiosk.html").read_text(encoding="utf-8")
        self.assertIn("data-delete-dialog", backup)
        self.assertNotIn('type="hidden" name="confirm" value="DELETE"', backup)
        self.assertIn("data-backup-progress", backup)
        for source in (history, events, logs):
            self.assertIn('type="date" name="from"', source)
            self.assertIn('type="date" name="to"', source)
            self.assertIn("data-page", source)
        self.assertIn("previewChannel==='webhook'", templates)
        self.assertIn("data-kiosk-targets", kiosk)
        self.assertIn("data-kiosk-eta", kiosk)
        self.assertIn("requestFullscreen", kiosk)
        self.assertIn("new Image()", kiosk)
        self.assertIn("next.onload", kiosk)
        self.assertIn("document.exitFullscreen", kiosk)
        self.assertNotIn("controls-hidden'),5000", kiosk)
        self.assertIn("backup-secrets-toggle-v253", backup)
        self.assertNotIn('class="toggle-row-v223c"><span class="toggle-copy-v223c"', backup.split('<div class="form-grid-2">', 1)[1].split('</div>', 1)[0])

    def test_internal_acceptance_notes_are_not_shipped_in_update_archive(self) -> None:
        builder = (ROOT / "scripts/build-release-package").read_text(encoding="utf-8")
        self.assertIn("path.name.startswith('ACCEPTANCE_')", builder)


class UpdaterCompletionTests(unittest.TestCase):
    def test_daily_next_run_handles_both_sides_of_selected_time(self) -> None:
        tz = ZoneInfo("Europe/Rome")
        cfg = checker.default_settings()
        cfg.update(schedule="daily", schedule_time="16:50", timezone="Europe/Rome")
        before = datetime(2026, 8, 9, 16, 30, tzinfo=tz)
        after = datetime(2026, 8, 9, 16, 52, tzinfo=tz)
        self.assertEqual(datetime.fromtimestamp(checker.next_scheduled_epoch(cfg, before.timestamp()), tz), datetime(2026, 8, 9, 16, 50, tzinfo=tz))
        self.assertEqual(datetime.fromtimestamp(checker.next_scheduled_epoch(cfg, after.timestamp()), tz), datetime(2026, 8, 10, 16, 50, tzinfo=tz))
        cfg["schedule_activated_epoch"] = after.timestamp()
        self.assertTrue(checker.scheduled_due(cfg, {"last_checked_epoch": 0}, after.timestamp()))

    def test_hourly_weekly_cet_and_cest_use_wall_clock_time(self) -> None:
        tz = ZoneInfo("Europe/Rome")
        hourly = checker.default_settings()
        hourly.update(schedule="hourly", schedule_minute=15, timezone="Europe/Rome")
        self.assertEqual(datetime.fromtimestamp(checker.next_scheduled_epoch(hourly, datetime(2026, 1, 15, 10, 2, tzinfo=tz).timestamp()), tz).minute, 15)
        weekly = checker.default_settings()
        weekly.update(schedule="weekly", schedule_time="09:30", schedule_weekday=0, timezone="Europe/Rome")
        next_weekly = datetime.fromtimestamp(checker.next_scheduled_epoch(weekly, datetime(2026, 8, 9, 18, tzinfo=tz).timestamp()), tz)
        self.assertEqual((next_weekly.weekday(), next_weekly.hour, next_weekly.minute), (0, 9, 30))
        for now in (datetime(2026, 1, 15, 8, tzinfo=tz), datetime(2026, 8, 15, 8, tzinfo=tz)):
            daily = checker.default_settings(); daily.update(schedule="daily", schedule_time="09:00", timezone="Europe/Rome")
            candidate = datetime.fromtimestamp(checker.next_scheduled_epoch(daily, now.timestamp()), tz)
            self.assertEqual((candidate.hour, candidate.minute), (9, 0))
            self.assertEqual(candidate.utcoffset(), now.utcoffset())

    def test_singleflight_and_telegram_notification_are_version_bound(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            previous = checker.LOCK_FILE
            checker.LOCK_FILE = Path(temporary) / "check.lock"
            first = None
            try:
                first = checker.acquire_singleflight()
                self.assertIsNotNone(first)
                self.assertIsNone(checker.acquire_singleflight())
            finally:
                if first is not None:
                    import fcntl
                    fcntl.flock(first.fileno(), fcntl.LOCK_UN); first.close()
                checker.LOCK_FILE = previous
        state = {"available": True, "latest_version": "2.5.1"}
        settings = {"telegram_notification": True}
        with mock.patch.object(checker, "telegram_send", return_value=(True, "ok")) as sender:
            checker.notify_telegram_once(state, settings)
            checker.notify_telegram_once(state, settings)
        self.assertEqual(sender.call_count, 1)
        self.assertEqual(state["last_notification_version"], "2.5.1")
        failed = {"available": True, "latest_version": "2.5.2"}
        with mock.patch.object(checker, "telegram_send", return_value=(False, "HTTP 403")):
            checker.notify_telegram_once(failed, settings)
        self.assertEqual(failed["last_notification_status"], "error")
        self.assertNotIn("last_notification_version", failed)


class BackupRestoreFunctionalTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.etc = self.root / "etc"
        self.etc.mkdir()
        self.config = self.etc / "config.yml"
        self.secrets = self.etc / "secrets.env"
        self.config.write_text("app:\n  name: original\n", encoding="utf-8")
        self.secrets.write_text('TELEGRAM_BOT_TOKEN="123456:abcdefghijklmnopqrstuv"\n', encoding="utf-8")
        self.installed_app = self.root / "app.py"
        self.installed_app.write_text('APP_VERSION = "2.5.0"\n', encoding="utf-8")
        self.exports = self.root / "exports"
        self.settings = self.root / "backup-settings.json"
        self.settings.write_text(json.dumps({"include_secrets": True, "retention_count": 20}), encoding="utf-8")
        self.env = os.environ.copy()
        self.env.update({
            "LDZ_METEO_WEB_DIR": str(ROOT / "web"),
            "LDZ_METEO_CONFIG": str(self.config),
            "LDZ_METEO_SECRETS": str(self.secrets),
            "LDZ_METEO_BACKUP_EXPORT_DIR": str(self.exports),
            "LDZ_METEO_BACKUP_SETTINGS": str(self.settings),
            "LDZ_METEO_BACKUP_STATE": str(self.root / "backup-state.json"),
            "LDZ_METEO_BACKUP_JOBS": str(self.root / "backup-jobs.jsonl"),
            "LDZ_METEO_BACKUP_PROGRESS": str(self.root / "backup-progress.json"),
            "LDZ_METEO_BACKUP_LOCK": str(self.root / "backup.lock"),
            "LDZ_METEO_INSTALLED_APP": str(self.installed_app),
        })

    def tearDown(self) -> None:
        self.temp.cleanup()

    def run_manager(self, mode: str) -> Path:
        result = subprocess.run(
            [sys.executable, str(ROOT / "scripts/ldz-meteo-backup-manager"), mode],
            env=self.env, capture_output=True, text=True, timeout=30, check=True,
        )
        return Path(result.stdout.strip().splitlines()[-1])

    def test_manual_and_pre_restore_backups_are_atomic_and_verified(self) -> None:
        manual = self.run_manager("--run-now")
        pre_restore = self.run_manager("--pre-restore")
        self.assertTrue(manual.is_file())
        self.assertTrue(pre_restore.is_file())
        with zipfile.ZipFile(pre_restore) as archive:
            self.assertEqual(
                set(archive.namelist()),
                {"etc/meteo-alert/config.yml", "etc/meteo-alert/secrets.env", "manifest.json"},
            )
            manifest = json.loads(archive.read("manifest.json"))
            self.assertEqual(manifest["backup_kind"], "pre-restore")
            for name, digest in manifest["files"].items():
                self.assertEqual(hashlib.sha256(archive.read(name)).hexdigest(), digest)
        jobs = [json.loads(line) for line in (self.root / "backup-jobs.jsonl").read_text().splitlines()]
        self.assertEqual([row["status"] for row in jobs], ["success", "success"])
        self.assertEqual(json.loads((self.root / "backup-progress.json").read_text())["status"], "completed")

    def test_restore_applies_only_allowed_data_and_creates_pre_restore_backup(self) -> None:
        uploads = self.root / "uploads"
        uploads.mkdir()
        payload = b"app:\n  name: restored\n"
        restored_secret = b'TELEGRAM_CHAT_ID="123"\n'
        manifest = {
            "app": "LDZ Meteo App", "type": "configuration-backup", "schema_version": 2,
            "version": "2.5.0", "files": {
                "etc/meteo-alert/config.yml": hashlib.sha256(payload).hexdigest(),
                "etc/meteo-alert/secrets.env": hashlib.sha256(restored_secret).hexdigest(),
            },
        }
        archive_path = uploads / "restore-test.zip"
        with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("etc/meteo-alert/config.yml", payload)
            archive.writestr("etc/meteo-alert/secrets.env", restored_secret)
            archive.writestr("manifest.json", json.dumps(manifest))
        pending = self.root / "pending-restore"
        pending.write_text(archive_path.name + "\n", encoding="utf-8")
        systemctl = self.root / "systemctl"
        systemctl.write_text("#!/usr/bin/env bash\nexit 0\n", encoding="utf-8")
        systemctl.chmod(0o755)
        env = dict(self.env)
        env.update({
            "CI": "true",
            "LDZ_METEO_RESTORE_TEST_MODE": "1",
            "LDZ_METEO_RESTORE_UPLOAD_DIR": str(uploads),
            "LDZ_METEO_PENDING_RESTORE_FILE": str(pending),
            "LDZ_METEO_SECURITY_TOOL": str(ROOT / "web/security_utils.py"),
            "LDZ_METEO_WEB_PYTHON": sys.executable,
            "LDZ_METEO_BACKUP_MANAGER": str(ROOT / "scripts/ldz-meteo-backup-manager"),
            "LDZ_METEO_ENGINE_ETC_DIR": str(self.etc),
            "LDZ_METEO_ENGINE_GROUP": "root",
            "LDZ_METEO_PRE_RESTORE_ROOT": str(self.root),
            "LDZ_METEO_RESTORE_WORK_ROOT": str(self.root / "restore-work"),
            "LDZ_METEO_SYSTEMCTL": str(systemctl),
        })
        result = subprocess.run(
            ["bash", str(ROOT / "scripts/ldz-meteo-restore-backup")], env=env,
            capture_output=True, text=True, timeout=45, check=False,
        )
        self.assertEqual(result.returncode, 0, result.stdout + "\n" + result.stderr)
        self.assertIn("Restore dati completato", result.stdout)
        self.assertEqual(self.config.read_bytes(), payload)
        self.assertEqual(self.secrets.read_bytes(), restored_secret)
        self.assertFalse(pending.exists())
        self.assertTrue(any("pre-restore" in path.name for path in self.exports.glob("*.zip")))
        jobs = [json.loads(line) for line in (self.root / "backup-jobs.jsonl").read_text().splitlines()]
        self.assertEqual(jobs[-1]["type"], "restore")
        self.assertEqual(jobs[-1]["status"], "success")

    def test_restore_failure_rolls_back_previous_configuration(self) -> None:
        uploads = self.root / "uploads-failure"
        uploads.mkdir()
        payload = b"app:\n  name: must-be-rolled-back\n"
        manifest = {
            "app": "LDZ Meteo App", "type": "configuration-backup", "schema_version": 2,
            "version": "2.5.0", "files": {"etc/meteo-alert/config.yml": hashlib.sha256(payload).hexdigest()},
        }
        archive_path = uploads / "restore-failure.zip"
        with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("etc/meteo-alert/config.yml", payload)
            archive.writestr("manifest.json", json.dumps(manifest))
        pending = self.root / "pending-restore-failure"
        pending.write_text(archive_path.name + "\n", encoding="utf-8")
        systemctl = self.root / "systemctl-failure"
        systemctl.write_text("#!/usr/bin/env bash\nexit 1\n", encoding="utf-8")
        systemctl.chmod(0o755)
        original = self.config.read_bytes()
        env = dict(self.env)
        env.update({
            "CI": "true",
            "LDZ_METEO_RESTORE_TEST_MODE": "1",
            "LDZ_METEO_RESTORE_UPLOAD_DIR": str(uploads),
            "LDZ_METEO_PENDING_RESTORE_FILE": str(pending),
            "LDZ_METEO_SECURITY_TOOL": str(ROOT / "web/security_utils.py"),
            "LDZ_METEO_WEB_PYTHON": sys.executable,
            "LDZ_METEO_BACKUP_MANAGER": str(ROOT / "scripts/ldz-meteo-backup-manager"),
            "LDZ_METEO_ENGINE_ETC_DIR": str(self.etc),
            "LDZ_METEO_ENGINE_GROUP": "root",
            "LDZ_METEO_PRE_RESTORE_ROOT": str(self.root),
            "LDZ_METEO_RESTORE_WORK_ROOT": str(self.root / "restore-work-failure"),
            "LDZ_METEO_SYSTEMCTL": str(systemctl),
        })
        result = subprocess.run(
            ["bash", str(ROOT / "scripts/ldz-meteo-restore-backup")], env=env,
            capture_output=True, text=True, timeout=45, check=False,
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.config.read_bytes(), original)
        self.assertIn("Rollback ripristino completato", result.stderr)
        jobs = [json.loads(line) for line in (self.root / "backup-jobs.jsonl").read_text().splitlines()]
        self.assertEqual(jobs[-1]["type"], "restore")
        self.assertEqual(jobs[-1]["status"], "error")


class CompletionWebTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        try:
            from werkzeug.security import generate_password_hash
        except ImportError as exc:  # pragma: no cover - enforced by full runner
            raise unittest.SkipTest(str(exc))
        cls.temp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temp.name)
        log_dir = cls.root / "logs"
        log_dir.mkdir()
        cls.state_file = cls.root / "state.json"
        config = cls.root / "config.yml"
        config.write_text(
            "app:\n  log_dir: " + str(log_dir) + "\n  state_file: " + str(cls.state_file) + "\n"
            "targets:\n  - name: Pescara\n    enabled: true\nmaintenance:\n  enabled: false\n"
            "event_feedback:\n  enabled: true\nnotifications:\n  email_enabled: true\n"
            "  smtp_host: smtp.example.test\n  smtp_port: 587\n  smtp_security: starttls\n"
            "  smtp_user: user@example.test\n  smtp_password: secret\n  email_from: user@example.test\n"
            "  email_to: dest@example.test\n  webhook_enabled: true\n  webhook_url: https://example.test/hook\n",
            encoding="utf-8",
        )
        cls.alert_log = log_dir / "alerts.log"
        cls.alert_log.write_text("\n".join([
            json.dumps({"time_utc": "2026-08-08T10:00:00+02:00", "event_type": "weather_alert", "target": {"name": "Pescara"}, "cell": {"risk": "MEDIO"}, "message": "pioggia"}),
            json.dumps({"time_utc": "2026-08-09T10:00:00+02:00", "event_type": "lightning_alert", "target": {"name": "Pescara"}, "lightning": {"count": 4}, "message": "fulmini"}),
        ]) + "\n", encoding="utf-8")
        cls.state_file.write_text(json.dumps({
            "precision": {"active_tracks": 1, "data_quality_percent": 87, "last_forecasts": {
                "Pescara": {"forecast": {"impact_probability_percent": 72, "eta_low_minutes": 8, "eta_high_minutes": 14, "direction_cardinal": "NE"}}
            }},
            "event_feedback": {"last_callback_at": "2026-08-09T20:00:00+02:00", "incidents": {
                "one": {"started_ms": 1786305600000, "event_type": "weather_alert", "target_name": "Pescara", "outcome_class": "tp", "feedback": "confirmed"},
                "two": {"started_ms": 1786392000000, "event_type": "lightning_alert", "target_name": "Pescara", "outcome_class": "not_on_site", "feedback": "not_on_site"},
            }},
        }), encoding="utf-8")
        secrets = cls.root / "secrets.env"
        secrets.write_text("", encoding="utf-8")
        env_file = cls.root / "web.env"
        env_file.write_text("\n".join([
            'LDZ_METEO_WEB_USERNAME="admin"',
            f'LDZ_METEO_WEB_PASSWORD_HASH="{generate_password_hash("test-password")}"',
            f'LDZ_METEO_WEB_SECRET_KEY="{"a" * 64}"',
            f'LDZ_METEO_CONFIG="{config}"', f'LDZ_METEO_SECRETS="{secrets}"',
            f'LDZ_METEO_LOG="{log_dir / "meteo.log"}"',
            f'LDZ_METEO_CHANNEL_TEST_STATE="{cls.root / "channel-state.json"}"',
            f'LDZ_METEO_UPDATE_STATE="{cls.root / "update-state.json"}"',
            f'LDZ_METEO_UPDATE_SETTINGS="{cls.root / "update-settings.json"}"',
            f'LDZ_METEO_UPDATE_PROGRESS="{cls.root / "update-progress.json"}"',
            f'LDZ_METEO_BACKUP_EXPORT_DIR="{cls.root / "exports"}"',
            f'LDZ_METEO_BACKUP_SETTINGS="{cls.root / "backup-settings.json"}"',
            f'LDZ_METEO_BACKUP_STATE="{cls.root / "backup-state.json"}"',
            f'LDZ_METEO_BACKUP_JOBS="{cls.root / "backup-jobs.jsonl"}"',
            f'LDZ_METEO_BACKUP_PROGRESS="{cls.root / "backup-progress.json"}"',
            f'LDZ_METEO_RESTORE_UPLOAD_DIR="{cls.root / "uploads"}"',
            f'LDZ_METEO_UPDATE_UPLOAD_DIR="{cls.root / "updates"}"',
            'LDZ_METEO_ROOT_ACTIONS_ENABLED="true"',
        ]) + "\n", encoding="utf-8")
        os.environ["LDZ_METEO_WEB_ENV"] = str(env_file)
        sys.modules.pop("app", None)
        cls.web = importlib.import_module("app")

    @classmethod
    def tearDownClass(cls) -> None:
        cls.temp.cleanup()

    @staticmethod
    def csrf(response) -> str:
        import re
        match = re.search(rb'name="_csrf_token" value="([^"]+)"', response.data)
        assert match
        return match.group(1).decode()

    def client(self):
        client = self.web.app.test_client()
        login = client.get("/login")
        token = self.csrf(login)
        response = client.post("/login", data={"_csrf_token": token, "username": "admin", "password": "test-password"})
        self.assertEqual(response.status_code, 302)
        return client

    def token(self, client, path: str = "/templates") -> str:
        return self.csrf(client.get(path))

    def test_history_feedback_and_kiosk_apis_expose_complete_dynamic_data(self) -> None:
        client = self.client()
        history = client.get("/api/history?event_type=lightning_alert&from=2026-08-09&to=2026-08-09").get_json()
        self.assertEqual(history["data"]["total"], 1)
        self.assertEqual(history["data"]["items"][0]["message"], "fulmini")
        feedback = client.get("/api/events-feedback?event_type=weather_alert").get_json()
        self.assertEqual(feedback["data"]["total"], 1)
        self.assertTrue(feedback["summary"]["configured"])
        kiosk = client.get("/api/kiosk-status").get_json()
        self.assertEqual(kiosk["targets"][0]["name"], "Pescara")
        self.assertEqual(kiosk["targets"][0]["eta"], "8–14 min")
        self.assertIn("warnings", kiosk)

    def test_template_test_uses_unsaved_editor_body_and_channel_tabs_render(self) -> None:
        client = self.client()
        token = self.token(client)
        response = client.post("/templates", data={
            "_csrf_token": token, "action": "test", "template_body": "Alert nuovo per {target}: {eta}",
        }, headers={"Accept": "application/json"})
        self.assertEqual(response.status_code, 200)
        self.assertIn("Alert nuovo per Pescasseroli", response.get_json()["preview"])
        page = client.get("/templates")
        self.assertIn(b"previewChannel==='email'", page.data)
        self.assertIn(b"previewChannel==='webhook'", page.data)

    def test_smtp_and_webhook_tests_persist_sanitized_results(self) -> None:
        client = self.client()

        class FakeSMTP:
            def __init__(self, *args, **kwargs): pass
            def __enter__(self): return self
            def __exit__(self, *args): return False
            def starttls(self, *args, **kwargs): return None
            def login(self, *args, **kwargs): return None
            def send_message(self, *args, **kwargs): return None

        token = self.token(client, "/channels")
        with mock.patch.object(self.web.smtplib, "SMTP", FakeSMTP):
            response = client.post("/channels/test-email", data={"_csrf_token": token}, headers={"Accept": "application/json"})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.get_json()["ok"])

        class FakeResponse:
            status = 204
            def __enter__(self): return self
            def __exit__(self, *args): return False

        class FakeOpener:
            def open(self, *args, **kwargs): return FakeResponse()

        token = self.token(client, "/channels")
        with mock.patch.object(self.web, "validate_public_webhook", return_value=("example.test", "/hook", 443)), mock.patch.object(self.web.urllib.request, "build_opener", return_value=FakeOpener()):
            response = client.post("/channels/test-webhook", data={"_csrf_token": token}, headers={"Accept": "application/json"})
        self.assertEqual(response.status_code, 200)
        state = json.loads((self.root / "channel-state.json").read_text())
        self.assertTrue(state["smtp"]["ok"])
        self.assertTrue(state["webhook"]["ok"])
        self.assertNotIn("secret", json.dumps(state))

    def test_all_corrected_pages_render_with_filters_progress_and_runtime_controls(self) -> None:
        client = self.client()
        expectations = {
            "/backup": (b"data-backup-progress", b"data-delete-dialog"),
            "/history": (b'name="event_type"', b'data-history-live'),
            "/events-feedback": (b'name="event_type"', b"data-feedback-console"),
            "/logs": (b'name="component"', b'name="from"'),
            "/kiosk": (b"data-kiosk-targets", b"requestFullscreen"),
            "/system": (b"data-system-operation", b"data-management-action"),
            "/channels": (b"Ultimo test SMTP", b"Ultimo test webhook"),
        }
        for path, needles in expectations.items():
            response = client.get(path)
            self.assertEqual(response.status_code, 200, path)
            for needle in needles:
                self.assertIn(needle, response.data, path)

    def test_channel_change_and_telegram_enable_trigger_one_initial_scan(self) -> None:
        client = self.client()
        token = self.token(client, "/update")
        with mock.patch.object(self.web, "run_update_checker", return_value=(0, "ok")) as run:
            response = client.post("/update/settings", data={
                "_csrf_token": token, "updates_enabled": "on", "schedule": "daily",
                "schedule_minute": "0", "schedule_time": "16:50", "schedule_weekday": "0",
                "channel": "beta", "telegram_notification": "on",
            }, headers={"Accept": "application/json"})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.get_json()["initial_scan"]["started"])
        run.assert_called_once_with("--check", "--force", "--interactive", "--trigger", "initial", timeout=75)


if __name__ == "__main__":
    unittest.main(verbosity=2)
