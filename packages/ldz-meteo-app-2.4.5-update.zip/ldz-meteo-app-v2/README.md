# LDZ Meteo App 2.4.5 · Login HUD V2

## Login HUD V2 2.4.5

La 2.4.5 rifinisce esclusivamente la schermata di accesso della 2.4.4 per aderire al concept futuristico approvato: geometria 16:9, radar rettangolare, pannello amministratore HUD, autofill scuro, barra stato compatta e animazioni leggere. Il motore meteorologico e la sicurezza di autenticazione non vengono modificati.

Release stabile basata sulla 2.4.3. Ridisegna completamente la schermata di accesso senza modificare il motore meteo o la logica di autenticazione.

## Login HUD 2.4.4

- Nuova schermata di accesso futuristica cyan/arancio ricostruita con HTML, CSS, SVG e JavaScript reali: il concept non viene usato come semplice immagine di sfondo.
- Radar centrale con sweep e blip animati, anteprima del `meteo.jpg` reale, timestamp dell'ultimo frame e stato della freschezza del feed.
- Barra inferiore dinamica con connessione, data stream e motore meteo; target e celle restano volutamente protetti prima del login invece di mostrare numeri inventati.
- Card applicative dedicate a Radar Live, Target Smart, Alert Telegram e Fulmini & Grandine con copy specifico LDZ Meteo.
- Form login ridisegnato mantenendo CSRF, rate limiting, password hash, remember-me, sessioni e gestione degli errori esistenti.
- Animazioni leggere con fallback `prefers-reduced-motion`, asset locali e layout responsive per desktop, notebook, tablet e smartphone.
- L'updater distribuisce l'intero albero `web/`, quindi i nuovi template e asset HUD vengono installati normalmente tramite LDZ Update Network.

## Feedback Telegram 2.4.3

- Un listener systemd dedicato riceve la scelta senza attendere il successivo ciclo meteo.
- Telegram conferma subito la presa in carico, rimuove i pulsanti e invia una ricevuta persistente con la scelta registrata.
- La prima risposta è definitiva; tocchi successivi non possono sostituirla né duplicare i dati di calibrazione.
- La coda locale è atomica e viene consolidata nello stato degli eventi sotto il lock del motore.
- Lo stato del listener è visibile in **Diagnostica** e **Sistema**.

## LDZ Update Network 2.4.2

- La pagina **Aggiornamenti** usa due indici pubblici generati automaticamente, `stable` e `beta`, senza richiedere account o token a chi installa l'app.
- Frequenze disponibili: manuale, oraria, giornaliera e settimanale. Il timer systemd è persistente e riprende dopo un riavvio.
- **Stabile** riceve soltanto release definitive. **Beta** riceve prerelease e tutte le stabili successive; tornare a Stabile non causa mai un downgrade.
- Il sorgente resta privato; la pipeline pubblica separatamente soltanto indice e pacchetti operativi su **LDZ Update Network**.
- L'indirizzo HTTPS di distribuzione è fissato nell'installazione. URL e percorsi non possono essere scelti dal browser.
- **Nessuna installazione automatica:** l'amministratore decide sempre se installare. Il clic applica l'approvazione Ed25519 locale; backup, verifica root-owned e rollback restano quelli della 2.4.0.
- Un popup futuristico in alto a destra segnala la nuova versione e può essere rinviato di 24 ore.
- La pagina è più compatta: switch correttamente disegnati, canali selezionabili con card e pulsante **Salva preferenze** a larghezza contenuto.
- Gli errori di controllo mostrano la causa reale restituita dal checker; è stato rimosso il generico “consulta lo stato updater”.
- Corretto il falso `Rischio: Attenzione`: `WARNING ... (HTTPError)` è ora una sorgente degradata, non un errore applicativo.

## Ground truth e nowcast event-driven 2.4.0

- Il WebSocket ufficiale Radar-DPC avvia l'elaborazione alla pubblicazione di un nuovo VMI; il timer periodico resta attivo come fallback e un lock impedisce cicli concorrenti.
- LTG usa la cadenza ufficiale di 10 minuti e finestre costruite dai timestamp reali. L'età è misurata rispetto all'ora d'invio; oltre 15 minuti il quadro non genera nuovi alert.
- I fulmini sono più visibili sulla mappa con simbolo vettoriale pieno, alone chiaro, bordo scuro, giallo per il quadro recente e arancione per il precedente.
- Il near-target override misura il bordo dell'eco e non solo il baricentro: pioggia osservata o fulmini molto vicini possono impedire che una traiettoria incerta riduca il rischio al 10%.
- VMI, SRI, POH, VIL, ETM, CAPPI, LTG e SITES formano un pacchetto temporale esplicito; prodotti disallineati o radar vicini fuori servizio degradano la confidenza e sono dichiarati.
- Target vicini interessati dallo stesso track condividono l'evento e l'avviso Telegram, mantenendo valutazioni e feedback distinti per località.
- Dopo la chiusura di un evento notificato, Telegram può chiedere cosa sia accaduto realmente: nessun fenomeno, soli fulmini, pioggia, pioggia intensa, grandine piccola, grandine con danni o non presente sul posto.
- I pulsanti sono firmati e legati all'evento e alla chat configurata. “Non ero sul posto” viene registrato ma non entra mai nel dataset di calibrazione.
- Replay compatti conservano ritagli radar, valori decisionali, motivi favorevoli e blocchi; la WebGUI aggiunge la pagina **Eventi & feedback**.
- La calibrazione grandine si addestra sugli eventi più vecchi e viene validata cronologicamente sui successivi. Si attiva solo con Brier migliore e senza più falsi negativi, con influenza e delta massimi limitati.
- Un watchdog systemd separato segnala via Telegram se il motore non aggiorna lo stato per 20 minuti e notifica il recupero.

## Profilo verticale grandine e auto-login 2.3.7

- Scarica tramite API ufficiale Radar-DPC i dieci livelli `CAPPI_1`–`CAPPI_10`, dalle quote 1–10 km.
- Per ogni cella misura fin dove persistono eco di 45/50/55 dBZ e le confronta con lo zero termico.
- CAPPI modifica la stima grandine soltanto entro limiti conservativi (+12/-6 punti); POH resta dominante e non viene stimata la dimensione dei chicchi.
- Telegram mostra il risultato negli alert iniziali e negli aggiornamenti; mappa e dashboard mostrano se CAPPI è realmente attivo e quanti livelli sono disponibili.
- Se CAPPI manca o è disallineato, il motore torna automaticamente alla Hail Fusion preesistente.
- “Ricordami” ripristina la sessione anche se il browser riapre direttamente `/login`; il token è firmato, `HttpOnly`, revocabile e non contiene la password.
- Il titolo del pannello è “Stable Impact & Hail Fusion”, senza un numero di una vecchia release.

## Fulmini, ETA live e messaggi chiari 2.3.6

- Il prodotto ufficiale Radar-DPC LGT può generare alert Telegram dedicati anche senza un alert temporalesco già attivo.
- Gli aggiornamenti migrano automaticamente la vecchia sorgente predefinita `open_meteo` a `radar_dpc_lgt`; una scelta esplicita diversa non viene sovrascritta.
- La mappa mostra il numero di fulmini recenti, la distanza minima dai target e un badge visibile quando sono presenti scariche nell'area.
- L'ETA viene ridotto dei minuti trascorsi tra il timestamp radar e l'elaborazione: una finestra già scaduta non viene notificata come previsione futura.
- Le probabilità con traiettoria debole vengono riportate prudentemente verso il 50% e limitate quando il tracking ha poche scansioni.
- La severità distingue pioggia temporalesca intensa, temporale forte e nucleo molto intenso: 50 dBZ non viene più presentato automaticamente come “mega forte”.
- Telegram usa righe uniformi, “Cosa sta rilevando il sistema” e “Stabilità previsione” spiegata; elimina “da confermare” e l'ambigua “Affidabilità della stima”.
- I rientri citano probabilità ed ETA dell'avviso realmente inviato e distinguono fenomeno transitato, passaggio marginale, traiettoria deviata e previsione non confermata.
- Il pannello mappa “In parole povere” è rinominato “Situazione stimata”.

## Messaggi radar chiari 2.3.5

- La situazione radar nomina il target e distingue impatto osservato, probabile, possibile, poco probabile, molto improbabile e fuori traiettoria.
- Distanza, direzione, probabilità ed ETA sono spiegate in italiano semplice senza usare “traiettoria incerta” come contenitore generico.
- Le etichette tecniche delle celle sono tradotte e confinate dentro la mappa; una cella fuori inquadratura non può più scrivere sopra il pannello sinistro.
- Intervalli ETA identici vengono mostrati una sola volta (`20 min`, non `20–20 min`).

## Stable Impact e grandine 2.3.4

- L'area esterna del temporale e il nucleo forte ≥55 dBZ sono misurati separatamente.
- Nessun `100%` automatico quando il solo inviluppo sfiora il target; un nucleo forte già osservato viene indicato al 97%.
- Due frame coerenti sono richiesti anche per un ETA urgente; due frame negativi sono richiesti prima del rientro.
- Hail Fusion usa POH come segnale principale e lo confronta con intensità del nucleo, densità VIL, sviluppo sopra lo zero termico, persistenza, crescita, Lightning Jump e IR_108.
- La qualità dei dati grandine è distinta dalla probabilità; nessuna dimensione dei chicchi viene dichiarata senza osservazioni idonee.
- Gli alert Telegram spiegano probabilità grandine, qualità e conferma multi-frame.

## Avvisi comprensibili 2.3.3

- Il messaggio principale risponde subito a quattro domande: cosa arriva, dove, tra quanto e cosa fare.
- Probabilità d'impatto, affidabilità dei dati e coerenza della traiettoria sono separate chiaramente.
- La sezione “Perché ricevi questo avviso” traduce VMI, SRI, POH, VIL ed ETM in descrizioni semplici, mantenendo anche il valore originale.
- I consigli cambiano in presenza di grandine, fulmini o pioggia molto intensa.
- Gli aggiornamenti successivi sono compatti: rischio aumentato, traiettoria meno probabile o minaccia rientrata.

## Motore di precisione 2.3.4

- Tracking persistente su 3–12 frame (default 6) con assegnazione globale delle celle e identificatore stabile.
- Filtro di Kalman per velocità/direzione, gestione frame radar duplicati e rilevamento indicativo di split, merge, crescita e decadimento.
- Forma reale della cella tramite inviluppo compatto: l'impatto non dipende più soltanto dal baricentro e dal raggio circolare equivalente.
- Optical flow VMI multi-scala con misura dello spread/deformazione, combinato in modo conservativo con il moto object-based.
- Ensemble deterministico riproducibile di 72 traiettorie con finestra ETA, probabilità d'impatto e cono d'incertezza.
- SRI, SRT1 e IR_108 nella catena radar per descrivere intensità al suolo, persistenza oraria e temperatura della sommità nuvolosa.
- Allineamento temporale VMI/SRI/POH/VIL/ETM: i prodotti troppo vecchi rispetto al VMI vengono esclusi dalla fusione.
- Consenso atmosferico debole ItaliaMeteo-ARPAE ICON-2I, DWD ICON, ECMWF e GFS, calcolato automaticamente per zone geografiche con spread, cache e fallback radar-only.
- Terrain Engine con profilo cella→target da Copernicus DEM; la correzione orografica è limitata al 15% e non sposta la traiettoria.
- Lifecycle Engine con trend VMI/area/VIL/ETM, Lightning Jump, ambiente e probabilità di sopravvivenza fino al target.
- Verifica a slot ed eventi TP/FP/FN/TN, inclusi eventi mancati senza alcuna previsione, più Brier Score, CSI, recall ed errore ETA.
- Sensori locali opzionali via snapshot JSON, HTTPS o MQTT/TLS; possono solo confermare, non guidare il moto radar.
- Storm Initiation Watch informativo, sempre etichettato come potenziale innesco e non come cella osservata.
- Adaptive Forecast AI inizialmente dormiente: collection → shadow → eligible → active_guarded; richiede almeno 80 verifiche, 12 eventi distinti, casi positivi/negativi, vantaggio Brier e controllo falsi negativi.
- Ogni modello batch nuovo torna obbligatoriamente shadow per almeno 25 verifiche; influenza iniziale 20%, delta massimo 18 punti e circuit breaker automatico.
- Alert separati per primo avviso, rischio in aumento, traiettoria meno probabile e minaccia rientrata.
- Dashboard con track attivi, optical flow, previsioni target, consenso NWP, lifecycle, AI shadow e avanzamento calibrazione.

La percentuale d'impatto e la confidenza sono deliberatamente separate: VMI/POH/VIL/ETM/LGT descrivono la pericolosità e la qualità dei dati, ma non possono spostare artificialmente la traiettoria geometrica.

## Correzioni di sicurezza 2.2.8

- Update autenticati con firma Ed25519 detached e chiave privata locale leggibile solo da root.
- Seconda verifica indipendente nell’helper privilegiato, snapshot root-owned anti-TOCTOU e rollback su errore.
- Policy ZIP unica: limiti compressi/espansi, rapporto anti-bomb, entry count, blocco traversal, symlink, file speciali, duplicati e case collision.
- Backup WebGUI limitati a `config.yml` e, su richiesta, `secrets.env`: non possono più sostituire codice o unità systemd.
- Sudoers senza wildcard: la WebGUI può invocare solo quattro comandi con argomenti esatti.
- Fix DOM-XSS nella ricerca geografica e nei popup Leaflet; rendering dei dati remoti tramite `textContent`.
- Leaflet 1.9.4 incluso localmente; CSP con nonce e nessun `unsafe-inline` per gli script.
- Rate limiting login, rotazione sessione/CSRF dopo l’accesso, logout POST, cache privata `no-store` e opzione `Ricordami` protetta con limite assoluto configurabile.
- Limiti sui raster, sulle tile PNG e sui layer LGT; controllo endpoint pubblici per mitigare SSRF.
- Runtime Python 3.12 e dipendenze con floor di sicurezza: Flask 3.1.3, Waitress 3.0.2, Pillow 12.3.0.

L’analisi completa, i vettori e la spiegazione delle modifiche sono in `SECURITY_REPORT.md`.

## Installazione completa

Su AlmaLinux/RHEL 9.4 o successivo:

Scaricare **Code → Download ZIP** da GitHub, quindi:

```bash
unzip ldz-meteo-app-v2-main.zip
cd ldz-meteo-app-v2-main
sudo ./install.sh
```

L’installer usa Python 3.12 in virtualenv separati e non modifica il Python predefinito del sistema.

### Aggiornamento ponte dalla 2.4.1

Scaricare dalla Release `v2.4.2` l'asset
`ldz-meteo-app-2.4.2-update.zip`, copiarlo sul server e usare il signer già
installato dalla 2.4.1:

```bash
sudo /usr/local/sbin/ldz-meteo-sign-update /root/ldz-meteo-app-2.4.2-update.zip
sudo /usr/local/sbin/ldz-meteo-apply-hotfix \
  /root/ldz-meteo-app-2.4.2-update.zip \
  /root/ldz-meteo-app-2.4.2-update.zip.sig
```

Il pacchetto della Release è già costruito con manifest completo e senza file
di sviluppo o vecchi archivi `dist/`. Il signer 2.4.1 ne verifica struttura e
SHA-256 prima di apporre l'approvazione locale. In alternativa si possono
caricare ZIP e firma dalla vecchia pagina **Aggiorna**.

Questa è l'ultima applicazione manuale necessaria. La 2.4.2 rimuove l'eventuale vecchio token updater, conserva target, soglie e impostazioni, quindi usa il canale pubblico senza credenziali. Dopo il riavvio aprire **Aggiornamenti** e premere **Cerca aggiornamenti**.

### Migrazione una tantum dalla 2.2.7 o precedente

Il vecchio updater 2.2.7 non conosce ancora firme né migrazione dei virtualenv. Per chiudere completamente il passaggio:

1. caricare questo ZIP dalla vecchia pagina **Aggiorna**; il vecchio helper installerà i nuovi sorgenti;
2. da SSH/root installare Python 3.12 se manca: `dnf install -y python3.12 python3.12-pip python3.12-devel`;
3. eseguire `sudo ldz-meteo-repair` per restringere sudoers/systemd e generare le chiavi locali;
4. firmare una copia server-side dell'update: `sudo /usr/local/sbin/ldz-meteo-sign-update /percorso/ldz-meteo-app-2.3.0-update.zip`;
5. applicarla una seconda volta con `sudo /usr/local/sbin/ldz-meteo-apply-hotfix /percorso/ldz-meteo-app-2.3.0-update.zip`.

La seconda applicazione verifica la firma, ricrea i virtualenv Python 3.12, esegue `pip check` e completa il nuovo sandbox. Dopo questa migrazione, tutti gli update successivi richiedono ZIP + `.sig`.

## Aggiornamenti automatici con approvazione firmata locale

La chiave Ed25519 viene generata sul server durante l’installazione:

- privata: `/etc/ldz-meteo-web/update-signing-private.pem`, mode `0600`, root-only;
- pubblica: `/etc/ldz-meteo-web/update-signing-public.pem`.

Per gli aggiornamenti ordinari non serve più usare la shell: dopo **Scarica e verifica**, il pulsante **Installa** approva il pacchetto con la chiave privata locale e richiama l'helper protetto. La firma non viene generata durante il semplice controllo o download.

La procedura manuale di emergenza resta disponibile. Prima di caricare uno ZIP esterno, l’amministratore lo approva da shell:

```bash
sudo ldz-meteo-sign-update /percorso/ldz-meteo-update.zip
```

Il comando genera `/percorso/ldz-meteo-update.zip.sig`. Nella pagina **Aggiorna** vanno caricati entrambi i file. Non copiare né esporre la chiave privata.

## Backup e ripristino

I backup schema 2 delle release 2.2.8 e successive sono deliberatamente data-only. Un restore dalla WebGUI può ripristinare configurazione e segreti, ma non engine, helper, virtualenv, Apache o systemd. Per un disaster recovery completo usare anche un backup amministrativo della VM/server.

## Test

```bash
./tests/run_tests.sh
python3 -m py_compile web/app.py web/security_utils.py engine/*.py
bash -n install.sh apply_hotfix.sh scripts/ldz-meteo-* scripts/build-release-package
```

## Struttura

- `engine/meteo_alert.py`: acquisizione Radar-DPC, alert, render e orchestrazione.
- `engine/precision_engine.py`: tracking, Kalman, optical flow, geometrie, ensemble e calibrazione.
- `engine/terrain_lifecycle.py`: orografia, ciclo vitale, Lightning Jump e Initiation Watch.
- `engine/adaptive_ai.py`: modello online shadow/guarded e circuit breaker.
- `engine/adaptive_ai_trainer.py`: training batch isolato con holdout cronologico e candidato JSON sicuro.
- `web/`: WebGUI Flask/Waitress, template e asset locali.
- `scripts/`: helper operativi, restore data-only, updater firmato e signer root.
- `install.sh`: installer full stack AlmaLinux/RHEL.
- `SECURITY_REPORT.md`: threat model, fix, mitigazioni e test.
- `TESTED.md`: evidenze dei controlli eseguiti sulla release.
