#!/usr/bin/env python3
from __future__ import annotations

import json
import fcntl
import math
import os
import re
import stat
import hmac
import hashlib
import secrets
import subprocess
import sys
import time
import urllib.parse
import urllib.request
import urllib.error
import zipfile
from tempfile import NamedTemporaryFile
from collections import deque
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path
from typing import Any

import yaml
from flask import Flask, abort, flash, g, jsonify, redirect, render_template, request, send_file, session, url_for, Response
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.security import check_password_hash
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer
from security_utils import ArchivePolicyError, sha256_file, validate_archive, verify_update_signature

APP_NAME = "LDZ Meteo App"
APP_VERSION = "2.4.3"
ASSET_VERSION = "2.4.3-ui1"


def parse_env_file(path: str | Path) -> dict[str, str]:
    env: dict[str, str] = {}
    p = Path(path)
    if not p.exists():
        return env
    for raw in p.read_text(errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        env[key.strip()] = value.strip().strip('"').strip("'")
    return env


WEB_ENV_PATH = Path(os.environ.get("LDZ_METEO_WEB_ENV", "/etc/ldz-meteo-web/web.env"))
WEB_ENV = parse_env_file(WEB_ENV_PATH)

CONFIG_PATH = Path(WEB_ENV.get("LDZ_METEO_CONFIG", "/etc/meteo-alert/config.yml"))
SECRETS_PATH = Path(WEB_ENV.get("LDZ_METEO_SECRETS", "/etc/meteo-alert/secrets.env"))
METEO_PYTHON = WEB_ENV.get("LDZ_METEO_PYTHON", "/opt/meteo-alert/venv/bin/python")
METEO_SCRIPT = WEB_ENV.get("LDZ_METEO_SCRIPT", "/opt/meteo-alert/meteo_alert.py")
METEO_LOG = Path(WEB_ENV.get("LDZ_METEO_LOG", "/var/log/meteo-alert/meteo-alert.log"))
PUBLIC_IMAGE = Path(WEB_ENV.get("LDZ_METEO_PUBLIC_IMAGE", "/var/www/html/meteo.jpg"))
PLACEHOLDER_IMAGE = Path(WEB_ENV.get("LDZ_METEO_PLACEHOLDER_IMAGE", str(Path(__file__).resolve().parent / "static" / "radar-placeholder.jpg")))
BACKUP_DIR = Path(WEB_ENV.get("LDZ_METEO_BACKUP_DIR", "/var/lib/ldz-meteo-web/backups"))
MPLCONFIGDIR = WEB_ENV.get("MPLCONFIGDIR", "/var/lib/meteo-alert/matplotlib")
WEB_PORT = int(WEB_ENV.get("LDZ_METEO_WEB_PORT", "8090"))
WEB_HOST = WEB_ENV.get("LDZ_METEO_WEB_HOST", "127.0.0.1")
APP_PREFIX = WEB_ENV.get("LDZ_METEO_APP_PREFIX", "/ldzmeteoapp").rstrip("/") or "/ldzmeteoapp"
PUBLIC_BASE_URL = WEB_ENV.get("LDZ_METEO_PUBLIC_BASE_URL", f"http://127.0.0.1{APP_PREFIX}")
REQUIRE_HTTPS = WEB_ENV.get("LDZ_METEO_REQUIRE_HTTPS", "false").lower() in ("1", "true", "yes", "y", "s", "si")
ALLOWED_HOSTS = [h.strip().lower() for h in WEB_ENV.get("LDZ_METEO_ALLOWED_HOSTS", "").split(",") if h.strip()]
ALLOWED_ORIGINS = [o.strip().rstrip("/") for o in WEB_ENV.get("LDZ_METEO_ALLOWED_ORIGINS", "").split(",") if o.strip()]
ROOT_ACTIONS_ENABLED = WEB_ENV.get("LDZ_METEO_ROOT_ACTIONS_ENABLED", "false").lower() in ("1", "true", "yes", "y", "s", "si")
ALLOW_EXTERNAL_ASSETS = WEB_ENV.get("LDZ_METEO_ALLOW_EXTERNAL_ASSETS", "true").lower() in ("1", "true", "yes", "y", "s", "si")
BACKUP_EXPORT_DIR = Path(WEB_ENV.get("LDZ_METEO_BACKUP_EXPORT_DIR", "/var/lib/ldz-meteo-web/exports"))
RESTORE_UPLOAD_DIR = Path(WEB_ENV.get("LDZ_METEO_RESTORE_UPLOAD_DIR", "/var/lib/ldz-meteo-web/uploads"))
UPDATE_UPLOAD_DIR = Path(WEB_ENV.get("LDZ_METEO_UPDATE_UPLOAD_DIR", "/var/lib/ldz-meteo-web/updates"))
GEOCODE_CACHE_FILE = Path(WEB_ENV.get("LDZ_METEO_GEOCODE_CACHE", "/var/lib/ldz-meteo-web/geocode_cache.json"))
GEOCODE_USER_AGENT = WEB_ENV.get("LDZ_METEO_GEOCODE_USER_AGENT", f"LDZMeteoApp/{APP_VERSION} ({PUBLIC_BASE_URL})")
GEOCODE_EMAIL = WEB_ENV.get("LDZ_METEO_GEOCODE_EMAIL", "").strip()
UPDATE_SIGNING_PUBLIC_KEY = Path(WEB_ENV.get("LDZ_METEO_UPDATE_SIGNING_PUBLIC_KEY", "/etc/ldz-meteo-web/update-signing-public.pem"))
PENDING_UPDATE_FILE = Path(WEB_ENV.get("LDZ_METEO_PENDING_UPDATE_FILE", "/var/lib/ldz-meteo-web/pending-update"))
PENDING_RESTORE_FILE = Path(WEB_ENV.get("LDZ_METEO_PENDING_RESTORE_FILE", "/var/lib/ldz-meteo-web/pending-restore"))
UPDATE_STATE_FILE = Path(WEB_ENV.get("LDZ_METEO_UPDATE_STATE", "/var/lib/ldz-meteo-web/update-state.json"))
UPDATE_SETTINGS_FILE = Path(WEB_ENV.get("LDZ_METEO_UPDATE_SETTINGS", "/var/lib/ldz-meteo-web/update-settings.json"))
UPDATE_CHECKER = WEB_ENV.get("LDZ_METEO_UPDATE_CHECKER", "/usr/local/sbin/ldz-meteo-update-check")
UPDATE_NETWORK_ROOT = WEB_ENV.get("LDZ_METEO_UPDATE_NETWORK_ROOT", "https://alexandersss.github.io/ldz-meteo-app-updates")
LOGIN_WINDOW_SECONDS = max(60, min(3600, int(WEB_ENV.get("LDZ_METEO_LOGIN_WINDOW_SECONDS", "900"))))
LOGIN_MAX_FAILURES = max(3, min(20, int(WEB_ENV.get("LDZ_METEO_LOGIN_MAX_FAILURES", "5"))))
SESSION_MINUTES = max(5, min(1440, int(WEB_ENV.get("LDZ_METEO_SESSION_MINUTES", "30"))))
REMEMBER_DAYS = max(1, min(90, int(WEB_ENV.get("LDZ_METEO_REMEMBER_DAYS", "30"))))
REMEMBER_COOKIE_NAME = "ldz_meteo_remember"
REMEMBER_COOKIE_PATH = "/"
MAX_UPDATE_BYTES = 80 * 1024 * 1024
MAX_RESTORE_BYTES = 8 * 1024 * 1024

app = Flask(__name__)
app.secret_key = WEB_ENV.get("LDZ_METEO_WEB_SECRET_KEY", "")
if not app.secret_key or len(app.secret_key) < 32:
    raise RuntimeError("LDZ_METEO_WEB_SECRET_KEY mancante o troppo corta (minimo 32 caratteri)")
app.config.update(
    MAX_CONTENT_LENGTH=90 * 1024 * 1024,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=PUBLIC_BASE_URL.lower().startswith("https://"),
    SESSION_COOKIE_NAME="ldz_meteo_session",
    PERMANENT_SESSION_LIFETIME=timedelta(days=REMEMBER_DAYS),
    SESSION_REFRESH_EACH_REQUEST=True,
)
app.wsgi_app = ProxyFix(app.wsgi_app, x_prefix=1, x_proto=1, x_host=1)

LOGIN_FAILURES: dict[str, deque[float]] = {}
REMEMBER_SERIALIZER = URLSafeTimedSerializer(app.secret_key, salt="ldz-meteo-remember-v1")


def password_fingerprint() -> str:
    value = WEB_ENV.get("LDZ_METEO_WEB_PASSWORD_HASH", "")
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:24]


def make_remember_token(username: str) -> str:
    return REMEMBER_SERIALIZER.dumps({"u": username, "p": password_fingerprint()})


def restore_remembered_session() -> bool:
    """Ricrea la sessione breve da un cookie persistente firmato e revocabile."""
    if session.get("logged_in") or request.endpoint in ("static", "logout"):
        return False
    tokens = [str(value) for value in request.cookies.getlist(REMEMBER_COOKIE_NAME) if value]
    if not tokens:
        return False
    expected_user = WEB_ENV.get("LDZ_METEO_WEB_USERNAME", "admin")
    username = ""
    valid_token = ""
    for token in tokens:
        try:
            payload = REMEMBER_SERIALIZER.loads(token, max_age=REMEMBER_DAYS * 86400)
        except (BadSignature, SignatureExpired):
            continue
        candidate_user = str(payload.get("u", "")) if isinstance(payload, dict) else ""
        fingerprint = str(payload.get("p", "")) if isinstance(payload, dict) else ""
        if hmac.compare_digest(candidate_user, expected_user) and hmac.compare_digest(fingerprint, password_fingerprint()):
            username = candidate_user
            valid_token = token
            break
    if not valid_token:
        g.clear_remember_cookie = True
        return False
    now = int(time.time())
    session.clear()
    session.permanent = True
    session.update(logged_in=True, username=username, remember_me=True, auth_started_at=now, last_seen_at=now)
    # Migra in modo trasparente il cookie delle release precedenti dal path
    # /ldzmeteoapp/ al path /. Il token resta lo stesso e non prolunga la sua
    # validità crittografica originaria.
    g.refresh_remember_cookie = valid_token
    return True


def set_remember_cookie(response: Response, token: str) -> None:
    response.set_cookie(
        REMEMBER_COOKIE_NAME,
        token,
        max_age=REMEMBER_DAYS * 86400,
        secure=PUBLIC_BASE_URL.lower().startswith("https://"),
        httponly=True,
        samesite="Lax",
        path=REMEMBER_COOKIE_PATH,
    )
    # Rimuove l'eventuale cookie creato dalle release precedenti sul solo
    # prefisso dell'app. Due cookie omonimi con path diversi possono essere
    # inviati insieme e rendere non deterministico il token letto da Flask.
    if f"{APP_PREFIX}/" != REMEMBER_COOKIE_PATH:
        response.delete_cookie(
            REMEMBER_COOKIE_NAME,
            secure=PUBLIC_BASE_URL.lower().startswith("https://"),
            httponly=True,
            samesite="Lax",
            path=f"{APP_PREFIX}/",
        )


def clear_remember_cookie(response: Response) -> None:
    for cookie_path in {REMEMBER_COOKIE_PATH, f"{APP_PREFIX}/"}:
        response.delete_cookie(
            REMEMBER_COOKIE_NAME,
            secure=PUBLIC_BASE_URL.lower().startswith("https://"),
            httponly=True,
            samesite="Lax",
            path=cookie_path,
        )


def split_host(host_header: str) -> str:
    return (host_header or "").split(":", 1)[0].strip().lower()


def is_safe_next_url(target: str | None) -> bool:
    if not target:
        return False
    parsed = urllib.parse.urlparse(target)
    return parsed.scheme == "" and parsed.netloc == "" and target.startswith("/")


def get_csrf_token() -> str:
    token = session.get("_csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["_csrf_token"] = token
    return str(token)


def csrf_field() -> str:
    return f'<input type="hidden" name="_csrf_token" value="{get_csrf_token()}">'


def validate_csrf_token() -> bool:
    expected = session.get("_csrf_token")
    supplied = request.form.get("_csrf_token") or request.headers.get("X-CSRF-Token")
    return bool(expected and supplied and hmac.compare_digest(str(expected), str(supplied)))


def origin_is_allowed() -> bool:
    if not ALLOWED_ORIGINS:
        return True
    origin = request.headers.get("Origin")
    if origin and origin != "null":
        return origin.rstrip("/") in ALLOWED_ORIGINS
    referer = request.headers.get("Referer")
    if referer:
        parsed = urllib.parse.urlparse(referer)
        ref_origin = f"{parsed.scheme}://{parsed.netloc}".rstrip("/")
        return ref_origin in ALLOWED_ORIGINS
    # Origin assente/null: non blocchiamo se il CSRF token è valido.
    return True


def login_rate_key(username: str = "") -> str:
    remote = request.remote_addr or "unknown"
    return remote


def login_is_limited(key: str) -> bool:
    now = time.monotonic()
    failures = LOGIN_FAILURES.setdefault(key, deque())
    while failures and now - failures[0] > LOGIN_WINDOW_SECONDS:
        failures.popleft()
    return len(failures) >= LOGIN_MAX_FAILURES


def record_login_failure(key: str) -> None:
    failures = LOGIN_FAILURES.setdefault(key, deque())
    failures.append(time.monotonic())


def clear_login_failures(key: str) -> None:
    LOGIN_FAILURES.pop(key, None)


def session_expired(now: int | None = None) -> bool:
    """Enforce a short idle timeout or the absolute remembered-session limit."""
    if not session.get("logged_in"):
        return False
    current = int(time.time()) if now is None else int(now)
    try:
        started_at = int(session.get("auth_started_at", 0))
        last_seen_at = int(session.get("last_seen_at", 0))
    except (TypeError, ValueError):
        return True
    if started_at <= 0 or last_seen_at <= 0 or current < started_at or current < last_seen_at:
        return True
    if session.get("remember_me") is True:
        return current - started_at > REMEMBER_DAYS * 86400
    return current - last_seen_at > SESSION_MINUTES * 60


@app.before_request
def security_gate():
    g.csp_nonce = secrets.token_urlsafe(18)
    if ALLOWED_HOSTS:
        host = split_host(request.host)
        if host not in ALLOWED_HOSTS:
            abort(Response(f"Host non consentito: {host}", 403))
    if REQUIRE_HTTPS and not request.is_secure:
        return redirect(request.url.replace("http://", "https://", 1), code=301)
    restore_remembered_session()
    if session.get("logged_in"):
        if session_expired():
            session.clear()
            if request.endpoint not in ("login", "static"):
                return redirect(url_for("login", next=request.path))
        elif request.endpoint != "static":
            session["last_seen_at"] = int(time.time())
    if request.method == "POST":
        if not validate_csrf_token():
            abort(Response("CSRF token non valido.", 403))
        if not origin_is_allowed():
            abort(Response(f"Origin non valido: {request.headers.get('Origin')}", 403))


@app.after_request
def security_headers(resp):
    if getattr(g, "clear_remember_cookie", False):
        clear_remember_cookie(resp)
    elif getattr(g, "refresh_remember_cookie", ""):
        set_remember_cookie(resp, str(g.refresh_remember_cookie))
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    resp.headers.setdefault("Permissions-Policy", "geolocation=(), microphone=(), camera=()")
    nonce = getattr(g, "csp_nonce", "")
    csp = [
        "default-src 'self'",
        "img-src 'self' data: https://*.tile.openstreetmap.org https://tile.openstreetmap.org",
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
        f"script-src 'self' 'nonce-{nonce}'",
        "font-src 'self' data: https://fonts.gstatic.com",
        "connect-src 'self' https://nominatim.openstreetmap.org",
        "frame-ancestors 'none'",
        "base-uri 'self'",
        "form-action 'self'",
    ]
    resp.headers.setdefault("Content-Security-Policy", "; ".join(csp))
    resp.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
    resp.headers.setdefault("Cross-Origin-Resource-Policy", "same-origin")
    if request.endpoint == "static":
        resp.headers.setdefault("Cache-Control", "public, max-age=86400")
    else:
        resp.headers.setdefault("Cache-Control", "private, no-store, max-age=0")
        resp.headers.setdefault("Pragma", "no-cache")
    if PUBLIC_BASE_URL.lower().startswith("https://"):
        resp.headers.setdefault("Strict-Transport-Security", "max-age=31536000")
    return resp


def require_root_actions(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not ROOT_ACTIONS_ENABLED:
            flash("Azione root disabilitata dall'hardening. Abilitala solo se la WebGUI è protetta.", "error")
            return redirect(url_for("dashboard"))
        return fn(*args, **kwargs)
    return wrapper


NAV_ITEMS = [
    {"endpoint": "dashboard", "label": "Dashboard", "icon": "⌁", "desc": "Vista operativa con radar, rischio, stato live, target e timeline eventi."},
    {"endpoint": "targets", "label": "Target", "icon": "◎", "desc": "Gestisci città, coordinate e raggio di monitoraggio, anche con ricerca e mappa."},
    {"endpoint": "appearance_page", "label": "Aspetto", "icon": "◐", "desc": "Scegli tema, look grafico e wallpaper della WebGUI."},
    {"endpoint": "settings", "label": "Regole", "icon": "⚙", "desc": "Configura soglie VMI, ETA/preavviso, cooldown e quiet hours."},
    {"endpoint": "telegram_page", "label": "Telegram", "icon": "✈", "desc": "Controlla bot, chat ID, invio messaggi e foto di test."},
    {"endpoint": "templates_page", "label": "Template", "icon": "✎", "desc": "Personalizza il testo degli alert Telegram con variabili dinamiche."},
    {"endpoint": "channels_page", "label": "Canali", "icon": "◌", "desc": "Configura webhook generico ed email SMTP per notifiche aggiuntive."},
    {"endpoint": "lightning_page", "label": "Fulmini", "icon": "ϟ", "desc": "Verifica il rischio elettrico tramite Open-Meteo o OpenWeather."},
    {"endpoint": "history_page", "label": "Storico", "icon": "⏲", "desc": "Consulta alert salvati, statistiche, grafici e timeline storica."},
    {"endpoint": "events_feedback_page", "label": "Eventi & feedback", "icon": "✓", "desc": "Rivedi decisioni, replay e riscontri reali raccolti tramite Telegram."},
    {"endpoint": "diagnostics_page", "label": "Diagnostica", "icon": "✚", "desc": "Esegue controlli su timer, servizi, config, Apache, DPC e permessi."},
    {"endpoint": "logs", "label": "Log", "icon": "≡", "desc": "Mostra log applicativi e output dei servizi per troubleshooting rapido."},
    {"endpoint": "backup_page", "label": "Backup", "icon": "⇪", "desc": "Crea e ripristina backup ZIP della configurazione e dei componenti principali."},
    {"endpoint": "maintenance_page", "label": "Manutenzione", "icon": "◇", "desc": "Imposta modalità manutenzione e messaggio operativo per interventi futuri."},
    {"endpoint": "update_page", "label": "Aggiornamenti", "icon": "⬆", "desc": "Controlla, scarica e installa nuove versioni senza usare SSH."},
    {"endpoint": "system_page", "label": "Sistema", "icon": "◈", "desc": "Controlla stato systemd di timer, motore radar, WebGUI e unità correlate."},
    {"endpoint": "kiosk_page", "label": "Kiosk", "icon": "▣", "desc": "Vista grande e pulita per monitor o display sempre acceso."},
    {"endpoint": "changelog_page", "label": "Changelog", "icon": "☷", "desc": "Storico release dalla 1.0 alla versione corrente e note anti-regressione."},
    {"endpoint": "guide_page", "label": "Readiness", "icon": "✓", "desc": "Inventario completo delle funzioni implementate e checklist anti-regressione."},
]

THEMES = {
    "dark": {"name": "Dark Classic", "description": "Tema scuro professionale, leggibile e stabile."},
    "light": {"name": "Light Clean", "description": "Tema chiaro e pulito per uso diurno."},
    "cyber": {"name": "Cyber Neon", "description": "Tema viola/blu neon stile control center futuristico."},
    "tactical": {"name": "Storm HUD", "description": "Tema nero/rosso tipo radar operativo e broadcast."},
}
DEFAULT_THEME = "dark"


def normalize_theme(value: str | None) -> str:
    value = (value or DEFAULT_THEME).strip().lower()
    return value if value in THEMES else DEFAULT_THEME


def get_current_theme() -> str:
    # Priorità: sessione utente, config globale, default.
    session_theme = session.get("theme") if "theme" in session else None
    if session_theme:
        return normalize_theme(str(session_theme))
    try:
        cfg = load_config()
        return normalize_theme(str(cfg.get("webui", {}).get("theme", DEFAULT_THEME)))
    except Exception:
        return DEFAULT_THEME


@app.context_processor
def inject_ui_context():
    theme = get_current_theme()
    return {
        "current_theme": theme,
        "themes": THEMES,
        "nav_items": NAV_ITEMS,
        "csrf_field": csrf_field,
        "root_actions_enabled": ROOT_ACTIONS_ENABLED,
        "allow_external_assets": ALLOW_EXTERNAL_ASSETS,
        "asset_version": ASSET_VERSION,
        "remember_days": REMEMBER_DAYS,
        "csp_nonce": getattr(g, "csp_nonce", ""),
        "update_banner": get_update_banner_state() if session.get("logged_in") else {"show": False},
    }


def logged_in() -> bool:
    return bool(session.get("logged_in"))


def require_login(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not logged_in():
            return redirect(url_for("login", next=request.path))
        return fn(*args, **kwargs)
    return wrapper


def load_config() -> dict[str, Any]:
    if not CONFIG_PATH.exists():
        return {}
    with CONFIG_PATH.open() as f:
        return yaml.safe_load(f) or {}


def backup_config() -> Path | None:
    if not CONFIG_PATH.exists():
        return None
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    dst = BACKUP_DIR / f"config.yml.bak.{ts}"
    dst.write_text(CONFIG_PATH.read_text())
    for old in sorted(BACKUP_DIR.glob("config.yml.bak.*"), key=lambda item: item.stat().st_mtime, reverse=True)[100:]:
        old.unlink(missing_ok=True)
    return dst


def save_config(cfg: dict[str, Any]) -> Path | None:
    """Save the root-owned, group-writable configuration safely.

    The WebGUI service can write the existing config file but deliberately
    cannot create files in /etc/meteo-alert.  Replacing it through a temporary
    sibling therefore fails with EACCES in production.  Keep the inode and its
    ownership, serialize before truncating, lock concurrent writers and refuse
    symlinks/non-regular files.
    """
    backup = backup_config()
    content = yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True).encode("utf-8")
    flags = os.O_WRONLY
    if hasattr(os, "O_CLOEXEC"):
        flags |= os.O_CLOEXEC
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    fd = os.open(CONFIG_PATH, flags)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise OSError("Il percorso configurazione non è un file regolare")
        fcntl.flock(fd, fcntl.LOCK_EX)
        os.ftruncate(fd, 0)
        view = memoryview(content)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                raise OSError("Scrittura configurazione incompleta")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)
    return backup


def load_secrets() -> dict[str, str]:
    return parse_env_file(SECRETS_PATH)


def safe_int(value: Any, default: int, minimum: int | None = None, maximum: int | None = None) -> int:
    try:
        v = int(str(value).strip())
    except Exception:
        v = default
    if minimum is not None:
        v = max(minimum, v)
    if maximum is not None:
        v = min(maximum, v)
    return v


def safe_float(value: Any, default: float, minimum: float | None = None, maximum: float | None = None) -> float:
    try:
        v = float(str(value).strip())
    except Exception:
        v = default
    if minimum is not None:
        v = max(minimum, v)
    if maximum is not None:
        v = min(maximum, v)
    return v


def safe_text(value: Any, maximum: int, *, multiline: bool = False) -> str:
    text = str(value or "").strip()
    if multiline:
        text = "".join(char for char in text if char in "\n\t" or ord(char) >= 32)
    else:
        text = " ".join("".join(char for char in text if ord(char) >= 32).split())
    return text[:maximum]


def run_cmd(cmd: list[str], timeout: int = 45) -> tuple[int, str]:
    env = os.environ.copy()
    env["MPLCONFIGDIR"] = MPLCONFIGDIR
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout, env=env)
        return p.returncode, p.stdout
    except subprocess.TimeoutExpired as exc:
        return 124, f"Timeout dopo {timeout}s\n{exc.stdout or ''}"


def systemctl_value(args: list[str]) -> str:
    code, out = run_cmd(["systemctl", *args], timeout=12)
    text = out.strip()
    return text if text else ("OK" if code == 0 else f"exit={code}")


def tail_lines(path: Path, lines: int = 250) -> list[str]:
    if not path.exists():
        return [f"Log non trovato: {path}"]
    q = deque(maxlen=lines)
    try:
        with path.open(errors="replace") as f:
            for line in f:
                q.append(line.rstrip("\n"))
    except Exception as exc:
        return [f"Errore lettura log {path}: {exc}"]
    return list(q)


def tail_file(path: Path, lines: int = 250) -> str:
    return "\n".join(tail_lines(path, lines))


def parse_recent_events(lines: list[str]) -> list[dict[str, str]]:
    events: list[dict[str, str]] = []
    keywords = [
        ("DPC-LGT stale", "warn", "Dati fulmini temporaneamente in ritardo"),
        ("stato radar SITES non disponibile", "warn", "Stato rete radar temporaneamente non disponibile"),
        ("Radar-DPC temporaneamente non disponibile", "warn", "Radar-DPC temporaneamente non disponibile"),
        ("no alerts sent", "ok", "Check completato - Nessun alert"),
        ("detected cells=0", "ok", "Celle radar analizzate - nessuna cella forte"),
        ("detected cells", "info", "Celle radar analizzate"),
        ("download product=VMI", "info", "Nuovo frame radar scaricato"),
        ("published local image", "ok", "Mappa aggiornata"),
        ("precision track=", "info", "Precision Engine - traiettoria aggiornata"),
        ("ALERT confirmed", "alert", "Alert Precision Engine confermato"),
        ("threat update", "alert", "Aggiornamento traiettoria inviato"),
        ("ALERT inside target", "alert", "Alert target coinvolto"),
        ("ALERT approaching", "alert", "Alert in avvicinamento"),
        ("ALERT sent", "alert", "Alert inviato"),
        ("quiet-hours active: alert suppressed", "info", "Alert silenziato da quiet hours"),
    ]
    for line in reversed(lines):
        msg = None
        kind = "info"
        level_match = re.match(r"^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}(?:,\d+)?\s+(DEBUG|INFO|WARNING|ERROR|CRITICAL)\b", line)
        log_level = level_match.group(1) if level_match else ""
        if log_level in {"ERROR", "CRITICAL"}:
            msg = "Errore applicazione" if log_level == "ERROR" else "Errore critico applicazione"
            kind = "error"
        else:
            for needle, event_kind, label in keywords:
                if needle.lower() in line.lower():
                    msg = label
                    kind = event_kind
                    break
        if not msg:
            continue
        ts = line[:19] if len(line) >= 19 and line[4] == "-" else "--:--:--"
        events.append({"time": ts, "kind": kind, "message": msg, "details": line[-160:]})
        if len(events) >= 8:
            break
    return events


def infer_risk(events: list[dict[str, str]]) -> dict[str, str]:
    for e in events:
        if e.get("kind") == "error":
            return {"label": "Attenzione", "badge": "bad", "subtitle": e.get("message", "Errore reale dell'applicazione")}
    for e in events:
        if e.get("kind") == "alert":
            return {"label": "Alto", "badge": "bad", "subtitle": "Alert reale rilevato/inviato"}
    for e in events:
        details = (e.get("details", "") or "").lower()
        m = re.search(r"detected cells=(\d+)", details)
        if m and int(m.group(1)) > 0:
            return {"label": "Moderato", "badge": "warn", "subtitle": "Celle forti viste: verifica traiettoria e target"}
    if any(e.get("kind") == "warn" for e in events):
        return {"label": "Basso", "badge": "ok", "subtitle": "Nessun fenomeno critico · una sorgente dati è degradata"}
    return {"label": "Basso", "badge": "ok", "subtitle": "Nessun segnale critico recente"}
def infer_last_alert(lines: list[str]) -> str:
    for line in reversed(lines):
        low = line.lower()
        if "alert inside target" in low or "alert approaching" in low or "alert sent" in low:
            return line[-100:]
    return "Nessun alert recente"


def next_check_label(cfg: dict[str, Any]) -> str:
    minutes = int(cfg.get("tracking", {}).get("check_interval_minutes", 5) or 5)
    return f"Ogni {minutes} minuti"


def masked_secret(value: str, keep_start: int = 6, keep_end: int = 4) -> str:
    if not value:
        return "Non configurato"
    if len(value) <= keep_start + keep_end:
        return "*" * len(value)
    return f"{value[:keep_start]}...{value[-keep_end:]}"


def telegram_get_me() -> dict[str, Any]:
    secrets = load_secrets()
    token = secrets.get("TELEGRAM_BOT_TOKEN", "")
    if not token:
        return {"ok": False, "description": "Token mancante"}
    url = f"https://api.telegram.org/bot{token}/getMe"
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8", errors="replace"))
    except Exception as exc:
        return {"ok": False, "description": str(exc)}


def telegram_api(method: str, data: dict[str, str], files: dict[str, Path] | None = None) -> tuple[bool, str]:
    secrets = load_secrets()
    token = secrets.get("TELEGRAM_BOT_TOKEN", "")
    chat_id = secrets.get("TELEGRAM_CHAT_ID", "")
    if not token or not chat_id:
        return False, "TELEGRAM_BOT_TOKEN o TELEGRAM_CHAT_ID mancante in secrets.env"

    url = f"https://api.telegram.org/bot{token}/{method}"
    if files:
        boundary = f"----LDZMeteoBoundary{int(time.time() * 1000)}"
        body = bytearray()
        for k, v in data.items():
            body.extend(f"--{boundary}\r\n".encode())
            body.extend(f'Content-Disposition: form-data; name="{k}"\r\n\r\n'.encode())
            body.extend(str(v).encode())
            body.extend(b"\r\n")
        for k, path in files.items():
            content = Path(path).read_bytes()
            body.extend(f"--{boundary}\r\n".encode())
            body.extend(f'Content-Disposition: form-data; name="{k}"; filename="{Path(path).name}"\r\n'.encode())
            body.extend(b"Content-Type: image/jpeg\r\n\r\n")
            body.extend(content)
            body.extend(b"\r\n")
        body.extend(f"--{boundary}--\r\n".encode())
        req = urllib.request.Request(url, data=bytes(body), headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    else:
        req = urllib.request.Request(url, data=urllib.parse.urlencode(data).encode())

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            text = resp.read().decode("utf-8", errors="replace")
        return True, text
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        return False, f"HTTP Error {exc.code}: {exc.reason}\n{body}".strip()
    except Exception as exc:
        return False, str(exc)


def list_config_backups() -> list[dict[str, str]]:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    items = []
    for p in sorted(BACKUP_DIR.glob("config.yml.bak.*"), reverse=True)[:40]:
        st = p.stat()
        items.append({
            "name": p.name,
            "path": str(p),
            "mtime": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
            "size": f"{st.st_size / 1024:.1f} KB",
        })
    return items




def is_valid_image_file(path: Path) -> bool:
    try:
        return path.exists() and path.is_file() and path.stat().st_size > 1024
    except Exception:
        return False


def no_cache(resp):
    resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    return resp


def placeholder_svg_response() -> Response:
    svg = """<svg xmlns='http://www.w3.org/2000/svg' width='1920' height='1080' viewBox='0 0 1920 1080'>
<defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#07111d'/><stop offset='1' stop-color='#0b2a44'/></linearGradient></defs>
<rect width='1920' height='1080' fill='url(#g)'/>
<rect x='260' y='260' width='1400' height='560' rx='36' fill='#0a1829' stroke='#4678b4' stroke-width='3'/>
<text x='360' y='410' fill='#eef4ff' font-family='Arial, sans-serif' font-size='72' font-weight='700'>LDZ Meteo Alert</text>
<text x='360' y='510' fill='#9ab9e6' font-family='Arial, sans-serif' font-size='38'>Mappa radar in attesa del primo frame valido</text>
<text x='360' y='590' fill='#8ca0c2' font-family='Arial, sans-serif' font-size='30'>Radar-DPC non disponibile o meteo.jpg non ancora generata.</text>
<text x='360' y='650' fill='#f4b436' font-family='Arial, sans-serif' font-size='28'>Placeholder: non rappresenta dati meteo reali.</text>
</svg>"""
    return no_cache(Response(svg, mimetype="image/svg+xml"))


def get_best_radar_image(view: str = "full") -> Path | None:
    candidates = {"full": PUBLIC_IMAGE}
    for name in ("map", "details"):
        candidates[name] = PUBLIC_IMAGE.with_name(f"{PUBLIC_IMAGE.stem}-{name}{PUBLIC_IMAGE.suffix}")
    selected = candidates.get(view, PUBLIC_IMAGE)
    if is_valid_image_file(selected):
        return selected
    if is_valid_image_file(PUBLIC_IMAGE):
        return PUBLIC_IMAGE
    if is_valid_image_file(PLACEHOLDER_IMAGE):
        return PLACEHOLDER_IMAGE
    return None


def write_backup_zip(include_secrets: bool = False) -> Path:
    BACKUP_EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    out = BACKUP_EXPORT_DIR / f"ldz-meteo-backup-{ts}.zip"
    files = [(CONFIG_PATH, "etc/meteo-alert/config.yml")]
    if include_secrets:
        files.append((SECRETS_PATH, "etc/meteo-alert/secrets.env"))
    payload: dict[str, bytes] = {}
    for source, archive_name in files:
        if not source.is_file() or source.is_symlink():
            if archive_name.endswith("config.yml"):
                raise FileNotFoundError(f"File configurazione non trovato: {source}")
            continue
        data = source.read_bytes()
        if len(data) > MAX_RESTORE_BYTES:
            raise ValueError(f"File backup troppo grande: {archive_name}")
        payload[archive_name] = data
    manifest = {
        "app": "LDZ Meteo App",
        "type": "configuration-backup",
        "schema_version": 2,
        "version": APP_VERSION,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "include_secrets": bool(include_secrets),
        "files": {name: hashlib.sha256(data).hexdigest() for name, data in sorted(payload.items())},
    }
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for archive_name, data in sorted(payload.items()):
            z.writestr(archive_name, data)
        z.writestr("manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False))
    for old in sorted(BACKUP_EXPORT_DIR.glob("ldz-meteo-backup-*.zip"), key=lambda item: item.stat().st_mtime, reverse=True)[20:]:
        old.unlink(missing_ok=True)
    return out


def save_upload_limited(file_storage, destination: Path, maximum: int) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    written = 0
    try:
        with destination.open("xb") as output:
            while True:
                chunk = file_storage.stream.read(1024 * 1024)
                if not chunk:
                    break
                written += len(chunk)
                if written > maximum:
                    raise ValueError(f"Upload oltre il limite di {maximum // (1024 * 1024)} MiB")
                output.write(chunk)
        destination.chmod(0o600)
        return destination
    except Exception:
        destination.unlink(missing_ok=True)
        raise


def safe_upload_name(filename: str, fallback: str, suffix: str) -> str:
    original = Path(filename or fallback).name
    cleaned = "".join(char for char in original if char.isalnum() or char in "._-")[:100]
    if not cleaned.lower().endswith(suffix):
        cleaned += suffix
    return cleaned or fallback


def save_uploaded_restore(file_storage) -> Path:
    RESTORE_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    name = safe_upload_name(file_storage.filename or "", "backup.zip", ".zip")
    out = RESTORE_UPLOAD_DIR / f"restore-{ts}-{secrets.token_hex(4)}-{name}"
    return save_upload_limited(file_storage, out, MAX_RESTORE_BYTES)


def save_uploaded_update(file_storage, signature_storage) -> tuple[Path, Path]:
    UPDATE_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    name = safe_upload_name(file_storage.filename or "", "hotfix.zip", ".zip")
    stem = f"update-{ts}-{secrets.token_hex(4)}-{name}"
    package = UPDATE_UPLOAD_DIR / stem
    signature = UPDATE_UPLOAD_DIR / f"{stem}.sig"
    save_upload_limited(file_storage, package, MAX_UPDATE_BYTES)
    try:
        save_upload_limited(signature_storage, signature, 4096)
    except Exception:
        package.unlink(missing_ok=True)
        raise
    for old in sorted(UPDATE_UPLOAD_DIR.glob("*.zip"), key=lambda item: item.stat().st_mtime, reverse=True)[10:]:
        old.unlink(missing_ok=True)
        old.with_name(old.name + ".sig").unlink(missing_ok=True)
    return package, signature


def verify_update_zip(path: Path, signature_path: Path | None = None) -> dict[str, Any]:
    result: dict[str, Any] = {
        "ok": False,
        "can_apply": False,
        "errors": [],
        "warnings": [],
        "files": [],
        "manifest": {},
        "root_dir": "",
        "sha256": "",
        "file_count": 0,
        "signature_valid": False,
    }
    signature_path = signature_path or path.with_name(path.name + ".sig")
    try:
        checked = validate_archive(path, "update")
        result.update({
            "manifest": checked["manifest"],
            "root_dir": checked["root_dir"],
            "file_count": checked["file_count"],
            "files": checked["files"][:120],
            "sha256": checked["sha256"],
        })
        signature_ok, signature_message = verify_update_signature(path, signature_path, UPDATE_SIGNING_PUBLIC_KEY)
        result["signature_valid"] = signature_ok
        if signature_ok:
            result["warnings"].append(signature_message)
        else:
            result["errors"].append(signature_message)
    except ArchivePolicyError as exc:
        result["errors"].append(str(exc))
    except Exception as exc:
        result["errors"].append(f"Verifica update fallita: {exc}")
    result["ok"] = not result["errors"]
    result["can_apply"] = bool(result["ok"] and result["signature_valid"])
    return result


def list_update_packages() -> list[dict[str, Any]]:
    UPDATE_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    items: list[dict[str, Any]] = []
    candidates = [p for p in UPDATE_UPLOAD_DIR.glob("*.zip") if p.is_file() and not p.is_symlink()]
    for p in sorted(candidates, key=lambda x: x.stat().st_mtime, reverse=True)[:10]:
        v = verify_update_zip(p, p.with_name(p.name + ".sig"))
        st = p.stat()
        items.append({
            "name": p.name,
            "path": str(p),
            "size": f"{st.st_size / 1024:.1f} KB",
            "mtime": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
            "ok": bool(v.get("ok")),
            "can_apply": bool(v.get("can_apply")),
            "warnings": v.get("warnings", []),
            "errors": v.get("errors", []),
            "manifest": v.get("manifest", {}),
            "sha256": v.get("sha256", ""),
            "file_count": v.get("file_count", 0),
            "root_dir": v.get("root_dir", ""),
            "signature_valid": bool(v.get("signature_valid")),
        })
    return items


def write_pending_selection(path: Path, filename: str) -> None:
    if filename != Path(filename).name or not filename or "\n" in filename or "\r" in filename:
        raise ValueError("Nome pacchetto staging non valido")
    path.parent.mkdir(parents=True, exist_ok=True)
    with NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
        handle.write(filename + "\n")
        handle.flush()
        os.fsync(handle.fileno())
        temporary = Path(handle.name)
    temporary.chmod(0o600)
    temporary.replace(path)


UPDATE_SCHEDULES = {"manuale": "manual", "oraria": "hourly", "giornaliera": "daily", "settimanale": "weekly"}
UPDATE_CHANNELS = {"stable", "beta"}


def release_version_key(value: Any) -> tuple[int, int, int, int, str]:
    match = re.fullmatch(r"v?(\d+)\.(\d+)\.(\d+)(?:[-+]([A-Za-z0-9._-]+))?", str(value or "").strip())
    if not match:
        return (0, 0, 0, -1, "")
    prerelease = match.group(4) or ""
    return (int(match.group(1)), int(match.group(2)), int(match.group(3)), 1 if not prerelease else 0, prerelease)


def read_small_json(path: Path, maximum: int = 1024 * 1024) -> dict[str, Any]:
    try:
        if path.is_symlink() or not path.is_file() or path.stat().st_size > maximum:
            return {}
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError, json.JSONDecodeError):
        return {}


def write_private_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())
        temporary = Path(handle.name)
    temporary.chmod(0o600)
    temporary.replace(path)


def write_private_json(path: Path, value: dict[str, Any]) -> None:
    write_private_text(path, json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def update_settings() -> dict[str, Any]:
    settings = {
        "enabled": True,
        "schedule": "daily",
        "channel": "stable",
        "auto_download": False,
        "telegram_notification": True,
    }
    settings.update(read_small_json(UPDATE_SETTINGS_FILE))
    if settings.get("schedule") not in UPDATE_SCHEDULES.values():
        settings["schedule"] = "daily"
    if settings.get("channel") not in UPDATE_CHANNELS:
        settings["channel"] = "stable"
    for obsolete in ("repository", "github_token", "token_configured"):
        settings.pop(obsolete, None)
    return settings


def update_state() -> dict[str, Any]:
    state = read_small_json(UPDATE_STATE_FILE)
    state.setdefault("status", "never_checked")
    state.setdefault("installed_version", APP_VERSION)
    state.setdefault("latest_version", "")
    state.setdefault("available", False)
    state.setdefault("archive_verified", False)
    if release_version_key(state.get("latest_version")) <= release_version_key(APP_VERSION):
        state["available"] = False
        if state.get("last_checked_at"):
            state["status"] = "up_to_date"
    return state


def get_update_banner_state() -> dict[str, Any]:
    state = update_state()
    try:
        snoozed = int(state.get("snoozed_until_epoch", 0) or 0) > int(time.time())
    except (TypeError, ValueError):
        snoozed = False
    available = bool(state.get("available") and state.get("latest_version"))
    return {
        "show": bool(available and not snoozed and request.endpoint != "update_page"),
        "available": available,
        "version": safe_text(state.get("latest_version", ""), 50),
        "status": safe_text(state.get("status", ""), 40),
        "downloaded": state.get("status") == "downloaded" and bool(state.get("archive_verified")),
    }


def save_update_settings_from_request() -> None:
    schedule = request.form.get("schedule", "daily")
    channel = request.form.get("channel", "stable")
    if schedule not in UPDATE_SCHEDULES.values() or channel not in UPDATE_CHANNELS:
        raise ValueError("Frequenza o canale aggiornamenti non valido")
    value = {
        "enabled": bool(request.form.get("updates_enabled")),
        "schedule": schedule,
        "channel": channel,
        "auto_download": bool(request.form.get("auto_download")),
        "telegram_notification": bool(request.form.get("telegram_notification")),
    }
    write_private_json(UPDATE_SETTINGS_FILE, value)


def run_update_checker(*args: str, timeout: int = 120) -> tuple[int, str]:
    allowed = {"--check", "--download", "--force"}
    if not args or any(arg not in allowed for arg in args):
        return 2, "Comando updater WebGUI non consentito"
    checker = Path(UPDATE_CHECKER)
    if not checker.is_file() or checker.is_symlink():
        return 127, "Helper aggiornamenti non installato"
    return run_cmd([sys.executable, str(checker), *args], timeout=timeout)


def updater_failure_message(code: int, output: str, state: dict[str, Any]) -> str:
    state_message = safe_text(state.get("error", ""), 500)
    if state_message:
        return state_message
    lines = [safe_text(line, 500) for line in str(output or "").splitlines() if line.strip()]
    if lines:
        try:
            decoded = json.loads(lines[-1])
            if isinstance(decoded, dict) and decoded.get("error"):
                return safe_text(decoded["error"], 500)
        except (ValueError, json.JSONDecodeError):
            pass
        return lines[-1]
    known = {
        124: "Il controllo ha superato il tempo massimo. Il server aggiornamenti potrebbe essere temporaneamente lento.",
        126: "Il componente aggiornamenti è presente ma non può essere eseguito.",
        127: "Il componente aggiornamenti non è installato correttamente.",
    }
    return known.get(code, f"Il controllo non è partito correttamente (codice {code}).")


def downloaded_remote_package(state: dict[str, Any]) -> Path | None:
    name = Path(str(state.get("downloaded_path", ""))).name
    expected = f"ldz-meteo-app-{state.get('latest_version', '')}-update.zip"
    if not name or name != expected or not re.fullmatch(r"ldz-meteo-app-[0-9A-Za-z.+_-]+-update\.zip", name):
        return None
    path = UPDATE_UPLOAD_DIR / name
    try:
        if path.is_file() and not path.is_symlink() and path.resolve().parent == UPDATE_UPLOAD_DIR.resolve():
            return path
    except OSError:
        pass
    return None


def verify_remote_download(state: dict[str, Any]) -> dict[str, Any]:
    package = downloaded_remote_package(state)
    if package is None:
        return {"ok": False, "errors": ["Pacchetto remoto non presente nello staging"]}
    try:
        checked = validate_archive(package, "update")
        expected = str(state.get("latest_version", ""))
        if release_version_key(expected) <= release_version_key(APP_VERSION):
            raise ArchivePolicyError(f"La versione {expected} non è più recente della versione installata {APP_VERSION}")
        if str(checked.get("version", "")) != expected:
            raise ArchivePolicyError(f"Versione pacchetto {checked.get('version')} diversa dalla release {expected}")
        expected_sha = str(state.get("archive_sha256", ""))
        if expected_sha and not hmac.compare_digest(str(checked.get("sha256", "")), expected_sha):
            raise ArchivePolicyError("SHA-256 del pacchetto cambiato dopo il download")
        return {"ok": True, **checked, "package": package}
    except (ArchivePolicyError, OSError, ValueError) as exc:
        return {"ok": False, "errors": [str(exc)]}


def open_meteo_lightning_check(targets: list[dict[str, Any]], cfg: dict[str, Any]) -> str:
    lines = []
    enabled_targets = [t for t in targets if t.get("enabled", True)]
    if not enabled_targets:
        return "Nessun target attivo."

    for t in enabled_targets:
        name = t.get("name", "target")
        lat = t.get("lat")
        lon = t.get("lon")
        if lat is None or lon is None:
            lines.append(f"{name}: coordinate mancanti")
            continue

        # Gratis: Open-Meteo non restituisce il singolo fulmine osservato.
        # Usiamo weather_code + CAPE come stima del rischio attività elettrica.
        base = "https://api.open-meteo.com/v1/forecast"
        params = {
            "latitude": str(lat),
            "longitude": str(lon),
            "hourly": "weather_code,cape",
            "forecast_days": "1",
            "timezone": "Europe/Rome",
        }
        url = base + "?" + urllib.parse.urlencode(params)
        try:
            with urllib.request.urlopen(url, timeout=20) as resp:
                data = json.loads(resp.read().decode("utf-8", errors="replace"))
        except Exception as exc:
            # Fallback senza CAPE se il modello scelto non la espone.
            params["hourly"] = "weather_code"
            url = base + "?" + urllib.parse.urlencode(params)
            try:
                with urllib.request.urlopen(url, timeout=20) as resp:
                    data = json.loads(resp.read().decode("utf-8", errors="replace"))
            except Exception as exc2:
                lines.append(f"{name}: errore Open-Meteo: {exc2}")
                continue

        hourly = data.get("hourly", {})
        times = hourly.get("time", [])[:6]
        codes = hourly.get("weather_code", [])[:6]
        cape = hourly.get("cape", [])[:6] if "cape" in hourly else []

        thunder = any(int(c or 0) in (95, 96, 99) for c in codes)
        max_cape = max([float(x or 0) for x in cape], default=0.0)
        if thunder or max_cape >= 1000:
            risk = "ALTO"
        elif max_cape >= 500:
            risk = "MEDIO"
        else:
            risk = "BASSO"

        lines.append(
            f"{name}: rischio elettrico stimato {risk} | temporale WMO={'Sì' if thunder else 'No'} | CAPE max {max_cape:.0f} J/kg | prossime ore: {', '.join(map(str, codes[:4]))}"
        )

    return "\n".join(lines)


def openweather_lightning_check(targets: list[dict[str, Any]], cfg: dict[str, Any]) -> str:
    lightning = cfg.get("lightning", {})
    api_key = lightning.get("openweather_api_key") or load_secrets().get("OPENWEATHER_API_KEY", "")
    if not api_key:
        return "OpenWeather selezionato, ma API key non configurata."

    from datetime import timezone, timedelta
    end = datetime.now(timezone.utc)
    window = int(lightning.get("window_minutes", 15) or 15)
    start = end - timedelta(minutes=max(1, min(1440, window)))
    radius = float(lightning.get("radius_km", 20) or 20)
    radius = max(0.1, min(50.0, radius))

    lines = []
    for t in [x for x in targets if x.get("enabled", True)]:
        name = t.get("name", "target")
        base = "https://api.openweathermap.org/lightning/1.0/data"
        params = {
            "lat": str(t.get("lat")),
            "lon": str(t.get("lon")),
            "radius": str(radius),
            "start_date": start.isoformat().replace("+00:00", "Z"),
            "end_date": end.isoformat().replace("+00:00", "Z"),
            "apikey": api_key,
        }
        url = base + "?" + urllib.parse.urlencode(params)
        try:
            with urllib.request.urlopen(url, timeout=20) as resp:
                data = json.loads(resp.read().decode("utf-8", errors="replace"))
            count = len(data if isinstance(data, list) else data.get("data", []))
            lines.append(f"{name}: fulmini osservati ultimi {window} min entro {radius:.0f} km = {count}")
        except Exception as exc:
            lines.append(f"{name}: errore OpenWeather: {exc}")
    return "\n".join(lines)


def haversine_km_web(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0088
    p1 = math.radians(lat1)
    p2 = math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def parse_dpc_lgt_bin_web(data: bytes, timestamp_ms: int) -> list[dict[str, float]]:
    if len(data) < 3 or data[0] != 2:
        return []
    count = int.from_bytes(data[1:3], "big", signed=False)
    out: list[dict[str, float]] = []
    offset = 3
    for _ in range(count):
        if offset + 6 > len(data):
            break
        lon_low = int.from_bytes(data[offset:offset + 2], "big", signed=False)
        lat_low = int.from_bytes(data[offset + 2:offset + 4], "big", signed=False)
        packed = data[offset + 4]
        extra_flag = data[offset + 5]
        lon18 = lon_low + (((packed >> 6) & 3) * 65536)
        lat18 = lat_low + (((packed >> 4) & 3) * 65536)
        lon = lon18 * (360.0 / 262144.0) - 180.0
        lat = lat18 * (180.0 / 262144.0) - 90.0
        if -90 <= lat <= 90 and -180 <= lon <= 180:
            out.append({"lat": lat, "lon": lon, "timestamp_ms": timestamp_ms})
        offset += 6 if extra_flag < 255 else 8
    return out


def dpc_lgt_timestamps_web(anchor_timestamp_ms: int, window_minutes: int, max_lookback_minutes: int | None = None) -> list[int]:
    step = 5 * 60 * 1000
    base = int(anchor_timestamp_ms // step * step)
    search_minutes = max(window_minutes, max_lookback_minutes or window_minutes)
    slots = max(1, min(288, int(math.ceil(max(1, search_minutes) / 5.0))))
    return [base - i * step for i in range(slots)]


def dpc_lgt_lightning_check(targets: list[dict[str, Any]], cfg: dict[str, Any]) -> str:
    lightning = cfg.get("lightning", {})
    enabled_targets = [t for t in targets if t.get("enabled", True)]
    if not enabled_targets:
        return "Nessun target attivo."

    anchor_ms = int(time.time() // 300 * 300 * 1000)

    base = str(lightning.get("dpc_lgt_base_url", "https://s3-prod-dpc-radar-webp-cache.s3.eu-south-1.amazonaws.com")).rstrip("/")
    window = max(10, int(lightning.get("window_minutes", 20) or 20))
    max_lookback = int(lightning.get("dpc_lgt_max_lookback_minutes", lightning.get("max_lookback_minutes", 180)) or 180)
    max_lookback = max(window, min(max_lookback, 720))
    max_age = int(lightning.get("dpc_lgt_max_age_minutes", lightning.get("max_age_minutes", 15)) or 15)
    max_age = max(10, min(max_age, 30))
    wanted_slots = max(1, min(12, int(math.ceil(max(1, window) / 10.0))))
    radius = float(lightning.get("radius_km", 20) or 20)
    strikes: list[dict[str, float]] = []
    used: list[int] = []
    errors: list[str] = []
    missing: dict[int, int] = {}
    next_cadence_slot: int | None = None
    for ts in dpc_lgt_timestamps_web(anchor_ms, window, max_lookback):
        if len(used) >= wanted_slots:
            break
        if next_cadence_slot is not None and ts != next_cadence_slot:
            continue
        url = f"{base}/LGT/lgt_5min_{ts}.bin"
        req = urllib.request.Request(url, headers={
            "Accept": "*/*",
            "Origin": "https://radar.protezionecivile.it",
            "Referer": "https://radar.protezionecivile.it/",
            "User-Agent": f"Mozilla/5.0 (compatible; LDZMeteoApp/{APP_VERSION})",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "cross-site",
        })
        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                data = resp.read()
            strikes.extend(parse_dpc_lgt_bin_web(data, ts))
            used.append(ts)
            next_cadence_slot = ts - 10 * 60 * 1000
        except urllib.error.HTTPError as exc:
            if exc.code in (401, 403, 404):
                missing[exc.code] = missing.get(exc.code, 0) + 1
            else:
                errors.append(f"{ts}: HTTP {exc.code}")
        except Exception as exc:
            errors.append(f"{ts}: {exc}")

    if not used:
        details = f" Errori reali: {'; '.join(errors[:3])}" if errors else ""
        miss = f" Slot mancanti S3: {missing}" if missing else ""
        return f"Radar-DPC LGT: nessun file disponibile cercando fino a {max_lookback} min indietro rispetto al frame radar.{miss}{details}"

    latest = max(used)
    lag = max(0.0, (time.time() * 1000.0 - latest) / 60000.0)
    stale = lag > max_age
    lag_txt = f" Ultimo slot LGT: {datetime.utcfromtimestamp(latest/1000).strftime('%Y-%m-%d %H:%M UTC')}"
    if lag >= 10:
        lag_txt += f" (pubblicato circa {lag:.0f} min fa)."
    freshness_txt = ""
    if stale:
        freshness_txt = f" ATTENZIONE: layer LGT troppo vecchio per gli alert live (soglia {max_age} min); viene mostrato solo come diagnostica e non usato per overlay/gating."
    else:
        freshness_txt = f" Layer LGT fresco entro soglia {max_age} min."
    lines = [f"Radar-DPC LGT OK: {len(strikes)} fulmini letti da {len(used)} quadri a cadenza ufficiale di 10 minuti.{lag_txt}{freshness_txt}"]
    for t in enabled_targets:
        name = t.get("name", "target")
        try:
            lat = float(t.get("lat")); lon = float(t.get("lon"))
        except Exception:
            lines.append(f"{name}: coordinate mancanti")
            continue
        distances = [haversine_km_web(lat, lon, float(s["lat"]), float(s["lon"])) for s in strikes]
        within = [d for d in distances if d <= radius]
        nearest = min(distances) if distances else None
        nearest_txt = "n/d" if nearest is None else f"{nearest:.1f} km"
        window_label = f"ultimi {window} min disponibili" if stale else f"ultimi {window} min"
        lines.append(f"{name}: fulmini {window_label} entro {radius:.0f} km = {len(within)} | più vicino {nearest_txt}")
    if errors:
        lines.append("Note: " + "; ".join(errors[:3]))
    return "\n".join(lines)



def get_image_age_minutes(path: Path) -> float | None:
    if not is_valid_image_file(path):
        return None
    try:
        return max(0.0, (time.time() - path.stat().st_mtime) / 60.0)
    except Exception:
        return None


def compute_health(status: dict[str, Any]) -> dict[str, Any]:
    score = 100
    issues: list[str] = []

    if status.get("timer_active") != "active":
        score -= 25
        issues.append("Timer non attivo")
    if status.get("timer_enabled") != "enabled":
        score -= 10
        issues.append("Timer non abilitato")

    image_age = get_image_age_minutes(PUBLIC_IMAGE)
    if image_age is None:
        score -= 20
        issues.append("Mappa reale non ancora disponibile")
    elif image_age > 30:
        score -= 12
        issues.append(f"Mappa vecchia: {image_age:.0f} minuti")

    if not CONFIG_PATH.exists():
        score -= 20
        issues.append("Config mancante")
    if not SECRETS_PATH.exists():
        score -= 15
        issues.append("Secrets Telegram mancanti")

    recent = "\\n".join(tail_lines(METEO_LOG, 80)).lower()
    if "radar-dpc temporaneamente non disponibile" in recent:
        score -= 8
        issues.append("Radar-DPC ha dato errori temporanei di recente")
    if "fatal error" in recent:
        score -= 15
        issues.append("Fatal error recente nel motore radar")

    score = max(0, min(100, score))
    if score >= 90:
        level = "OK"
        badge = "ok"
    elif score >= 70:
        level = "Warning"
        badge = "warn"
    else:
        level = "Critical"
        badge = "bad"
    return {"score": score, "level": level, "badge": badge, "issues": issues[:5]}


def diagnostic_checks() -> list[dict[str, str]]:
    checks: list[dict[str, str]] = []

    def add(name: str, state: str, detail: str):
        checks.append({"name": name, "state": state, "detail": detail})

    code, out = run_cmd(["systemctl", "is-active", "meteo-alert.timer"], timeout=10)
    add("Timer meteo-alert", "ok" if out.strip() == "active" else "error", out.strip() or f"exit={code}")

    code, out = run_cmd(["systemctl", "is-active", "ldz-meteo-web.service"], timeout=10)
    add("WebGUI service", "ok" if out.strip() == "active" else "error", out.strip() or f"exit={code}")

    code, out = run_cmd(["systemctl", "is-active", "meteo-alert-radar-events.service"], timeout=10)
    add("WebSocket Radar-DPC", "ok" if out.strip() == "active" else "warn", out.strip() or f"exit={code} · il timer resta il fallback")

    code, out = run_cmd(["systemctl", "is-active", "meteo-alert-telegram-feedback.service"], timeout=10)
    add("Feedback Telegram immediato", "ok" if out.strip() == "active" else "error", out.strip() or f"exit={code}")

    code, out = run_cmd(["systemctl", "is-active", "meteo-alert-watchdog.timer"], timeout=10)
    add("Watchdog esterno", "ok" if out.strip() == "active" else "warn", out.strip() or f"exit={code}")

    code, out = run_cmd(["systemctl", "is-active", "ldz-meteo-update-check.timer"], timeout=10)
    add("Controllo aggiornamenti", "ok" if out.strip() == "active" else "warn", out.strip() or f"exit={code}")

    add("Config YAML", "ok" if CONFIG_PATH.exists() else "error", str(CONFIG_PATH))
    add("Secrets Telegram", "ok" if SECRETS_PATH.exists() else "warn", str(SECRETS_PATH))

    if is_valid_image_file(PUBLIC_IMAGE):
        age = get_image_age_minutes(PUBLIC_IMAGE)
        add("Mappa reale meteo.jpg", "ok" if age is not None and age < 30 else "warn", f"{PUBLIC_IMAGE} · età {age:.0f} min" if age is not None else str(PUBLIC_IMAGE))
    elif is_valid_image_file(PLACEHOLDER_IMAGE):
        add("Mappa reale meteo.jpg", "warn", "Mappa reale non ancora generata, placeholder disponibile")
    else:
        add("Mappa reale meteo.jpg", "error", "Nessuna immagine valida disponibile")

    # Radar-DPC v2 richiede una vera GET e gli header Origin/Referer della piattaforma radar.
    # Usare HEAD/-I puo' produrre falsi WARN/403 anche quando l'API GET e' utilizzabile.
    code, out = run_cmd([
        "/usr/bin/curl", "-sS", "--max-time", "10",
        "-o", "/dev/null", "-w", "HTTP/%{http_version} %{http_code}",
        "-H", "Origin: https://radar.protezionecivile.it",
        "-H", "Referer: https://radar.protezionecivile.it/",
        "-H", "Accept: application/json,text/plain,*/*",
        "-A", f"LDZMeteoApp/{APP_VERSION} (+https://radar.protezionecivile.it/)",
        "https://radar-api.protezionecivile.it/findLastProductByType?type=VMI",
    ], timeout=15)
    first = out.splitlines()[-1] if out.strip() else f"exit={code}"
    if " 200" in first or first.endswith(" 200"):
        add("Radar-DPC endpoint", "ok", first)
    elif any(s in first for s in (" 503", " 502", " 504", " 429")):
        add("Radar-DPC endpoint", "warn", first + " · servizio remoto temporaneamente non disponibile")
    elif " 403" in first or first.endswith(" 403"):
        add("Radar-DPC endpoint", "warn", first + " · endpoint remoto ha rifiutato la richiesta")
    else:
        add("Radar-DPC endpoint", "warn" if code == 0 else "error", first)

    code, out = run_cmd(["/usr/bin/curl", "-sS", "-I", "--max-time", "10", f"http://127.0.0.1:{WEB_PORT}/login"], timeout=15)
    first_line = out.splitlines()[0] if out.strip() else f"exit={code}"
    add("Waitress locale", "ok" if "200" in first_line else "warn", first_line)

    code, out = run_cmd(["/usr/sbin/apachectl", "configtest"], timeout=15)
    add("Apache config", "ok" if code == 0 else "error", out.strip() or f"exit={code}")

    code, out = run_cmd(["/usr/bin/sudo", "-n", "-l", "/usr/local/sbin/ldz-meteo-sync-timer"], timeout=15)
    add("Permessi sync timer", "ok" if code == 0 else "error", out.strip()[-220:] or f"exit={code}")

    return checks


def get_dashboard_status() -> dict[str, Any]:
    cfg = load_config()
    timer_active = systemctl_value(["is-active", "meteo-alert.timer"])
    timer_enabled = systemctl_value(["is-enabled", "meteo-alert.timer"])
    img_mtime, img_size = None, None
    if is_valid_image_file(PUBLIC_IMAGE):
        st = PUBLIC_IMAGE.stat()
        img_mtime = datetime.fromtimestamp(st.st_mtime).strftime("%H:%M")
        img_size = f"{st.st_size / 1024:.0f} KB"
    elif is_valid_image_file(PLACEHOLDER_IMAGE):
        img_mtime = "placeholder"
        img_size = "placeholder"
    lines = tail_lines(METEO_LOG, 300)
    events = parse_recent_events(lines)
    engine_state: dict[str, Any] = {}
    state_path = Path(cfg.get("app", {}).get("state_file", "/var/lib/meteo-alert/state.json"))
    try:
        if state_path.is_file() and not state_path.is_symlink() and state_path.stat().st_size <= 12 * 1024 * 1024:
            loaded_state = json.loads(state_path.read_text(encoding="utf-8"))
            if isinstance(loaded_state, dict):
                engine_state = loaded_state
    except Exception:
        engine_state = {}
    precision_state = engine_state.get("precision", {}) if isinstance(engine_state.get("precision"), dict) else {}
    lightning_state = engine_state.get("last_lightning", {}) if isinstance(engine_state.get("last_lightning"), dict) else {}
    calibration = precision_state.get("calibration", {}) if isinstance(precision_state.get("calibration"), dict) else {}
    best_rows = []
    for target_name, item in (precision_state.get("last_forecasts") or {}).items():
        if not isinstance(item, dict) or not isinstance(item.get("forecast"), dict):
            continue
        forecast = item["forecast"]
        best_rows.append({
            "target": str(target_name),
            "probability": float(forecast.get("impact_probability_percent", 0.0) or 0.0),
            "confidence": float(forecast.get("impact_confidence_percent", 0.0) or 0.0),
            "eta_low": float(forecast.get("eta_low_minutes", forecast.get("eta_minutes", 0.0)) or 0.0),
            "eta_high": float(forecast.get("eta_high_minutes", forecast.get("eta_minutes", 0.0)) or 0.0),
            "direction": str(forecast.get("direction_cardinal", "N/D")),
            "frames": int(forecast.get("track_frames", 0) or 0),
            "growth": str(forecast.get("growth_state", "in acquisizione")),
            "survival": float(forecast.get("survival_probability_percent", 50.0) or 50.0),
            "hail_probability": float(forecast.get("hail_probability_percent", forecast.get("hail_confidence_percent", 0.0)) or 0.0),
            "hail_quality": float(forecast.get("hail_data_quality_percent", 0.0) or 0.0),
            "hail_frames": int(forecast.get("hail_persistence_frames", 0) or 0),
            "cappi": (
                forecast.get("cappi_vertical")
                if isinstance(forecast.get("cappi_vertical"), dict)
                else {}
            ),
            "ai_status": str((forecast.get("adaptive_ai") or {}).get("status", "collection")),
            "model": str(forecast.get("model", "stable-impact-ensemble-2.4.0")),
        })
    best_rows.sort(key=lambda row: (row["probability"], row["confidence"]), reverse=True)
    brier = calibration.get("brier_score")
    adaptive_state = precision_state.get("adaptive_ai", {}) if isinstance(precision_state.get("adaptive_ai"), dict) else {}
    verification_v2 = precision_state.get("verification_v2", {}) if isinstance(precision_state.get("verification_v2"), dict) else {}
    adaptive_model = adaptive_state.get("model", {}) if isinstance(adaptive_state.get("model"), dict) else {}
    adaptive_metrics = adaptive_state.get("metrics", {}) if isinstance(adaptive_state.get("metrics"), dict) else {}
    adaptive_requirements = adaptive_state.get("requirements", {}) if isinstance(adaptive_state.get("requirements"), dict) else {}
    adaptive_cfg = cfg.get("adaptive_ai", {}) if isinstance(cfg.get("adaptive_ai"), dict) else {}
    ai_updates = int(adaptive_model.get("updates", 0) or 0)
    ai_storms = int(adaptive_state.get("unique_storms", len(adaptive_state.get("storms", []) or [])) or 0)
    ai_positive = int(adaptive_state.get("positive_events", adaptive_metrics.get("positive_events", 0)) or 0)
    ai_negative = int(adaptive_state.get("negative_events", adaptive_metrics.get("negative_events", 0)) or 0)
    ai_min_events = max(1, int(adaptive_requirements.get("min_events", adaptive_cfg.get("activation_min_events", 80)) or 80))
    ai_min_storms = max(1, int(adaptive_requirements.get("min_unique_storms", adaptive_cfg.get("activation_min_unique_storms", 12)) or 12))
    ai_min_positive = max(1, int(adaptive_requirements.get("min_positive", adaptive_cfg.get("activation_min_positive", 20)) or 20))
    ai_min_negative = max(1, int(adaptive_requirements.get("min_negative", adaptive_cfg.get("activation_min_negative", 20)) or 20))
    ai_min_improvement = float(adaptive_requirements.get("min_brier_improvement_percent", adaptive_cfg.get("activation_min_brier_improvement_percent", 10)) or 10)
    ai_improvement = adaptive_metrics.get("improvement_percent")
    ai_status = str(adaptive_state.get("status", "collection"))
    ai_numeric_gates = [
        ("Verifiche", ai_updates, ai_min_events),
        ("Temporali distinti", ai_storms, ai_min_storms),
        ("Eventi positivi", ai_positive, ai_min_positive),
        ("Eventi negativi", ai_negative, ai_min_negative),
    ]
    ai_gate_progress = [min(1.0, current / required) for _label, current, required in ai_numeric_gates]
    ai_readiness = round(min(ai_gate_progress) * 100) if ai_gate_progress else 0
    if ai_status == "active_guarded":
        ai_readiness = 100
    elif ai_improvement is None or float(ai_improvement) < ai_min_improvement:
        ai_readiness = min(ai_readiness, 90)
    ai_status_labels = {
        "collection": "Raccolta dati", "shadow": "Validazione ombra", "eligible": "Idonea",
        "active_guarded": "Attiva protetta", "suspended": "Sospesa", "disabled": "Disattivata",
    }
    ai_dashboard = {
        "status": ai_status,
        "status_label": ai_status_labels.get(ai_status, ai_status.replace("_", " ").title()),
        "readiness_percent": max(0, min(100, ai_readiness)),
        "influence_percent": round(float(adaptive_state.get("influence", 0.0) or 0.0) * 100),
        "gates": [
            {"label": label, "current": current, "required": required, "ready": current >= required}
            for label, current, required in ai_numeric_gates
        ],
        "improvement": None if ai_improvement is None else float(ai_improvement),
        "min_improvement": ai_min_improvement,
        "brier_ready": ai_improvement is not None and float(ai_improvement) >= ai_min_improvement,
        "evaluated": int(adaptive_metrics.get("evaluated", 0) or 0),
    }
    precision_status = {
        "enabled": bool(cfg.get("precision_engine", {}).get("enabled", True)),
        "model": str(precision_state.get("model", "stable-impact-ensemble-2.4.0")),
        "active_tracks": int(precision_state.get("active_tracks", 0) or 0),
        "retained_tracks": int(precision_state.get("retained_tracks", 0) or 0),
        "optical_flow_cells": int(precision_state.get("optical_flow_cells", 0) or 0),
        "forecast_count": int(precision_state.get("forecast_count", 0) or 0),
        "resolved": int(calibration.get("resolved", 0) or 0),
        "brier_score": None if brier is None else float(brier),
        "learning": int(calibration.get("resolved", 0) or 0) < int(cfg.get("precision_engine", {}).get("calibration_min_samples", 30) or 30),
        "best": best_rows[:4],
        "product_quality": precision_state.get("product_quality", {}),
        "cappi_profile": precision_state.get("cappi_profile", {}),
        "atmospheric": precision_state.get("atmospheric_context", {}),
        "adaptive_ai": adaptive_state,
        "ai_dashboard": ai_dashboard,
        "initiation_watch": precision_state.get("initiation_watch", {}),
        "verification_v2": verification_v2,
        "terrain_profiles": precision_state.get("terrain_profiles", {}),
        "local_sensors": precision_state.get("local_sensors", {}),
        "compatibility_mode": str(precision_state.get("compatibility_mode", "native")),
        "temporal_bundle": precision_state.get("temporal_bundle", {}),
        "radar_sites": precision_state.get("radar_sites", {}),
    }
    now_dt = datetime.now()
    public_image_cfg = cfg.get("public_image", {})
    status = {
        "timer_active": timer_active,
        "timer_enabled": timer_enabled,
        "image_mtime": img_mtime,
        "image_size": img_size,
        "image_age_minutes": get_image_age_minutes(PUBLIC_IMAGE),
        "targets": cfg.get("targets", []),
        "tracking": cfg.get("tracking", {}),
        "public_image": public_image_cfg,
        "public_url": public_image_cfg.get("public_url", "/meteo.jpg"),
        "telegram": cfg.get("telegram", {}),
        "recent_events": events,
        "risk": infer_risk(events),
        "last_alert": infer_last_alert(lines),
        "server_time": now_dt.strftime("%H:%M:%S"),
        "server_date": now_dt.strftime("%d %B %Y"),
        "next_check_text": next_check_label(cfg),
        "alerts_enabled": "Sì" if cfg.get("telegram", {}).get("send_photo", True) else "Solo testo",
        "now": int(time.time()),
        "app_prefix": APP_PREFIX,
        "public_base_url": PUBLIC_BASE_URL,
        "precision": precision_status,
        "lightning_live": lightning_state,
        "event_feedback": engine_state.get("event_feedback", {}),
    }
    status["health"] = compute_health(status)
    return status


@app.route("/login", methods=["GET", "POST"])
def login():
    # Il browser può ripristinare direttamente la vecchia scheda /login.
    # security_gate ha già ricreato la sessione dal cookie persistente: in tal
    # caso il modulo non deve essere mostrato di nuovo.
    if request.method == "GET" and session.get("logged_in"):
        return redirect(url_for("dashboard"))
    entered_username = ""
    remember_checked = False
    if request.method == "POST":
        username = safe_text(request.form.get("username", ""), 64)
        password = str(request.form.get("password", ""))[:1024]
        entered_username = username
        remember_checked = request.form.get("remember_me") == "1"
        rate_key = login_rate_key(username)
        if login_is_limited(rate_key):
            flash("Troppi tentativi non validi. Riprova più tardi.", "error")
            return render_template(
                "login.html", app_name=APP_NAME, app_version=APP_VERSION,
                entered_username=entered_username, remember_checked=remember_checked,
            ), 429
        expected_user = WEB_ENV.get("LDZ_METEO_WEB_USERNAME", "admin")
        password_hash = WEB_ENV.get("LDZ_METEO_WEB_PASSWORD_HASH", "")
        user_ok = hmac.compare_digest(username.encode("utf-8"), expected_user.encode("utf-8"))
        password_ok = bool(password_hash and check_password_hash(password_hash, password))
        if user_ok and password_ok:
            clear_login_failures(rate_key)
            session.clear()
            session.permanent = remember_checked
            session["logged_in"] = True
            session["username"] = username
            session["remember_me"] = remember_checked
            session["auth_started_at"] = int(time.time())
            session["last_seen_at"] = int(time.time())
            next_url = request.args.get("next") or ""
            destination = url_for("dashboard") if not is_safe_next_url(next_url) or next_url in ("", "/") else next_url
            response = redirect(destination)
            if remember_checked:
                set_remember_cookie(response, make_remember_token(username))
            else:
                clear_remember_cookie(response)
            return response
        record_login_failure(rate_key)
        flash("Login non valido", "error")
    return render_template(
        "login.html", app_name=APP_NAME, app_version=APP_VERSION,
        entered_username=entered_username, remember_checked=remember_checked,
    )


@app.route("/logout", methods=["POST"])
@require_login
def logout():
    session.clear()
    response = redirect(url_for("login"))
    clear_remember_cookie(response)
    return response


@app.route("/")
@require_login
def dashboard():
    return render_template("dashboard.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status())


@app.route("/radar-image")
@require_login
def radar_image():
    view = request.args.get("view", "full")
    if view not in {"full", "map", "details"}:
        abort(Response("Vista radar non valida.", 400))
    image_path = get_best_radar_image(view)
    if image_path is not None:
        return no_cache(send_file(image_path, mimetype="image/jpeg", max_age=0))
    return placeholder_svg_response()




def validate_hhmm(value: str | None, default: str = "00:00") -> str:
    value = (value or "").strip()
    if re.match(r"^(?:[01]\d|2[0-3]):[0-5]\d$", value):
        return value
    return default

@app.route("/settings", methods=["GET", "POST"])
@require_login
def settings():
    cfg = load_config()
    if request.method == "POST":
        tracking = cfg.setdefault("tracking", {})
        thresholds = cfg.setdefault("thresholds", {})
        quiet_hours = cfg.setdefault("quiet_hours", {})
        precision = cfg.setdefault("precision_engine", {})
        vertical_profile = cfg.setdefault("vertical_profile", {})
        terrain = cfg.setdefault("terrain_engine", {})
        lifecycle = cfg.setdefault("lifecycle_engine", {})
        adaptive = cfg.setdefault("adaptive_ai", {})
        near_target = cfg.setdefault("near_target_override", {})
        event_feedback = cfg.setdefault("event_feedback", {})
        event_replay = cfg.setdefault("event_replay", {})
        hail_feedback = cfg.setdefault("hail_feedback_calibration", {})

        tracking["prealert_minutes"] = safe_int(request.form.get("prealert_minutes"), 20, 1, 120)
        tracking["check_interval_minutes"] = safe_int(request.form.get("check_interval_minutes"), 5, 1, 60)
        tracking["cooldown_minutes"] = safe_int(request.form.get("cooldown_minutes"), 35, 1, 1440)
        tracking["alert_cooldown_minutes"] = tracking["cooldown_minutes"]
        tracking["strong_alert_vmi_dbz"] = safe_float(request.form.get("strong_alert_vmi_dbz"), 45.0, 5.0, 80.0)
        tracking["min_alert_probability_percent"] = safe_float(request.form.get("min_alert_probability_percent"), 60.0, 20.0, 99.0)
        tracking["require_consecutive_hits"] = safe_int(request.form.get("require_consecutive_hits"), 2, 1, 5)
        tracking["update_cooldown_minutes"] = safe_int(request.form.get("update_cooldown_minutes"), 12, 5, 120)

        thresholds["vmi_strong_dbz"] = tracking["strong_alert_vmi_dbz"]
        thresholds["vmi_hail_dbz"] = safe_float(request.form.get("vmi_hail_dbz"), 55.0, 5.0, 90.0)

        precision["enabled"] = bool(request.form.get("precision_enabled"))
        precision["verification_enabled"] = bool(request.form.get("verification_enabled"))
        precision["history_frames"] = safe_int(request.form.get("history_frames"), 6, 3, 12)
        precision["ensemble_members"] = safe_int(request.form.get("ensemble_members"), 72, 16, 256)
        precision["optical_flow_weight"] = safe_float(request.form.get("optical_flow_weight"), 0.30, 0.0, 0.45)
        precision["max_product_skew_minutes"] = safe_int(request.form.get("max_product_skew_minutes"), 12, 5, 30)
        vertical_profile["enabled"] = bool(request.form.get("vertical_profile_enabled"))
        terrain["enabled"] = bool(request.form.get("terrain_enabled"))
        terrain["max_survival_adjustment"] = safe_float(request.form.get("terrain_max_adjustment"), 0.12, 0.0, 0.15)
        lifecycle["enabled"] = bool(request.form.get("lifecycle_enabled"))
        lifecycle["survival_weight"] = safe_float(request.form.get("survival_weight"), 0.34, 0.10, 0.50)
        adaptive["enabled"] = bool(request.form.get("adaptive_ai_enabled"))
        adaptive["auto_activate"] = bool(request.form.get("adaptive_ai_auto_activate"))
        adaptive["activation_min_events"] = safe_int(request.form.get("adaptive_ai_min_events"), 80, 30, 1000)
        adaptive["activation_min_brier_improvement_percent"] = safe_float(request.form.get("adaptive_ai_min_improvement"), 10.0, 1.0, 50.0)
        adaptive["guarded_influence"] = safe_float(request.form.get("adaptive_ai_guarded_influence"), 0.20, 0.0, 0.30)
        near_target["enabled"] = bool(request.form.get("near_target_enabled"))
        near_target["edge_margin_km"] = safe_float(request.form.get("near_target_edge_margin_km"), 3.0, 0.5, 10.0)
        near_target["lightning_radius_km"] = safe_float(request.form.get("near_target_lightning_radius_km"), 3.0, 0.5, 10.0)
        event_feedback["enabled"] = bool(request.form.get("event_feedback_enabled"))
        event_feedback["prompt_delay_minutes"] = safe_int(request.form.get("feedback_prompt_delay_minutes"), 25, 5, 180)
        event_replay["enabled"] = bool(request.form.get("event_replay_enabled"))
        event_replay["retention_days"] = safe_int(request.form.get("event_replay_retention_days"), 60, 7, 180)
        hail_feedback["enabled"] = bool(request.form.get("hail_feedback_enabled"))
        hail_feedback["auto_activate"] = bool(request.form.get("hail_feedback_auto_activate"))
        hail_feedback["minimum_events"] = safe_int(request.form.get("hail_feedback_minimum_events"), 40, 30, 1000)
        hail_feedback["minimum_brier_improvement_percent"] = safe_float(request.form.get("hail_feedback_minimum_improvement"), 10.0, 1.0, 50.0)
        hail_feedback["guarded_influence"] = safe_float(request.form.get("hail_feedback_guarded_influence"), 0.18, 0.0, 0.25)

        quiet_hours["enabled"] = bool(request.form.get("quiet_hours_enabled"))
        quiet_hours["start"] = validate_hhmm(request.form.get("quiet_start"), "00:00")
        quiet_hours["end"] = validate_hhmm(request.form.get("quiet_end"), "07:00")
        quiet_hours["mode"] = request.form.get("quiet_mode") if request.form.get("quiet_mode") in ("critical_only", "mute_all") else "critical_only"

        backup = save_config(cfg)
        flash(f"Regole alert salvate. Backup: {backup}", "success")
        return redirect(url_for("settings"))
    return render_template("settings.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), cfg=cfg)



def geocode_search(query: str, limit: int = 5) -> list[dict[str, Any]]:
    query = (query or "").strip()
    if len(query) < 2:
        return []

    GEOCODE_CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
    cache: dict[str, Any] = {}
    try:
        if GEOCODE_CACHE_FILE.exists():
            cache = json.loads(GEOCODE_CACHE_FILE.read_text())
    except Exception:
        cache = {}

    key = query.lower()
    now = time.time()
    cached = cache.get("items", {}).get(key)
    if cached and now - float(cached.get("ts", 0)) < 86400:
        return cached.get("results", [])

    # Nominatim policy: massimo 1 richiesta/sec e User-Agent identificativo.
    last_ts = float(cache.get("last_request_ts", 0) or 0)
    wait = 1.1 - (now - last_ts)
    if wait > 0:
        time.sleep(wait)

    params = {
        "format": "jsonv2",
        "q": query,
        "limit": str(max(1, min(10, limit))),
        "addressdetails": "1",
        "accept-language": "it",
        "countrycodes": "it",
    }
    if GEOCODE_EMAIL:
        params["email"] = GEOCODE_EMAIL

    url = "https://nominatim.openstreetmap.org/search?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": GEOCODE_USER_AGENT,
            "Referer": PUBLIC_BASE_URL,
        },
    )

    with urllib.request.urlopen(req, timeout=20) as resp:
        raw = json.loads(resp.read().decode("utf-8", errors="replace"))

    results = []
    for item in raw[:limit]:
        try:
            lat = float(item["lat"])
            lon = float(item["lon"])
        except Exception:
            continue
        address = item.get("address") or {}
        name = (
            address.get("city")
            or address.get("town")
            or address.get("village")
            or address.get("municipality")
            or item.get("name")
            or query
        )
        display = item.get("display_name") or name
        results.append({
            "name": str(name),
            "display_name": str(display),
            "lat": lat,
            "lon": lon,
            "type": str(item.get("type", "")),
            "class": str(item.get("class", "")),
        })

    cache.setdefault("items", {})[key] = {"ts": now, "results": results}
    cache["last_request_ts"] = time.time()
    GEOCODE_CACHE_FILE.write_text(json.dumps(cache, indent=2, ensure_ascii=False))
    return results


@app.route("/targets/geocode")
@require_login
def targets_geocode():
    q = request.args.get("q", "")
    try:
        return jsonify({"ok": True, "results": geocode_search(q, limit=6)})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc), "results": []}), 500


@app.route("/targets/add-geocoded", methods=["POST"])
@require_login
def targets_add_geocoded():
    cfg = load_config()
    targets = cfg.get("targets")
    if not isinstance(targets, list):
        targets = []
        cfg["targets"] = targets
    name = safe_text(request.form.get("name", ""), 100)
    lat = safe_float(request.form.get("lat"), 0.0, -90, 90)
    lon = safe_float(request.form.get("lon"), 0.0, -180, 180)
    radius = safe_float(request.form.get("radius_km"), 7.0, 1, 100)

    if not name:
        flash("Nome località mancante.", "error")
        return redirect(url_for("targets"))

    targets.append({
        "name": name,
        "lat": lat,
        "lon": lon,
        "radius_km": radius,
        "enabled": True,
    })
    backup = save_config(cfg)
    flash(f"Target '{name}' aggiunto automaticamente. Backup: {backup}", "success")
    return redirect(url_for("targets"))


@app.route("/targets", methods=["GET", "POST"])
@require_login
def targets():
    cfg = load_config()
    targets = cfg.get("targets")
    if not isinstance(targets, list):
        targets = []
        cfg["targets"] = targets
    if request.method == "POST":
        for idx, target in enumerate(targets):
            prefix = f"target_{idx}_"
            target["name"] = safe_text(request.form.get(prefix + "name", target.get("name", "")), 100) or "Target"
            target["lat"] = safe_float(request.form.get(prefix + "lat"), float(target.get("lat", 0)), -90, 90)
            target["lon"] = safe_float(request.form.get(prefix + "lon"), float(target.get("lon", 0)), -180, 180)
            target["radius_km"] = safe_float(request.form.get(prefix + "radius_km"), float(target.get("radius_km", 7)), 1, 100)
            target["enabled"] = bool(request.form.get(prefix + "enabled", "on"))
        if request.form.get("add_target"):
            targets.append({"name": "Nuovo target", "lat": 42.46, "lon": 14.21, "radius_km": 7, "enabled": True})
        if request.form.get("delete_index") is not None:
            try:
                del targets[int(request.form["delete_index"])]
            except Exception:
                pass
        backup = save_config(cfg)
        flash(f"Target salvati. Backup: {backup}", "success")
        return redirect(url_for("targets"))
    return render_template("targets.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), targets=targets)


@app.route("/telegram")
@require_login
def telegram_page():
    secrets = load_secrets()
    getme = telegram_get_me()
    return render_template(
        "telegram.html",
        app_name=APP_NAME,
        app_version=APP_VERSION,
        status=get_dashboard_status(),
        secrets={
            "chat_id": secrets.get("TELEGRAM_CHAT_ID", "Non configurato"),
            "token_masked": masked_secret(secrets.get("TELEGRAM_BOT_TOKEN", "")),
        },
        getme=getme,
    )


@app.route("/lightning", methods=["GET", "POST"])
@require_login
def lightning_page():
    cfg = load_config()
    lightning = cfg.setdefault("lightning", {})
    if request.method == "POST":
        lightning["enabled"] = bool(request.form.get("lightning_enabled"))
        lightning["source"] = request.form.get("lightning_source", lightning.get("source", "radar_dpc_lgt")).strip() or "radar_dpc_lgt"
        lightning["radius_km"] = safe_int(request.form.get("lightning_radius_km"), 20, 1, 100)
        lightning["window_minutes"] = safe_int(request.form.get("lightning_window_minutes"), 20, 10, 120)
        lightning["official_cadence_minutes"] = 10
        lightning["dpc_lgt_max_age_minutes"] = safe_int(request.form.get("dpc_lgt_max_age_minutes"), 15, 10, 30)
        lightning["dpc_lgt_max_lookback_minutes"] = safe_int(request.form.get("dpc_lgt_max_lookback_minutes"), 180, 15, 720)
        lightning["severity_boost"] = bool(request.form.get("lightning_severity_boost"))
        lightning["notify_on_lightning"] = bool(request.form.get("notify_on_lightning"))
        lightning["notify_lightning_clear"] = bool(request.form.get("notify_lightning_clear"))
        lightning["alert_min_strikes"] = safe_int(request.form.get("alert_min_strikes"), 2, 1, 50)
        lightning["alert_urgent_radius_km"] = safe_int(request.form.get("alert_urgent_radius_km"), 8, 1, 50)
        lightning["alert_cooldown_minutes"] = safe_int(request.form.get("alert_cooldown_minutes"), 20, 5, 180)
        lightning["alert_escalation_delta"] = safe_int(request.form.get("alert_escalation_delta"), 5, 2, 50)
        lightning["notify_on_lightning_plus_radar"] = bool(request.form.get("notify_on_lightning_plus_radar"))
        api_key = request.form.get("openweather_api_key", "").strip()
        if api_key and api_key != "********":
            lightning["openweather_api_key"] = api_key
        backup = save_config(cfg)
        flash(f"Impostazioni fulmini salvate. Backup: {backup}", "success")
        return redirect(url_for("lightning_page"))
    return render_template("lightning.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), lightning=lightning)


@app.route("/lightning/test", methods=["POST"])
@require_login
def lightning_test():
    cfg = load_config()
    source = cfg.get("lightning", {}).get("source", "open_meteo")
    if source == "openweather":
        out = openweather_lightning_check(cfg.get("targets", []), cfg)
    elif source in {"radar_dpc_lgt", "dpc_lgt", "radar_dpc"}:
        out = dpc_lgt_lightning_check(cfg.get("targets", []), cfg)
    elif source == "none":
        out = "Fonte fulmini impostata su Nessuna."
    else:
        out = open_meteo_lightning_check(cfg.get("targets", []), cfg)

    return render_template(
        "command_output.html",
        app_name=APP_NAME,
        app_version=APP_VERSION,
        status=get_dashboard_status(),
        title="Test modulo fulmini",
        output=out,
        code=0
    )

@app.route("/actions/dry-run", methods=["POST"])
@require_login
def dry_run():
    code, out = run_cmd([METEO_PYTHON, METEO_SCRIPT, "--config", str(CONFIG_PATH), "--dry-run"], timeout=180)
    flash("Dry-run completato." if code == 0 else f"Dry-run terminato con exit={code}", "success" if code == 0 else "error")
    return render_template("command_output.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), title="Dry-run", output=out, code=code)


@app.route("/actions/test-telegram", methods=["POST"])
@require_login
def test_telegram():
    ok, out = telegram_api("sendMessage", {
        "chat_id": load_secrets().get("TELEGRAM_CHAT_ID", ""),
        "parse_mode": "HTML",
        "text": "✅ <b>Test LDZ Meteo App OK</b>\nTelegram funziona correttamente.",
    })
    flash("Test Telegram inviato." if ok else f"Errore Telegram: {out}", "success" if ok else "error")
    return render_template("command_output.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), title="Test Telegram", output=out, code=0 if ok else 1)


@app.route("/actions/test-photo", methods=["POST"])
@require_login
def test_photo():
    image_path = get_best_radar_image()
    using_placeholder = image_path is not None and image_path != PUBLIC_IMAGE
    situation = (
        "Test con immagine placeholder allegata: il radar reale non ha ancora prodotto una mappa valida."
        if using_placeholder
        else "Simulazione di test con mappa allegata."
    )
    caption = (
        "⚠️ <b>SIMULAZIONE - LDZ Meteo Alert</b>\n\n"
        "<b>Temporale forte verso un target monitorato</b>\n\n"
        "<b>Situazione:</b>\n"
        f"{situation}\n\n"
        "Grandine: <b>non indicata dai radar</b>\n"
        "Arrivo stimato: <b>15-20 minuti</b>\n"
        "Intensità: <b>FORTE</b>\n\n"
        "👉 <b>Cosa fare:</b>\n"
        "Nessuna azione reale: è solo un test."
    )
    if image_path is not None:
        ok, out = telegram_api("sendPhoto", {
            "chat_id": load_secrets().get("TELEGRAM_CHAT_ID", ""),
            "parse_mode": "HTML",
            "caption": caption,
        }, files={"photo": image_path})
    else:
        ok, out = telegram_api("sendMessage", {
            "chat_id": load_secrets().get("TELEGRAM_CHAT_ID", ""),
            "parse_mode": "HTML",
            "text": caption + "\n\nNota: nessuna immagine valida disponibile sul server.",
        })
    flash("Simulazione foto inviata." if ok else f"Errore Telegram: {out}", "success" if ok else "error")
    return render_template("command_output.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), title="Simulazione Telegram con foto", output=out, code=0 if ok else 1)

@app.route("/logs")
@require_login
def logs():
    source = request.args.get("source", "file")
    if source == "journal":
        code, out = run_cmd(["journalctl", "-u", "meteo-alert.service", "-n", "250", "--no-pager"], timeout=15)
    else:
        code, out = 0, tail_file(METEO_LOG, 300)
    return render_template("logs.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), output=out, source=source, code=code)


@app.route("/system")
@require_login
def system_page():
    svc = {
        "meteo_service": systemctl_value(["status", "meteo-alert.service", "--no-pager"]),
        "meteo_timer": systemctl_value(["status", "meteo-alert.timer", "--no-pager"]),
        "radar_events": systemctl_value(["status", "meteo-alert-radar-events.service", "--no-pager"]),
        "telegram_feedback": systemctl_value(["status", "meteo-alert-telegram-feedback.service", "--no-pager"]),
        "watchdog_timer": systemctl_value(["status", "meteo-alert-watchdog.timer", "--no-pager"]),
        "update_timer": systemctl_value(["status", "ldz-meteo-update-check.timer", "--no-pager"]),
        "web_service": systemctl_value(["status", "ldz-meteo-web.service", "--no-pager"]),
        "timers": systemctl_value(["list-timers", "meteo-alert.timer", "meteo-alert-watchdog.timer", "ldz-meteo-update-check.timer", "--no-pager"]),
    }
    return render_template("system.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), svc=svc)


@app.route("/actions/sync-timer", methods=["POST"])
@require_login
@require_root_actions
def sync_timer():
    code, out = run_cmd(["/usr/bin/sudo", "-n", "/usr/local/sbin/ldz-meteo-sync-timer"], timeout=45)
    flash("Timer sincronizzato con il config." if code == 0 else f"Errore sincronizzazione timer exit={code}", "success" if code == 0 else "error")
    return render_template("command_output.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), title="Sincronizzazione timer", output=out, code=code)


@app.route("/backup")
@require_login
def backup_page():
    return render_template("backup.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), backups=list_config_backups())


@app.route("/backup/create", methods=["POST"])
@require_login
def backup_create():
    include_secrets = bool(request.form.get("include_secrets"))
    path = write_backup_zip(include_secrets=include_secrets)
    return send_file(path, as_attachment=True, download_name=path.name, mimetype="application/zip")


@app.route("/backup/restore", methods=["POST"])
@require_login
@require_root_actions
def backup_restore():
    f = request.files.get("backup_file")
    if not f or not f.filename:
        flash("Nessun file backup caricato.", "error")
        return redirect(url_for("backup_page"))
    try:
        uploaded = save_uploaded_restore(f)
        validate_archive(uploaded, "backup")
        write_pending_selection(PENDING_RESTORE_FILE, uploaded.name)
    except (ArchivePolicyError, OSError, ValueError) as exc:
        if "uploaded" in locals():
            uploaded.unlink(missing_ok=True)
        flash(f"Backup rifiutato: {exc}", "error")
        return redirect(url_for("backup_page"))
    code, out = run_cmd(["/usr/bin/sudo", "-n", "/usr/local/sbin/ldz-meteo-restore-backup"], timeout=180)
    flash("Restore completato." if code == 0 else f"Restore fallito exit={code}", "success" if code == 0 else "error")
    return render_template("command_output.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), title="Restore backup", output=out, code=code)



@app.route("/appearance", methods=["GET", "POST"])
@require_login
def appearance_page():
    cfg = load_config()
    webui = cfg.setdefault("webui", {})
    if request.method == "POST":
        selected = normalize_theme(request.form.get("theme"))
        webui["theme"] = selected
        session["theme"] = selected
        backup = save_config(cfg)
        flash(f"Tema '{THEMES[selected]['name']}' salvato. Backup: {backup}", "success")
        return redirect(url_for("appearance_page"))
    return render_template("appearance.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), cfg=cfg)

def read_alert_history(limit: int = 500) -> list[dict[str, Any]]:
    cfg = load_config()
    log_dir = Path(cfg.get("app", {}).get("log_dir", METEO_LOG.parent))
    path = log_dir / "alerts.log"
    items: list[dict[str, Any]] = []
    if not path.exists():
        return items
    for line in path.read_text(errors="replace").splitlines()[-limit:]:
        try:
            obj = json.loads(line)
        except Exception:
            continue
        target = obj.get("target", {}) if isinstance(obj, dict) else {}
        cell = obj.get("cell", {}) if isinstance(obj, dict) else {}
        eta = obj.get("eta", {}) if isinstance(obj, dict) else {}
        lightning = obj.get("lightning", {}) if isinstance(obj, dict) else {}
        event_type = str(obj.get("event_type", "alert")) if isinstance(obj, dict) else "alert"
        items.append({
            "time": str(obj.get("time_utc", "")),
            "event_type": event_type,
            "target": target.get("name", "N/D") if isinstance(target, dict) else "N/D",
            "vmi": cell.get("max_vmi", "") if isinstance(cell, dict) else "",
            "poh": cell.get("max_poh", "") if isinstance(cell, dict) else "",
            "risk": ("FULMINI" if event_type.startswith("lightning_") else cell.get("risk", "")) if isinstance(cell, dict) else ("FULMINI" if event_type.startswith("lightning_") else ""),
            "eta": eta.get("eta_minutes", "") if isinstance(eta, dict) else "",
            "lightning_count": lightning.get("count", "") if isinstance(lightning, dict) else "",
            "lightning_nearest": lightning.get("nearest_km") if isinstance(lightning, dict) else None,
            "message": obj.get("message", ""),
        })
    return list(reversed(items))


def alert_history_stats(items: list[dict[str, Any]]) -> dict[str, Any]:
    by_target: dict[str, int] = {}
    by_day: dict[str, int] = {}
    by_risk: dict[str, int] = {}
    vmi_points: list[dict[str, Any]] = []
    max_vmi = None
    for item in items:
        target = str(item.get("target") or "N/D")
        by_target[target] = by_target.get(target, 0) + 1
        risk = str(item.get("risk") or "N/D")
        by_risk[risk] = by_risk.get(risk, 0) + 1
        t = str(item.get("time") or "")
        day = t[:10] if len(t) >= 10 else "N/D"
        by_day[day] = by_day.get(day, 0) + 1
        try:
            v = float(item.get("vmi"))
            max_vmi = v if max_vmi is None else max(max_vmi, v)
            vmi_points.append({"time": t[:16], "vmi": v, "target": target})
        except Exception:
            pass
    top_targets = sorted(by_target.items(), key=lambda x: x[1], reverse=True)[:8]
    days = sorted(by_day.items())[-14:]
    risks = sorted(by_risk.items(), key=lambda x: x[0])
    return {
        "total": len(items),
        "max_vmi": max_vmi,
        "top_targets": top_targets,
        "days": days,
        "risks": risks,
        "vmi_points": list(reversed(vmi_points[-30:])),
        "max_day_count": max([v for _, v in days], default=1),
        "max_target_count": max([v for _, v in top_targets], default=1),
        "max_risk_count": max([v for _, v in risks], default=1),
    }


@app.route("/events-feedback")
@require_login
def events_feedback_page():
    cfg = load_config()
    state_path = Path(cfg.get("app", {}).get("state_file", "/var/lib/meteo-alert/state.json"))
    engine_state: dict[str, Any] = {}
    try:
        if state_path.is_file() and not state_path.is_symlink() and state_path.stat().st_size <= 16 * 1024 * 1024:
            value = json.loads(state_path.read_text(encoding="utf-8"))
            if isinstance(value, dict):
                engine_state = value
    except Exception:
        engine_state = {}
    feedback = engine_state.get("event_feedback") if isinstance(engine_state.get("event_feedback"), dict) else {}
    incidents = feedback.get("incidents") if isinstance(feedback.get("incidents"), dict) else {}
    rows: list[dict[str, Any]] = []
    for event in incidents.values():
        if not isinstance(event, dict):
            continue
        item = dict(event)
        timestamp_ms = int(item.get("started_ms", 0) or 0)
        item["started_label"] = datetime.fromtimestamp(timestamp_ms / 1000).strftime("%d/%m/%Y %H:%M") if timestamp_ms else "N/D"
        rows.append(item)
    rows.sort(key=lambda item: int(item.get("last_seen_ms", 0) or 0), reverse=True)
    data_dir = Path(cfg.get("app", {}).get("data_dir", "/var/lib/meteo-alert"))
    hcfg = cfg.get("hail_feedback_calibration", {})
    report_path = Path(hcfg.get("training_report_file", str(data_dir / "feedback" / "hail-training-report.json")))
    training: dict[str, Any] = {"ready": False, "reason": "insufficient_ground_truth", "events": 0}
    try:
        if report_path.is_file() and not report_path.is_symlink() and report_path.stat().st_size <= 1024 * 1024:
            value = json.loads(report_path.read_text(encoding="utf-8"))
            if isinstance(value, dict):
                training = value
    except Exception:
        pass
    return render_template(
        "events_feedback.html", app_name=APP_NAME, app_version=APP_VERSION,
        status=get_dashboard_status(), feedback=feedback, incidents=rows[:100],
        training=training, cfg=cfg,
    )


@app.route("/history")
@require_login
def history_page():
    items = read_alert_history(500)
    return render_template("history.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), items=items, stats=alert_history_stats(items))


@app.route("/templates", methods=["GET", "POST"])
@require_login
def templates_page():
    cfg = load_config()
    templates = cfg.setdefault("telegram_templates", {})
    if request.method == "POST":
        templates["enabled"] = bool(request.form.get("templates_enabled"))
        templates["alert"] = safe_text(request.form.get("alert_template", ""), 8000, multiline=True)
        backup = save_config(cfg)
        flash(f"Template Telegram salvato. Backup: {backup}", "success")
        return redirect(url_for("templates_page"))
    default_template = (
        "⚠️ <b>Meteo Alert - {target}</b>\\n\\n"
        "<b>{intensity_title}</b>\\n"
        "{hail}\\n\\n"
        "Arrivo stimato: <b>{eta}</b>\\n"
        "Intensità: <b>{intensity}</b>\\n"
        "VMI: <b>{vmi} dBZ</b> | POH: <b>{poh}</b>\\n\\n"
        "👉 <b>Cosa fare:</b>\\n"
        "{action}\\n\\n"
        "Fonte: {source}"
    )
    return render_template("templates_page.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), templates=templates, default_template=default_template)


@app.route("/channels", methods=["GET", "POST"])
@require_login
def channels_page():
    cfg = load_config()
    notifications = cfg.setdefault("notifications", {})
    if request.method == "POST":
        notifications["webhook_enabled"] = bool(request.form.get("webhook_enabled"))
        notifications["webhook_url"] = safe_text(request.form.get("webhook_url", ""), 2048)
        notifications["email_enabled"] = bool(request.form.get("email_enabled"))
        notifications["smtp_host"] = safe_text(request.form.get("smtp_host", ""), 253)
        notifications["smtp_port"] = safe_int(request.form.get("smtp_port"), 587, 1, 65535)
        notifications["smtp_starttls"] = bool(request.form.get("smtp_starttls"))
        notifications["smtp_user"] = safe_text(request.form.get("smtp_user", ""), 320)
        smtp_password = safe_text(request.form.get("smtp_password", ""), 1024)
        if smtp_password and smtp_password != "********":
            notifications["smtp_password"] = smtp_password
        notifications["email_from"] = safe_text(request.form.get("email_from", ""), 320)
        notifications["email_to"] = safe_text(request.form.get("email_to", ""), 2000)
        notifications["email_subject"] = safe_text(request.form.get("email_subject", "LDZ Meteo Alert"), 200) or "LDZ Meteo Alert"
        backup = save_config(cfg)
        flash(f"Canali notifica salvati. Backup: {backup}", "success")
        return redirect(url_for("channels_page"))
    return render_template("notifications.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), notifications=notifications)


@app.route("/maintenance", methods=["GET", "POST"])
@require_login
def maintenance_page():
    cfg = load_config()
    maintenance = cfg.setdefault("maintenance", {})
    if request.method == "POST":
        maintenance["enabled"] = bool(request.form.get("maintenance_enabled"))
        maintenance["message"] = (request.form.get("maintenance_message", "") or "").strip()[:4000]
        backup = save_config(cfg)
        state = "attivata" if maintenance["enabled"] else "disattivata"
        flash(f"Modalità manutenzione {state}. Backup: {backup}", "success")
        return redirect(url_for("maintenance_page"))
    return render_template("maintenance.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), maintenance=maintenance)


def apply_update_package(package: Path) -> tuple[int, str]:
    write_pending_selection(PENDING_UPDATE_FILE, package.name)
    return run_cmd(["/usr/bin/sudo", "-n", "/usr/local/sbin/ldz-meteo-apply-hotfix"], timeout=1200)


def render_update_result(title: str, code: int, output: str, verify_result: dict[str, Any] | None = None):
    ok = code == 0
    return render_template(
        "command_output.html",
        app_name=APP_NAME,
        app_version=APP_VERSION,
        status=get_dashboard_status(),
        title=title,
        output=output,
        code=code,
        verify_result=verify_result,
        refresh_seconds=9 if ok else 0,
        refresh_url=url_for("dashboard"),
        success_message="Aggiornamento applicato. La WebGUI si riavvia e questa pagina si aggiorna automaticamente." if ok else "Aggiornamento non applicato: controlla il log qui sotto.",
    )


def render_update_page(verify_result: dict[str, Any] | None = None):
    remote = update_state()
    remote_verify = verify_remote_download(remote) if remote.get("status") == "downloaded" else None
    return render_template(
        "update.html",
        app_name=APP_NAME,
        app_version=APP_VERSION,
        status=get_dashboard_status(),
        packages=list_update_packages(),
        verify_result=verify_result,
        remote=remote,
        remote_verify=remote_verify,
        update_cfg=update_settings(),
        update_network_name="LDZ Update Network",
        schedule_labels={value: label.capitalize() for label, value in UPDATE_SCHEDULES.items()},
    )


@app.route("/update", methods=["GET", "POST"])
@require_login
def update_page():
    verify_result = None
    if request.method == "POST":
        if not ROOT_ACTIONS_ENABLED:
            flash("Installazione manuale disabilitata dall'hardening delle azioni root.", "error")
            return redirect(url_for("update_page"))
        f = request.files.get("update_file")
        signature = request.files.get("update_signature")
        if not f or not f.filename or not signature or not signature.filename:
            flash("Seleziona sia il pacchetto ZIP sia la firma detached .sig.", "error")
            return redirect(url_for("update_page"))
        try:
            uploaded, uploaded_signature = save_uploaded_update(f, signature)
        except (OSError, ValueError) as exc:
            flash(f"Upload update rifiutato: {exc}", "error")
            return redirect(url_for("update_page"))
        verify_result = verify_update_zip(uploaded, uploaded_signature)
        if not verify_result.get("ok"):
            uploaded.unlink(missing_ok=True)
            uploaded_signature.unlink(missing_ok=True)
            flash("Pacchetto caricato ma non valido: " + "; ".join(verify_result.get("errors", [])), "error")
            return render_update_page(verify_result)
        if not verify_result.get("can_apply"):
            flash("Pacchetto verificato e messo in staging, ma non è auto-applicabile.", "error")
            return render_update_page(verify_result)

        code, out = apply_update_package(uploaded)
        flash("Pacchetto verificato e aggiornamento avviato." if code == 0 else f"Pacchetto verificato ma applicazione fallita exit={code}", "success" if code == 0 else "error")
        return render_update_result("Aggiornamento App", code, out, verify_result)

    return render_update_page(verify_result)


@app.route("/update/settings", methods=["POST"])
@require_login
def update_settings_save():
    try:
        save_update_settings_from_request()
        flash("Preferenze aggiornamenti salvate.", "success")
    except (OSError, ValueError) as exc:
        flash(f"Impostazioni aggiornamenti non salvate: {exc}", "error")
    return redirect(url_for("update_page"))


@app.route("/update/check", methods=["POST"])
@require_login
def update_check_now():
    code, output = run_update_checker("--check", "--force", timeout=60)
    state = update_state()
    if code == 0 and state.get("available"):
        flash(f"Nuovo aggiornamento {state.get('latest_version')} disponibile.", "success")
    elif code == 0:
        flash("Controllo completato: stai già usando l'ultima versione disponibile.", "success")
    else:
        flash("Controllo non riuscito: " + updater_failure_message(code, output, state), "error")
    return redirect(url_for("update_page"))


@app.route("/update/download", methods=["POST"])
@require_login
def update_download():
    code, output = run_update_checker("--download", timeout=180)
    state = update_state()
    checked = verify_remote_download(state) if code == 0 else {"ok": False}
    if code == 0 and checked.get("ok"):
        flash(f"Release {state.get('latest_version')} scaricata e verificata. Ora puoi decidere se installarla.", "success")
    else:
        details = "; ".join(checked.get("errors", [])) if checked.get("errors") else updater_failure_message(code, output, state)
        flash(f"Download o verifica falliti: {details}", "error")
    return redirect(url_for("update_page"))


@app.route("/update/install", methods=["POST"])
@require_login
@require_root_actions
def update_install_remote():
    state = update_state()
    checked = verify_remote_download(state)
    if not checked.get("ok"):
        flash("Installazione bloccata: " + "; ".join(checked.get("errors", [])), "error")
        return redirect(url_for("update_page"))
    package = checked["package"]
    write_pending_selection(PENDING_UPDATE_FILE, package.name)
    code, out = run_cmd(["/usr/bin/sudo", "-n", "/usr/local/sbin/ldz-meteo-approve-update"], timeout=1200)
    flash(
        "Aggiornamento approvato e applicato; la WebGUI si riavvierà." if code == 0 else f"Installazione fallita exit={code}",
        "success" if code == 0 else "error",
    )
    return render_update_result("Installazione aggiornamento remoto", code, out, checked)


@app.route("/update/remind-later", methods=["POST"])
@require_login
def update_remind_later():
    state = update_state()
    state["snoozed_until_epoch"] = int(time.time()) + 24 * 3600
    write_private_json(UPDATE_STATE_FILE, state)
    flash("Promemoria aggiornamento sospeso per 24 ore.", "success")
    destination = request.form.get("next") or url_for("dashboard")
    return redirect(destination if is_safe_next_url(destination) else url_for("dashboard"))


@app.route("/api/update-status")
@require_login
def update_status_api():
    banner = get_update_banner_state()
    return jsonify({
        "show": bool(banner.get("show")),
        "available": bool(banner.get("available")),
        "version": safe_text(banner.get("version", ""), 50),
        "downloaded": bool(banner.get("downloaded")),
        "page_url": url_for("update_page"),
    })


@app.route("/update/apply", methods=["POST"])
@require_login
@require_root_actions
def update_apply():
    name = Path(request.form.get("package", "")).name
    if not name:
        flash("Seleziona un pacchetto da applicare.", "error")
        return redirect(url_for("update_page"))
    package = UPDATE_UPLOAD_DIR / name
    verify_result = verify_update_zip(package, package.with_name(package.name + ".sig"))
    if not verify_result.get("ok"):
        flash("Pacchetto non applicato perché la verifica è fallita.", "error")
        return redirect(url_for("update_page"))
    if not verify_result.get("can_apply"):
        flash("Pacchetto non applicato perché la firma Ed25519 non è valida.", "error")
        return redirect(url_for("update_page"))
    code, out = apply_update_package(package)
    flash("Aggiornamento applicato. La WebGUI si riavvierà tra pochi secondi." if code == 0 else f"Applicazione aggiornamento fallita exit={code}", "success" if code == 0 else "error")
    return render_update_result("Applicazione aggiornamento", code, out, verify_result)


@app.route("/diagnostics")
@require_login
def diagnostics_page():
    checks = diagnostic_checks()
    return render_template("diagnostics.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), checks=checks)


@app.route("/actions/repair", methods=["POST"])
@require_login
@require_root_actions
def repair_installation():
    code, out = run_cmd(["/usr/bin/sudo", "-n", "/usr/local/sbin/ldz-meteo-repair", "--web-safe"], timeout=120)
    flash("Repair completato." if code == 0 else f"Repair terminato con exit={code}", "success" if code == 0 else "error")
    return render_template("command_output.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status(), title="Repair installazione", output=out, code=code)


@app.route("/kiosk")
@require_login
def kiosk_page():
    return render_template("kiosk.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status())

@app.route("/guide")
@require_login
def guide_page():
    return render_template("guide.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status())


@app.route("/changelog")
@require_login
def changelog_page():
    return render_template("changelog.html", app_name=APP_NAME, app_version=APP_VERSION, status=get_dashboard_status())


@app.template_filter("bool_text")
def bool_text(v):
    return "Sì" if bool(v) else "No"


if __name__ == "__main__":
    from waitress import serve
    serve(app, host=WEB_HOST, port=WEB_PORT)
