from __future__ import annotations

import hashlib
import importlib
import importlib.util
from importlib.machinery import SourceFileLoader
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load_checker():
    path = ROOT / "scripts/ldz-meteo-update-check"
    spec = importlib.util.spec_from_loader("ldz_meteo_update_check_242", SourceFileLoader("ldz_meteo_update_check_242", str(path)))
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


checker = load_checker()


def sample_feed(version: str = "2.4.2", *, prerelease: bool = False) -> dict:
    name = f"ldz-meteo-app-{version}-update.zip"
    return {
        "schema": 1,
        "product": "LDZ Meteo App",
        "channel": "beta" if prerelease else "stable",
        "version": version,
        "title": f"LDZ Meteo App {version}",
        "prerelease": prerelease,
        "published_at": "2026-08-03T09:00:00Z",
        "notes": "Interfaccia aggiornata.",
        "package": {"name": name, "size": 2048, "sha256": "a" * 64},
    }


class PublicUpdateNetworkTests(unittest.TestCase):
    def test_stable_and_beta_feeds_have_explicit_rules(self) -> None:
        stable = checker.release_summary(sample_feed(), "2.4.1", "stable")
        self.assertTrue(stable["available"])
        self.assertFalse(stable["prerelease"])

        beta_feed = sample_feed("2.5.0-beta.1", prerelease=True)
        beta = checker.release_summary(beta_feed, "2.4.2", "beta")
        self.assertTrue(beta["available"])
        with self.assertRaisesRegex(ValueError, "canale stabile"):
            checker.release_summary(beta_feed, "2.4.2", "stable")

    def test_returning_to_stable_never_downgrades(self) -> None:
        stable = checker.release_summary(sample_feed("2.4.2"), "2.5.0-beta.1", "stable")
        self.assertFalse(stable["available"])

    def test_feed_and_package_urls_are_fixed_to_ldz_network(self) -> None:
        self.assertTrue(checker.allowed_update_url("https://alexandersss.github.io/ldz-meteo-app-updates/updates/stable.json"))
        self.assertTrue(checker.allowed_update_url("https://alexandersss.github.io/ldz-meteo-app-updates/packages/ldz-meteo-app-2.4.2-update.zip"))
        self.assertFalse(checker.allowed_update_url("http://alexandersss.github.io/ldz-meteo-app-updates/updates/stable.json"))
        self.assertFalse(checker.allowed_update_url("https://alexandersss.github.io.evil.test/ldz-meteo-app-updates/updates/stable.json"))
        self.assertFalse(checker.allowed_update_url("file:///etc/passwd"))

    def test_no_client_github_credentials_or_private_api(self) -> None:
        source = (ROOT / "scripts/ldz-meteo-update-check").read_text(encoding="utf-8")
        page = (ROOT / "web/templates/update.html").read_text(encoding="utf-8")
        self.assertNotIn("api.github.com", source)
        self.assertNotIn('headers["Authorization"]', source)
        self.assertNotIn("read_token", source)
        self.assertNotIn("Token GitHub", page)
        self.assertNotIn("Rimuovi il token", page)
        self.assertIn("Nessun account o token è necessario", page)

    def test_feed_builder_binds_size_and_sha256(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            package = base / "ldz-meteo-app-2.4.2-update.zip"
            package.write_bytes(b"valid-package-placeholder" * 8)
            manifest = base / "manifest.json"
            manifest.write_text(json.dumps({"version": "2.4.2"}), encoding="utf-8")
            changelog = base / "CHANGELOG.md"
            changelog.write_text("# Changelog → 2.4.2\n\n## 2.4.2\n\n- Token rimossi.\n\n## 2.4.1\n\n- Vecchia.\n", encoding="utf-8")
            output = base / "stable.json"
            subprocess.run([
                sys.executable, str(ROOT / "scripts/build-update-feed"),
                "--package", str(package), "--manifest", str(manifest),
                "--changelog", str(changelog), "--channel", "stable",
                "--output", str(output),
            ], check=True, capture_output=True, text=True)
            feed = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(feed["package"]["size"], package.stat().st_size)
            self.assertEqual(feed["package"]["sha256"], hashlib.sha256(package.read_bytes()).hexdigest())
            self.assertIn("Token rimossi", feed["notes"])


class DashboardRiskRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        if importlib.util.find_spec("flask") is None:
            raise unittest.SkipTest("Flask non installato")
        from werkzeug.security import generate_password_hash

        cls.temp = tempfile.TemporaryDirectory()
        base = Path(cls.temp.name)
        (base / "config.yml").write_text("app: {}\ntargets: []\n", encoding="utf-8")
        (base / "secrets.env").write_text("", encoding="utf-8")
        (base / "web.env").write_text(
            "\n".join([
                'LDZ_METEO_WEB_USERNAME="admin"',
                f'LDZ_METEO_WEB_PASSWORD_HASH="{generate_password_hash("test")}"',
                f'LDZ_METEO_WEB_SECRET_KEY="{"a" * 64}"',
                f'LDZ_METEO_CONFIG="{base / "config.yml"}"',
                f'LDZ_METEO_SECRETS="{base / "secrets.env"}"',
                f'LDZ_METEO_UPDATE_STATE="{base / "update-state.json"}"',
                f'LDZ_METEO_UPDATE_SETTINGS="{base / "update-settings.json"}"',
                f'LDZ_METEO_UPDATE_UPLOAD_DIR="{base / "updates"}"',
            ]) + "\n",
            encoding="utf-8",
        )
        os.environ["LDZ_METEO_WEB_ENV"] = str(base / "web.env")
        sys.path.insert(0, str(ROOT / "web"))
        sys.modules.pop("app", None)
        cls.web = importlib.import_module("app")

    @classmethod
    def tearDownClass(cls) -> None:
        cls.temp.cleanup()

    def test_httperror_inside_warning_is_not_an_application_error(self) -> None:
        lines = [
            "2026-08-02 22:20:15,353 WARNING stato radar SITES non disponibile (HTTPError)",
            "2026-08-02 22:20:15,716 WARNING DPC-LTG stale: quadro pubblicato 20 min fa",
            "2026-08-02 22:20:16,790 INFO no alerts sent",
        ]
        events = self.web.parse_recent_events(lines)
        self.assertFalse(any(event["kind"] == "error" for event in events))
        risk = self.web.infer_risk(events)
        self.assertEqual(risk["label"], "Basso")
        self.assertEqual(risk["badge"], "ok")

    def test_real_error_level_still_sets_attention(self) -> None:
        events = self.web.parse_recent_events([
            "2026-08-02 22:20:15,353 ERROR impossibile pubblicare la mappa",
        ])
        self.assertEqual(events[0]["kind"], "error")
        self.assertEqual(self.web.infer_risk(events)["label"], "Attenzione")

    def test_checker_failure_uses_real_output_instead_of_generic_text(self) -> None:
        message = self.web.updater_failure_message(1, '{"error":"Feed LDZ non disponibile"}\n', {})
        self.assertEqual(message, "Feed LDZ non disponibile")
        app_source = (ROOT / "web/app.py").read_text(encoding="utf-8")
        self.assertNotIn("consulta lo stato updater", app_source)


class UpdaterIntegrationStaticTests(unittest.TestCase):
    def test_webgui_is_compact_tokenless_and_has_clear_controls(self) -> None:
        app = (ROOT / "web/app.py").read_text(encoding="utf-8")
        base = (ROOT / "web/templates/base.html").read_text(encoding="utf-8")
        page = (ROOT / "web/templates/update.html").read_text(encoding="utf-8")
        css = (ROOT / "web/static/app.css").read_text(encoding="utf-8")
        self.assertIn('APP_VERSION = "2.4.3"', app)
        self.assertIn("Nuovo aggiornamento disponibile!", base)
        self.assertIn("update-switch-v242", page)
        self.assertIn('type="radio" name="channel" value="stable"', page)
        self.assertIn("update-save-button-v242", page)
        self.assertIn("width: auto !important", css)
        self.assertNotIn("RELEASE CONTROL CENTER", page)

    def test_privileged_approval_has_no_user_arguments_or_urls(self) -> None:
        helper = (ROOT / "scripts/ldz-meteo-approve-update").read_text(encoding="utf-8")
        sudoers_sources = "\n".join((ROOT / path).read_text(encoding="utf-8") for path in ("install.sh", "scripts/ldz-meteo-apply-hotfix", "scripts/ldz-meteo-repair"))
        self.assertNotIn("$1", helper)
        self.assertNotIn("http://", helper)
        self.assertNotIn("https://", helper)
        self.assertIn("verify-update", helper)
        self.assertIn("exec /usr/local/sbin/ldz-meteo-apply-hotfix", helper)
        self.assertIn("/usr/local/sbin/ldz-meteo-approve-update", sudoers_sources)

    def test_timer_is_persistent_and_never_auto_installs(self) -> None:
        installer = (ROOT / "install.sh").read_text(encoding="utf-8")
        checker_source = (ROOT / "scripts/ldz-meteo-update-check").read_text(encoding="utf-8")
        self.assertIn("ldz-meteo-update-check.timer", installer)
        self.assertIn("Persistent=true", installer)
        self.assertNotIn("ldz-meteo-approve-update", checker_source)
        self.assertNotIn("ldz-meteo-apply-hotfix", checker_source)

    def test_pipeline_publishes_stable_and_beta_public_feeds(self) -> None:
        workflow = (ROOT / ".github/workflows/release.yml").read_text(encoding="utf-8")
        self.assertIn("Alexandersss/ldz-meteo-app-updates", workflow)
        self.assertIn("secrets.LDZ_UPDATES_TOKEN", workflow)
        self.assertIn("updates/stable.json", workflow)
        self.assertIn("updates/beta.json", workflow)
        self.assertIn("scripts/build-update-feed", workflow)
        self.assertIn("--prerelease", workflow)


if __name__ == "__main__":
    unittest.main(verbosity=2)
