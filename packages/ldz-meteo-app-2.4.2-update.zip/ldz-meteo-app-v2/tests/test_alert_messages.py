from __future__ import annotations

import importlib.util
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]


def stub_module(name: str, **attributes):
    module = types.ModuleType(name)
    for key, value in attributes.items():
        setattr(module, key, value)
    return module


class Dummy:
    pass


def load_message_module():
    matplotlib = stub_module("matplotlib", use=lambda *_: None)
    pyplot = stub_module("matplotlib.pyplot")
    colors = stub_module(
        "matplotlib.colors",
        LinearSegmentedColormap=Dummy,
        ListedColormap=Dummy,
        BoundaryNorm=Dummy,
    )
    matplotlib.pyplot = pyplot
    matplotlib.colors = colors
    scipy = stub_module("scipy")
    ndimage = stub_module("scipy.ndimage")
    spatial = stub_module("scipy.spatial", ConvexHull=Dummy)
    scipy.ndimage = ndimage
    scipy.spatial = spatial
    rasterio = stub_module("rasterio")
    rasterio_enums = stub_module("rasterio.enums", Resampling=Dummy)
    rasterio_transform = stub_module("rasterio.transform", from_bounds=lambda *args, **kwargs: None)
    rasterio_warp = stub_module("rasterio.warp", reproject=lambda *args, **kwargs: None)
    rasterio.enums = rasterio_enums
    rasterio.transform = rasterio_transform
    rasterio.warp = rasterio_warp
    no_op = lambda *args, **kwargs: {}
    stubs = {
        "matplotlib": matplotlib,
        "matplotlib.pyplot": pyplot,
        "matplotlib.colors": colors,
        "numpy": stub_module("numpy", ndarray=object),
        "requests": stub_module("requests", Session=Dummy, Response=Dummy, get=no_op, post=no_op),
        "yaml": stub_module("yaml", safe_load=lambda *_: {}, safe_dump=lambda *args, **kwargs: ""),
        "pyproj": stub_module("pyproj", Transformer=Dummy),
        "scipy": scipy,
        "scipy.ndimage": ndimage,
        "scipy.spatial": spatial,
        "rasterio": rasterio,
        "rasterio.enums": rasterio_enums,
        "rasterio.transform": rasterio_transform,
        "rasterio.warp": rasterio_warp,
        "precision_engine": stub_module(
            "precision_engine",
            COMPAT_MODULE_SOURCE="stub",
            best_forecasts_by_target=no_op,
            build_precision_forecasts=no_op,
            estimate_optical_flows=no_op,
            load_radar_cache=no_op,
            save_radar_cache=no_op,
            update_tracks=no_op,
            update_verification=no_op,
        ),
        "terrain_lifecycle": stub_module(
            "terrain_lifecycle",
            initiation_watch=no_op,
            terrain_summary=no_op,
            update_lightning_jump=no_op,
        ),
        "adaptive_ai": stub_module("adaptive_ai", load_batch_candidate=no_op),
        "verification_engine": stub_module("verification_engine", update_complete_verification=no_op),
        "event_feedback": stub_module(
            "event_feedback",
            build_feedback_prompt=lambda *args, **kwargs: ("", {}),
            handle_feedback_updates=lambda *args, **kwargs: [],
            mark_prompt_sent=lambda *args, **kwargs: None,
            pending_feedback_prompts=lambda *args, **kwargs: [],
            save_replay_snapshots=lambda *args, **kwargs: 0,
            update_incidents=lambda *args, **kwargs: {"totals": {}},
        ),
        "hail_feedback": stub_module(
            "hail_feedback",
            apply_candidate=lambda probability, features, cfg: {
                "probability_percent": probability, "status": "collection", "applied": False,
            },
            build_feature_vector=lambda values: [0.0] * 9,
        ),
    }
    module_name = "ldz_meteo_alert_message_test"
    with patch.dict(sys.modules, stubs):
        spec = importlib.util.spec_from_file_location(module_name, ROOT / "engine/meteo_alert.py")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        assert spec.loader is not None
        spec.loader.exec_module(module)
    return module


class HumanAlertMessageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.ma = load_message_module()

    def sample_cell(self):
        return self.ma.Cell(
            cell_id="cell-human", timestamp_ms=2_000_000_000_000,
            lat=42.47, lon=13.31, area_km2=80.0, radius_km=5.0, pixels=120,
            max_vmi=48.5, mean_vmi=42.0, max_sri=23.3, max_poh=0.0,
            max_vil=18.0, max_etm=10940.0, risk="HIGH", risk_reasons=[],
            nearest_target="Capitignano", nearest_distance_km=15.0,
            footprint_xy_km=[], pixel_bbox=[0, 0, 10, 10], centroid_row=5.0,
            centroid_col=5.0, shape_eccentricity=0.4, shape_orientation_deg=60.0,
            track_id="track-human", track_frames=6, lifecycle="stable",
        )

    def test_initial_alert_is_readable_balanced_and_caption_safe(self) -> None:
        eta = {
            "eta_minutes": 10.0, "eta_low_minutes": 9.0, "eta_high_minutes": 12.0,
            "impact_probability_percent": 85.0, "impact_confidence_percent": 78.0,
            "motion_confidence_percent": 97.0, "speed_kmh": 86.0,
            "direction_cardinal": "NE", "model": "precision-ensemble-2.3",
            "lightning_source": "radar_dpc_lgt", "lightning_count": 3,
            "lightning_radius_km": 20.0, "lightning_nearest_km": 8.4,
            "multisignal": {
                "trajectory_probability_percent": 85.0,
                "hail_confidence_percent": 11.0,
                "hail_factors": ["POH probabilità grandine 0%"],
            },
        }
        cfg = {"thresholds": {
            "poh_medium_percent": 40, "poh_high_percent": 60,
            "vil_hail_threshold": 35, "etm_hail_threshold_m": 9000,
        }}
        message = self.ma.build_alert_message(
            self.ma.Target("Capitignano", 42.52, 13.30, 3.0), self.sample_cell(), eta, cfg,
        )
        for expected in (
            "TEMPORALE CON PIOGGIA INTENSA IN ARRIVO", "Arrivo stimato",
            "Possibilità che raggiunga la zona", "Indicazioni pratiche",
            "Cosa sta rilevando il sistema", "Nucleo", "Grandine",
            "Movimento", "Stabilità",
        ):
            self.assertIn(expected, message)
        self.assertNotIn("Perché ricevi questo avviso", message)
        self.assertNotIn("Affidabilità della stima", message)
        self.assertNotIn("Ensemble traiettorie", message)
        self.assertNotIn("Precision Engine", message)
        self.assertNotIn("senza panico", message)
        self.assertLessEqual(len(message), 1000)
        self.assertEqual(message.count("<b>"), message.count("</b>"))
        self.assertEqual(message.count("<i>"), message.count("</i>"))

    def test_update_is_short_and_free_of_engine_jargon(self) -> None:
        eta = {
            "impact_probability_percent": 84.0, "impact_confidence_percent": 76.0,
            "eta_minutes": 7.0, "eta_low_minutes": 6.0, "eta_high_minutes": 9.0,
        }
        message = self.ma.build_threat_update_message(
            self.ma.Target("Pescara", 42.46, 14.21, 3.0),
            {"last_probability_percent": 64.0}, self.sample_cell(), eta, "escalation",
        )
        self.assertIn("RISCHIO AUMENTATO", message)
        self.assertIn("64% → 84%", message)
        self.assertNotIn("track", message.lower())
        self.assertNotIn("VMI", message)

    def test_public_radar_copy_explains_each_probability_band(self) -> None:
        cell = self.sample_cell()
        eta = {
            "eta_minutes": 20.0,
            "eta_low_minutes": 20.0,
            "eta_high_minutes": 20.0,
            "direction_cardinal": "E",
        }

        def copy_for(probability: float):
            best = {
                "target": "Pescara",
                "cell": cell,
                "eta": {**eta, "impact_probability_percent": probability},
                "direction": "E",
                "probability": probability,
            }
            return self.ma.build_public_radar_copy(best, [cell], 60.0, "Basso")

        very_low = copy_for(1.0)
        low = copy_for(22.0)
        watch = copy_for(46.0)
        alert = copy_for(72.0)
        self.assertIn("molto improbabile", very_low[0])
        self.assertIn("1%", very_low[2])
        self.assertIn("poco probabile", low[0])
        self.assertIn("avvicinamento possibile", watch[0])
        self.assertIn("temporale probabile", alert[0])
        self.assertIn("20 min", alert[2])
        self.assertNotIn("20–20", alert[2])
        for copy in (very_low, low, watch, alert):
            self.assertNotIn("traiettoria incerta", " ".join(copy).lower())

    def test_public_radar_copy_reports_observed_outside_and_clear_states(self) -> None:
        cell = self.sample_cell()
        observed = {
            "target": "Pescara",
            "cell": cell,
            "eta": {
                "eta_minutes": 0.0,
                "impact_probability_percent": 97.0,
                "observed_core_impact": True,
                "mode": "observed_core",
            },
            "direction": "E",
            "probability": 97.0,
        }
        observed_copy = self.ma.build_public_radar_copy(observed, [cell], 60.0, "Alto")
        outside_copy = self.ma.build_public_radar_copy(None, [cell], 60.0, "Basso")
        clear_copy = self.ma.build_public_radar_copy(None, [], 60.0, "Basso")
        self.assertIn("nucleo intenso rilevato", observed_copy[0])
        self.assertIn("Grandine probabile", observed_copy[2] + observed_copy[3])
        self.assertIn("fuori traiettoria", outside_copy[0])
        self.assertIn("Nessun temporale intenso", clear_copy[0])


if __name__ == "__main__":
    unittest.main(verbosity=2)
